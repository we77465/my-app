using System.Windows.Forms;
using CHBApp.BK.Models;
using CHBApp.BK.Services;

namespace CHBApp.BK.Forms;

/// <summary>FRMLOGIN - 對應原 CHBK.EXE 登入畫面</summary>
public partial class FrmLogin : Form
{
    public AppUser? LoggedUser { get; private set; }

    public FrmLogin()
    {
        InitializeComponent();
        txtUserId.Text = "1111";
        txtPassword.Text = "1111";
    }

    private void btnOk_Click(object sender, EventArgs e)
    {
        var u = BkacRepository.Users.FirstOrDefault(x =>
            x.UserId.Equals(txtUserId.Text.Trim(), StringComparison.OrdinalIgnoreCase) &&
            x.Password == txtPassword.Text);
        if (u == null)
        {
            MessageBox.Show("使用者代碼或密碼錯誤！", "錯誤",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtPassword.SelectAll();
            txtPassword.Focus();
            return;
        }
        LoggedUser = u;
        DialogResult = DialogResult.OK;
        Close();
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        Close();
    }
}
