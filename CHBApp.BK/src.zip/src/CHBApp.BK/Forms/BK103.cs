using System.Windows.Forms;
using CHBApp.BK.Common;
using CHBApp.BK.Models;
using CHBApp.BK.Services;

namespace CHBApp.BK.Forms;

/// <summary>
/// BK103 薪資輸入－個人 - 對應 SCT FORMS\BK103.SCX
/// 含首筆/上筆/下筆/末筆 導覽，輸入完一筆按下筆即可換下一個員工
/// </summary>
public partial class BK103 : CrudFormBase
{
    private int _idx = 0;

    public BK103()
    {
        InitializeComponent();
        BtnSave    = btnSave;    BtnCancel = btnCancel;
        BtnFirst   = btnFirst;   BtnPrev   = btnPrev;
        BtnNext    = btnNext;    BtnLast   = btnLast;
        BtnPreview = btnPreview; BtnPrint  = btnPrint;
        BtnExit    = btnExit;

        cbFlag.Items.AddRange(new object[] { "1 - 轉提", "2 - 轉存" });

        // 完整 18 項轉帳類別
        cbKind.DisplayMember = nameof(PayKind.KIND_NAME);
        cbKind.DataSource = new BindingSource(BkacRepository.PayKinds, null);

        if (BkacRepository.Employees.Count > 0) BindAt(0);
    }

    private void BindAt(int idx)
    {
        if (idx < 0 || idx >= BkacRepository.Employees.Count) return;
        _idx = idx;
        var e = BkacRepository.Employees[idx];

        txtEmpNo.Text   = e.EMP_NO;
        lblName.Text    = e.EMP_NAME;
        txtAccNo.Text   = e.EMP_ACCNO;
        numPay.Value    = (decimal)Math.Min((double)e.EMP_PAY, (double)numPay.Maximum);
        cbFlag.SelectedIndex = e.EMP_FLAG == "1" ? 0 : 1;

        // 對應 PayKind 物件
        var pk = BkacRepository.PayKinds.FirstOrDefault(k => k.KIND_CODE == e.EMP_KIND);
        cbKind.SelectedItem = pk ?? BkacRepository.PayKinds[1];   // 預設 51 薪資

        rbCheckYes.Checked  = e.EMP_FLAG1 == "Y";
        rbCheckNo.Checked   = e.EMP_FLAG1 != "Y";
        txtMail.Text        = e.MAILADD;
        txtContent.Text     = e.CONTENT;

        // 97 自訂時顯示輸入框
        UpdateCustomKindVisibility();
        txtCustomKind.Text  = e.EMP_KIND == "97" ? e.EMP_KNAME : "";

        // 狀態列
        lblPos.Text = $"第 {_idx + 1} / {BkacRepository.Employees.Count} 筆";
    }

    private void UpdateCustomKindVisibility()
    {
        bool is97 = (cbKind.SelectedItem as PayKind)?.KIND_CODE == "97";
        lblCustomKind.Visible = is97;
        txtCustomKind.Visible = is97;
    }

    private Bkac? Current =>
        (_idx >= 0 && _idx < BkacRepository.Employees.Count)
        ? BkacRepository.Employees[_idx] : null;

    // ─── 員工編號 KeyDown 跳到該員工 ──────
    private void txtEmpNo_KeyDown(object s, KeyEventArgs e)
    {
        if (e.KeyCode != Keys.Enter) return;
        var no = txtEmpNo.Text.Trim();
        var idx = BkacRepository.Employees.FindIndex(x => x.EMP_NO == no);
        if (idx < 0) MessageBox.Show("找不到該員工代號", "注意");
        else BindAt(idx);
    }

    // ─── 儲存 ──────
    private void btnSave_Click(object s, EventArgs e)
    {
        if (Current is not Bkac cur) return;
        cur.BASE_SAL = numPay.Value; cur.ALLOWANCE = 0; cur.OVERTIME = 0; cur.DEDUCTION = 0;
        cur.EMP_FLAG   = (cbFlag.SelectedItem?.ToString() ?? "2 - 轉存").Substring(0, 1);
        var pk = cbKind.SelectedItem as PayKind;
        cur.EMP_KIND   = pk?.KIND_CODE ?? "51";
        cur.EMP_KNAME  = pk?.KIND_CODE == "97"
            ? txtCustomKind.Text.Trim()
            : (pk?.KIND_NAME ?? "薪資");
        cur.EMP_FLAG1  = rbCheckYes.Checked ? "Y" : "N";
        cur.MAILADD    = txtMail.Text.Trim();
        cur.CONTENT    = txtContent.Text.Trim();
        MessageBox.Show($"已儲存 {cur.EMP_NAME} 之資料", "訊息");
    }

    private void btnCancel_Click(object s, EventArgs e)
    {
        // 還原到目前員工資料
        BindAt(_idx);
    }

    // ─── 導覽 ──────
    private void btnFirst_Click(object s, EventArgs e) => BindAt(0);
    private void btnPrev_Click(object s, EventArgs e)
    {
        if (_idx > 0) BindAt(_idx - 1);
        else MessageBox.Show("已是第一筆", "注意");
    }
    private void btnNext_Click(object s, EventArgs e)
    {
        if (_idx < BkacRepository.Employees.Count - 1) BindAt(_idx + 1);
        else MessageBox.Show("已是最後一筆", "注意");
    }
    private void btnLast_Click(object s, EventArgs e)
        => BindAt(BkacRepository.Employees.Count - 1);

    // ─── 列印 ──────
    private BkReportPrinter.ReportConfig MakeCfg()
    {
        var list = Current != null ? new List<Bkac> { Current } : new List<Bkac>();
        return new()
        {
            Type = BkReportPrinter.ReportType.PayrollList,
            Title = "本月薪資清冊 - 個人",
            Employees = list
        };
    }
    private void btnPreview_Click(object s, EventArgs e) => BkReportPrinter.ShowPreview(MakeCfg());
    private void btnPrint_Click(object s, EventArgs e)   => BkReportPrinter.Print(MakeCfg());
    private void btnExit_Click(object s, EventArgs e)    => Close();

    // ─── 轉帳類別變更 → 顯示/隱藏自訂名稱欄 ──────
    private void cbKind_SelectedIndexChanged(object s, EventArgs e) => UpdateCustomKindVisibility();
}
