namespace CHBApp.BK.Models;

/// <summary>使用者 (對應 USER.DBF)</summary>
public class AppUser
{
    public string UserId   { get; set; } = "";
    public string UserName { get; set; } = "";
    public string Password { get; set; } = "";
}
