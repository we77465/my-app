﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// R3801 的摘要描述
/// </summary>
public class R3801 : eai
{
    public string Q_ACFLG = "ACFLG"; //配合金資軋帳記號0
    public string Q_REMDAY = "REMDAY"; //YYYY-MM-DD
    public string Q_RCVBK = "RCVBK"; //009+單位代號
    public string Q_REMTYPE = "REMTYPE"; //固定04
    public string Q_MSG1 = "MSG1"; //訊息1,X(70)
    public string Q_MSG2 = "MSG2"; //訊息2,X(70)
    public string Q_MSG3 = "MSG3"; //訊息3,X(70)
    public string Q_RECVER = "RECVER"; //收訊人, X(42)
    public string Q_SENDER = "SENDER"; //發訊人, X(42)

    public R3801(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }
    public void GetRS()
    {
        SetRQ();
    }
  
}