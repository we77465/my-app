﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// P0001 的摘要描述
/// </summary>
public class P0001:eai
{
    public string Q_ACTNO = "ACTNO"; //帳號, X(16)

    public string S_AVBAL = "AVBAL"; //一位正負號+整數11位+2位小數(備償帳戶餘額)
    public P0001(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }
    public void GetRS()
    {
        SetRQ();

        if (isSuccess)
        {
            AVBAL = GetValue(docsvcRs, S_AVBAL);
        }
        else
        {
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }
    public string AVBAL { get; set; }
}