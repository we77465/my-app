﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// P0001 的摘要描述
/// </summary>
public class I0301: eai
{
    public string Q_RECKEY = "RECKEY"; //本行交易參考編號,X(12)
    public string Q_ACFLG = "0"; // <ACFLG>配合金資軋帳記號, 9(01)</ACFLG> 0 不配合金資軋帳記號。

    public string S_RECKEY = "RECKEY"; //本行交易參考編號,X(12)
    public string S_REMDAY = "REMDAY"; //匯款日             <REMDAY>2024-01-25</REMDAY>
    public string S_RREMDAY = "RREMDAY";//止付日             <RREMDAY>2024-02-06</RREMDAY>
    public string S_REMAMT = "REMAMT";//匯款金額         <REMAMT>+000096535157.45</REMAMT>
    public string S_NAME = "NAME";//匯款人名稱     <NAME>測試戶名二測試戶名二測試戶名二測 </NAME>
    public string S_CKNO = "CKNO"; //票號                 <CKNO>  00000001          </CKNO>
    public string S_CURCD = "CURCD"; //幣別,9(2)
    public string S_RECNAM1 = "RECNAM1"; //受款人名稱     <RECNAM1>AAAAAAAAAAAAAA                     </RECNAM1>
    public I0301(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }
    public void GetRS()
    {
        SetRQ();

        if (isSuccess)
        {
            RECKEY= GetValue(docsvcRs, S_RECKEY);
            REMDAY = GetValue(docsvcRs, S_REMDAY);
            RREMDAY = GetValue(docsvcRs, S_RREMDAY);
            REMAMT = GetValue(docsvcRs, S_REMAMT);
            NAME = GetValue(docsvcRs, S_NAME);
            CKNO = GetValue(docsvcRs, S_CKNO);
            CURCD = GetValue(docsvcRs, S_CURCD);
            RECNAM1 = GetValue(docsvcRs, S_RECNAM1);
        }
        else
        {
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }
    public string RECKEY { get; set; }
    public string REMDAY { get; set; }
    public string RREMDAY { get; set; }
    public string REMAMT { get; set; }
    public string NAME { get; set; }
    public string CKNO { get; set; }
    public string CURCD { get; set; }
    public string RECNAM1 { get; set; }
}