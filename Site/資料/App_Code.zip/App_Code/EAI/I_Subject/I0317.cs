﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// P0001 的摘要描述
/// </summary>
public class I0317: eai
{
    public string Q_RECKEY = "RECKEY"; //本行交易參考編號,X(12)

    public string S_Detail = "Detail";

    public string D_REMDAY = "REMDAY"; //發票日期(YYYY-MM-DD),9(08)
    public string D_RECKEY = "RECKEY"; //本行交易參考編號,X(12)
    public string D_CKNO = "CKNO"; //匯票號碼 ,X(20)
    public string D_CURCD = "CURCD"; //幣別,9(2)
    public I0317(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }
    public void GetRS()
    {
        SetRQ();

        if (isSuccess)
        {
            List<string> list = new List<string>();
            list.Add(D_REMDAY);
            list.Add(D_RECKEY);
            list.Add(D_CKNO);
            list.Add(D_CURCD);

            Detail = GetDetailValue(docsvcRs, list);

        }
        else
        {
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }
    public Dictionary<int, Dictionary<string, string>> Detail { get; set; }
}