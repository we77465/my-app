﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Xml;

/// <summary>
/// eai 的摘要描述
/// </summary>
public class eai
{
    public string S_RspCode = "RspCode";
    public string S_Desc = "Desc";
    public string S_RTNCD = "RTNCD";

    public eai(string sEmpID, string sTaskName)
    {
        dic_Rq = new Dictionary<string, string>();
    }

    public void SetPmtID(string sEmpID, string sTaskName)
    {
        DataTable dt = bos.GetDataTable(bos.cnnstr_iom, "exec dbo.EAI_PmtID_TaskName @EmpID='" + sEmpID + "',@TxnId='" + TxnId + "',@TaskName='" + sTaskName + "';");
        PmtID = dt.Rows[0][0].ToString();
    }

    public void SetRQWithOutRS()
    {
        string rq = GetRQ();

        byte[] byteArray = Encoding.Default.GetBytes(PmtID);

        MQDlvComNow.WriteMQMsg("EA.INTRA", rq, byteArray);
    }

    public void SetRQ()
    {
        string rq = GetRQ();

        byte[] byteArray = Encoding.Default.GetBytes(PmtID);

        string rs = MQDlvComNow.WriteMQMsg("EA.INTRA", rq, byteArray);

        //送出查詢電文
        isSuccess = rs == "OK";

        if (isSuccess)
        {
            XmlDocument doc = new XmlDocument();

            rs = MQDlvComNow.ReadMQMsg("EA.INTRA", rq, byteArray);
            string rts = rs.Replace("</OK/>", "");  // 取代有取到格式的標記
            //rts = HttpUtility.HtmlDecode(rts);

            try
            {
                //從指定的字串載入XML文件
                doc.LoadXml(rts);

                docsvcHeader = doc.DocumentElement["EAIBody"]["MsgRs"]["Header"];
                docsvcRs = doc.DocumentElement["EAIBody"]["MsgRs"]["SvcRs"];

                RspCode =  docsvcHeader[S_RspCode].InnerText;
                Desc =  docsvcHeader[S_Desc].InnerText;
            }
            catch (XmlException ex)
            {
                isSuccess = false;
                SendMail(TxnId, rq, rs, ex.Message);
            }
        }

        SqlCommand cmdrs = new SqlCommand("Update EAI_RQRS Set Rs=@Rs, RsTime=getDate() Where PmtID=@PmtID");

        cmdrs.Parameters.AddWithValue("Rs", rs);
        cmdrs.Parameters.AddWithValue("PmtID", PmtID);

        bos.transCommit(bos.cnnstr_iom, cmdrs);
    }

    private string GetRQ()
    {
        StringBuilder sb = new StringBuilder();

        sb.Append("<?xml version=\"1.0\" ?>");
        sb.Append("<!-- edited with XML Spy v4.1 U (http://www.xmlspy.com) by chb (chb) -->");
        sb.Append("<IFX xmlns=\"http://www.ifxforum.org\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:tw.org.ba=\"http://www.ba.org.tw\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance \" xsi:scheamLocation=\"http://www.ifxforum.org http://www.ba.org.tw/FXML/IFX130-TW12-URI.xsd \" xsi:schemaLocation=\"http://www.ifxforum.org http://www.ba.org.tw/FXML/IFX130-TW12-URI.xsd \" > ");
        sb.Append("	<EAIHeader>");
        sb.Append("		<TxnID>" + TxnId + "</TxnID>");
        sb.Append("		<RecID>sendToHost</RecID>");
        sb.Append("		<SrcSystemID>INTRA</SrcSystemID>");
        sb.Append("		<DomID>XML</DomID>");
        sb.Append("	</EAIHeader>");
        sb.Append("	<LogTxn>");
        sb.Append("		<TxnID>" + TxnId + "</TxnID>");
        sb.Append("		<PrcDt>" + DateTime.Now.ToString("yyyy-MM-dd") + "</PrcDt>");
        sb.Append("		<PmtID>" + PmtID + "</PmtID>");
        sb.Append("	</LogTxn>");
        sb.Append("	<EAIBody>");
        sb.Append("		<MsgRq>");
        sb.Append("			<Header>");
        sb.Append("				<TxnId>" + TxnId + "</TxnId>");
        sb.Append("			</Header>");
        sb.Append("			<SvcRq>");
        foreach (KeyValuePair<string, string> k in dic_Rq)
            sb.Append("				<" + k.Key + ">" + k.Value + "</" + k.Key + ">");
        sb.Append("			</SvcRq>");
        sb.Append("		</MsgRq>");
        sb.Append("	</EAIBody>");
        sb.Append("</IFX>");

        SqlCommand cmdrq = new SqlCommand("Update EAI_RQRS Set Rq=@Rq, RqTime=getDate() Where PmtID=@PmtID");

        cmdrq.Parameters.AddWithValue("Rq", sb.ToString());
        cmdrq.Parameters.AddWithValue("PmtID", PmtID);

        bos.transCommit(bos.cnnstr_iom, cmdrq);

        return sb.ToString();
    }

    public void SetFURQ()
    {
        StringBuilder sb = new StringBuilder();

        sb.Append("<?xml version=\"1.0\" ?>");
        sb.Append("<!-- edited with XML Spy v4.1 U (http://www.xmlspy.com) by chb (chb) -->");
        sb.Append("<IFX xmlns=\"http://www.ifxforum.org\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:tw.org.ba=\"http://www.ba.org.tw\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance \" xsi:scheamLocation=\"http://www.ifxforum.org http://www.ba.org.tw/FXML/IFX130-TW12-URI.xsd \" xsi:schemaLocation=\"http://www.ifxforum.org http://www.ba.org.tw/FXML/IFX130-TW12-URI.xsd \" > ");
        sb.Append("	<EAIHeader>");
        sb.Append("		<TxnID>" + TxnId + "</TxnID>");
        sb.Append("		<RecID>sendToHost</RecID>");
        sb.Append("		<SrcSystemID>INTRA</SrcSystemID>");
        sb.Append("		<DomID>XML</DomID>");
        sb.Append("	</EAIHeader>");
        sb.Append("	<LogTxn>");
        sb.Append("		<TxnID>" + TxnId + "</TxnID>");
        sb.Append("		<PrcDt>" + DateTime.Now.ToString("yyyy-MM-dd") + "</PrcDt>");
        sb.Append("		<PmtID>" + PmtID + "</PmtID>");
        sb.Append("	</LogTxn>");
        sb.Append("	<EAIBody>");
        sb.Append("		<MSG>");
        sb.Append("			<HEAD>");
        sb.Append("				<PGMID>PRC</PGMID>");
        sb.Append("				<TXNID>501</TXNID>");
        sb.Append("				<CHNCD>INTRA</CHNCD>");
        sb.Append("			</HEAD>");
        sb.Append("			<TITA>");
        foreach (KeyValuePair<string, string> k in dic_Rq)
            sb.Append("				<" + k.Key + ">" + k.Value.Trim() + "</" + k.Key + ">");
        sb.Append("			</TITA>");
        sb.Append("		</MSG>");
        sb.Append("	</EAIBody>");
        sb.Append("</IFX>");

        SqlCommand cmdrq = new SqlCommand("Update EAI_RQRS Set Rq=@Rq, RqTime=getDate() Where PmtID=@PmtID");

        cmdrq.Parameters.AddWithValue("Rq", sb.ToString());
        cmdrq.Parameters.AddWithValue("PmtID", PmtID);

        bos.transCommit(bos.cnnstr_iom, cmdrq);

        byte[] byteArray = Encoding.Default.GetBytes(PmtID);

        string rs = "EAI003";

        //送出查詢電文
        isSuccess = MQDlvComNow.WriteMQMsg("EA.INTRA", sb.ToString(), byteArray) == "OK";

        if (isSuccess)
        {
            XmlDocument doc = new XmlDocument();

            rs = MQDlvComNow.ReadMQMsg("EA.INTRA", sb.ToString(), byteArray);

            string rts = rs.Replace("</OK/>", "");  // 取代有取到格式的標記
            //rts = HttpUtility.HtmlDecode(rts);                                    

            try
            {
                //從指定的字串載入XML文件
                doc.LoadXml(rts);

                docsvcHeader = doc.DocumentElement["EAIBody"]["MSG"]["HEAD"];
                docsvcRs = doc.DocumentElement["EAIBody"]["MSG"]["TOTA"]["DATA"];

                isSuccess = docsvcRs.ChildNodes.Count > 1;
            }
            catch (XmlException ex)
            {
                isSuccess = false;
                SendMail(TxnId, sb.ToString(), rs, ex.Message);
            }
        }

        SqlCommand cmdrs = new SqlCommand("Update EAI_RQRS Set Rs=@Rs, RsTime=getDate() Where PmtID=@PmtID");

        cmdrs.Parameters.AddWithValue("Rs", rs);
        cmdrs.Parameters.AddWithValue("PmtID", PmtID);

        bos.transCommit(bos.cnnstr_iom, cmdrs);
    }

    private static void SendMail(string txnid, string rq, string rs, string exception)
    {
        //發mail
        MailUtility MailUtility = new MailUtility();
        MailUtility.SetSenderInfo("EAI Error", "intra@chb.com.tw");

        StringBuilder sb = new StringBuilder();

        sb.Append("Exception：" + rq);
        sb.Append("<br />");
        sb.Append("RQ：" + exception);
        sb.Append("<br />");
        sb.Append("RS：" + rs);

        MailUtility.SendMail("", "chb179848@chb.com.tw;chb182255@chb.com.tw", txnid + "【電文錯誤】", sb.ToString());
    }

    public static string GetValue(XmlElement rs, string tag)
    {
        if (rs[tag] == null)
            return "";

        return HttpUtility.HtmlDecode(rs[tag].InnerText.Trim());
    }

    public static Dictionary<int, Dictionary<string, string>> GetDetailValue(XmlElement rs, List<string> tags)
    {
        Dictionary<int, Dictionary<string, string>> detail = new Dictionary<int, Dictionary<string, string>>();

        XmlNodeList nodelist = rs.GetElementsByTagName("Detail");

        int iCount = 0;

        foreach (XmlNode node in nodelist)
        {
            Dictionary<string, string> values = new Dictionary<string, string>();

            for (int j = 0; j < tags.Count; j++)
            {
                string key = tags[j];
                string value = node[key].InnerText;

                values.Add(key, value);
            }

            detail.Add(iCount, values);
            iCount++;
        }

        return detail;
    }

    public bool isSuccess { get; set; }
    public string TxnId { get; set; }
    public string PmtID { get; set; }
    public string RspCode { get; set; }
    public string Desc { get; set; }
    public Dictionary<string, string> dic_Rq { get; set; }
    public XmlElement docsvcHeader { get; set; }
    public XmlElement docsvcRs { get; set; }
}