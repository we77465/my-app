﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// F0600 的摘要描述
/// </summary>
public class F0600 : eai
{
    public string Q_KINBR = "KINBR";
    public string Q_CIFKEY = "CIFKEY";

    // 本行自訂其他註記
    public string Q_FLAG = "FLAG";
    public string Q_DLEVEL = "DLEVEL";
    public F0600(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }

    public void GetRS()
    {
        SetRQ();

        if (RspCode == this.GetType().Name)
        {
            FLAG = GetValue(docsvcRs, Q_FLAG);
            DLEVEL = GetValue(docsvcRs, Q_DLEVEL);
        }
        else
        {
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }

    public string FLAG { get; set; }
    public string DLEVEL { get; set; }
}