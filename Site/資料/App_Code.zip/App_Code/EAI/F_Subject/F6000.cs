﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// F6000 的摘要描述
/// </summary>
public class F6000 : eai
{
    public string Q_KINBR = "KINBR";
    public string Q_ACFLG = "ACFLG";
    // 異動員編
    public string Q_EMPNOT = "EMPNOT";
    // 端末預設,2
    public string Q_FUNCD = "FUNCD";
    // 統編
    public string Q_CIFKEY = "CIFKEY";
    // 客戶盡職調查日期(不再使用)
    public string Q_DDDAY = "DDDAY";
    // 客戶交易模式有無變更
    public string Q_MCFG = "MCFG";
    // 客戶交易模式變更原因
    public string Q_MCRSN = "MCRSN";
    // 本行自訂其他註記
    public string Q_FLAG = "FLAG";
    // 客戶得否發行無記名股票(不再使用)
    public string Q_STOCK = "STOCK";
    // 盡職調查作業通知行
    public string Q_DDBRNO = "DDBRNO";
    // 首次通知日期
    public string Q_FSTDAY = "FSTDAY";
    // 再次通知日期
    public string Q_NXTDAY = "NXTDAY";
    // 排除盡職調查(限法遵處登打)
    public string Q_NORPT = "NORPT";
    // 指定高風險客戶(限法遵處登打) 
    public string Q_DLEVEL = "DLEVEL";
    // 股權結構複雜 0否,1是
    public string Q_SRSFG = "SRSFG";
    public string Q_SRSRSN = "SRSRSN";
    public string Q_TAXRSK = "TAXRSK";
    public F6000(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }
}