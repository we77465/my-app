﻿using System.Collections.Generic;
/// <summary>
/// F0106 的摘要描述：
/// 1. 新增 F0106 電文 查詢 需去識別化名單 add by sunny20241024
/// </summary>
public class F0106 : eai
{
     /* Req (這支沒用到，外面呼叫會用到) */
    // 統一編號
    public string Q_CIFKEY = "CIFKEY";
	// 查詢選項 0: 全部   1:解除   2:未解除  
	public string Q_INQCD = "INQCD"; /* 去識別化名單 INQCD固定放2 */

	/* Resp */
	// 中文名字
	public string S_CNAME = "CNAME";
    public string S_Detail = "Detail";

	/* Resp Detail */
	/* 狀態項目 */
	public string D_STATUS = "STATUS"; /* 狀態36 去識別化名單 */

	public F0106(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }

    public void GetRS()
    {
        SetRQ();

        if (isSuccess)
        {
			/* 實際抓取Resp */
            CNAME = GetValue(docsvcRs, S_CNAME);

			/* --START-- 實際抓取Resp Detail */
			List<string> list = new List<string>();

			list.Add(D_STATUS);

			Detail = GetDetailValue(docsvcRs, list);
			/* ---END--- 實際抓取Resp Detail */
		}
		else
        {
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }

	/* 實際抓取Resp */
    public string CNAME { get; set; }

	/* 實際抓取Resp Detail */
	public Dictionary<int, Dictionary<string, string>> Detail { get; set; }
}