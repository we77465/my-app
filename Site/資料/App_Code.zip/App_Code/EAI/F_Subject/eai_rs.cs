﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// F0600 的摘要描述
/// </summary>
public class eai_rs : eai
{
    public eai_rs(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        TxnId = sTaskName;
        SetPmtID(sEmpID, this.GetType().Name + sTaskName);
    }

    public void GetRS()
    {
        SetRQ();

        if (RspCode == this.GetType().Name)
        {
            //FLAG = GetValue(docsvcRs, Q_FLAG);
        }
        else
        {
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }

    public string GetValue(string sTaskName, string a_tag)
    {
        string value = string.Empty;
        if (RspCode == sTaskName)
        {
            value = GetValue(docsvcRs, a_tag);
        }
        return value;
    }
}