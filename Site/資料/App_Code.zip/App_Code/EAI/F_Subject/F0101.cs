﻿/// <summary>
/// F0101 的摘要描述
/// </summary>
public class F0101 : eai
{
    public string Q_KINBR = "KINBR";
    public string Q_INQCD = "INQCD";
    public string Q_CIFKEY = "CIFKEY";

    // 統編
    public string S_CIFKEY = "CIFKEY";
    // 中文名字
    public string S_CNAME = "CNAME";
    // 生日
    public string S_BIRTHDAY = "BIRTHDAY";
    // 行動電話
    public string S_MPHONE = "MPHONE";
    // EMAIL
    public string S_EMAIL = "EMAIL";
    // 死亡記號
    public string S_DEADFG = "DEADFG";
    // 顧客資料卡序號
    public string S_CUSRNO = "CUSRNO";
    //歸屬行
    //public string S_BRNO = "BRNO";
    public string S_BRNO = "CREBRN";
    
    public F0101(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }

    public void GetRS()
    {
        SetRQ();

        if (isSuccess)
        {
            CIFKEY = GetValue(docsvcRs, S_CIFKEY);
            CNAME = GetValue(docsvcRs, S_CNAME);
            if (CNAME == "查詢結果：顧客資料未建檔")
                isSuccess = false;
            BIRTHDAY = GetValue(docsvcRs, S_BIRTHDAY);
            MPHONE = GetValue(docsvcRs, S_MPHONE);
            EMAIL = GetValue(docsvcRs, S_EMAIL);
            DEADFG = GetValue(docsvcRs, S_DEADFG);
            CUSRNO = GetValue(docsvcRs, S_CUSRNO);
            BRNO=GetValue(docsvcRs, S_BRNO);
        }
        else
        {
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }

    public string CIFKEY { get; set; }
    public string CNAME { get; set; }
    public string BIRTHDAY { get; set; }
    public string MPHONE { get; set; }
    public string EMAIL { get; set; }
    public string DEADFG { get; set; }
    public string CUSRNO { get; set; }
    public string BRNO { get; set; }
}