﻿/// <summary>
/// F3012 的摘要描述
/// </summary>
public class F3012 : eai
{
    // 分行別
    public string Q_KINBR = "KINBR";
    // 統一編號
    public string Q_CIFKEY = "CIFKEY";
    // 戶名
    public string Q_CNAME = "CNAME";
    // 負責人統一編號
    public string Q_PCIFKEY = "PCIFKEY";
    // 負責人戶名
    public string Q_PIDNAM = "PIDNAM";
    // 國家別
    public string Q_CNTRY = "CNTRY";
    // 負責人國家別
    public string Q_PCNTRY = "PCNTRY";
    // 0:主機使用 1:內網使用
    public string Q_KIND = "KIND";
    // 異動員編
    public string Q_EMPNOT = "EMPNOT";

    public F3012(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }
}