﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// F0550 的摘要描述
/// </summary>
public class F0550 : eai
{
    public string Q_KINBR = "KINBR";
    public string Q_CIFKEY = "CIFKEY";

    // 客戶是否為制裁名單[0:否,1:是]
    public string S_CNAME = "CNAME";
    // 客戶是否為制裁名單[0:否,1:是]
    public string S_BLACKFG = "BLACKFG";
    // 是否為政治人物[0:否,1:是]
    public string S_POLIFG = "POLIFG";
    // 是否為負面新聞[0:否,1:是]
    public string S_NEWSFG = "NEWSFG";
    // AML狀態 0:審核完畢 1:處理中 9:送 AML 中
    public string S_STATUS1 = "STATUS1";
    // 洗錢及資恐制裁國家	0: 否 1: 是
    public string S_PML = "PML";

    public F0550(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }

    public void GetRS()
    {
        SetRQ();

        if(RspCode == this.GetType().Name)
        {
            CNAME = GetValue(docsvcRs, S_CNAME);
            BLACKFG = GetValue(docsvcRs, S_BLACKFG);
            POLIFG = GetValue(docsvcRs, S_POLIFG);
            NEWSFG = GetValue(docsvcRs, S_NEWSFG);
            STATUS1 = GetValue(docsvcRs, S_STATUS1);
            PML = GetValue(docsvcRs, S_PML);
        }
        else
        {
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }
    public string CNAME { get; set; }
    public string BLACKFG { get; set; }
    public string POLIFG { get; set; }
    public string NEWSFG { get; set; }
    public string STATUS1 { get; set; }
    public string PML { get; set; }
}