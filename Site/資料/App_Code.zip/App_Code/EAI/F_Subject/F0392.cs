﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// F0392 的摘要描述
/// </summary>
public class F0392 : eai
{
    //輸入行,9(04)
    public string Q_KINBR = "KINBR";
    //統一編號, X(10)
    public string Q_CIFKEY = "CIFKEY";
    //查詢資料	0:全部 1:本行自訂外籍高風險客戶,9(01)
    public string Q_IQKIND = "IQKIND";

    public F0392(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }

    public void GetRS()
    {
        SetRQ();

        if(RspCode == this.GetType().Name)
        {
            RISK = "1";
        }
        else
        {
            RISK = "0";
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }
    public string RISK { get; set; }
}