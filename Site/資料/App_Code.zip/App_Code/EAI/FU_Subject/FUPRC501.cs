﻿/// <summary>
/// FUPRC501 的摘要描述
/// </summary>
public class FUPRC501 : eai
{
    public string Q_ID = "ID";

    // 行動電話
    public string S_MOBTEL = "MOBTEL";
    // 管理行
    public string S_BRANCH = "BRANCH";
    // 電子郵件
    public string S_EMAIL = "EMAIL";

    public FUPRC501(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        TxnId = "FUPRC501";
        SetPmtID(sEmpID, sTaskName);
    }

    public void GetRS()
    {
        if (isSuccess)
        {
            MOBTEL = GetValue(docsvcRs, S_MOBTEL);
            BRANCH = GetValue(docsvcRs, S_BRANCH);
            EMAIL = GetValue(docsvcRs, S_EMAIL);
        }
        else
        {
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }

    public string MOBTEL { get; set; }
    public string BRANCH { get; set; }
    public string EMAIL { get; set; }
}