﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// D0310 的摘要描述
/// </summary>
public class D0310:eai
{
    public string Q_BRNO = "BRNO";       //分行別，放9999
    public string Q_INQCD = "INQCD";     //查詢方式，放2
    public string Q_CIFKEY = "CIFKEY";     //統一編號
    public string Q_INQKIND = "INQKIND"; //查詢種類，放1(20230926更改，原本放0)
       
    public string S_Detail = "Detail";

    public string D_MGNO = "MGNO";       //額度號碼, X(14)
    public string D_SUPFG = "SUPFG";     //狀態，僅限1(核可)
    public string D_ACTAMT = "ACTAMT";   //額度可動用限額(額度總額)
    public string D_FLBAL = "FLBAL";     //放款餘額(額度現放)  
    public string D_RMBAL = "RMBAL";     //一位正負號+整數11位+2位小數，剩餘可用額度(餘額)

    public D0310(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
        TxnId = this.GetType().Name;
        SetPmtID(sEmpID, sTaskName);
    }
    public void GetRS()
    {
        SetRQ();

        if (isSuccess)
        {
            List<string> list = new List<string>();
            list.Add(D_MGNO);
            list.Add(D_SUPFG);
            list.Add(D_ACTAMT);
            list.Add(D_FLBAL);
            list.Add(D_RMBAL);

            Detail = GetDetailValue(docsvcRs, list);
        }
        else
        {
            if (docsvcHeader == null)
                Desc = "查詢電文失敗，請稍後再試。";
        }
    }
    
    public Dictionary<int, Dictionary<string, string>> Detail { get; set; }
}