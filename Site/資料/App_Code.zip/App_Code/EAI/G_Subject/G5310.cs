﻿
using System;
using System.Collections.Generic;

/// <summary>
/// G5310 大額資金通報電文
/// </summary>
public class G5310 : eai
{
    // ===== EAI Header 欄位 =====
    public string Q_KINBR = "KINBR";       // 輸入行 9(04)
    public string Q_ACFLG = "ACFLG";       // 金資軋帳記號 9(01)，固定帶 2
    public string Q_RBRNO = "RBRNO";       // 分行代號 9(04)
    public string Q_FBRNO = "FBRNO";       // 分行代號 9(04)

    // ===== EAI Body Request 欄位 (按規格書順序) =====
    public string Q_KIND = "KIND";         // 功能 9(01)
    public string Q_APTYPE = "APTYPE";     // 案件種類 X(02)
    public string Q_DATE = "DATE";         // 通報日期 9(08)
    public string Q_SRNO = "SRNO";         // 案件編號 9(04)，新增時送0000
    public string Q_UNINO = "UNINO";       // 統編 X(11)
    public string Q_STDAY = "STDAY";       // 交割日期 9(08)
    public string Q_IBRNO = "IBRNO";       // 通報行 9(04)
    public string Q_ACBRNO = "ACBRNO";     // 掛帳行 9(04)
    public string Q_CURCD = "CURCD";       // 幣別 9(02)
    public string Q_BKCUR = "BKCUR";       // 存匯行幣別 9(02)
    public string Q_BKSRNO = "BKSRNO";     // 存匯行流水號 9(03)
    public string Q_AMT = "AMT";           // 金額 9(12)V9(02)
    public string Q_IOCD = "IOCD";         // 匯出匯入別 9(01)
    public string Q_AMTWHERE = "AMTWHERE"; // 資金來源/去處 X(40)
    public string Q_REASON = "REASON";     // 變動原因 X(80)
    public string Q_EMPNO = "EMPNO";       // 員工編號 X(06)
    public string Q_EMPNM = "EMPNM";       // 員工姓名 X(10)
    public string Q_END = "END";           // 結尾符號 X(01)，固定 $

    // ===== 移除不需要的欄位 =====
    // public string Q_CIFKEY = "CIFKEY";  // 不需要，已合併到 UNINO
    // public string Q_CIFERR = "CIFERR";  // 不需要，已合併到 UNINO

    // ===== Response 欄位 =====
    public string S_BRNO = "BRNO";         // 輸入行
    public string S_TRMSEQ = "TRMSEQ";     // 櫃檯機編號
    public string S_TXTNO = "TXTNO";       // 交易序號
    public string S_APTYPE = "APTYPE";     // 案件種類
    public string S_DATE = "DATE";         // 通報日期
    public string S_SRNO = "SRNO";         // 案件編號 ← 主機回傳的
    public string S_STATUS = "STATUS";     // 狀態 1有效 2無效

    public G5310(string sEmpID, string sTaskName) : base(sEmpID, sTaskName)
    {
        TxnId = "G5310";
        SetPmtID(sEmpID, sTaskName);
    }

    /// <summary>
    /// 發送電文並取得回應
    /// </summary>
    public void GetRS()
    {
        SetRQ();

        if (RspCode == "G5310")
        {
            // 解析回應
            BRNO = GetValue(docsvcRs, S_BRNO);
            TRMSEQ = GetValue(docsvcRs, S_TRMSEQ);
            TXTNO = GetValue(docsvcRs, S_TXTNO);
            ReturnAPTYPE = GetValue(docsvcRs, S_APTYPE);
            ReturnDATE = GetValue(docsvcRs, S_DATE);
            ReturnSRNO = GetValue(docsvcRs, S_SRNO);    // 主機回傳的案件編號
            STATUS = GetValue(docsvcRs, S_STATUS);      // 1有效 2無效
        }
        else
        {
            if (docsvcHeader == null)
            {
                Desc = "電文發送失敗，請稍後再試。";
            }
            else if (string.IsNullOrEmpty(Desc))
            {
                Desc = string.Format("主機回應異常，RspCode={0}", RspCode ?? "null");
            }
        }
    }

    // ===== Response 屬性 =====
    public string BRNO { get; set; }
    public string TRMSEQ { get; set; }
    public string TXTNO { get; set; }
    public string ReturnAPTYPE { get; set; }
    public string ReturnDATE { get; set; }
    public string ReturnSRNO { get; set; }  // 主機回傳的案件編號
    public string STATUS { get; set; }      // 1有效 2無效
}