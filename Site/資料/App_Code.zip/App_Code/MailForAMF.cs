﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Collections.Generic;
using System.Net.Mime;
using System.Text;
using System.IO;

/// <summary>
/// MailForAMF 的摘要描述
/// </summary>
public class MailForAMF
{
    private System.Net.Mail.MailMessage mailContent = new System.Net.Mail.MailMessage();
    private System.Net.Mail.SmtpClient smtpMail = new System.Net.Mail.SmtpClient();
    private string mailhost = "mra.chb.com.tw";//郵件主機
    private string username = string.Empty;//帳號
    private string password = string.Empty;//密碼
    private string sendermail = "intra@chb.com.tw";//送件者郵件
    private string sendername = "內網組";//送件者名稱
    private List<string> attachFiles = new List<string>();//附加檔案列表
    private StringBuilder messageBody;//內文
    private AlternateView avHtml;//內文格式
    private List<LinkedResource> linkCollect = new List<LinkedResource>();//附加資源檔(圖檔等)
	public MailForAMF()
	{
        messageBody = new StringBuilder();
        avHtml = AlternateView.CreateAlternateViewFromString
        (messageBody.ToString(), null, MediaTypeNames.Text.Html);
	}
    /// <summary>
    /// 設定寄件者資訊
    /// </summary>
    /// <param name="name">顯示名稱</param>
    /// <param name="mail">信箱</param>
    public void SetSenderInfo(string name, string mail)
    {
        sendername = string.Copy(name);
        sendermail = string.Copy(mail);
    }
    /// <summary>
    /// 設定附加檔案
    /// </summary>
    /// <param name="filelist">檔案完整路徑可多筆輸入</param>
    public void SetAttachFiles(List<string> filelist)
    {
        attachFiles.Clear();
        attachFiles.AddRange(filelist.ToArray());
        mailContent.Attachments.Clear();
        foreach (string tempfiles in attachFiles)
        {
            mailContent.Attachments.Add(new Attachment(tempfiles));
        }
    }
    /// <summary>
    /// 設定郵件伺服器
    /// </summary>
    /// <param name="host">ip地址</param>
    /// <param name="user">帳號</param>
    /// <param name="pwd">密碼</param>
    public void SetMailServerInfo(string host, string user, string pwd)
    {
        mailhost = string.Copy(host);
        username = string.Copy(user);
        password = string.Copy(pwd);
    }
    /// <summary>
    /// 寄送郵件使用訊息內容
    /// </summary>
    /// <param name="name">收件者名稱</param>
    /// <param name="mail">收件者信箱</param>
    /// <param name="subject">主旨</param>
    /// <param name="message">訊息內容</param>
    public void SendMail(string name, string mail, string subject, string message)
    {


        try
        {

            mailContent.From = new System.Net.Mail.MailAddress(sendermail, sendername);  //寄件者                        
            mailContent.Subject = subject;
            //設定郵件內容
            mailContent.AlternateViews.Clear();
            mailContent.Body = message;
            //設定編碼方式
            mailContent.SubjectEncoding = System.Text.Encoding.GetEncoding("BIG5");    //編碼方式         
            mailContent.BodyEncoding = System.Text.Encoding.GetEncoding("BIG5");    //編碼方式
            mailContent.To.Clear();
            mailContent.To.Add(new System.Net.Mail.MailAddress(mail, name));
            mailContent.IsBodyHtml = true; //是否為HTML格式            
            smtpMail.Host = mailhost;
            smtpMail.Credentials = new System.Net.NetworkCredential(username, password);
            smtpMail.Send(mailContent);
        }
        catch (Exception e)
        {
            Console.WriteLine("e.Message : " + e.Message);
        }
    }
    /// <summary>
    /// 寄送郵件,使用AddContent及AddPicture之後的內容
    /// </summary>
    /// <param name="name">收件者名稱</param>
    /// <param name="mail">收件者信箱</param>
    /// <param name="subject">主旨</param>    
    public void SendMail(string name, string mail, string subject)
    {


        try
        {

            mailContent.From = new System.Net.Mail.MailAddress(sendermail, sendername);  //寄件者                                    
            mailContent.Subject = subject;
            //設定郵件內容
            mailContent.AlternateViews.Clear();
            avHtml = AlternateView.CreateAlternateViewFromString
            (messageBody.ToString(), null, MediaTypeNames.Text.Html);
            foreach (LinkedResource item in linkCollect)
            {
                avHtml.LinkedResources.Add(item);
            }
            mailContent.AlternateViews.Add(avHtml);
            //設定編碼方式
            mailContent.SubjectEncoding = System.Text.Encoding.GetEncoding("BIG5");    //編碼方式         
            mailContent.BodyEncoding = System.Text.Encoding.GetEncoding("BIG5");    //編碼方式
            mailContent.To.Clear();
            mailContent.To.Add(new System.Net.Mail.MailAddress(mail, name));
            mailContent.IsBodyHtml = true; //是否為HTML格式            
            smtpMail.Host = mailhost;
            smtpMail.Credentials = new System.Net.NetworkCredential(username, password);
            smtpMail.Send(mailContent);
        }
        catch (Exception e)
        {
            Console.WriteLine("e.Message : " + e.Message);
        }
    }
    /// <summary>
    /// 設定替代方式
    /// </summary>
    private void SetReceiverWay(string message)
    {
        //純文字
        AlternateView plainView = AlternateView.CreateAlternateViewFromString(message, null, "text/plain");
        //HTML
        AlternateView htmlView = AlternateView.CreateAlternateViewFromString(message, null, "text/html");
        mailContent.AlternateViews.Add(plainView);
        mailContent.AlternateViews.Add(htmlView);
    }
    /// <summary>
    /// 增加內文
    /// </summary>
    /// <param name="content"></param>
    public void AddContent(string content)
    {
        messageBody.Replace("無內容", string.Empty);
        messageBody.Append(content);
    }
    /// <summary>
    /// 重新設定信件內容
    /// </summary>
    public void RemoveAll()
    {
        mailContent.AlternateViews.Clear();
        mailContent.Attachments.Clear();
        messageBody.Remove(0, messageBody.Length);
        messageBody.Append("無內容");
    }
    /// <summary>
    /// 顯示內文
    /// </summary>
    /// <returns></returns>
    public string DisplayContent()
    {
        return messageBody.ToString();
    }
    /// <summary>
    /// 插入圖片
    /// </summary>
    /// <param name="filename"></param>
    public void AddPicture(string filename)
    {
        FileInfo fi = new FileInfo(filename);
        if (fi.Exists == false)
        {
            return;
        }
        messageBody.AppendLine("<br><img src=\"cid:" + fi.Name.Replace(fi.Extension, string.Empty) + "\">");
        LinkedResource pic1 = new LinkedResource(filename, MediaTypeNames.Image.Jpeg);
        pic1.ContentId = fi.Name.Replace(fi.Extension, string.Empty);
        linkCollect.Add(pic1);
    }
}