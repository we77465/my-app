﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.IO;
using JonSkeet.Ebcdic;
/// <summary>
/// UnisysCode 優利工具
/// </summary>
public class UnisysCode
{
    /// <summary>
    /// 轉EBCDIC編碼
    /// </summary>
    /// <param name="inputFile">輸入檔案完整路徑</param>
    /// <param name="outputFile">輸出檔案完整路徑</param>
    public void ExportToUnisys(string inputFile, string outputFile)
    {

        Encoding inputEncoding = Encoding.ASCII;
        Encoding outputEncoding = EbcdicEncoding.GetEncoding("EBCDIC-US");

        try
        {
            // Create the reader and writer with appropriate encodings.
            using (StreamReader inputReader = new StreamReader(inputFile, inputEncoding))
            {
                using (StreamWriter outputWriter = new StreamWriter(outputFile, false, outputEncoding))
                {
                    while (inputReader.Peek() > -1)
                    {
                        outputWriter.Write(inputReader.ReadLine()+"\r\n");
                        outputWriter.Flush();
                    }
                    inputReader.Close();
                    outputWriter.Close();
                }
            }
        }
        // Not much in the way of error handling here - you may well want
        // to do better handling yourself!
        catch (IOException e)
        {
            //Debug.WriteLine("Exception during processing: {0}", e.Message);
        }
    }
}
