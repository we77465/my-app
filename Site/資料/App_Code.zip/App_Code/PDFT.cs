﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.IO.Compression;
using iTextSharp.text;
using iTextSharp.text.pdf;

/// <summary>
/// Class1 的摘要描述
/// </summary>
public class PDFT
{
    HttpResponse Response;
    string srcFileName;
    public PDFT(string isrcFileName, HttpResponse iResponse)
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
        srcFileName = isrcFileName;
        Response = iResponse;
    }
    public void DownLoadFile(string StampWord, string newFileName)
    {
        /* PdfReader reader;// =*/
        //載入PDF檔
        PdfReader reader = new PdfReader(srcFileName);


        //載入字型
        BaseFont bfChinese = BaseFont.CreateFont(@"C:\WINDOWS\Fonts\kaiu.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);


        //宣告串流
        MemoryStream ms = new MemoryStream();


        //宣告浮水印
        PdfStamper pStamper = new PdfStamper(reader, ms);

        //浮水印樣式
        PdfGState gstate = new PdfGState()
        {
            FillOpacity = 0.6f,
            StrokeOpacity = 0.6f

        };

        try
        {
            Rectangle pSize = reader.GetPageSizeWithRotation(1);
            //逐頁上浮水印
            for (int i = 1; i <= reader.NumberOfPages; i++)
            {
                pSize = reader.GetPageSizeWithRotation(i);
                PdfContentByte pdfPageContents = pStamper.GetOverContent(i);

                pdfPageContents.BeginText();
                //pdfPageContents.SetFontAndSize(bfChinese, 80);
                pdfPageContents.SetFontAndSize(bfChinese, 15);
                pdfPageContents.SetRGBColorFill(180, 180, 180);
                pdfPageContents.SetGState(gstate);

                float textAngle = 45.0f;

                //浮水印置中
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 4, pSize.Height - 150f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 4, pSize.Height / 2 + 100f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 4, pSize.Height / 3 + 70f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 4, 160f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 2f, pSize.Height - 150f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 2f, pSize.Height / 2 + 100f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 2f, pSize.Height / 3 + 70f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 2f, 160f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 1.5f + 40f, pSize.Height - 150f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 1.5f + 40f, pSize.Height / 2 + 100f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 1.5f + 40f, pSize.Height / 3 + 70f, textAngle);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 1.5f + 40f, 160f, textAngle);

                pdfPageContents.SetFontAndSize(bfChinese, 20);
                pdfPageContents.SetRGBColorFill(0, 0, 0);
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "CHB機密文件請勿外流", 20f, pSize.Height - 20f, 0f);

                pdfPageContents.EndText();

            }

            pStamper.FormFlattening = true;
            //奇數頁的話,追加一頁空白頁
            /*if (reader.NumberOfPages % 2 == 1)
            {
                Document document = new Document(pSize);
                //PdfImportedPage page;
                //PdfWriter writer = null;
                //int importedPageNumber = 0;
                //PdfContentByte cb = writer.DirectContent;
                document.NewPage();
                document.Add(new Chunk());
            }*/
        }
        catch (Exception)
        {

            throw;
        }
        finally
        {
            pStamper.Close();
            reader.Close();
        }

        Response_Output(ms, newFileName);



    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="fn"></param>
    /// <param name="StampWord"></param>
    public void DownLoadFileManager(string StampWord, string newFileName)
    {
        /* PdfReader reader;// =*/
        //載入PDF檔
        PdfReader reader = new PdfReader(srcFileName);


        //載入字型
        BaseFont bfChinese = BaseFont.CreateFont(@"C:\WINDOWS\Fonts\kaiu.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);


        //宣告串流
        MemoryStream ms = new MemoryStream();


        //宣告浮水印
        PdfStamper pStamper = new PdfStamper(reader, ms);

        //浮水印樣式
        PdfGState gstate = new PdfGState()
        {
            FillOpacity = 0.45f,
            StrokeOpacity = 0.45f

        };

        try
        {
            //逐頁上浮水印
            for (int i = 1; i <= reader.NumberOfPages; i++)
            {
                Rectangle pSize = reader.GetPageSizeWithRotation(i);
                PdfContentByte pdfPageContents = pStamper.GetOverContent(i);

                pdfPageContents.BeginText();
                pdfPageContents.SetFontAndSize(bfChinese, 66);
                pdfPageContents.SetRGBColorFill(190, 190, 190);
                pdfPageContents.SetGState(gstate);

                float textAngle = 45.0f;

                //浮水印置中
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 2f, pSize.Height / 2, textAngle);
                pdfPageContents.EndText();

            }

            pStamper.FormFlattening = true;


        }
        catch (Exception)
        {

            throw;
        }
        finally
        {
            pStamper.Close();
            reader.Close();


        }

        Document myDocument = new Document();
        PdfWriter myPDFWriter = PdfWriter.GetInstance(myDocument, ms);

        byte[] content = ms.ToArray();

        //// Write out PDF from memory stream.
        //using (FileStream fs = File.Create(@"E:\PaperLessUpload\9999123101\test.pdf"))
        //{
        //    fs.Write(content, 0, (int)content.Length);
        //}

        Response_Output(ms, newFileName);

    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="ms">來源資料流</param>
    /// <param name="fn">輸出的檔名</param>
    /// <param name="rp">HttpResponse Page</param>
    public void Response_Output(MemoryStream ms, string newFileName)
    {

        Response.Clear();
        Response.AddHeader("Content-Disposition", "attachment;filename=" + HttpUtility.UrlEncode(newFileName));
        Response.ContentType = "application/octet-stream"; Response.OutputStream.Write(ms.GetBuffer(), 0, ms.GetBuffer().Length);
        Response.OutputStream.Flush();
        Response.OutputStream.Close();
        Response.Flush();
        Response.End();
    }

    public void MultiDownload(string StampWord, string newFileName)
    {

        /* PdfReader reader;// =*/
        //載入PDF檔
        PdfReader reader = new PdfReader(srcFileName);

        //載入字型
        BaseFont bfChinese = BaseFont.CreateFont(@"C:\WINDOWS\Fonts\kaiu.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);

        //宣告串流
        MemoryStream ms = new MemoryStream();

        //宣告浮水印
        PdfStamper pStamper = new PdfStamper(reader, ms);

        //浮水印樣式
        PdfGState gstate = new PdfGState()
        {
            FillOpacity = 0.45f,
            StrokeOpacity = 0.45f

        };

        try
        {
            Rectangle pSize = reader.GetPageSizeWithRotation(1);
            //逐頁上浮水印
            for (int i = 1; i <= reader.NumberOfPages; i++)
            {
                pSize = reader.GetPageSizeWithRotation(i);
                PdfContentByte pdfPageContents = pStamper.GetOverContent(i);

                pdfPageContents.BeginText();
                pdfPageContents.SetFontAndSize(bfChinese, 66);
                pdfPageContents.SetRGBColorFill(190, 190, 190);
                pdfPageContents.SetGState(gstate);

                float textAngle = 45.0f;

                //浮水印置中
                pdfPageContents.ShowTextAligned(PdfContentByte.ALIGN_CENTER, StampWord, pSize.Width / 2f, pSize.Height / 2, textAngle);
                pdfPageContents.EndText();

            }

            pStamper.FormFlattening = true;

        }
        catch (Exception)
        {

            throw;
        }
        finally
        {
            pStamper.Close();
            reader.Close();
        }

        Document myDocument = new Document();
        PdfWriter myPDFWriter = PdfWriter.GetInstance(myDocument, ms);

        byte[] content = ms.ToArray();

        using (FileStream fs = File.Create(newFileName))
        {
            fs.Write(content, 0, (int)content.Length);
        }

    }

    /// <summary> 合併PDF檔(集合) </summary> 
    /// <param name="fileList">欲合併PDF檔之集合(一筆以上)</param>
    /// <param name="outMergeFile">合併後的檔名</param> 
    public void mergePDFFiles(List<string> fileList, string outMergeFile)
    {
        PdfReader reader;
        Document document = new Document();
        PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(outMergeFile, FileMode.Create));
        document.Open();
        PdfContentByte cb = writer.DirectContent;
        PdfImportedPage newPage;

        foreach (string s in fileList)
        {
            reader = new PdfReader(s);
            int iPageNum = reader.NumberOfPages;
            for (int j = 1; j <= iPageNum; j++)
            {
                document.NewPage();
                newPage = writer.GetImportedPage(reader, j);
                //cb.AddTemplate(newPage, 0, 0);

                Rectangle psize = reader.GetPageSizeWithRotation(j);
                switch (psize.Rotation)
                {
                    case 0:
                        cb.AddTemplate(newPage, 1f, 0, 0, 1f, 0, 0);
                        break;
                    case 90:
                        cb.AddTemplate(newPage, 0, -1f, 1f, 0, 0, psize.Height);
                        break;
                    case 180:
                        cb.AddTemplate(newPage, -1f, 0, 0, -1f, 0, 0);
                        break;
                    case 270:
                        cb.AddTemplate(newPage, 0, 1.0F, -1.0F, 0, psize.Width, 0);
                        break;
                    default:
                        break;
                }
            }
            //20210506 判斷檔案為基數頁，加一頁空白頁
            if (iPageNum > 0 && iPageNum % 2 == 1)
            {
                bool result = document.NewPage();
                document.Add(new Chunk());
            }
        }

        document.Close();
        //document.Dispose();
    }

}