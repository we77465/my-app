﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.VisualBasic;

/// <summary>
/// FCurrency 的摘要描述
/// </summary>
public static class FCurrency
{
	//public FCurrency(){}

    /// <summary>
    /// 將數值轉為貨幣 ex 2500->2,500
    /// </summary>
    /// <param name="amount"></param>
    /// <returns></returns>
    public static string getCurrency(string amount,bool showZero)
    {
        if (amount == "")
        {
            if (showZero)
                return "0";
            else
                return "";
        }
        else if (amount == "0")
            return "0";
        else
            return Microsoft.VisualBasic.Strings.FormatCurrency(amount, 0, TriState.False, TriState.False, TriState.True).Replace("NT$", "").Replace("$", "");
    }

    /// <summary>
    /// 輸入金額回傳數值 ex 2,500-->2500
    /// </summary>
    /// <param name="currency"></param>
    /// <returns></returns>
    public static long getNum(string currency)
    {
        long num = (currency == "") ? long.Parse("0") : long.Parse(currency.Replace(",", ""));
        return num;
    }
    public static decimal getDec(string currency)
    {
        decimal num = (currency == "") ? decimal.Parse("0.00") : decimal.Parse(currency.Replace(",", ""));
        return num;
    }
}
