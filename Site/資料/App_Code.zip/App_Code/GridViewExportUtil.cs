﻿using System;
using System.Web;
using System.IO;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Text;

/// <summary>
/// GridView匯出工具
/// </summary>
public class GridViewExportUtil
{
    public GridViewExportUtil()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    /// <summary>將GridView畫面上的內容，直接以HTML存成Excel檔。若欄位要純文字顯示，請於GridView的DataFormatString填入「 {0}」(空白+[0])。
    /// ExportGridView:GridView名稱，FileName:存檔檔名不含.xls，vPage:直接填Page
    /// </summary>
    public static void ExportExcel(System.Web.UI.WebControls.GridView vGridView, string vFileName, Page vPage)
    {
        ExportToOfficeFile(vGridView, vFileName + ".xls", vPage);
    }

    /// <summary>匯出成Word</summary>
    public static void ExportWord(System.Web.UI.WebControls.GridView vGridView, string vFileName, Page vPage)
    {
        ExportToOfficeFile(vGridView, vFileName + ".doc", vPage);
    }

    /// <summary>
    /// 將GridView畫面上的內容，直接以HTML存成Excel、Word檔案，
    /// ExportGridView:GridView名稱，FileName:存檔檔名不含.xls，vPage:直接填Page。
    /// 若欄位要純文字顯示，請於GridView的DataFormatString填入「 {0}」(空白+[0])
    /// </summary>
    /// <param name="vGridView">GridView物件名稱</param>
    /// <param name="vFileName">存檔檔名</param>
    /// <param name="vPage">來源Page頁面(ex:Page)</param>
    /// <remarks>
    /// 程式做法：
    ///   利用GridView自行Render出與網頁上格式相同的HTML，
    ///   配合application/vnd.xls MIME Type，讓資料可以直接在Excel、Word中重現
    /// 註：
    /// 儲存後內容含格式資訊，另外，使用此 Function 須 using System.Web
    /// </remarks>
    private static void ExportToOfficeFile(System.Web.UI.WebControls.GridView vGridView, string vFileName, Page vPage)
    {
        //關閉換頁跟排序
        //說明：若GridView無分頁功能、或有啟用分頁但只有1頁的資料時，則直接將資料Render出來
        //      若有啟用分頁功能且頁數有2頁以上，當DataSource為null時，則不進行轉換為Excel的動作
        if (vGridView.AllowPaging && vGridView.DataSource != null)
        {
            vGridView.AllowSorting = false;
            vGridView.AllowPaging = false;
            vGridView.DataBind();
        }

        if (vGridView.PageCount == 1)
        {
            //瀏覽器為IE時將檔名編碼，避免存檔後中文檔名會變亂碼
            string strFileName = string.Empty;
            if (HttpContext.Current.Request.Browser.Browser == "IE")
                strFileName = HttpUtility.UrlPathEncode(vFileName);
            else
                strFileName = vFileName;
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.ContentType = "application/vnd.xls";
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=\"" + strFileName);
            HttpContext.Current.Response.AddHeader("mata", "http-equiv=Content-Type content=text/html;charset=utf-8");
            HttpContext.Current.Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");

            //註：若中文字會變亂碼，則替換下面的程式試試,或者修改aspx的第一行,ResponseEncoding="big5"
            //HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("big5") 
            //HttpContext.Current.Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
            //HttpContext.Current.Response.Write("<head><meta http-equiv=Content-Type content=text/html;charset=big5></head>")
            //HttpContext.Current.Response.Charset = "big5";

            System.IO.StringWriter sw = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htw = new System.Web.UI.HtmlTextWriter(sw);

            //建立假HtmlForm避免以下錯誤：
            //Control 'GridView1' of type 'GridView' must be placed inside a form tag with runat=server
            //另一種做法是建立 override VerifyRenderingInServerForm function，在function內不寫程式碼
            //這樣就可以直接執行 GridView1.RenderControl(htw)
            System.Web.UI.HtmlControls.HtmlForm hf = new System.Web.UI.HtmlControls.HtmlForm();
            vPage.Controls.Add(hf);
            hf.Controls.Add(vGridView);
            hf.RenderControl(htw);  //指定GridView，若此行錯誤，請新增EnableEventValidation = "false"於aspx的<page>
            string style = "<style> .text { mso-number-format:\"\\@\"; } </style> ";
            //欄位為文字的 CSS設定
            HttpContext.Current.Response.Write(style);
            HttpContext.Current.Response.Write(sw.ToString().Replace("<div>", "").Replace("</div>", ""));
            HttpContext.Current.Response.End();
        }
        else
        {
            throw new ArgumentException("無資料來源！GridView有分頁時，" +
                "在呼叫SaveToOfficeFile函式前須重新繫結資料，" +
                "請在呼叫此函式前再次給予資料來源！");
        }
    }

    /// <summary>
    /// 匯出Excel(沒有套格式)
    /// </summary>
    /// <param name="fileName"></param>
    /// <param name="gv"></param>
    public static void Export(string fileName, GridView gv)
    {
        //關閉換頁跟排序
        //說明：若GridView無分頁功能、或有啟用分頁但只有1頁的資料時，則直接將資料Render出來
        //若有啟用分頁功能且頁數有2頁以上，當DataSource為null時，則不進行轉換為Excel的動作
        if (gv.AllowPaging && gv.DataSource != null)
        {
            gv.AllowSorting = false;
            gv.AllowPaging = false;
            gv.DataBind();
        }
        string strFileName = string.Empty;
        if (HttpContext.Current.Request.Browser.Browser == "IE")
            strFileName = HttpUtility.UrlPathEncode(fileName);
        else
            strFileName = fileName;
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        HttpContext.Current.Response.ContentType = "application/vnd.xls";
        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=\"" + HttpUtility.UrlEncode(strFileName, Encoding.UTF8) + ".xls\"");
        HttpContext.Current.Response.AddHeader("mata", "http-equiv=Content-Type content=text/html;charset=big5");
        using (StringWriter sw = new StringWriter())
        {
            using (HtmlTextWriter htw = new HtmlTextWriter(sw))
            {
                //  Create a form to contain the grid
                Table table = new Table();

                //  add the header row to the table
                if (gv.HeaderRow != null)
                {
                    PrepareControlForExport(gv.HeaderRow);
                    table.Rows.Add(gv.HeaderRow);
                }

                //  add each of the data rows to the table
                foreach (GridViewRow row in gv.Rows)
                {
                    PrepareControlForExport(row);
                    table.Rows.Add(row);
                }

                //  add the footer row to the table
                if (gv.FooterRow != null)
                {
                    PrepareControlForExport(gv.FooterRow);
                    table.Rows.Add(gv.FooterRow);
                }

                //  render the table into the htmlwriter
                table.RenderControl(htw);

                //  render the htmlwriter into the response
                HttpContext.Current.Response.Write(sw.ToString());
                HttpContext.Current.Response.End();
            }
        }
    }

    /// 
    /// Replace any of the contained controls with literals
    /// 
    /// 
    private static void PrepareControlForExport(Control control)
    {
        for (int i = 0; i < control.Controls.Count; i++)
        {
            Control current = control.Controls[i];
            if (current is LinkButton)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as LinkButton).Text));
            }
            else if (current is ImageButton)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as ImageButton).AlternateText));
            }
            else if (current is HyperLink)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as HyperLink).Text));
            }
            else if (current is DropDownList)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as DropDownList).SelectedItem.Text));
            }
            else if (current is CheckBox)
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl((current as CheckBox).Checked ? "True" : "False"));
            }

            if (current.HasControls())
            {
                PrepareControlForExport(current);
            }
        }
    }

    public static void MultiExcelSheet(GridView[] gvs, string[] sSheetNames, string sFileName, string sTitle)
    {
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.Buffer = true;
        HttpContext.Current.Response.Charset = "big5";

        //HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment;filename={0}", sFileName));
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", HttpUtility.UrlEncode(sFileName, Encoding.UTF8)));
        //HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode("Ap<x", System.Text.Encoding.UTF8) + ".xls"); 
        HttpContext.Current.Response.ContentEncoding = Encoding.GetEncoding("big5");
        //HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        HttpContext.Current.Response.ContentType = "application/ms-excel";
        HttpContext.Current.Response.Write("<meta http-equiv=Content-Type content=text/html; charset=UTF-8>");

        HttpContext.Current.Response.Write("MIME-Version: 1.0\r\n");
        HttpContext.Current.Response.Write("X-Document-Type: Workbook\r\n");
        HttpContext.Current.Response.Write("Content-Type: multipart/related; boundary=\"-=BOUNDARY_EXCEL\"\r\n\r\n");
        HttpContext.Current.Response.Write("---=BOUNDARY_EXCEL\r\n");
        HttpContext.Current.Response.Write("Content-Type: text/html; charset=\"big5\"\r\n\r\n");
        HttpContext.Current.Response.Write("<html xmlns:o=\"urn:schemas-microsoft-com:office:office\"\r\n");
        HttpContext.Current.Response.Write("      xmlns:x=\"urn:schemas-microsoft-com:office:excel\">\r\n");
        HttpContext.Current.Response.Write("<head>\r\n");
        HttpContext.Current.Response.Write("<xml>\r\n");
        HttpContext.Current.Response.Write("<o:DocumentProperties>\r\n");
        HttpContext.Current.Response.Write("<o:Author>User Name</o:Author>\r\n");
        HttpContext.Current.Response.Write("<o:LastAuthor>User Name</o:LastAuthor>\r\n");
        HttpContext.Current.Response.Write("<o:Created>DateTime</o:Created>\r\n");
        HttpContext.Current.Response.Write("<o:LastSaved>DateTime</o:LastSaved>\r\n");
        HttpContext.Current.Response.Write("<o:Company>Company Name</o:Company>\r\n");
        HttpContext.Current.Response.Write("<o:Version>1.0</o:Version>\r\n");
        HttpContext.Current.Response.Write("</o:DocumentProperties>\r\n");
        HttpContext.Current.Response.Write("</xml>\r\n");
        HttpContext.Current.Response.Write("<xml>\r\n");
        HttpContext.Current.Response.Write("<x:ExcelWorkbook>\r\n");
        HttpContext.Current.Response.Write("<x:ExcelWorksheets>\r\n");

        for (int i = 0; i < sSheetNames.Length; i++)
        {
            AddGrid(sSheetNames[i]);
        }

        HttpContext.Current.Response.Write("</x:ExcelWorksheets>\r\n");
        HttpContext.Current.Response.Write("</x:ExcelWorkbook>\r\n");
        HttpContext.Current.Response.Write("</xml>\r\n");
        HttpContext.Current.Response.Write("</head>\r\n");
        HttpContext.Current.Response.Write("</html>\r\n");

        for (int j = 0; j < sSheetNames.Length; j++)
        {
            AddGrid(gvs[j], sSheetNames[j], sTitle);
        }

        //System.IO.File.WriteAllText(@"C:\inetpub\wwwroot\mo2\Upload" + sFileName, "big5");
        HttpContext.Current.Response.Write("---=BOUNDARY_EXCEL--");
    }

    public static void AddGrid(string sheetName)
    {
        HttpContext.Current.Response.Write("<x:ExcelWorksheet>\r\n");
        HttpContext.Current.Response.Write(string.Format("<x:Name>{0}</x:Name>\r\n", sheetName));
        HttpContext.Current.Response.Write(string.Format("<x:WorksheetSource HRef=\"cid:{0}\"/>\r\n", sheetName));
        HttpContext.Current.Response.Write("</x:ExcelWorksheet>\r\n");
    }

    public static void AddGrid(GridView grid, string sheetName, string sTitle)
    {
        HttpContext.Current.Response.ContentEncoding = Encoding.GetEncoding("big5");
        HttpContext.Current.Response.Write("---=BOUNDARY_EXCEL\r\n");
        HttpContext.Current.Response.Write(string.Format("Content-ID: {0}\r\n", sheetName));
        HttpContext.Current.Response.Write("Content-Type: text/html; charset=\"big5\"\r\n\r\n");
        HttpContext.Current.Response.Write("<html xmlns:o=\"urn:schemas-microsoft-com:office:office\"\r\n");
        HttpContext.Current.Response.Write("      xmlns:x=\"urn:schemas-microsoft-com:office:excel\">\r\n");
        HttpContext.Current.Response.Write("<head>\r\n");
        HttpContext.Current.Response.Write("<xml>\r\n");
        HttpContext.Current.Response.Write("<x:WorksheetOptions>\r\n");
        HttpContext.Current.Response.Write("<x:ProtectContents>False</x:ProtectContents>\r\n");
        HttpContext.Current.Response.Write("<x:ProtectObjects>False</x:ProtectObjects>\r\n");
        HttpContext.Current.Response.Write("<x:ProtectScenarios>False</x:ProtectScenarios>\r\n");
        HttpContext.Current.Response.Write("</x:WorksheetOptions>\r\n");
        HttpContext.Current.Response.Write("</xml>\r\n");
        HttpContext.Current.Response.Write("</head>\r\n");
        HttpContext.Current.Response.Write("<body>\r\n");

        HttpContext.Current.Response.ContentEncoding = Encoding.GetEncoding("utf-8");
        StringWriter sw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(sw);
        GridViewRow gvr1 = new GridViewRow(-1, 0, DataControlRowType.DataRow, DataControlRowState.Normal);

        gvr1.Cells.Add(GetTableCell(sTitle, grid.Columns.Count, 1));

        grid.Controls[0].Controls.AddAt(0, gvr1);

        GridViewRow gvr = new GridViewRow(-1, 0, DataControlRowType.DataRow, DataControlRowState.Normal);
       
        gvr.Cells.Add(GetTableCell("後台經辦：", grid.Columns.Count / 2, 3));
        gvr.Cells.Add(GetTableCell("後台主管：", grid.Columns.Count / 2, 3));

        grid.Controls[0].Controls.Add(gvr);

        grid.RenderControl(htw);
        HttpContext.Current.Response.Write("<style> .text { mso-number-format:\\@; } </style> ");
        HttpContext.Current.Response.Write(sw.ToString());

        HttpContext.Current.Response.Write("</body>\r\n");
        HttpContext.Current.Response.Write("</html>\r\n");

        sw.Close();
        htw.Close();
    }

    public static TableCell GetTableCell(string sLabel, int iColSpan, int iRowSpan)
    {
        TableCell tc = new TableCell();
        Label lb = new Label();
        lb.Text = sLabel;
        tc.ColumnSpan = iColSpan;
        tc.RowSpan = iRowSpan;
        tc.HorizontalAlign = HorizontalAlign.Left;
        tc.VerticalAlign = VerticalAlign.Bottom;
        tc.BackColor = System.Drawing.Color.White;
        tc.Font.Size = 12;
        tc.Font.Underline = true;
        tc.BorderWidth = 0;
        tc.Controls.Add(lb);

        return tc;
    }


    public static void GVDataToText(GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            foreach (TableCell tc in e.Row.Cells)
            {
                if (tc.Text.ToLower().Trim().StartsWith("http://") ||
                    tc.Text.ToLower().Trim().StartsWith("https://"))
                {
                    tc.Text = "<a href='" + tc.Text + "' >查看</a>";
                }
                tc.Attributes.Add("class", "text");
            }
        }
    }
}