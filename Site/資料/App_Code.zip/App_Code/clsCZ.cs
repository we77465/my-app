﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using System.Text;
using System.IO;

/// <summary>
/// clsCZ 的摘要描述
/// </summary>
public class clsCZ
{

    enum ResponseCode
    {
        新增成功 = 200,
        新增失敗 = -200,
        新增失敗回覆案件編號已存在 = -201,
        查詢成功回覆案件已完成 = 210,
        查詢成功回覆案件未完成 = 211,
        查詢失敗回覆案件不存在 = -210,
        通知成功 = 230,
        通知失敗 = -230,
        未知的錯誤 = -999
    };




    public clsCZ()
    {
        //
        // TODO: 在此加入建構函式的程式碼
        //
    }

    /// <summary>
    /// 取得未通知子Case清單
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable getReCaseList(string a_completedCaseNo)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT ISNULL(CaseNo_GW, CaseNo) MasterNo, CaseNo, FlowStatus, CompletedNoticeTime FROM CZ_Main" + Environment.NewLine
                     + " WHERE ISNULL(CaseNo_GW, CaseNo) IN" + Environment.NewLine
                     + "  (SELECT ISNULL(CaseNo_GW, CaseNo) FROM CZ_Main WHERE CaseNo = @completedCaseNo) AND CompletedNoticeTime IS NULL" + Environment.NewLine;

                Cmd.Parameters.AddWithValue("@completedCaseNo", a_completedCaseNo);
                Cmd.CommandText = str;

                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得子Case清單清單發生錯誤：" + ex.Message);
        }
    }

    #region 自訂副程式


    public void PostAndGetResponse(string a_valCaseNo, string a_valPostData)
    {
        DataTable cases = getReCaseList(a_valCaseNo);
        if (cases.Rows.Count == 0)
        {
            InsLogWithCaseNo(a_valCaseNo, "Sys", "已通知", "");
            return; // 已通知
        }
        bool allClear = true;
        foreach (DataRow dr in cases.Rows)
        {
            if (dr["FlowStatus"].ToString() != "5")
            {
                InsLogWithCaseNo(dr["CaseNo"].ToString(), "Sys", "該受查企業同一批查詢尚有未放行完成之案件，待全部放行完成後才會通知Gateway", "");
                if (allClear == true)
                {
                    allClear = false;
                }
            }
        }
        if (allClear == false)
        {
            return;//尚未放行完成
        }

        string masterNo = cases.Rows[0]["MasterNo"].ToString();
        string postData = "CaseNo=" + masterNo;

        string strPostUrl = System.Web.Configuration.WebConfigurationManager.AppSettings["CZ_PostUrl"].ToString();


        string decodeUrl = Uri.UnescapeDataString(strPostUrl);

        HttpWebRequest rq = (HttpWebRequest)WebRequest.Create(decodeUrl);

        InsLogWithCaseNo(masterNo, "Sys", "通知URL：" + decodeUrl, "");
        ////rq.Timeout：10000毫秒(=10秒)
        //rq.Timeout = 10000;

        rq.Proxy = null;

        byte[] byteArray = Encoding.UTF8.GetBytes(postData);

        rq.Method = "POST";
        rq.ContentType = "application/x-www-form-urlencoded";
        rq.ContentLength = byteArray.Length;

        using (Stream dataStream = rq.GetRequestStream())
        {
            dataStream.Write(byteArray, 0, byteArray.Length);

            //InsLogWithCaseNo(masterNo, "Sys", "Write dataStream：" + byteArray, "");
        }

        HttpWebResponse rs = (HttpWebResponse)rq.GetResponse();

        string responseFromServer = new StreamReader(rs.GetResponseStream()).ReadToEnd();

        InsLogWithCaseNo(masterNo, "Sys", "responseFromServer：" + responseFromServer, "");

        if (responseFromServer == Convert.ToInt32(ResponseCode.通知成功).ToString())
        {

            //InsLogWithCaseNo(masterNo, "Sys", "通知成功：" + responseFromServer, "");

            clsSQLAgent DB = new clsSQLAgent();

            foreach (DataRow dr in cases.Rows)
            {
                SqlCommand UptCompletedNoticeTimeCmd = getUptCompletedNoticeTimeCmd(dr["CaseNo"].ToString());
                DB.AddCommand(UptCompletedNoticeTimeCmd, "更新通知完成日期");
            }
            SqlCommand InsLogCmd = getInsLogWithCaseNoCmd(masterNo, "Sys", "通知成功。", "");
            DB.AddCommand(InsLogCmd, "寫LOG");

            DB.ExecuteAllCommand();

        }
        else
        {

            //寫LOG
            InsLogWithCaseNo(masterNo, "Sys", "通知失敗：" + responseFromServer, "");

        }

        rs.Close();

    }


    /// <summary>
    /// 寫入Log
    /// </summary>
    /// <param name="valCaseNo"></param>
    /// <param name="valLogType"></param>
    /// <param name="valLogDesc"></param>
    /// <param name="valEmpID"></param>
    public void InsLogWithCaseNo(string valCaseNo, string valLogType, string valLogDesc, string valEmpID)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {
                //ModifiedTime欄位已設定預設值getdate()
                string str = "INSERT INTO [CZ_Log]" + Environment.NewLine
                     + " ([CaseNo],[LogType],[LogDesc],[EmpID])" + Environment.NewLine
                     + " VALUES" + Environment.NewLine
                     + " (@CaseNo,@LogType,@LogDesc,@EmpID)";

                Cmd.CommandText = str;

                Cmd.Parameters.AddWithValue("@CaseNo", valCaseNo);
                Cmd.Parameters.AddWithValue("@LogType", valLogType);
                Cmd.Parameters.AddWithValue("@LogDesc", valLogDesc);
                Cmd.Parameters.AddWithValue("@EmpID", valEmpID);

                DB.ExecuteCommand(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("寫入Log時發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 整批更新表單狀態
    /// </summary>
    /// <param name="valQryFlowStatus"></param>
    /// <param name="valUptFlowStatus"></param>
    /// <returns>SQL指令碼</returns>
    public void UptFlowStatusByFlowStatus(int valQryFlowStatus, int valUptFlowStatus)
    {
        try
        {

            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand UptCmd = new SqlCommand())
            {
                string str = "UPDATE [CZ_Main]" + Environment.NewLine
                     + " SET [FlowStatus]=@UptFlowStatus" + Environment.NewLine
                     + " WHERE [FlowStatus]=@QryFlowStatus";

                UptCmd.CommandText = str;

                UptCmd.Parameters.AddWithValue("@UptFlowStatus", valUptFlowStatus);
                UptCmd.Parameters.AddWithValue("@QryFlowStatus", valQryFlowStatus);

                DB.ExecuteCommand(UptCmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("更新表單狀態時發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 傳送至倉儲後整批更新表單狀態
    /// </summary>
    /// <param name="valQryFlowStatus"></param>
    /// <param name="valUptFlowStatus"></param>
    /// <returns>SQL指令碼</returns>
    public void UptFlowStatusAndSentToDWTimeByFlowStatus(int valQryFlowStatus, int valUptFlowStatus)
    {
        try
        {

            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand UptCmd = new SqlCommand())
            {
                string str = "UPDATE [CZ_MainGWPost]" + Environment.NewLine
                     + " SET [FlowStatus]=@UptFlowStatus" + Environment.NewLine
                     + " ,[SentToDWTime]=GETDATE()" + Environment.NewLine
                     + " WHERE [FlowStatus]=@QryFlowStatus";

                UptCmd.CommandText = str;

                UptCmd.Parameters.AddWithValue("@UptFlowStatus", valUptFlowStatus);
                UptCmd.Parameters.AddWithValue("@QryFlowStatus", valQryFlowStatus);

                DB.ExecuteCommand(UptCmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("更新表單狀態時發生錯誤：" + ex.Message);
        }
    }


    #endregion

    #region 自訂函式


    /// <summary>
    /// 取得詢證函資訊
    /// </summary>
    /// <returns>DataTable</returns
    public DataTable getCZMainByCaseNo(string valCaseNo)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT [CaseNo]" + Environment.NewLine
                     + "      ,[FirmCode]" + Environment.NewLine
                     + "      ,[FirmName]" + Environment.NewLine
                     + "      ,[FirmContactName]" + Environment.NewLine
                     + "      ,[FirmContactPhone]" + Environment.NewLine
                     + "      ,[FirmContactEmail]" + Environment.NewLine
                     + "      ,[CorporateCode]" + Environment.NewLine
                     + "      ,ISNULL([CorporateName],'') AS CorporateName" + Environment.NewLine
                     + "      ,[Branch]" + Environment.NewLine
                     + "      ,CONVERT(NVARCHAR(10),[DataDate],121) AS DataDate" + Environment.NewLine
                     + "      ,ISNULL([Remark],'') AS Remark" + Environment.NewLine
                     + "      ,[RequestTime]" + Environment.NewLine
                     + "      ,[CloesdTime]" + Environment.NewLine
                     + "      ,[FlowStatus]" + Environment.NewLine
                     + "      ,[CompletedNoticeTime]" + Environment.NewLine
                     + "      ,[ImportTime]" + Environment.NewLine
                     + "      ,[SentToDWTime]" + Environment.NewLine
                     + "	  ,[dbo].[ufn_CZ_GetPreCaseNo]([CaseNo]) AS PreCaseNo" + Environment.NewLine
                     + "	  ,[dbo].[ufn_CZ_GetDataDateBiz] ([CaseNo]) AS DataDate_Biz" + Environment.NewLine
                     + " FROM [CZ_Main]" + Environment.NewLine
                     + "  WHERE [CaseNo]=@CaseNo";

                Cmd.Parameters.AddWithValue("@CaseNo", valCaseNo);
                Cmd.CommandText = str;

                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得詢證函資訊發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 取得詢證函資訊(用Gateway Post的案件編號做查詢)
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable getCZMainByCaseNoGW(string valCaseNo)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT TOP(1) [CaseNo_GW] AS [CaseNo]" + Environment.NewLine
                     + "      ,[FirmCode]" + Environment.NewLine
                     + "      ,[FirmName]" + Environment.NewLine
                     + "      ,[FirmContactName]" + Environment.NewLine
                     + "      ,[FirmContactPhone]" + Environment.NewLine
                     + "      ,[FirmContactEmail]" + Environment.NewLine
                     + "      ,[CorporateCode]" + Environment.NewLine
                     + "      ,ISNULL([CorporateName],'') AS CorporateName" + Environment.NewLine
                     + "      ,[Branch]" + Environment.NewLine
                     + "      ,CONVERT(NVARCHAR(10),[DataDate],121) AS DataDate" + Environment.NewLine
                     + "      ,ISNULL([Remark],'') AS Remark" + Environment.NewLine
                     + "      ,[RequestTime]" + Environment.NewLine
                     + "      ,[CloesdTime]" + Environment.NewLine
                     + "      ,[FlowStatus]" + Environment.NewLine
                     + "      ,[CompletedNoticeTime]" + Environment.NewLine
                     + "      ,[ImportTime]" + Environment.NewLine
                     + "      ,[SentToDWTime]" + Environment.NewLine
                     + "	  ,[dbo].[ufn_CZ_GetPreCaseNo]([CaseNo]) AS PreCaseNo" + Environment.NewLine
                     + "	  ,[dbo].[ufn_CZ_GetDataDateBiz] ([CaseNo]) AS DataDate_Biz" + Environment.NewLine
                     + " FROM [CZ_Main]" + Environment.NewLine
                     + "  WHERE [CaseNo_GW]=@CaseNo";

                Cmd.Parameters.AddWithValue("@CaseNo", valCaseNo);
                Cmd.CommandText = str;

                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得詢證函資訊發生錯誤：" + ex.Message);
        }
    }

    /// <summary>
    /// 取得重送POST清單
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable getRePostList(int valFlowStatus)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT [CaseNo]" + Environment.NewLine
                     + " FROM [CZ_Main]" + Environment.NewLine
                     + "  WHERE [FlowStatus]=@FlowStatus" + Environment.NewLine
                     + "    AND [CompletedNoticeTime] IS NULL";

                Cmd.Parameters.AddWithValue("@FlowStatus", valFlowStatus);
                Cmd.CommandText = str;

                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得重送POST清單發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 取得查詢清單
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable getRequestList(int valFlowStatus)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT CAST([CorporateCode] AS CHAR(10)) AS CorporateCode" + Environment.NewLine
                     + ",CAST([Branch] AS CHAR(4)) AS Branch" + Environment.NewLine
                     + ",CONVERT(CHAR(10),[DataDate],121) AS DataDate" + Environment.NewLine
                     + " FROM [CZ_Main]" + Environment.NewLine
                     + "  WHERE [FlowStatus]=@FlowStatus";

                Cmd.Parameters.AddWithValue("@FlowStatus", valFlowStatus);
                Cmd.CommandText = str;

                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得查詢清單發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 取得查詢清單(包含當日重送處理)
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable getRequestAndResendList(int valFlowStatus, int valResendFlowStatus,string valResendSentToDWTime)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT CAST([CorporateCode] AS CHAR(10)) AS CorporateCode" + Environment.NewLine
                     + ",CAST([Branch] AS CHAR(4)) AS Branch" + Environment.NewLine
                     + ",CONVERT(CHAR(10),[DataDate],121) AS DataDate" + Environment.NewLine
                     + " FROM [CZ_MainGWPost]" + Environment.NewLine
                     + "  WHERE [FlowStatus]=@FlowStatus" + Environment.NewLine
                     +" UNION" + Environment.NewLine
                     + "SELECT CAST([CorporateCode] AS CHAR(10)) AS CorporateCode" + Environment.NewLine
                     + ",CAST([Branch] AS CHAR(4)) AS Branch" + Environment.NewLine
                     + ",CONVERT(CHAR(10),[DataDate],121) AS DataDate" + Environment.NewLine
                     + " FROM [CZ_MainGWPost]" + Environment.NewLine
                     + "  WHERE [FlowStatus]=@ResendFlowStatus" + Environment.NewLine
                     + " AND CAST([SentToDWTime] AS DATE)=CAST(@ResendSentToDWTime AS DATE)" ;

                Cmd.Parameters.AddWithValue("@FlowStatus", valFlowStatus);
                Cmd.Parameters.AddWithValue("@ResendFlowStatus", valResendFlowStatus);
                Cmd.Parameters.AddWithValue("@ResendSentToDWTime", valResendSentToDWTime);
                Cmd.CommandText = str;

                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得查詢清單發生錯誤(包含當日重送處理)：" + ex.Message);
        }
    }


    /// <summary>
    /// 取得待辦清單
    /// </summary>
    /// <param name="valBranch"></param>
    /// <param name="valRoleID"></param>
    /// <returns>DataTable</returns>
    public DataTable getTodoListByRoleID(string valBranch, string valRoleID)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["chb_pub"].ConnectionString);

            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT A.[USR_ID]" + Environment.NewLine
                     + " FROM [SC_ROL_USR] AS A" + Environment.NewLine
                     + " INNER JOIN [SC_USER] AS B ON A.[USR_ID]=B.[USR_ID]" + Environment.NewLine
                     + " WHERE B.[OU_ID]=@OU_ID" + Environment.NewLine
                     + " AND A.[ROL_ID]=@ROL_ID";

                Cmd.CommandText = str;

                Cmd.Parameters.AddWithValue("@OU_ID", valBranch);
                Cmd.Parameters.AddWithValue("@ROL_ID", valRoleID);


                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得待辦清單發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 取得匯入資料表清單
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable getImportTableList()
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT DISTINCT [FtpFilePath]" + Environment.NewLine
                     + ",[FtpFileName]" + Environment.NewLine
                     + ",[LocalFilePath]" + Environment.NewLine
                     + ",[LocalFileName]" + Environment.NewLine
                     + ",[SourceTableName]" + Environment.NewLine
                     + ",[TableName]" + Environment.NewLine
                     + " FROM [CZ_TableList]" + Environment.NewLine
                     + " WHERE [IsImport]=CAST(1 AS BIT)";

                Cmd.CommandText = str;

                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得匯入資料表清單發生錯誤：" + ex.Message);
        }
    }

    /// <summary>
    /// 取得匯入資料表之欄位資訊
    /// </summary>
    /// <param name="valTableName"></param>
    /// <returns>DataTable</returns>
    public DataTable getImportFieldListByTableName(string valTableName)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT [Field_ID]" + Environment.NewLine
                     + ",[Table_Name]" + Environment.NewLine
                     + ",[Seq_NO]" + Environment.NewLine
                     + ",[Field_Name]" + Environment.NewLine
                     + ",[Field_Desc]" + Environment.NewLine
                     + ",[Field_Size]" + Environment.NewLine
                     + ",[Field_Type]" + Environment.NewLine
                     + "  FROM [CZ_FieldList]" + Environment.NewLine
                     + " WHERE [Table_Name]=@Table_Name";

                Cmd.CommandText = str;
                Cmd.Parameters.AddWithValue("@Table_Name", valTableName);


                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得匯入資料表之欄位資訊發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 寫入Log
    /// </summary>
    /// <param name="valCaseNo"></param>
    /// <param name="valLogType"></param>
    /// <param name="valLogDesc"></param>
    /// <param name="valEmpID"></param>
    /// <returns>SQL指令碼</returns>
    public SqlCommand getInsLogWithCaseNoCmd(string valCaseNo, string valLogType, string valLogDesc, string valEmpID)
    {
        try
        {
            using (SqlCommand InsCmd = new SqlCommand())
            {
                //ModifiedTime欄位已設定預設值getdate()
                string str = "INSERT INTO [CZ_Log]" + Environment.NewLine
                     + " ([CaseNo],[LogType],[LogDesc],[EmpID])" + Environment.NewLine
                     + " VALUES" + Environment.NewLine
                     + " (@CaseNo,@LogType,@LogDesc,@EmpID)";

                InsCmd.CommandText = str;

                InsCmd.Parameters.AddWithValue("@CaseNo", valCaseNo);
                InsCmd.Parameters.AddWithValue("@LogType", valLogType);
                InsCmd.Parameters.AddWithValue("@LogDesc", valLogDesc);
                InsCmd.Parameters.AddWithValue("@EmpID", valEmpID);

                return InsCmd;
            }
        }
        catch (Exception ex)
        {
            throw new Exception("寫入Log時發生錯誤：" + ex.Message);
        }
    }

    /// <summary>
    /// 寫入Log
    /// </summary>
    /// <param name="valCaseNo"></param>
    /// <param name="valLogType"></param>
    /// <param name="valLogDesc"></param>
    /// <param name="valEmpID"></param>
    /// <returns>SQL指令碼</returns>
    public SqlCommand getInsCounterLogWithPartyIdCmd(string valPartyId, string valPartyName, string valDataDate, string valTableContent, string valEmpID, string valBrno)
    {
        try
        {
            using (SqlCommand InsCmd = new SqlCommand())
            {
                //ModifiedTime欄位已設定預設值getdate()
                string str = "INSERT INTO [CZ_CounterLog]" + Environment.NewLine
                     + " ([PARTY_ID],[PARTY_NAME],[AS_OF_DATE],[TableContent],[EmpID],[Brno])" + Environment.NewLine
                     + " VALUES" + Environment.NewLine
                     + " (@PartyId,@PartyName,@DataDate,@TableContent,@EmpID,@Brno)";

                InsCmd.CommandText = str;

                InsCmd.Parameters.AddWithValue("@PartyId", valPartyId);
                InsCmd.Parameters.AddWithValue("@PartyName", valPartyName);
                InsCmd.Parameters.AddWithValue("@DataDate", valDataDate);
                InsCmd.Parameters.AddWithValue("@TableContent", valTableContent);
                InsCmd.Parameters.AddWithValue("@EmpID", valEmpID);
                InsCmd.Parameters.AddWithValue("@Brno", valBrno);

                return InsCmd;
            }
        }
        catch (Exception ex)
        {
            throw new Exception("寫入Log時發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 更新表單狀態
    /// </summary>
    /// <param name="valCaseNo"></param>
    /// <param name="valFlowStatus"></param>
    /// <returns>SQL指令碼</returns>
    public SqlCommand getUptFlowStatusCmd(string valCaseNo, string valFlowStatus)
    {
        try
        {
            using (SqlCommand UptCmd = new SqlCommand())
            {
                string str = "UPDATE [CZ_Main]" + Environment.NewLine
                     + " SET [FlowStatus]=@FlowStatus" + Environment.NewLine
                     + " WHERE [CaseNo]=@CaseNo";

                UptCmd.CommandText = str;

                UptCmd.Parameters.AddWithValue("@CaseNo", valCaseNo);
                UptCmd.Parameters.AddWithValue("@FlowStatus", valFlowStatus);

                return UptCmd;
            }
        }
        catch (Exception ex)
        {
            throw new Exception("更新表單狀態時發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 更新通知完成時間
    /// </summary>
    /// <param name="valCaseNo"></param>
    /// <param name="valFlowStatus"></param>
    /// <returns>SQL指令碼</returns>
    public SqlCommand getUptCompletedNoticeTimeCmd(string valCaseNo)
    {
        try
        {
            using (SqlCommand UptCmd = new SqlCommand())
            {
                string str = "UPDATE [CZ_Main]" + Environment.NewLine
                     + " SET [CompletedNoticeTime]=GETDATE()" + Environment.NewLine
                     + " WHERE [CaseNo]=@CaseNo";

                UptCmd.CommandText = str;

                UptCmd.Parameters.AddWithValue("@CaseNo", valCaseNo);

                return UptCmd;
            }
        }
        catch (Exception ex)
        {
            throw new Exception("更新案件通知完成時間時發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 更新案件結案時間
    /// </summary>
    /// <param name="valCaseNo"></param>
    /// <param name="valFlowStatus"></param>
    /// <returns>SQL指令碼</returns>
    public SqlCommand getUptCloesdTimeCmd(string valCaseNo)
    {
        try
        {
            using (SqlCommand UptCmd = new SqlCommand())
            {
                string str = "UPDATE [CZ_Main]" + Environment.NewLine
                     + " SET [CloesdTime]=GETDATE()" + Environment.NewLine
                     + " WHERE [CaseNo]=@CaseNo";

                UptCmd.CommandText = str;

                UptCmd.Parameters.AddWithValue("@CaseNo", valCaseNo);

                return UptCmd;
            }
        }
        catch (Exception ex)
        {
            throw new Exception("更新案件結案時間時發生錯誤：" + ex.Message);
        }
    }


    /// <summary>
    /// 取得等待資料倉儲回覆之檔案日期
    /// </summary>
    /// <returns></returns>
    public string getDownLoadDWDataDT(int valFlowStatus)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {

                string r;
                Cmd.CommandText = "SELECT ISNULL(CONVERT(NVARCHAR(8),MAX([SentToDWTime]),112),'') AS DT " + Environment.NewLine
                    + " FROM [CZ_MainGWPost]" + Environment.NewLine
                    + " WHERE [FlowStatus]=@FlowStatus";

                Cmd.Parameters.AddWithValue("@FlowStatus", valFlowStatus);

                r = DB.ExecuteScalar(Cmd);
                return r;             

            }
        }

        catch (Exception ex)
        {
            throw new Exception("查詢等待資料倉儲回覆之檔案日期發生錯誤。錯誤訊息：" + ex.Message);
        }
    }


    /// <summary>
    /// 取得詢證函項目
    /// </summary>
    /// <param name="valCaseNo"></param>
    /// <returns>詢證函項目</returns>
    public string getItemDescByTableName(string valTableName)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {

                Cmd.CommandText = "SELECT [dbo].[ufn_CZ_GetItemDesc](@TableName)";

                Cmd.Parameters.AddWithValue("@TableName", valTableName);

                return DB.ExecuteScalar(Cmd);

            }
        }

        catch (Exception ex)
        {
            throw new Exception("查詢詢證函項目時發生錯誤。錯誤訊息：" + ex.Message);
        }
    }

    /// <summary>
    /// 取得詢證函項目說明
    /// </summary>
    /// <param name="valCaseNo"></param>
    /// <returns>詢證函項目說明</returns>
    public string getTableNoteByTableName(string valTableName)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {

                Cmd.CommandText = "SELECT [dbo].[ufn_CZ_GetTableNote](@TableName)";

                Cmd.Parameters.AddWithValue("@TableName", valTableName);

                return DB.ExecuteScalar(Cmd);

            }
        }

        catch (Exception ex)
        {
            throw new Exception("查詢詢證函項目說明時發生錯誤。錯誤訊息：" + ex.Message);
        }
    }


    /// <summary>
    /// 取得案件所屬分行
    /// </summary>
    /// <param name="valCaseNo"></param>
    /// <returns></returns>
    public string getBranchByCaseNo(string valCaseNo)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {

                string r;
                Cmd.CommandText = "SELECT [Branch] " + Environment.NewLine
                    + " FROM [CZ_Main]" + Environment.NewLine
                    + " WHERE [CaseNo]=@CaseNo";

                Cmd.Parameters.AddWithValue("@CaseNo", valCaseNo);

                r = DB.ExecuteScalar(Cmd);

                if (!string.IsNullOrEmpty(r))
                {
                    return r;
                }
                else
                {
                    throw new Exception("查無案件！");
                }

            }
        }

        catch (Exception ex)
        {
            throw new Exception("查詢案件所屬分行發生錯誤。錯誤訊息：" + ex.Message);
        }
    }


    /// <summary>
    /// 取得案件狀態
    /// </summary>
    /// <param name="valCaseNo"></param>
    /// <returns></returns>
    public int getFlowStatusByCaseNo(string valCaseNo)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {

                string r;
                Cmd.CommandText = "SELECT [FlowStatus] " + Environment.NewLine
                    + " FROM [CZ_Main]" + Environment.NewLine
                    + " WHERE [CaseNo]=@CaseNo";

                Cmd.Parameters.AddWithValue("@CaseNo", valCaseNo);

                r = DB.ExecuteScalar(Cmd);

                if (!string.IsNullOrEmpty(r))
                {
                    return Int32.Parse(r);
                }
                else
                {
                    throw new Exception("查無案件！");
                }

            }
        }

        catch (Exception ex)
        {
            throw new Exception("查詢案件狀態發生錯誤。錯誤訊息：" + ex.Message);
        }
    }



    /// <summary>
    /// 取得通知經辦填報案件清單
    /// </summary>
    /// <param name="valFlowStatus"></param>
    /// <param name="valImportTime"></param>
    /// <returns>DataTable</returns>
    public DataTable getAlertCaseNoList(int valFlowStatus, string valImportTime)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();



            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT [CaseNo]" + Environment.NewLine
                     + " FROM [CZ_Main]" + Environment.NewLine
                     + "  WHERE [FlowStatus]=@FlowStatus" + Environment.NewLine
                     + " AND CAST([ImportTime] AS DATE)=CAST(@ImportTime AS DATE)";

                Cmd.CommandText = str;
                Cmd.Parameters.AddWithValue("@FlowStatus", valFlowStatus);
                Cmd.Parameters.AddWithValue("@ImportTime", valImportTime);

                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得通知經辦填報清單發生錯誤：" + ex.Message);
        }
    }



    /// <summary>
    /// 取得通知管理單位經辦未處理案件清單
    /// </summary>
    /// <param name="valFlowStatus"></param>
    /// <param name="valImportTime"></param>
    /// <returns>DataTable</returns>
    public DataTable getAlertUncompletedCaseNoList(int valFlowStatus, string valImportTime)
    {
        try
        {
            clsSQLAgent DB = new clsSQLAgent();

            using (SqlCommand Cmd = new SqlCommand())
            {
                string str = "SELECT [CaseNo]" + Environment.NewLine
                     + " FROM [CZ_Main]" + Environment.NewLine
                     + " WHERE CAST([ImportTime] AS DATE)<=CAST(@ImportTime AS DATE)" + Environment.NewLine
                     + " AND [FlowStatus]>@FlowStatus" + Environment.NewLine
                     + " AND [CloesdTime] IS NULL";

                Cmd.CommandText = str;
                Cmd.Parameters.AddWithValue("@FlowStatus", valFlowStatus);
                Cmd.Parameters.AddWithValue("@ImportTime", valImportTime);

                return DB.GetDataTableBySQL(Cmd);
            }
        }
        catch (Exception ex)
        {
            throw new Exception("取得通知管理單位經辦未處理案件清單發生錯誤：" + ex.Message);
        }
    }

    #endregion

}
