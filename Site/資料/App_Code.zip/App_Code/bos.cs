﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// bos 的摘要描述
/// </summary>
public class bos : clsSQLAgent
{
    public static string cnnstr_CHBSC = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["chb_pub"].ToString();
    public static string cnnstr_iom = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["chb_iom"].ToString();
    public static string cnnstr_chb_pub = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["chb_pub1"].ToString();
    public static string cnnstr_chb_eform = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["chb_eform"].ToString();
    public static string cnnstr_CHECKIN = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["CHECKIN"].ToString();

    public static DataView GetDataView(string cnnstr, string sql)
    {
        DataTable dt = GetDataTable(cnnstr, sql);

        DataView dv = dt.DefaultView;

        return dv;
    }

    public static DataTable GetDataTable(string cnnstr, string sql)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sql;

        DataTable dt = GetDataTable(cnnstr, cmd);

        return dt;
    }

    public static DataView GetDataView(string cnnstr, SqlCommand cmd)
    {
        DataTable dt = GetDataTable(cnnstr, cmd);

        DataView dv = dt.DefaultView;

        return dv;
    }

    public static DataTable GetDataTable(string cnnstr, SqlCommand cmd)
    {
        SqlConnection conn = new SqlConnection(cnnstr);

        cmd.Connection = conn;

        DataSet ds = new DataSet();

        try
        {
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(ds);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message + "," + cmd.CommandText);
        }
        finally
        {
            cmd.Dispose();

            if (conn != null)
                conn.Close();
        }

        return ds.Tables[0];
    }

    public static void transCommit(string cnnstr, SqlCommand cmd)
    {
        using (SqlConnection cnn = new SqlConnection(cnnstr))
        {
            cnn.Open();

            SqlTransaction trans = cnn.BeginTransaction("ContentTransaction");

            try
            {
                cmd.Connection = cnn;
                cmd.Transaction = trans;

                cmd.ExecuteNonQuery();

                trans.Commit();
            }
            catch (Exception ex)
            {
                trans.Rollback();
            }
            finally
            {
                cmd.Cancel();
                cmd.Dispose();

                trans.Dispose();
            }
        }
    }

    public static void transCommit(string cnnstr, Queue<SqlCommand> queue)
    {
        if (queue.Count > 0)
        {
            using (SqlConnection cnn = new SqlConnection(cnnstr))
            {
                cnn.Open();

                SqlTransaction trans = cnn.BeginTransaction("ContentTransaction");

                try
                {
                    foreach (SqlCommand cmd in queue)
                    {
                        cmd.Connection = cnn;
                        cmd.Transaction = trans;

                        cmd.ExecuteNonQuery();
                    }

                    trans.Commit();
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    throw new Exception("執行時發生錯誤！錯誤訊息：" + ex.Message);
                }
                finally
                {
                    foreach (SqlCommand cmd in queue)
                    {
                        cmd.Cancel();
                        cmd.Dispose();
                    }

                    trans.Dispose();
                }
            }
        }
    }
}