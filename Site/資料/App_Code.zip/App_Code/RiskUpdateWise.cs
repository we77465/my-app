﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Resources;
using System.Data.SqlClient;
using System.Web.Script.Serialization;
using System.Net;
using System.IO;
using System.Data.Odbc;
using System.Globalization;
using System.Data.OleDb;
using System.Data;
using System.Text.RegularExpressions;
using System.Web.Configuration;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

/// <summary>
/// RiskUpdateWise 的摘要描述
/// </summary>
public class RiskUpdateWise
{
    public static string[] CRC = CRCString();

    //0291-財富管理處 1094-信託處 1230-資金營運處 1334-保險代理人處 0501-資訊處 0051-稽核處
    //20210705 依需求單R110070291005增加法遵處
    public static string[] HeadOffice = { "0291", "1094", "1230", "1334", "0501", "0051" ,"0284"};

    public RiskUpdateWise()
	{
		//
		// TODO: 在這裡新增建構函式邏輯
		//
	}
    protected static string[] CRCString()
    {
        List<string> CRC = new List<string>();
        DataTable result = new DataTable();
        using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_pub1"].ToString()))
        {
            cn.Open();
            string SqlCmd = "SELECT distinct CRCNO FROM crc_rel_br";
            using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            CRC.Add(dr["CRCNO"].ToString());
                        }
                        //result.Load(dr);
                    }
                }
            }
        }
        return CRC.ToArray();
    }

    /// <summary>
    /// 更新基金系統(WISE)
    /// </summary>
    /// <param name="cusId"></param>
    /// <param name="cuLvl"></param>
    /// <param name="cuAssmDate"></param>
    /// <param name="cuName"></param>
    public bool UpdateWise(string partyId)
    {
        if (RiskParameter.UPDATE_WISE == "N")
        {
            return true;
        }
        else
        {
            try
            {
                string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString;
                string cusId = string.Empty;
                string cuLvl = string.Empty;
                string cuAssmDate = string.Empty;
                string cuName = string.Empty;
                string riskLvlLastUpdStaff = string.Empty;
                string OVER65DATE = string.Empty;

                this.GetRisk(partyId, out cusId, out cuLvl, out cuAssmDate, out cuName, out riskLvlLastUpdStaff);

                //20220817 另外撈取交易日不更動GetRisk Fuction
                string OVERDCmd = @"SELECT isnull(OVER65DATE,'') FROM [iom].[dbo].[RISK] WHERE ID = @ID ;";
                SqlCommand cmd = new SqlCommand(OVERDCmd);
                cmd.Parameters.AddWithValue("ID", partyId);
                DataView dv = bos.GetDataView(bos.cnnstr_iom, cmd);
                if (dv.Count > 0)
                    OVER65DATE = dv[0][0].ToString();

                var httpWebRequest = (HttpWebRequest)WebRequest.Create(RiskParameter.WISE_API);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";

                JavaScriptSerializer serializer = new JavaScriptSerializer();

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    var obj = new { cuId = cusId, cuLvl = cuLvl, cuAssmDate = cuAssmDate, cuName = cuName, riskLvlLastUpdStaff = riskLvlLastUpdStaff, OVER65DATE= OVER65DATE };
                    streamWriter.Write(serializer.Serialize(obj));
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    WiseUpdateResult i = serializer.Deserialize<WiseUpdateResult>(result);

                    if (i.ResultCode == "N")
                    {
                        return false;
                    }
                }

                return true;
            }
            catch
            {
                return false;
            }
            
        }
    }

    /// <summary>
    /// 更新基金系統(AS400)
    /// </summary>
    /// <param name="partyId">統編</param>
    /// <param name="cusLvl">風險屬性等級</param>
    /// <param name="cusName">姓名</param>
    /// <param name="evalDate">登打日期</param>
    /// <returns></returns>
    public bool UpdateAS400(string partyId,bool show_Exception=false)
    {

        if (RiskParameter.UPDATE_WISE == "Y")
        {
            return true;
        }
        else
        {

            partyId = partyId.Trim();

            string iomConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString;

            string cusId = string.Empty;
            string cuLvl = string.Empty;
            string cuAssmDate = string.Empty;
            string cuName = string.Empty;
            string riskLvlLastUpdStaff = string.Empty;

            //取得客戶風險屬性資料
            this.GetRisk(partyId, out cusId, out cuLvl, out cuAssmDate, out cuName, out riskLvlLastUpdStaff);

            partyId = partyId.Trim();
            cusId = cusId.Trim();
            cuAssmDate = cuAssmDate.Trim();
            cuName = cuName.Trim();

            #region 更新中菲系統的DB 2016/12/28 EDIT

            string connStr = string.Empty;
            string odbcCommand = string.Empty;
            string odbcCommand_Insert = string.Empty;

            //是否為正式環境
            if (RiskParameter.PRODUCTION == "N")
            {
                //測試套
                connStr = "Driver={iSeries Access ODBC Driver}; Force Translate=0;ALLOWUNSCHAR=1; System=10.100.7.147; Uid=RRUSERT; Pwd=RRUSERT;";
                odbcCommand = "DELETE FROM PTFLIBRWK.CTMFILRR WHERE CTMR01 = ?";
                odbcCommand_Insert = "INSERT INTO PTFLIBRWK.CTMFILRR (CTMR01,CTMR02,CTMR03) VALUES(?,?,?)";
                //odbcCommand_Insert = "INSERT INTO PTFLIBRWK.CTMFILRR (CTMR01,CTMR02,CTMR03,CTMR04) VALUES(?,?,?,?)";
            }
            else
            {
                //正式套
                connStr = "Driver={iSeries Access ODBC Driver}; Force Translate=0;ALLOWUNSCHAR=1; System=10.100.8.207; Uid=RRUSERP; Pwd=RR02USERP;";
                odbcCommand = "DELETE FROM PTFLIBR.CTMFILRR WHERE CTMR01= ?";
                odbcCommand_Insert = "INSERT INTO PTFLIBR.CTMFILRR (CTMR01,CTMR02,CTMR03) VALUES(?,?,?)";
                //odbcCommand_Insert = "INSERT INTO PTFLIBR.CTMFILRR (CTMR01,CTMR02,CTMR03,CTMR04) VALUES(?,?,?,?)";
            }

            using (OdbcConnection conn = new OdbcConnection(connStr))
            {
                try
                {
                    conn.Open();

                    OdbcCommand Cmd = new OdbcCommand(odbcCommand, conn);
                    //Cmd.Transaction = tran;
                    Cmd.Parameters.AddWithValue("ID", partyId);
                    //刪除舊資料
                    Cmd.ExecuteNonQuery();

                    Cmd.Parameters.Clear();
                    Cmd.CommandText = odbcCommand_Insert;

                    Cmd.Parameters.AddWithValue("ID", partyId);
                    Cmd.Parameters.AddWithValue("CLASS", cuLvl);
                    Cmd.Parameters.AddWithValue("DATE", cuAssmDate);
                    Cmd.Parameters.AddWithValue("NAME", cuName);

                    //新增資料
                    Cmd.ExecuteNonQuery();

                }
                catch (Exception e)
                {
                    if (show_Exception)
                    {
                        throw new Exception(e.Message);
                    }
                }
                finally
                {
                    conn.Close();
                    conn.Dispose();
                }
            }

            #endregion

            return true;
        }
    }

    /// <summary>
    /// 更新基金系統(AS400) OLEDB
    /// </summary>
    /// <param name="partyId">統編</param>
    /// <param name="cusLvl">風險屬性等級</param>
    /// <param name="cusName">姓名</param>
    /// <param name="evalDate">登打日期</param>
    /// <returns></returns>
    public bool UpdateAS400_OLEDB(string partyId)
    {

        if (RiskParameter.UPDATE_WISE == "Y")
        {
            return true;
        }
        else
        {
            partyId = partyId.Trim();

            string iomConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString;

            string cusId = string.Empty;
            string cuLvl = string.Empty;
            string cuAssmDate = string.Empty;
            string cuName = string.Empty;
            string riskLvlLastUpdStaff = string.Empty;

            this.GetRisk(partyId, out cusId, out cuLvl, out cuAssmDate, out cuName, out riskLvlLastUpdStaff);


            partyId = partyId.Trim();
            cusId = cusId.Trim();
            cuAssmDate = cuAssmDate.Trim();
            cuName = cuName.Trim();


            #region 更新中菲系統的DB 2016/12/28 EDIT

            string connStr = string.Empty;
            string odbcCommand = string.Empty;
            string odbcCommand_Insert = string.Empty;

            //是否為正式環境
            if (RiskParameter.PRODUCTION == "N")
            {
                //測試套
                //connStr = "Driver={iSeries Access ODBC Driver}; Force Translate=0;ALLOWUNSCHAR=1; System=10.100.7.147; Uid=RRUSERT; Pwd=RRUSERT;";
                connStr = "Provider=IBMDA400;Data Source=10.100.7.147;User ID=RRUSERT;Password=RRUSERT;Transport Product=Client Access;SSL=DEFAULT";
                odbcCommand = "DELETE FROM PTFLIBRWK.CTMFILRR WHERE CTMR01 = ?";
                odbcCommand_Insert = "INSERT INTO PTFLIBRWK.CTMFILRR (CTMR01,CTMR02,CTMR03) VALUES(?,?,?)";
            }
            else
            {
                //正式套
                connStr = "Provider=IBMDA400;Data Source=10.100.8.207;User ID=RRUSERP;Password=RR02USERP;Transport Product=Client Access;SSL=DEFAULT";
                odbcCommand = "DELETE FROM PTFLIBR.CTMFILRR WHERE CTMR01= ?";
                odbcCommand_Insert = "INSERT INTO PTFLIBR.CTMFILRR (CTMR01,CTMR02,CTMR03) VALUES(?,?,?)";
            }

            using (OleDbConnection conn = new OleDbConnection(connStr))
            {
                try
                {
                    conn.Open();

                    OleDbCommand Cmd = new OleDbCommand(odbcCommand, conn);
                    //Cmd.Transaction = tran;
                    Cmd.Parameters.AddWithValue("ID", partyId);
                    //刪除舊資料
                    Cmd.ExecuteNonQuery();

                    Cmd.Parameters.Clear();
                    Cmd.CommandText = odbcCommand_Insert;

                    Cmd.Parameters.AddWithValue("ID", partyId);
                    Cmd.Parameters.AddWithValue("CLASS", cuLvl);
                    Cmd.Parameters.AddWithValue("DATE", cuAssmDate);
                    Cmd.Parameters.AddWithValue("NAME", cuName);

                    //新增資料
                    Cmd.ExecuteNonQuery();

                }
                catch (Exception e)
                {
                    //throw new Exception(e.Message);
                }
                finally
                {
                    conn.Close();
                    conn.Dispose();
                }
            }

            #endregion

            return true;
        }
    }



    /// <summary>
    /// 更新財富管理系統
    /// </summary>
    /// <param name="partyId"></param>
    /// <returns></returns>
    public bool UpdateWMS(string partyId)
    {
        string cusId = string.Empty;
        string cuLvl = string.Empty;
        string cuAssmDate = string.Empty;
        string cuName = string.Empty;
        string riskLvlLastUpdStaff = string.Empty;

        this.GetRisk(partyId, out cusId, out cuLvl, out cuAssmDate, out cuName, out riskLvlLastUpdStaff);

        try
        {
            int date = Convert.ToInt32(cuAssmDate) + 19110000;
            DateTime dt = DateTime.ParseExact(date.ToString(), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None);
            //1年後風險屬性到期
            DateTime nextDt = dt.AddYears(1);

            using (SqlConnection Cnn = new SqlConnection(RiskParameter.WMS_CHB))
            {
                Cnn.Open();
                string riskCmd = "UPDATE WMSR5USR.CUSTOMERS SET NEXT_RANK_QUE_DT = @NEXTDATE,RANK_CODE = @CLASS,SELF_RANK_CODE = @CLASS,LAST_RANK_QUE_DT = @DATE, MODIFY_DT = GETDATE() WHERE CUS_CODE = @ID";

                using (SqlCommand Cmd = new SqlCommand(riskCmd, Cnn))
                {
                    Cmd.Parameters.AddWithValue("NEXTDATE", nextDt.ToString("yyyy-MM-dd"));
                    Cmd.Parameters.AddWithValue("CLASS", cuLvl);
                    Cmd.Parameters.AddWithValue("DATE", dt.ToString("yyyy-MM-dd"));
                    Cmd.Parameters.AddWithValue("ID", cusId);

                    Cmd.ExecuteNonQuery();
                }
            }
        }
        catch
        {
            return false;
            //throw new Exception(ex.Message);
            //DB 讀取錯誤
        }

        return true;
    }


    /// <summary>
    /// 取得客戶風險屬性資料
    /// </summary>
    /// <param name="partyId">統編</param>
    /// <param name="cusId"></param>
    /// <param name="cuLvl"></param>
    /// <param name="cuAssmDate"></param>
    /// <param name="cuName"></param>
    /// <param name="riskLvlLastUpdStaff"></param>
    public void GetRisk(string partyId, out string cusId, out string cuLvl, out string cuAssmDate, out string cuName, out string riskLvlLastUpdStaff)
    {
        string iomConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString;
        cusId = string.Empty;
        cuLvl = string.Empty;
        cuAssmDate = string.Empty;
        cuName = string.Empty;
        riskLvlLastUpdStaff = string.Empty;

        try
        {
            using (SqlConnection Cnn = new SqlConnection(iomConnStr))
            {
                Cnn.Open();
                string riskCmd = "SELECT * FROM [iom].[dbo].[RISK] WHERE ID = @ID";

                using (SqlCommand Cmd = new SqlCommand(riskCmd, Cnn))
                {
                    Cmd.Parameters.AddWithValue("ID", partyId);

                    SqlDataReader reader = Cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            cusId = Convert.ToString(reader["ID"]);
                            cuLvl = Convert.ToString(reader["CLASS"]);
                            cuAssmDate = Convert.ToString(reader["DATE"]);
                            cuName = Convert.ToString(reader["NAME"]);
                            riskLvlLastUpdStaff = Convert.ToString(reader["KEYIN"]);
                        }
                    }
                }
            }
        }
        catch(Exception ex)
        {
            throw new Exception(ex.Message);
            //DB 讀取錯誤
        }
    }
    
    /// <summary>
    /// 確認本日客戶是否有承作風險屬性
    /// </summary>
    /// <param name="partyId">統編</param>
    /// <returns></returns>
    public DataView CheckRiskRecord5Days(string partyId)
    {
        string riskCmd = @"SELECT TOP 1 *,
                                        convert(varchar, convert(varchar, DATEADD(day, 5, Convert(varchar(4), (Convert(int, SUBSTRING(DATE, 1, 3)) + 1911)) + '/' + SUBSTRING(DATE, 4, 2) + '/' + SUBSTRING(DATE, 6, 2)), 111)) as NextDate
                                        FROM[iom].[dbo].[RISK]
                                        WHERE SOURCE NOT IN ('SysBatch')
                                        AND(DATEDIFF(day, convert(varchar, DATEADD(day, 5, Convert(varchar(4), (Convert(int, SUBSTRING(DATE, 1, 3)) + 1911)) + '/' + SUBSTRING(DATE, 4, 2) + '/' + SUBSTRING(DATE, 6, 2)), 111), getdate())) < 0
                                        AND ID = @ID";

        SqlCommand cmd = new SqlCommand(riskCmd);
        cmd.Parameters.AddWithValue("ID", partyId);

        DataView dv = bos.GetDataView(bos.cnnstr_iom, cmd);

        return dv;
    }

    /// <summary>
    /// 確認本日客戶是否有承作風險屬性(低轉高未放行)
    /// </summary>
    /// <param name="partyId">統編</param>
    /// <returns></returns>
    public bool CheckApprovedRiskRecord(string partyId)
    {
        string iomConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString;

        try
        {
            using (SqlConnection Cnn = new SqlConnection(iomConnStr))
            {
                Cnn.Open();

                string riskCmd = @"SELECT * FROM [iom].[dbo].[RISK_APPROVE] WHERE  ID = @ID";

                using (SqlCommand Cmd = new SqlCommand(riskCmd, Cnn))
                {
                    Cmd.Parameters.AddWithValue("ID", partyId);

                    SqlDataReader reader = Cmd.ExecuteReader();

                    return reader.HasRows;
                }
            }
        }
        catch
        {
            return true;
            //throw new Exception(ex.Message);
            //DB 讀取錯誤
        }
    }

}
/// <summary>
/// WISE更新結果
/// </summary>
public class WiseUpdateResult
{
    public string ResultCode { get; set; }
}

public class RiskUtils
{
    public static F0101 GetF0101Rs(string empid, string partyId, string taskname, string brno)
    {
        F0101 f0101 = new F0101(empid, taskname);

        f0101.dic_Rq.Add(f0101.Q_KINBR, brno);
        // 查詢方式(1:依統一編號,2:依帳號,3:依顧客號碼,4:依保管序號)
        f0101.dic_Rq.Add(f0101.Q_INQCD, "5");
        f0101.dic_Rq.Add(f0101.Q_CIFKEY, partyId);

        f0101.GetRS();

        return f0101;
    }

    public static bool isBRNO(string[] chkBRNO, string sBRNO)
    {
        for (int i = 0; i < chkBRNO.Length; i++)
        {
            if (sBRNO == chkBRNO[i])
                return true;
        }

        return false;
    }

    public static bool CheckUniformNo(string strCardno)
    {
        Regex monitor = new Regex(@"^[0-9]*$");

        if (!monitor.IsMatch(strCardno))
            return false;

        if (strCardno.Trim().Length < 8)
        {
            return false;
        }
        else
        {
            int[] intTmpVal = new int[6];
            int intTmpSum = 0;
            for (int i = 0; i < 6; i++)
            {
                //位置在奇數位置的*2，偶數位置*1，位置計算從0開始
                if (i % 2 == 1)
                    intTmpVal[i] = overTen(int.Parse(strCardno[i].ToString()) * 2);
                else
                    intTmpVal[i] = overTen(int.Parse(strCardno[i].ToString()));

                intTmpSum += intTmpVal[i];
            }
            intTmpSum += overTen(int.Parse(strCardno[6].ToString()) * 4); //第6碼*4
            intTmpSum += overTen(int.Parse(strCardno[7].ToString())); //第7碼*1

            if (intTmpSum % 5 != 0) //除以10後餘0表示正確，反之則錯誤
                return false;
        }
        return true;
    }

    private static int overTen(int intVal) //超過10則十位數與個位數相加，直到相加後小於10
    {
        if (intVal >= 10)
            intVal = overTen((intVal / 10) + (intVal % 10));

        return intVal;
    }

    public static bool isIdentificationId(string sCustID)
    {
        if (sCustID.Length != 10)
            return false;

        Regex regex = new Regex("^[A-Z]{1}[0-9]{9}$");

        if (!regex.IsMatch(sCustID))
            return false;

        //除了檢查碼外每個數字的存放空間 
        int[] seed = new int[10];

        //建立字母陣列(A~Z)
        //A=10 B=11 C=12 D=13 E=14 F=15 G=16 H=17 J=18 K=19 L=20 M=21 N=22
        //P=23 Q=24 R=25 S=26 T=27 U=28 V=29 X=30 Y=31 W=32  Z=33 I=34 O=35            
        string[] charMapping = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V", "X", "Y", "W", "Z", "I", "O" };
        string target = sCustID.Substring(0, 1); //取第一個英文數字
        for (int index = 0; index < charMapping.Length; index++)
        {
            if (charMapping[index] == target)
            {
                index += 10;
                //10進制的高位元放入存放空間   (權重*1)
                seed[0] = index / 10;

                //10進制的低位元*9後放入存放空間 (權重*9)
                seed[1] = (index % 10) * 9;

                break;
            }
        }
        for (int index = 2; index < 10; index++) //(權重*8~1)
        {   //將剩餘數字乘上權數後放入存放空間                
            seed[index] = Convert.ToInt32(sCustID.Substring(index - 1, 1)) * (10 - index);
        }

        //檢查是否符合檢查規則，10減存放空間所有數字和除以10的餘數的個位數字是否等於檢查碼            
        //(10 - ((seed[0] + .... + seed[9]) % 10)) % 10 == 身分證字號的最後一碼   
        if ((10 - ((seed[0] + seed[1] + seed[2] + seed[3] + seed[4] + seed[5] + seed[6] + seed[7] + seed[8] + seed[9]) % 10)) % 10 != Convert.ToInt32(sCustID.Substring(9, 1)))
            return false;

        return true;
    }

    public static DataView GetRiskView(string sQA, string sPTYPE)
    {
        string sSQL = "SELECT * FROM RISKNUMBER WHERE QA ='"+ sQA + "' AND PTYPE ='"+ sPTYPE + "'  ";
        sSQL += "AND START_DATE = (SELECT MAX(START_DATE) FROM RISKNUMBER WHERE QA ='" + sQA + "' AND PTYPE ='" + sPTYPE + "' ) ";
        sSQL += "Order by convert(int, ITEM) ";

        DataView dvGrade = bos.GetDataView(bos.cnnstr_iom, sSQL);

        return dvGrade;
    }

    public static DataView GetRiskViewVersion(string sQA, string sPTYPE, string sDate)
    {
        string tSQL = "SELECT count(1) FROM RISKNUMBER WHERE QA ='" + sQA + "' AND PTYPE ='" + sPTYPE + "'  AND START_DATE < '" + sDate + "'  ";
        DataView dvCount = bos.GetDataView(bos.cnnstr_iom, tSQL);
        DataView dvGrade;
        string sSQL;
        if (dvCount[0][0].ToString() == "0")
        {
            sSQL = "SELECT * FROM RISKNUMBER WHERE QA ='" + sQA + "' AND PTYPE ='" + sPTYPE + "'  ";
            sSQL += "AND START_DATE = (SELECT MAX(START_DATE) FROM RISKNUMBER WHERE QA ='" + sQA + "' AND PTYPE ='" + sPTYPE + "' ) ";
            sSQL += "Order by convert(int, ITEM) ";
        }else
        {
            sSQL = "SELECT * FROM RISKNUMBER WHERE QA ='" + sQA + "' AND PTYPE ='" + sPTYPE + "'  ";
            sSQL += "AND START_DATE = (SELECT MAX(START_DATE) FROM RISKNUMBER WHERE QA ='" + sQA + "' AND PTYPE ='" + sPTYPE + "' AND START_DATE < '" + sDate + "' ) ";
            sSQL += "Order by convert(int, ITEM) ";
        }
        dvGrade = bos.GetDataView(bos.cnnstr_iom, sSQL);
        return dvGrade;
    }

    public static int GetScore(DataView dv, string sItem, string sType)
    {
        if (sType.Length == 1)
        {
            dv.RowFilter = "ITEM = '" + sItem + "' And TYPE = '" + sType + "'";
            if (dv.Count > 0)
                return int.Parse(dv[0]["NUMBER"].ToString());
        }
        else if (sType.Length > 1)
        {
            int iScore = 0;
            int iLength = sType.Length;

            for (int i = 0; i < iLength; i++)
            {
                dv.RowFilter = "ITEM = '" + sItem + "' And TYPE = '" + sType.Substring(i, 1) + "'";
                if(dv.Count > 0)
                {
                    int score = int.Parse(dv[0]["NUMBER"].ToString());
                    if (score > 0)
                    {
                        if (score > iScore)
                            iScore = score;
                    }
                    else
                    {
                        //負數問題
                        if (iScore == 0)
                            iScore = score;
                        else
                        {
                            if (score < iScore)
                                iScore = score;
                        }
                    }
                }
            }

            return iScore;
        }

        return 0;
    }

    public static string GetCustName(string sCustID)
    {
        DataView dv = bos.GetDataView(RiskParameter.WMS_CHB_BATCH, "SELECT TOP 1 PARTY_NAME FROM [WMSR5_CHB_BATCH].[WMSR5USR].[WMS_PARTY_UNI] WITH(NOLOCK) WHERE PARTY_ID = '" + sCustID + "'");

        if (dv.Count > 0)
            return dv[0]["PARTY_NAME"].ToString();

        return "";
    }

    public static string GetCustBirthDay(string sCustID)
    {
        DataView dv = bos.GetDataView(RiskParameter.WMS_CHB, "SELECT TOP 1 * FROM [WMSR5_CHB].[WMSR5USR].[CUSTOMERS_VIEW] WITH(NOLOCK) WHERE CUS_CODE = '" + sCustID + "'");

        if (dv.Count > 0)
        {
            string sYY = dv[0]["BIRTH_YY"].ToString();
            string sMM = dv[0]["BIRTH_MM"].ToString();
            string sDD = dv[0]["BIRTH_DD"].ToString();

            return sYY + "/" + sMM + "/" + sDD;
        }

        return "";
    }

    public static string GetAGE(string sBirthday)
    {
        if (sBirthday != "" && sBirthday != null)
        {
            DateTime now = DateTime.Now;
            DateTime dTime = DateTime.Parse(sBirthday);

            int age = now.Year - dTime.Year;
            if (now.Month < dTime.Month || (now.Month == dTime.Month && now.Day < dTime.Day)) age--;

            return age.ToString();
        }

        return "";
    }

    public static string GetSource(string sSOURCE)
    {
        if (sSOURCE == "IntraWeb")
            return "臨櫃";
        else if (sSOURCE == "Web")
            return "網銀";
        else if (sSOURCE == "STM")
            return "STM";
        else
            return "外出取件";
    }

    public static string GetClassName(string sClass)
    {
        if (sClass == "5")
            return "積極型";
        else if (sClass == "4")
            return "成長型";
        else if (sClass == "3")
            return "平衡型";
        else if (sClass == "2")
            return "穩健型";
        else
            return "保守型";
    }

    public static string GetClassName(string sPTYPE, int iScore)
    {
        if (sPTYPE == "N")
        {
            if (iScore > 66)
                return "5.積極型";
            else if (iScore > 54)
                return "4.成長型";
            else if (iScore > 39)
                return "3.平衡型";
            else if (iScore > 24)
                return "2.穩健型";
            else
                return "1.保守型";
        }
        else
        {
            if (iScore > 69)
                return "5.積極型";
            else if (iScore > 54)
                return "4.成長型";
            else if (iScore > 39)
                return "3.平衡型";
            else if (iScore > 29)
                return "2.穩健型";
            else
                return "1.保守型";
        }
    }
    public static bool ValidateServerCertificate(Object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
    {
        return true;
    }
    /// <summary>呼叫文件掃描系統Web Service</summary>
    /// <param name="FullCode">類別：CM0106 投資風險屬性評量表、CM0107 專業投資人資格申請書</param>
    /// <param name="Brno">單位代號</param>
    /// <param name="UserID">使用者員編</param>
    /// <param name="CustID">客戶統編</param>
    /// <returns>成功：SendSN匯入序號，失敗：錯誤訊息</returns>
    public static string DMSScan(string FullCode, string Brno, string UserID, string CustID)
    {
        string sn = "ITA" + Brno.Substring(0, 3) + UserID.Substring(0, 5) + DateTime.Now.ToString("yyyyMMddHHmmss");
        string DocName = FullCode == "CM0107" ? "專業投資人資格申請書" : "投資風險屬性評量表";
        CustID = CustID.Trim();
        string DMSReturn;
        try
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(ValidateServerCertificate);
            DMSService.DocServiceSoapClient docServiceSoap = new DMSService.DocServiceSoapClient();
            DMSReturn = docServiceSoap.NewSysInScan("ITA", "1", sn, DocName, Brno, CustID, "", FullCode, "", "", "", "", "", "", "");
            string InsertSQL = "INSERT INTO [dbo].[RISK_Scan]([SendSN],[FullCode],[Brno],[CustID],[ReturnValue],[UserID],[SendTime])" +
                "VALUES('" + sn + "','" + FullCode + "','" + Brno + "','" + CustID + "','" + DMSReturn + "','" + UserID + "',GETDATE());select 1 ;";
            DataView dv = bos.GetDataView(bos.cnnstr_iom, InsertSQL);
        }
        catch (Exception ex)
        {
            return "錯誤訊息：" + ex.Message;
        }
        if (!DMSReturn.Contains("00000"))
            sn = DMSReturn.Split('"')[3];
        else
            sn = "匯入序號" + sn;
        return sn;
    }
}

[Serializable]
public class Risk
{
    /// <summary>
    /// 1=自然人 2=法人
    /// </summary>
    public string CR_TIME { get; set; }
    public int CusType { get; set; }
    public string ID { get; set; }
    public string CLASS { get; set; }
    public string DATE { get; set; }
    public string NAME { get; set; }
    public string ITEM1 { get; set; }
    public string ITEM2 { get; set; }
    public string ITEM3 { get; set; }
    public string ITEM4 { get; set; }
    public string ITEM5 { get; set; }
    public string ITEM6 { get; set; }
    public string ITEM7 { get; set; }
    public string ITEM8 { get; set; }
    public string ITEM9 { get; set; }
    public string ITEM10 { get; set; }
    public string ITEM11 { get; set; }
    public string ITEM12 { get; set; }
    public string ITEM13 { get; set; }
    public string ITEM14 { get; set; }
    public string ITEM15 { get; set; }
    public string ITEM16 { get; set; }
    public string ITEM17 { get; set; }
    public string ITEM18 { get; set; }
    public string ITEM19 { get; set; }
    public string ITEM20 { get; set; }
    public string KEYIN { get; set; }
    public string SOURCE { get; set; }
    public string BRNO { get; set; }
    public string CUST_NBR { get; set; }
    public string OWNER_ID { get; set; }
    public string OWNER_NAME { get; set; }
    public string AGENT_ID { get; set; }
    public string AGENT_NAME { get; set; }
    public string KEYIN_NEW { get; set; }
    public string NOT_AGREE { get; set; }
    public string MANAGER { get; set; }
    public string SI_IND { get; set; }
    public string PRODUCT_TYPE { get; set; }
    public string CONFIRMPage { get; set; }
    public string FillinDate { get; set; }
    public string DISEASE { get; set; }
    public string FINANCIALINF { get; set; }
    public string CONFIRMY { get; set; }
    public string OVER65DATE { get; set; }
    public string SCORE { get; set; }
    public string preCLASS { get; set; }
    
}
