﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// CheckID 的摘要描述
/// </summary>
public class CheckID
{
	public string check(string strID)
	{
        int[] num = new int[8];
        num[0] = 1;
        num[1] = 2;
        num[2] = 1;
        num[3] = 2;
        num[4] = 1;
        num[5] = 2;
        num[6] = 4;
        num[7] = 1;
        if (strID.Trim().ToString().Length != 8)
            return "統編輸入錯誤!";

        int[] id = new int[8];
        id[0] = int.Parse(strID.Substring(0,1));
        id[1] = int.Parse(strID.Substring(1,1));
        id[2] = int.Parse(strID.Substring(2,1));
        id[3] = int.Parse(strID.Substring(3,1));
        id[4] = int.Parse(strID.Substring(4,1));
        id[5] = int.Parse(strID.Substring(5,1));
        id[6] = int.Parse(strID.Substring(6,1));
        id[7] = int.Parse(strID.Substring(7,1));

        int sum = 0;
        for (int i = 0; i < 8; i++)
        {
            sum += process( num[i] * id[i] );
        }

        if (sum % 10 == 0)
        {
            return "統編正確";
        }
        else if (id[6] == 7 && (sum+1)%10==0)
        {
            return "統編正確";
        }
        else
        {
            return "統一編號輸入錯誤!";
        }
	}
    public int process(int n)
    {
        if (n > 9)
        {
            int a1 = int.Parse(n.ToString().Substring(0,1));
            int a2 = int.Parse(n.ToString().Substring(1,1));
            n = a1 + a2;
            return n;
        }
        else
            return n;
    }
}
