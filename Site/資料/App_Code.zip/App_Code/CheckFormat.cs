﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Text.RegularExpressions;

/// <summary>
/// CheckFormat 的摘要描述
/// </summary>
public class CheckFormat
{
	public CheckFormat()
	{
		//
		// TODO: 在此加入建構函式的程式碼
		//
	}
    /// <summary>
    /// 檢查是否為數字
    /// </summary>
    /// <param name="strToCheck"></param>
    /// <returns></returns>
    public static bool IsAlphaNumeric(String strToCheck)
    {
        Regex objAlphaNumericPattern = new Regex("[^a-zA-Z0-9]");
        if (strToCheck == string.Empty)
            return false;
        else
        return !objAlphaNumericPattern.IsMatch(strToCheck);
    }

    /// <summary>
    /// 檢查是否為正整數包括零
    /// </summary>
    /// <param name="strNumber"></param>
    /// <returns></returns>
    public static bool IsWholeNumber(String strNumber)
    {
        Regex objNotWholePattern = new Regex("[^0-9]");
        if (strNumber == string.Empty)
            return false;
        else
        return !objNotWholePattern.IsMatch(strNumber);
    }

    /// <summary>
    /// 檢查自然數包括實數
    /// </summary>
    /// <param name="strNumber"></param>
    /// <returns></returns>
    public static bool IsPositiveNumber(String strNumber)
    {
        Regex objNotPositivePattern = new Regex("[^0-9.]");
        Regex objPositivePattern = new Regex("^[.][0-9]+$|[0-9]*[.]*[0-9]+$");
        Regex objTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*");
        if (strNumber == string.Empty)
            return false;
        else
        return !objNotPositivePattern.IsMatch(strNumber) &&
        objPositivePattern.IsMatch(strNumber) &&
        !objTwoDotPattern.IsMatch(strNumber);
    }
    /// <summary>
    /// 檢查是否為合法email
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsEmail(string InputString)
    {
        string strRegex = @"^\w+((-\w+)|(\.\w+))*\@\w+((\.|-)\w+)*\.\w+$";
        //string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查輸入數字是否位數符合
    /// </summary>
    /// <param name="InputString"></param>
    /// <param name="median"></param>
    /// <returns></returns>
    public static bool IsNumberMedianMatch(string InputString, int median)
    {
        string strRegex = @"^\d{" + median.ToString() + "}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查輸入數字是否最少為n位數
    /// </summary>
    /// <param name="InputString"></param>
    /// <param name="median">n</param>
    /// <returns></returns>
    public static bool IsNumberMedianMatchlast(string InputString, int median)
    {
        string strRegex = @"^\d{" + median.ToString() + ",}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查輸入數字是否在MAX到MIN位數
    /// </summary>
    /// <param name="InputString"></param>
    /// <param name="Max">最大位數</param>
    /// <param name="Min">最小位數</param>
    /// <returns></returns>
    public static bool IsNumberInRange(string InputString, int Max, int Min)
    {
        string strRegex = @"^\d{" + Max.ToString() + "," + Min.ToString() + "}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為金額 小數固定為兩位
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsAmount(string InputString)
    {
        string strRegex = "^[0-9]+(.[0-9]{2})?$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為金額 小數為一位或兩位
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsAmountLast(string InputString)
    {
        string strRegex = "^[0-9]+(.[0-9]{1,2})?$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為非零的正整數
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsPositiveInteger(string InputString)
    {
        string strRegex = @"^\+?[1-9][0-9]*$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為非零的負整數
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsNegativeInteger(string InputString)
    {
        string strRegex = @"^\-?[1-9][0-9]*$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查字串是否符合長度
    /// </summary>
    /// <param name="InputString"></param>
    /// <param name="median"></param>
    /// <returns></returns>
    public static bool IsStringMatchLength(string InputString, int median)
    {
        string strRegex = "^.{" + median.ToString() + "}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 是否為符合型式的密碼,字母開頭,長度6~18,字母及數字和下底線混合
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsValidPassword(string InputString)
    {
        string strRegex = @"^[a-zA-Z]\w{5,17}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為網址
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsWebSite(string InputString)
    {
        string strRegex = @"^http://([\w-]+\.)+[\w-]+(/[\w-./?%&=]*)?$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為月份 01~09 , 1~12
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsMonth(string InputString)
    {
        string strRegex = "^(0?[1-9]|1[0-2])$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為日期 01~09 , 1~31
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsDay(string InputString)
    {
        string strRegex = "^((0?[1-9])|((1|2)[0-9])|30|31)$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }

    /// <summary>
    /// 檢查是否有下列符號 ^%&’,;=?$\"
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsDelimiter(string InputString)
    {
        string strRegex = "[^%&’,;=?$\x22]+";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }

    /// <summary>
    /// 檢查是否有逗點分割的字串
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsDotString(string InputString)
    {
        string strRegex = @"^([\w\d\u4e00-\u9fa5],?)+$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為漢字
    /// </summary>
    /// <param name="InputString"></param>
    /// <returns></returns>
    public static bool IsChiWord(string InputString)
    {
        string strRegex = "^[\u4e00-\u9fa5]{0,}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為手機號碼.
    /// </summary>
    /// <param name="InputString">The input email.</param>
    /// <returns>
    /// 	<c>true</c> if [is cell phone] [the specified input email]; otherwise, <c>false</c>.
    /// </returns>
    public static bool IsCellPhone(string InputString)
    {
        string strRegex = "^[0-9]{4}-[0-9]{6}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(InputString))
            return (true);
        else
            return (false);
    }

    /// <summary>
    ///
    /// 檢查是否為身分證字號
    /// </summary>
    /// <param name="ID"></param>
    /// <returns></returns>
    public static bool CHECKID(string ID)
    {
        if (ID.Length != 10) return false;
        string NEWID = "";
        int[] MULT = new int[] { 1, 9, 8, 7, 6, 5, 4, 3, 2, 1, 1 };
        int SUM = 0;
        bool RESULT = true;
        switch (ID.Substring(0, 1).ToUpper())
        {
            case "A":
                NEWID = "10";
                break;
            case "B":
                NEWID = "11";
                break;
            case "C":
                NEWID = "12";
                break;
            case "D":
                NEWID = "13";
                break;
            case "E":
                NEWID = "14";
                break;
            case "F":
                NEWID = "15";
                break;
            case "G":
                NEWID = "16";
                break;
            case "H":
                NEWID = "17";
                break;
            case "J":
                NEWID = "18";
                break;
            case "K":
                NEWID = "19";
                break;
            case "L":
                NEWID = "20";
                break;
            case "M":
                NEWID = "21";
                break;
            case "N":
                NEWID = "22";
                break;
            case "P":
                NEWID = "23";
                break;
            case "Q":
                NEWID = "24";
                break;
            case "R":
                NEWID = "25";
                break;
            case "S":
                NEWID = "26";
                break;
            case "T":
                NEWID = "27";
                break;
            case "U":
                NEWID = "28";
                break;
            case "V":
                NEWID = "29";
                break;
            case "X":
                NEWID = "30";
                break;
            case "Y":
                NEWID = "31";
                break;
            case "W":
                NEWID = "32";
                break;
            case "Z":
                NEWID = "33";
                break;
            case "I":
                NEWID = "34";
                break;
            case "O":
                NEWID = "35";
                break;
            default:
                return false;
            // break;
        }
        NEWID += ID.Substring(1, 9);
        for (int i = 0; i < NEWID.Length; i++)
        {
            SUM += int.Parse(NEWID.Substring(i, 1)) * MULT[i];
        }
        if (SUM % 10 != 0) RESULT = false;
        return RESULT;
    }
    /// <summary>
    /// Determines whether [is correnct IP] [the specified STR IP].
    /// </summary>
    /// <param name="strIP">The STR IP.</param>
    /// <returns>
    /// 	<c>true</c> if [is correnct IP] [the specified STR IP]; otherwise, <c>false</c>.
    /// </returns>
    public static bool IsCorrenctIP(string strIP)
    {
        string strRegExp = @"(\d{1,2}|1 \d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])";
        if (System.Text.RegularExpressions.Regex.IsMatch(strIP, strRegExp)) return true;
        else return false;
    }

    /// <summary>
    /// Determines whether [is valid IP] [the specified STR IP].
    /// </summary>
    /// <param name="strIP">The STR IP.</param>
    /// <returns>
    /// 	<c>true</c> if [is valid IP] [the specified STR IP]; otherwise, <c>false</c>.
    /// </returns>
    public static bool IsValidIP(string strIP)
    {
        if (System.Text.RegularExpressions.Regex.IsMatch(strIP, "[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}"))
        {
            string[] ip_ = strIP.Split('.');
            if (ip_.Length == 4 || ip_.Length == 6)
            {
                if (System.Int32.Parse(ip_[0]) < 256 && System.Int32.Parse(ip_[1]) < 256 & System.Int32.Parse(ip_[2]) < 256 & System.Int32.Parse(ip_[3]) < 256) return true;
                else return false;
            }
            else return false;
        }
        else return false;
    }
}
