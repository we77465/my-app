using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Serialization.Formatters.Binary;
//using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;


/// <summary>
/// �ǦC��
/// </summary>
public static class ObjSerial
{
    /// <summary>
    /// �N����ǦC�Ƭ� XML �ɮסC
    /// </summary>
    /// <param name="Value">����C</param>
    /// <param name="FileName">�ɮצW�١C</param>
    public static void ObjectToXmlFile(object Value, string FileName)
    {
        XmlSerializer oSerializer;
        StreamWriter oStream;
        string sPath;

        sPath = System.IO.Path.GetDirectoryName(FileName);
        if (!System.IO.Directory.Exists(sPath))
        {
            System.IO.Directory.CreateDirectory(sPath);
        }

        oSerializer = new XmlSerializer(Value.GetType());
        oStream = new StreamWriter(FileName);

        oSerializer.Serialize(oStream, Value);
        oStream.Close();
    }

    /// <summary>
    /// �N XML �ɮפϧǦC�Ƭ�����C
    /// </summary>
    /// <param name="FileName">�ɮצW�١C</param>
    public static object XmlFileToObject(string FileName, System.Type Type)
    {
        XmlSerializer oSerializer;
        FileStream oFileStream;
        object oValue;

        //�Y���w���ɮפ��s�b�h���}
        if (!System.IO.File.Exists(FileName)) return null;

        oSerializer = new XmlSerializer(Type);
        oFileStream = new FileStream(FileName, FileMode.Open);

        //Call the Deserialize method and cast to the object type.
        oValue = oSerializer.Deserialize(oFileStream);
        oFileStream.Close();
        return oValue;
    }

    /// <summary>
    /// �N����ǦC�Ƭ� XML �r��C
    /// </summary>
    /// <param name="Value">����C</param>
    public static string ObjectToXml(object Value)
    {
        XmlSerializer olSerializer;
        MemoryStream oMemoryStream;
        StreamReader oReader;
        string sText;

        olSerializer = new XmlSerializer(Value.GetType());
        oMemoryStream = new MemoryStream();

        olSerializer.Serialize(oMemoryStream, Value);

        oMemoryStream.Position = 0;
        oReader = new StreamReader(oMemoryStream);
        sText = oReader.ReadToEnd();
        return sText;
    }

    /// <summary>
    /// �N XML �r��ϧǦC�Ƭ�����C
    /// </summary>
    /// <param name="Text">XML �r��C</param>
    public static object XmlToObject(string Text, System.Type Type)
    {
        XmlSerializer oSerializer;
        MemoryStream oMemoryStream;
        byte[] oBuffer;
        object oValue;

        oSerializer = new XmlSerializer(Type);
        oBuffer = System.Text.Encoding.UTF8.GetBytes(Text);
        oMemoryStream = new MemoryStream(oBuffer);

        //Call the Deserialize method and cast to the object type.
        oValue = oSerializer.Deserialize(oMemoryStream);
        return oValue;
    }

    /// <summary>
    /// �N����ǦC�Ƭ� Soap �ɮסC
    /// </summary>
    /// <param name="Value">����C</param>
    /// <param name="FileName">�ɮצW�١C</param>
    public static void ObjectToSoapFile(object Value, string FileName)
    {
        SoapFormatter oFormatter;
        FileStream oFileStream;
        string sPath;

        sPath = System.IO.Path.GetDirectoryName(FileName);
        if (!System.IO.Directory.Exists(sPath))
        {
            System.IO.Directory.CreateDirectory(sPath);
        }

        oFormatter = new SoapFormatter();
        oFileStream = new FileStream(FileName, FileMode.Create);

        oFormatter.Serialize(oFileStream, Value);
        oFileStream.Close();
    }

    /// <summary>
    /// �N Soap �ɮפϧǦC�Ƭ�����C
    /// </summary>
    /// <param name="FileName">�ɮצW�١C</param>
    public static object SoapFileToObject(string FileName, System.Type Type)
    {
        SoapFormatter oFormatter;
        FileStream oFileStream;
        object oValue;

        //�Y���w���ɮפ��s�b�h���}
        if (!System.IO.File.Exists(FileName)) return null;

        oFormatter = new SoapFormatter();
        oFileStream = new FileStream(FileName, FileMode.Open);

        //Call the Deserialize method and cast to the object type.
        oValue = oFormatter.Deserialize(oFileStream);
        oFileStream.Close();
        return oValue;
    }

    /// <summary>
    /// �N����ǦC�Ƭ� Soap �r��C
    /// </summary>
    /// <param name="Value">����C</param>
    public static string ObjectToSoap(object Value)
    {
        SoapFormatter oFormatter;
        MemoryStream oMemoryStream;
        StreamReader oReader;
        string sText;

        oFormatter = new SoapFormatter();
        oMemoryStream = new MemoryStream();

        oFormatter.Serialize(oMemoryStream, Value);

        oMemoryStream.Position = 0;
        oReader = new StreamReader(oMemoryStream);
        sText = oReader.ReadToEnd();

        return sText;
    }

    /// <summary>
    /// �N Soap �r��ϧǦC�Ƭ�����C
    /// </summary>
    /// <param name="Text">Soap �r��C</param>
    public static object SoapToObject(string Text, System.Type Type)
    {
        SoapFormatter oFormatter;
        MemoryStream oMemoryStream;
        byte[] oBuffer;
        object oValue;

        oFormatter = new SoapFormatter();
        oBuffer = System.Text.Encoding.UTF8.GetBytes(Text);
        oMemoryStream = new MemoryStream(oBuffer);

        //Call the Deserialize method and cast to the object type.
        oValue = oFormatter.Deserialize(oMemoryStream);
        return oValue;
    }

    /// <summary>
    /// �N����ǦC�Ƭ� Binary �ɮסC
    /// </summary>
    /// <param name="Value">����C</param>
    /// <param name="FileName">�ɮצW�١C</param>
    public static void ObjectToBinaryFile(object Value, string FileName)
    {
        BinaryFormatter oFormatter;
        FileStream oFileStream;
        string sPath;

        sPath = System.IO.Path.GetDirectoryName(FileName);
        if (!System.IO.Directory.Exists(sPath))
        {
            System.IO.Directory.CreateDirectory(sPath);
        }

        oFormatter = new BinaryFormatter();
        oFileStream = new FileStream(FileName, FileMode.Create);

        oFormatter.Serialize(oFileStream, Value);
        oFileStream.Close();
    }

    /// <summary>
    /// �N Binary �ɮפϧǦC�Ƭ�����C
    /// </summary>
    /// <param name="FileName">�ɮצW�١C</param>
    public static object BinaryFileToObject(string FileName, System.Type Type)
    {
        BinaryFormatter oFormatter;
        FileStream oFileStream;
        object oValue;

        //�Y���w���ɮפ��s�b�h���}
        if (!System.IO.File.Exists(FileName)) return null;

        oFormatter = new BinaryFormatter();
        oFileStream = new FileStream(FileName, FileMode.Open);

        //Call the Deserialize method and cast to the object type.
        oValue = oFormatter.Deserialize(oFileStream);
        oFileStream.Close();
        return oValue;
    }

    /// <summary>
    /// �N����ǦC�Ƭ� Binary ��ơC
    /// </summary>
    /// <param name="Value">����C</param>
    public static byte[] ObjectToBinary(object Value)
    {
        SoapFormatter oFormatter;
        MemoryStream oMemoryStream;

        oFormatter = new SoapFormatter();
        oMemoryStream = new MemoryStream();

        oFormatter.Serialize(oMemoryStream, Value);

        oMemoryStream.Position = 0;
        return oMemoryStream.GetBuffer();
    }

    /// <summary>
    /// �N Binary ��ƤϧǦC�Ƭ�����C
    /// </summary>
    /// <param name="Buffer">Binary ��ơC</param>
    public static object BinaryToObject(byte[] Buffer, System.Type Type)
    {
        SoapFormatter oFormatter;
        MemoryStream oMemoryStream;
        object oValue;

        oFormatter = new SoapFormatter();
        oMemoryStream = new MemoryStream(Buffer);

        //Call the Deserialize method and cast to the object type.
        oValue = oFormatter.Deserialize(oMemoryStream);
        return oValue;
    }

    ///// <summary>
    ///// �N����ǦC�Ƭ� Json �ɮסC
    ///// </summary>
    ///// <param name="Value">����C</param>
    ///// <param name="FileName">�ɮצW�١C</param>
    //public static void ObjectToJsonFile(object Value, string FileName)
    //{
    //    DataContractJsonSerializer oSerializer;
    //    FileStream oFileStream;
    //    string sPath;

    //    sPath = System.IO.Path.GetDirectoryName(FileName);
    //    if (!System.IO.Directory.Exists(sPath))
    //    {
    //        System.IO.Directory.CreateDirectory(sPath);
    //    }

    //    oSerializer = new DataContractJsonSerializer(Value.GetType());
    //    oFileStream = new FileStream(FileName, FileMode.Create);

    //    oSerializer.WriteObject(oFileStream, Value);
    //    oFileStream.Close();
    //}

    ///// <summary>
    ///// �N Json �ɮפϧǦC�Ƭ�����C
    ///// </summary>
    ///// <param name="FileName">�ɮצW�١C</param>
    //public static object JsonFileToObject(string FileName, System.Type Type)
    //{
    //    DataContractJsonSerializer oSerializer;
    //    FileStream oFileStream;
    //    object oValue;

    //    //�Y���w���ɮפ��s�b�h���}
    //    if (!System.IO.File.Exists(FileName)) return null;

    //    oSerializer = new DataContractJsonSerializer(Type);
    //    oFileStream = new FileStream(FileName, FileMode.Open);

    //    //Call the Deserialize method and cast to the object type.
    //    oValue = oSerializer.ReadObject(oFileStream);
    //    oFileStream.Close();
    //    return oValue;
    //}

    ///// <summary>
    ///// �N����ǦC�Ƭ� Json �r��C
    ///// </summary>
    ///// <param name="Value">����C</param>
    //public static string ObjectToJson(object Value)
    //{
    //    DataContractJsonSerializer oSerializer;
    //    MemoryStream oMemoryStream;
    //    StreamReader oReader;
    //    string sText;

    //    oSerializer = new DataContractJsonSerializer(Value.GetType);
    //    oMemoryStream = new MemoryStream();

    //    oSerializer.WriteObject(oMemoryStream, Value);

    //    oMemoryStream.Position = 0;
    //    oReader = new StreamReader(oMemoryStream);
    //    sText = oReader.ReadToEnd();

    //    return sText;
    //}

    ///// <summary>
    ///// �N Json �r��ϧǦC�Ƭ�����C
    ///// </summary>
    ///// <param name="Text">Json �r��C</param>
    //public static object JsonToObject(string Text, System.Type Type)
    //{
    //    DataContractJsonSerializer oSerializer;
    //    MemoryStream oMemoryStream;
    //    byte[] oBuffer;
    //    object oValue;

    //    oSerializer = new DataContractJsonSerializer(Type);
    //    oBuffer = System.Text.Encoding.UTF8.GetBytes(Text);
    //    oMemoryStream = new MemoryStream(oBuffer);

    //    //Call the Deserialize method and cast to the object type.
    //    oValue = oSerializer.ReadObject(oMemoryStream);
    //    return oValue;
    //}

    /// <summary>
    /// �N����ǦC�Ƭ� DataContract �ɮסC
    /// </summary>
    /// <param name="Value">����C</param>
    /// <param name="FileName">�ɮצW�١C</param>
    public static void ObjectToDataContractFile(object Value, string FileName)
    {
        DataContractSerializer oSerializer;
        FileStream oFileStream;
        string sPath;

        sPath = System.IO.Path.GetDirectoryName(FileName);
        if (!System.IO.Directory.Exists(sPath))
        {
            System.IO.Directory.CreateDirectory(sPath);
        }

        oSerializer = new DataContractSerializer(Value.GetType());
        oFileStream = new FileStream(FileName, FileMode.Create);

        oSerializer.WriteObject(oFileStream, Value);
        oFileStream.Close();
    }

    /// <summary>
    /// �N DataContract �ɮפϧǦC�Ƭ�����C
    /// </summary>
    /// <param name="FileName">�ɮצW�١C</param>
    public static object DataContractFileToObject(string FileName, System.Type Type)
    {
        DataContractSerializer oSerializer;
        FileStream oFileStream;
        object oValue;

        //�Y���w���ɮפ��s�b�h���}
        if (!System.IO.File.Exists(FileName)) return null;

        oSerializer = new DataContractSerializer(Type);
        oFileStream = new FileStream(FileName, FileMode.Open);

        //Call the Deserialize method and cast to the object type.
        oValue = oSerializer.ReadObject(oFileStream);
        oFileStream.Close();
        return oValue;
    }

    /// <summary>
    /// �N����ǦC�Ƭ� DataContract �r��C
    /// </summary>
    /// <param name="Value">����C</param>
    public static string ObjectToDataContract(object Value)
    {
        DataContractSerializer oSerializer;
        MemoryStream oMemoryStream;
        StreamReader oReader;
        string sText;

        oSerializer = new DataContractSerializer(Value.GetType());
        oMemoryStream = new MemoryStream();

        oSerializer.WriteObject(oMemoryStream, Value);

        oMemoryStream.Position = 0;
        oReader = new StreamReader(oMemoryStream);
        sText = oReader.ReadToEnd();

        return sText;
    }

    /// <summary>
    /// �N DataContract �r��ϧǦC�Ƭ�����C
    /// </summary>
    /// <param name="Text">Json �r��C</param>
    public static object DataContractToObject(string Text, System.Type Type)
    {
        DataContractSerializer oSerializer;
        MemoryStream oMemoryStream;
        byte[] oBuffer;
        object oValue;

        oSerializer = new DataContractSerializer(Type);
        oBuffer = System.Text.Encoding.UTF8.GetBytes(Text);
        oMemoryStream = new MemoryStream(oBuffer);

        //Call the Deserialize method and cast to the object type.
        oValue = oSerializer.ReadObject(oMemoryStream);
        return oValue;
    }

}
