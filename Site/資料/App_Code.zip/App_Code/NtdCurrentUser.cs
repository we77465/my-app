﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;

/// <summary>
/// NTD 專案登入使用者資訊。
///
/// 【公司正式環境】
///   URL 帶 sid (由 SSO 注入)，呼叫 UserInfo.getUserId(sid, Request) 取得員編，
///   再呼叫 UserInfo.getUserInfo(empId) 取得人員資料。
///   getUserInfo 回傳格式（逗號分隔）：
///     [0] OU_ID    → BranchCode（分行代碼）
///     [1] USR_NAME → EmpName（員工姓名）
///     [2] OU_NAME  → BranchName（分行名稱）
///
/// 【本機開發環境】
///   URL ?sid=員編 (例：Main.aspx?sid=A0001)，getUserId 例外時 fallback 直接用 sid。
///
/// 注意：此 class 名稱為 NtdCurrentUser，避免與公司共用的
///       靜態 UserInfo (AD/SSO) 類別衝突 (CS0722)。
/// </summary>
public class NtdCurrentUser
{
    public string EmpID      { get; private set; }
    public string EmpName    { get; private set; }
    public string BranchCode { get; private set; }
    public string BranchName { get; private set; }
    public string Title      { get; private set; }
    public int    TitleLevel { get; private set; }
    public int    BranchType { get; private set; }  // 1=分行, 2=總行

    /// <summary>是否為總行單位 (BranchType = 2)。</summary>
    public bool IsHeadOffice { get { return BranchType == 2; } }

    /// <summary>是否可新增申請 (僅「經辦」TitleLevel=1)。</summary>
    public bool CanCreateApply { get { return TitleLevel == 1; } }

    private NtdCurrentUser() { }

    // =====================================================================
    // Current 屬性：取得本次請求的登入使用者；同 Session 內快取。
    // =====================================================================
    public static NtdCurrentUser Current
    {
        get
        {
            var context = HttpContext.Current;
            var cached  = context.Session != null
                        ? context.Session["NTD_NtdCurrentUser"] as NtdCurrentUser
                        : null;

            // 公司 SSO 用小寫 sid；兼容舊有大寫 SID
            string sid = (context.Request.QueryString["sid"]
                       ?? context.Request.QueryString["SID"]
                       ?? "").Trim();

            // Session 已快取且 SID 未換 → 直接回傳
            if (string.IsNullOrEmpty(sid) && cached != null) return cached;

            // Step 1：用公司既有的 UserInfo.getUserId() 解析 sid → 員編
            string empId = "";
            try   { empId = UserInfo.getUserId(sid, context.Request); }
            catch { empId = sid; }  // 本機測試：getUserId 不可用，直接用 sid 當員編

            if (string.IsNullOrEmpty(empId))
                empId = string.IsNullOrEmpty(sid) ? "A0001" : sid;

            // Step 2：員編 → 詳細資訊（參考 NC 專案，透過 getUserInfo 取得）
            var user = LoadByUserInfo(empId) ?? DefaultUser(empId);

            if (context.Session != null)
                context.Session["NTD_NtdCurrentUser"] = user;

            return user;
        }
    }

    // =====================================================================
    // 導覽輔助：在相對 URL 後面附加 sid 參數，讓 SSO 不中斷。
    // =====================================================================
    public string AppendSid(string url)
    {
        if (string.IsNullOrEmpty(url)) return url;
        string sid = HttpContext.Current.Request.QueryString["sid"]
                  ?? HttpContext.Current.Request.QueryString["SID"]
                  ?? "";
        if (string.IsNullOrEmpty(sid)) return url;
        return url + (url.Contains("?") ? "&" : "?") + "sid=" + sid;
    }

    // =====================================================================
    // 私有：員編 → 完整使用者物件（透過公司 UserInfo.getUserInfo 取得）
    // 參考 NC 專案寫法（範例/NC/Query.aspx.cs）
    // =====================================================================
    private static NtdCurrentUser LoadByUserInfo(string empId)
    {
        try
        {
            string raw = UserInfo.getUserInfo(empId);
            if (string.IsNullOrEmpty(raw)) return null;

            string[] info = raw.Split(',');
            if (info.Length < 3) return null;

            string branchCode = info[0].Trim();  // OU_ID
            string empName    = info[1].Trim();  // USR_NAME
            string branchName = info[2].Trim();  // OU_NAME

            // 查 chb_pub.dbo.HEADQUARTERS 判斷是否為總行單位（BRNOINTRA 有記錄且 ALIVE='Y'）
            int branchType = IsHeadOfficeBranch(branchCode) ? 2 : 1;

            return new NtdCurrentUser
            {
                EmpID      = empId,
                EmpName    = empName,
                BranchCode = branchCode,
                BranchName = branchName,
                Title      = "",        // getUserInfo 未提供職稱，預設空字串
                TitleLevel = 1,         // getUserInfo 未提供職級，預設 1(經辦)
                BranchType = branchType
            };
        }
        catch { return null; }
    }

    // =====================================================================
    // 私有：查 chb_pub.dbo.HEADQUARTERS 判斷分行代碼是否為總行單位。
    // =====================================================================
    private static bool IsHeadOfficeBranch(string branchCode)
    {
        if (string.IsNullOrEmpty(branchCode)) return false;
        try
        {
            string connStr = ConfigurationManager
                .ConnectionStrings["chb_iom"].ConnectionString;
            using (var conn = new SqlConnection(connStr))
            using (var cmd  = new SqlCommand(
                "SELECT COUNT(1) FROM chb_pub.dbo.HEADQUARTERS " +
                "WHERE BRNOINTRA = @BranchCode AND ALIVE = 'Y'", conn))
            {
                cmd.Parameters.AddWithValue("@BranchCode", branchCode);
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
            }
        }
        catch { return false; }
    }

    // ==============================================  // 公用靜態 helper：透過 getUserInfo 查詢任意員編的姓名。
    // 供各頁面列表顯示建單人/更新人姓名使用。
    // =====================================================================

    /// <summary>
    /// 透過 getUserInfo 取得員工姓名（index 1 = USR_NAME）。
    /// 查無或例外時回傳員編 ID 本身。
    /// </summary>
    public static string GetEmpName(string empId)
    {
        if (string.IsNullOrEmpty(empId)) return empId;
        try
        {
            string raw = UserInfo.getUserInfo(empId);
            if (string.IsNullOrEmpty(raw)) return empId;
            string[] info = raw.Split(',');
            string name = info.Length > 1 ? info[1].Trim() : "";
            return string.IsNullOrEmpty(name) ? empId : name;
        }
        catch { return empId; }
    }

    /// <summary>
    /// 將 DataTable 中指定欄位的員編 ID 全部替換為姓名。
    /// 例：FillEmpNames(table, "CreateUserName", "UpdateName")
    /// </summary>
    public static void FillEmpNames(System.Data.DataTable table, params string[] columns)
    {
        foreach (System.Data.DataRow row in table.Rows)
            foreach (string col in columns)
                if (table.Columns.Contains(col))
                    row[col] = GetEmpName(Convert.ToString(row[col]));
    }

    /// <summary>getUserInfo 失敗時的 fallback 使用者。</summary>
    private static NtdCurrentUser DefaultUser(string empId)
    {
        return new NtdCurrentUser
        {
            EmpID      = string.IsNullOrEmpty(empId) ? "UNKNOWN" : empId,
            EmpName    = string.IsNullOrEmpty(empId) ? "未知使用者" : empId,
            BranchCode = "000",
            BranchName = "",
            Title      = "未知分行",
            TitleLevel = 1,
            BranchType = 1
        };
    }
}