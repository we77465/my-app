﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.IO.Compression;
using iTextSharp.text;
using iTextSharp.text.pdf;


/// <summary>PDF轉檔工具</summary>
public class Pdf
{
    static HttpResponse Response;
    private enum TransmitMethod
    {
        None,
        Attachment,
        Inline
    }
    /// <summary>確認Chrome路徑</summary>
    private string LocateChrome()
    {
        var chromePath = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
        var chromePathx86 = @"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe";

        if (!File.Exists(chromePath)) //順序 1.Program Files 2.Program Files (x86) 3.AppData
        {
            chromePath = chromePathx86;
        }else if (!File.Exists(chromePath))
        {
            string userfolder = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            chromePath = userfolder + @"\AppData\Local\Google\Chrome\Application\chrome.exe";
        }
        
        if (!File.Exists(chromePath))
        {
            throw new Exception("Unable to locate Chrome.exe");
        }
        return chromePath;
    }

    /// <summary>以chrome headless指令產出PDF，print-to-pdf-no-header代表無頁首標頭頁尾路徑</summary>
    private void GeneratePdf(string url, string filePath)
    {
        var pdf = new Pdf();
        string chromePath=pdf.LocateChrome();

        using (var p = new Process())
        {
            p.StartInfo.FileName = chromePath;
            p.StartInfo.Arguments = "--headless --print-to-pdf-no-header --print-to-pdf=\"" + filePath + "\" --disable-gpu " + url;
            p.Start();
            p.WaitForExit();
        }

        GC.Collect();
    }
    /// <summary>從Control轉出html字串，邊框寬度15px，右側邊框23px，加id=comments的div不會列印</summary>
    /// <param name="Con">Control名稱，必須要有runat="server"</param>
    public static string GetHtmlText(Control cn)
    {
        StringWriter stringWrite = new StringWriter();
        HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
        cn.RenderControl(htmlWrite);
        htmlWrite.Flush();
        string addhtml = "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>";
        addhtml = addhtml + "<style>@page {margin: 15px; margin-right: 25px;} @media print { #comments {display:none;} }</style>";
        return addhtml + stringWrite.ToString();
    }

    /// <summary>PDF轉檔：將控制項以HTML模式轉出PDF，CSS記得寫入控制項中，可inline顯示畫面、attach產出下載檔案</summary>
    /// <param name="Con">Control名稱，必須要有runat="server"，例如〈div id="tempPdf" runat="server"〉</param>
    /// <param name="ToStyle">轉出方式：inline顯示畫面，attach產出下載檔案</param>
    public static void GeneratePdfFromControl(Control Con,string ToStyle)
    {
        string html = GetHtmlText(Con);
        if (ToStyle == "inline")
            ChromePublish(html, TransmitMethod.Inline, null);
        else if (ToStyle == "attach")
            ChromePublish(html, TransmitMethod.Attachment, "file.pdf");        
    }

    /// <summary>PDF轉檔：從html轉PDF並顯示在畫面上，避免混亂隱藏</summary>
    private void GeneratePdfInline(string html)
    {
        ChromePublish(html, TransmitMethod.Inline, null);
    }

    /// <summary>PDF轉檔：從html轉PDF並產出下載檔案，避免混亂隱藏</summary>
    private void GeneratePdfAttachment(string html, string filenameWithPdf)
    {
        ChromePublish(html, TransmitMethod.Attachment, filenameWithPdf);
    }

    private static void ChromePublish(string html, TransmitMethod transmitMethod, string filename)
    {
        string tPath = "/Program/temp/";
        string folderTemp = HttpContext.Current.Server.MapPath("~" + tPath);    //路徑

        if (!Directory.Exists(folderTemp))  //檢查路徑是否存在，不存在建立
        {
            Directory.CreateDirectory(folderTemp);
        }

        Random rd = new Random();

        string randomstr = rd.Next(100000000, int.MaxValue).ToString(); //產生亂數檔名

        string fileHtml = folderTemp + randomstr + ".html";
        string filePdf = folderTemp + randomstr + ".pdf";

        File.WriteAllText(fileHtml, html);

        //var r = HttpContext.Current.Request.Url;
        //string url = r.Scheme + "://" + r.Host + ":" + r.Port + tPath + randomstr + ".html";
        string url = fileHtml;

        var pdf = new Pdf();
        pdf.GeneratePdf(url, filePdf);

        FileInfo fi = new FileInfo(filePdf);
        string filelength = fi.Length.ToString();
        byte[] ba = File.ReadAllBytes(filePdf); //讀取產出PDF

        try //刪除產出檔案
        {
            File.Delete(filePdf);
            File.Delete(fileHtml);
        }
        catch { }

        HttpContext.Current.Response.Clear();

        if (transmitMethod == TransmitMethod.Inline)
            HttpContext.Current.Response.AddHeader("Content-Disposition", "inline");
        else if (transmitMethod == TransmitMethod.Attachment)
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");

        HttpContext.Current.Response.ContentType = "application/pdf;charset=utf-8";
        HttpContext.Current.Response.Charset = "utf-8";
        HttpContext.Current.Response.AddHeader("Content-Length", filelength);
        HttpContext.Current.Response.BinaryWrite(ba);
        HttpContext.Current.Response.End();
    }
    public static string GetHtmlTextH(Control cn)
    {
        StringWriter stringWrite = new StringWriter();
        HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
        cn.RenderControl(htmlWrite);
        htmlWrite.Flush();
        string addhtml = "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>";
        addhtml = addhtml + "<style>@page {margin: 1px; margin-right: 2px;} @media print { #comments {display:none;} }</style>";
        return addhtml + stringWrite.ToString();
    }
    public static void GeneratePdfFromControlpStamper(Control Con, string filename)
    {
        string html = GetHtmlTextH(Con);

        ChromePublishNoDel(html, filename);
    }
    private static void ChromePublishNoDel(string html, string filename)
    {
        //TransmitMethod transmitMethod = TransmitMethod.Attachment;
        //string folderTemp = HttpContext.Current.Server.MapPath("~" + tPath);    //路徑
        //string folderTemp = @"C:\temp\"; //\\本機測試
        string folderTemp = @"E:\Portal\IntraWeb\DotNet\Program\Audit_Supervisor\DownLoad\";

        if (!Directory.Exists(folderTemp))  //檢查路徑是否存在，不存在建立
        {
            Directory.CreateDirectory(folderTemp);
        }

        string fileHtml = folderTemp + filename + ".html";
        string filePdf = folderTemp + filename + ".pdf";
        File.WriteAllText(fileHtml, html);

        var pdf = new Pdf();
        pdf.GeneratePdf(fileHtml, filePdf);
        
        FileInfo fi = new FileInfo(filePdf);
        string filelength = fi.Length.ToString();
        byte[] ba = File.ReadAllBytes(filePdf); //讀取產出PDF

        HttpContext.Current.Response.Clear();
        //HttpContext.Current.Response.AddHeader("Content-Disposition", "inline");
        HttpContext.Current.Response.ContentType = "application/pdf;charset=utf-8";
        HttpContext.Current.Response.Charset = "utf-8";
        //HttpContext.Current.Response.AddHeader("Content-Length", filelength);
        HttpContext.Current.Response.BinaryWrite(ba);
        //HttpContext.Current.Response.End();
    }
    public static void GeneratePdfFromHTML(string html, string filename)
    {
        //string html = GetHtmlTextH(Con);

        ChromePublish(html, TransmitMethod.Attachment, filename+".pdf");
    }
}
