﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using System.Web.Services;
using System.Web.UI;
/// <summary>
/// Sharedcode 的摘要描述
/// </summary>
public class Sharedcode
{
    public Sharedcode()
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
    }
    #region 加解密
    /// <summary>
    /// 加密
    /// </summary>
    /// <param name="source">要加密的字串</param>
    /// <returns></returns>
    public static string DESCryptoServiceProvider_1(string source)
    {
        DESCryptoServiceProvider des = new DESCryptoServiceProvider();
        //產生金鑰並轉成字串
        byte[] key = Encoding.ASCII.GetBytes("handsome");//金鑰
        byte[] iv = Encoding.ASCII.GetBytes("emosdanh");//金鑰
        byte[] dataByteArray = Encoding.UTF8.GetBytes(source);
        des.Key = key;
        des.IV = iv;
        string encrypt = "";
        using (MemoryStream ms = new MemoryStream())
        using (CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write))
        {
            cs.Write(dataByteArray, 0, dataByteArray.Length);
            cs.FlushFinalBlock();
            encrypt = Convert.ToBase64String(ms.ToArray());
        }
        return encrypt;
    }
    /// <summary>
    /// 解密
    /// </summary>
    /// <param name="encrypt">要解密的字串</param>
    /// <returns></returns>
    public static string desDecryptBase64(string encrypt)
    {
        DESCryptoServiceProvider des = new DESCryptoServiceProvider();
        byte[] key = Encoding.ASCII.GetBytes("handsome");//金鑰
        byte[] iv = Encoding.ASCII.GetBytes("emosdanh");//金鑰
        des.Key = key;
        des.IV = iv;

        byte[] dataByteArray = Convert.FromBase64String(encrypt);
        using (MemoryStream ms = new MemoryStream())
        {
            using (CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write))
            {
                cs.Write(dataByteArray, 0, dataByteArray.Length);
                cs.FlushFinalBlock();
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }
    }

    #endregion
}