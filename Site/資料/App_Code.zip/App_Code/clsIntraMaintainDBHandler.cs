﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web;

/// <summary>
/// clsIntraMaintainDBHandler 的摘要描述
/// </summary>
public abstract class clsIntraMaintainDBHandler
{
    public string ConnectionString;
    public string ConnectionStringWithNoDefaultDBName;
    public string Message;

    public clsIntraMaintainDBHandler()
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
    }

    /// <summary>
    /// 取得TableList
    /// </summary>
    /// <param name="sType"></param>
    /// <param name="sCategory"></param>
    /// <returns></returns>
    public abstract DataTable GetTableList(string sType, string sCategory);

    /// <summary>
    /// 以SQL查詢字串取得資料
    /// </summary>
    /// <param name="sql"></param>
    /// <param name="connStr"></param>
    /// <returns></returns>
    public abstract DataTable GetDataTableFromSQL(string sql , int MaxRowCount);

    /// <summary>
    /// 執行SQL命令
    /// </summary>
    /// <param name="sql"></param>
    /// <returns></returns>
    public abstract int ExecuteNonQuery(string sql);

    /// <summary>
    /// 執行SQL命令後,取得第一行第一欄資料
    /// </summary>
    /// <param name="sql">SQL描述</param>
    /// <returns>回傳第一行第一欄資料</returns>
    public abstract string ExecuteScale(string sql);


    /// <summary>
    /// 確認連線是否正常
    /// </summary>
    /// <param name="Msg"></param>
    /// <returns></returns>
    public abstract bool isConnected();


    //整批讀入Datatable
    public abstract void GenerateDataReader(string sql);

    public abstract DataTable ReadToDatatable();



}