﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// IntraPage 的摘要描述
/// </summary>
public class IntraPage : System.Web.UI.Page
{
    //public string UserId;
    //public string UserName;
    //public string OU_Id;
    //public string OU_Name;


    public IntraPage()
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string UserId;
        string UserName;
        string OU_Id;
        string OU_Name;

        if (!IsPostBack)
        {
            UserId = UserInfo.getUserId(Request.QueryString["sid"].ToString(), Request);
            string info = UserInfo.getUserInfo(UserId);
            OU_Id = info.Split(',')[0];
            UserName = info.Split(',')[1];
            OU_Name = info.Split(',')[2];

            Session["UserID"] = UserId;
            Session["UserName"] = UserName;
            Session["OU_Id"] = OU_Id;
            Session["OU_Name"] = OU_Name;
            Session["isIntraMaintain"] = UserInfo.UserRoleContainIntraMaintain(UserId); //是否具備IntraMaintain角色


        }
    }
}