﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// 待辦事項共用函數
/// </summary>
public class Todolist
{
    public Todolist()
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
    }

    /// <summary>表單放行待辦事項新增，docno:表單編號-若空回覆TodoID，systemname:系統名稱，username:填報人姓名，approvelink:放行頁面連結，assignee:放行者員編</summary>
    /// <param name="docno">表單編號，若為空時回覆TodoID</param>
    /// <param name="systemname">系統名稱</param>
    /// <param name="username">填報人姓名</param>
    /// <param name="approvelink">放行頁面連結</param>
    /// <param name="assignee">放行者員編</param>
    /// <returns>result:失敗回覆「fail」，成功但update tblLogDetail失敗回覆「TodolistID」，成功且update tblLogDetail回覆「TodolistID + ,待辦事項更新成功」</returns>
    /// 若用Thread的方式，可以不用等回應，語法：var tsk = Task.Factory.StartNew(() =>EFormTodoAdd(docno, systemname, username, approvelink, assignee));
    public string EFormTodoAdd(string docno, string systemname, string username, string approvelink, string assignee)
    {
        string result = string.Empty;
        result = TodolistAdd(systemname + "放行", username + "申請的" + systemname + "待放行", "一般", approvelink + "?DOCNO=" + docno + "&EMPID=" + assignee, assignee);
        if (result != "fail" && docno != "")
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_eform"].ToString()))
                {
                    cn.Open();
                    string SqlCmd = "insert into TodoIDMap(TodoID,DocNo,Assignee) values(@TodoID,@DocNo,@Assignee)";
                    using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                    {
                        cmd.Parameters.AddWithValue("@TodoID", Convert.ToInt32(result));
                        cmd.Parameters.AddWithValue("@DocNo", docno);
                        cmd.Parameters.AddWithValue("@Assignee", assignee);
                        cmd.ExecuteNonQuery();
                    }
                }
                result = result + ",待辦事項更新成功";
            }
            catch (Exception k)
            {
                //result = "失敗，待辦事項編號：[" + result + "]資料庫處理失敗，錯誤訊息：" + k.Message;
                //失敗只回覆待辦事項編號，讓前端程式處理
            }
        }
        return result;
    }

    /// <summary>表單放行待辦事項新增-連結不自動加Docno，docno:表單編號-若空回覆TodoID，systemname:系統名稱，username:填報人姓名，approvelink:放行頁面連結，assignee:放行者員編</summary>
    /// <param name="docno">表單編號，若為空時回覆TodoID</param>
    /// <param name="systemname">系統名稱</param>
    /// <param name="username">填報人姓名</param>
    /// <param name="approvelink">放行頁面連結</param>
    /// <param name="assignee">放行者員編</param>
    /// <returns>result:失敗回覆「fail」，成功但update tblLogDetail失敗回覆「TodolistID」，成功且update tblLogDetail回覆「TodolistID + ,待辦事項更新成功」</returns>
    public string EFormTodoAddNODocnolink(string docno, string systemname, string username, string approvelink, string assignee)
    {
        string result = string.Empty;
        result = TodolistAdd(systemname + "放行", username + "申請的" + systemname + "待放行", "一般", approvelink, assignee);
        if (result != "fail" && docno != "")
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_eform"].ToString()))
                {
                    cn.Open();
                    string SqlCmd = "insert into TodoIDMap(TodoID,DocNo,Assignee) values(@TodoID,@DocNo,@Assignee)";
                    using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                    {
                        cmd.Parameters.AddWithValue("@TodoID", Convert.ToInt32(result));
                        cmd.Parameters.AddWithValue("@DocNo", docno);
                        cmd.Parameters.AddWithValue("@Assignee", assignee);
                        cmd.ExecuteNonQuery();
                    }
                }
                result = result + ",待辦事項更新成功";
            }
            catch (Exception k)
            {
                //result = "失敗，待辦事項編號：[" + result + "]資料庫處理失敗，錯誤訊息：" + k.Message;
                //失敗只回覆待辦事項編號，讓前端程式處理
            }
        }
        return result;
    }

    /// <summary>表單放行待辦事項新增-標題與內容自訂，docno:表單編號-若空回覆TodoID，title:待辦事項標題，description:內容，approvelink:連結網址，assignee:要傳送的員編</summary>
    /// <param name="docno">表單編號，若為空時回覆TodoID</param>
    /// <param name="title">待辦事項標題</param>
    /// <param name="description">內容</param>
    /// <param name="approvelink">連結網址</param>
    /// <param name="assignee">要傳送的員編</param>
    /// <returns>result:失敗回覆「fail」，成功但update tblLogDetail失敗回覆「TodolistID」，成功且update tblLogDetail回覆「TodolistID + ,待辦事項更新成功」</returns>
    public string EFormTodoAddOther(string docno, string title, string description, string approvelink, string assignee)
    {
        string result = string.Empty;
        result = TodolistAdd(title, description, "一般", approvelink, assignee);
        if (result != "fail" && docno != "")
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_eform"].ToString()))
                {
                    cn.Open();
                    string SqlCmd = "insert into TodoIDMap(TodoID,DocNo,Assignee) values(@TodoID,@DocNo,@Assignee)";
                    using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                    {
                        cmd.Parameters.AddWithValue("@TodoID", Convert.ToInt32(result));
                        cmd.Parameters.AddWithValue("@DocNo", docno);
                        cmd.Parameters.AddWithValue("@Assignee", assignee);
                        cmd.ExecuteNonQuery();
                    }
                }
                result = result + ",待辦事項更新成功";
            }
            catch (Exception k)
            {
                //result = "失敗，待辦事項編號：[" + result + "]資料庫處理失敗，錯誤訊息：" + k.Message;
                //失敗只回覆待辦事項編號，讓前端程式處理
            }
        }
        return result;
    }

    /// <summary>表單放行待辦事項刪除，docno:表單編號</summary>
    /// <param name="docno">表單編號</param>
    /// <returns>result:失敗回覆「fail」，成功回覆「success」</returns>
    public string EFormTodoDel(string docno)
    {
        string result = string.Empty;
        string connectString = WebConfigurationManager.ConnectionStrings["chb_eform"].ToString();
        DataSet ds = new DataSet();

        try
        {
            using (SqlConnection cn = new SqlConnection(connectString))
            {
                cn.Open();
                string SqlCmd = "select TodoID from TodoIDMap where DocNo=@DocNo order by TodoID desc";
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    cmd.Parameters.AddWithValue("@DocNo", docno);
                    result = result + "docno:" + docno;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while ((dr.Read()))
                        {
                            result = result + "-dr[0].ToString():" + dr[0].ToString();
                            result = result + "-TodolistDel:" + TodolistDel(dr[0].ToString());
                        }
                    }
                }
            }
        }
        catch (Exception k)
        {
            result = "失敗，找不到表單編號，錯誤訊息：" + k.Message;
        }
        return result;
    }

    /// <summary>新增待辦事項，title:待辦事項標題(必填)，description:描述，priority:優先順序(高、一般、低)，datasource:資料來源，assignee:待辦事項收件者(必填)</summary>
    /// <param name="title">待辦事項標題(必填)</param>
    /// <param name="description">描述</param>
    /// <param name="priority">優先順序(高、一般、低)</param>
    /// <param name="datasource">資料來源</param>
    /// <param name="assignee">待辦事項收件者(必填)</param>
    /// <returns>result:success或fail，ItemId:必須記錄起來，以確保未來更新/刪除待辦事項可正常執行</returns>
    public string TodolistAdd(string title, string description, string priority, string datasource, string assignee)
    {
        string result = string.Empty;
        string url = string.Format(WebConfigurationManager.AppSettings["TodolistUrl"].ToString() + "/AddItem");
        //傳給Todolist資料
        string jsonText = "{\"title\": \"" + title + "\"," +
                            "\"description\": \"" + description + "\"," +
                            "\"priority\": \"" + priority + "\"," +
                            "\"datasource\": \"" + datasource + "\"," +
                            "\"assignee\": \"" + assignee + "\"" +
                            "}";
        try
        {
            WebClient client = new WebClient();
            client.Credentials = new NetworkCredential(WebConfigurationManager.AppSettings["TodolistLoginID"].ToString(), WebConfigurationManager.AppSettings["TodolistPassword"].ToString());
            client.Encoding = Encoding.UTF8;
            client.Headers.Add(HttpRequestHeader.ContentType, "application/json");
            result = Encoding.UTF8.GetString(client.UploadData(url, "POST", Encoding.UTF8.GetBytes(jsonText))); //讀取回覆結果 {"msg":"1645","result":"success"} 
            string[] deResult = new string[2];
            deResult = result.Replace("\"", "").Replace("{msg:", "").Replace("result:", "").Replace("}", "").Split(new Char[] { ',' }); //將結果轉成陣列
            if (deResult[1] != "fail")  //成功回覆ItemId，失敗回覆fail
            {
                result = deResult[0];
            }
            else
            {
                result = "fail";
            }
        }
        catch (Exception ex)
        {
            result = ex.Message;
        }
        return result;
    }

    /// <summary>刪除待辦事項，itemid:待辦事項ID(必填)</summary>
    /// <param name="itemid">待辦事項ID(必填)</param>
    /// <returns>result:success或fail</returns>
    public string TodolistDel(string itemid)
    {
        string result = string.Empty;
        string url = string.Format(WebConfigurationManager.AppSettings["TodolistUrl"].ToString() + "/DeleteItem/" + itemid);
        try
        {
            WebClient client = new WebClient();
            client.Credentials = new NetworkCredential(WebConfigurationManager.AppSettings["TodolistLoginID"].ToString(), WebConfigurationManager.AppSettings["TodolistPassword"].ToString());
            client.Encoding = Encoding.UTF8;
            client.Headers.Add(HttpRequestHeader.ContentType, "application/json");
            StreamReader reader = new StreamReader(new MemoryStream(Encoding.UTF8.GetBytes(client.DownloadString(url))));
            result = reader.ReadToEnd();

            string[] deResult = new string[2];
            deResult = result.Replace("\"", "").Replace("{msg:", "").Replace("result:", "").Replace("}", "").Split(new Char[] { ',' });
            result = deResult[1];
        }
        catch (Exception ex)
        {
            result = ex.Message;
        }
        return result;
    }
    /// <summary>預設放行待辦事項通知，找ApproveLog的資料通知，請先Insert ApproveLog，docno:表單編號</summary>
    /// <param name="docno">表單編號</param>
    /// <param name="managerPage">0:傳送電子表單單位負責人,1:傳送電子表單單位主管</param>
    /// <returns>result:失敗回覆「fail」，成功回覆「待辦事項更新成功」</returns>
    public string DefaultSend(string docno, string managerPage,string tid)
    {
        string ServerName = WebConfigurationManager.AppSettings["ServerName"];
        string result = string.Empty;
        string brno = "0000", systemname = "", username = "", approvelink = "";
        String originalPath = new Uri(HttpContext.Current.Request.Url.AbsoluteUri).OriginalString;
        String parentDirectory = originalPath.Substring(0, originalPath.LastIndexOf("/"));
        approvelink = parentDirectory + "ApproveList.aspx";
        if (ServerName.Contains("t"))
            approvelink = "http://inspt01.intra.chb.com.tw/_layouts/15/CHB.EIP.Pages/EIPSystemFrame.aspx?tid="+ tid + "&amp;isASP=0&amp;APServer=2&amp;Target=_iframe";
        else
            approvelink = "http://www.intra.chb.com.tw/_layouts/15/CHB.EIP.Pages/EIPSystemFrame.aspx?tid=" + tid + "&amp;isASP=0&amp;APServer=2&amp;Target=_iframe";
        Todolist todolist = new Todolist();

        if (docno != "")
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_iom"].ToString()))
                {
                    cn.Open();
                    string SqlCmd = "select l.BrNo,d.TypeName,e.NAME from [iom].[dbo].[ApproveLog] l left join [iom].[dbo].[ApproveType] d on l.DocType=d.DocType left join [chb_pub].[dbo].[EMPLOYEE] e on l.EmpId=e.STAFF where l.DocNo=@DocNo";
                    using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                    {
                        cmd.Parameters.AddWithValue("@DocNo", docno);
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                DataTable dt = new DataTable();
                                dt.Load(dr);
                                brno = dt.Rows[0]["BrNo"].ToString();
                                systemname = dt.Rows[0]["TypeName"].ToString();
                                username = dt.Rows[0]["NAME"].ToString();
                            }
                        }
                    }
                    SqlCmd = "select r.USR_ID from [CHBSC].[dbo].[SC_ROL_USR] r left join [CHBSC].[dbo].[SC_USER] u on r.USR_ID=u.USR_ID where u.OU_ID=@brno and r.ROL_ID=@Rol_ID";
                    using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                    {
                        cmd.Parameters.AddWithValue("@brno", brno);
                        if (managerPage == "0") //電子表單單位負責人
                        {
                            cmd.Parameters.AddWithValue("@Rol_ID", "OAFRM_Manager");
                        }
                        else if (managerPage == "1") //電子表單單位主管
                        {
                            cmd.Parameters.AddWithValue("@Rol_ID", "OAFRM_GManager");
                        }
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    result = todolist.EFormTodoAddNODocnolink(docno, systemname, username, approvelink, dr["USR_ID"].ToString());
                                }
                            }
                        }
                    }
                }
                result = result + ",待辦事項更新成功";
            }
            catch (Exception k)
            {
                result = "fail";
            }
        }
        return result;
    }
}