﻿using System;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.DirectoryServices;
using System.Data.SqlClient;

/// <summary>
/// LMSAES 的摘要描述
/// </summary>
public class LMSAES
{
    public LMSAES()
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
    }
    //IV：34B590EDB2DE39FDFD2231D278613CBF
    //Key：1829718689E15F6E0CDF3554FE899E9C03135C7148C36BA1CEAB5ED187F07AAD

    // 加密
    public static string EncryptAES(string text)
    {
        try
        {
            RijndaelManaged rijalg = new RijndaelManaged();
            rijalg.BlockSize = 256;
            rijalg.KeySize = 256;
            rijalg.FeedbackSize = 256;
            rijalg.Padding = PaddingMode.PKCS7;
            rijalg.Mode = CipherMode.CBC;

            rijalg.Key = (new SHA256Managed()).ComputeHash(Encoding.UTF8.GetBytes("1829718689E15F6E0CDF3554FE899E9C03135C7148C36BA1CEAB5ED187F07AAD"));
            rijalg.IV = (new SHA256Managed()).ComputeHash(Encoding.UTF8.GetBytes("34B590EDB2DE39FDFD2231D278613CBF"));
            byte[] dataByteArray = Encoding.UTF8.GetBytes(text);
            //-----------------
            //加密
            ICryptoTransform encryptor = rijalg.CreateEncryptor(rijalg.Key, rijalg.IV);

            string encrypt = "";
            // Create the streams used for encryption.
            using (MemoryStream ms = new MemoryStream())
            using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
            {
                cs.Write(dataByteArray, 0, dataByteArray.Length);
                cs.FlushFinalBlock();
                encrypt = Convert.ToBase64String(ms.ToArray());
            }
            return encrypt.Replace("+", "-").Replace("/", "_");
        }
        catch (Exception ex)
        {
            return text;
        }
    }
    // 解密
    public static string DecryptAES(string text)
    {
        try
        {
            RijndaelManaged rijalg = new RijndaelManaged();
            rijalg.BlockSize = 256;
            rijalg.KeySize = 256;
            rijalg.FeedbackSize = 256;
            rijalg.Padding = PaddingMode.PKCS7;
            rijalg.Mode = CipherMode.CBC;

            rijalg.Key = (new SHA256Managed()).ComputeHash(Encoding.UTF8.GetBytes("1829718689E15F6E0CDF3554FE899E9C03135C7148C36BA1CEAB5ED187F07AAD"));
            rijalg.IV = (new SHA256Managed()).ComputeHash(Encoding.UTF8.GetBytes("34B590EDB2DE39FDFD2231D278613CBF"));
            byte[] dataByteArray = Convert.FromBase64String(text);
            //-----------------
            //加密
            ICryptoTransform decryptor = rijalg.CreateDecryptor(rijalg.Key, rijalg.IV);

            // Create the streams used for encryption.
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Write))
                {
                    cs.Write(dataByteArray, 0, dataByteArray.Length);
                    cs.FlushFinalBlock();
                    return Encoding.UTF8.GetString(ms.ToArray());
                }
            }
        }
        catch (Exception ex)
        {
            return text;
        }
    }

    public static string ConfirmAD(String UserId, String PassWord)
    {
        string sMessage = string.Empty;
        string LDAPServer = ConfigurationManager.AppSettings["LDAPServer"];
        string DomainName = ConfigurationManager.AppSettings["DomainName"];
        if (LDAPServer == "") return "NOAD";

        string domainAndUsername = DomainName + UserId;

        DirectoryEntry entry = new DirectoryEntry("LDAP://" + LDAPServer + "/DC=tschb,DC=com", domainAndUsername, PassWord);
        DirectorySearcher dirsearcher = new DirectorySearcher(entry);
        //dirsearcher.Filter = "(&(objectClass=user)(cn=" + UserId + "))";
        dirsearcher.Filter = "(&(cn=" + UserId + "))";
        //dirsearcher.Filter = Microsoft.Security.Application.Encoder.LdapFilterEncode("(sAMAccountName=" + UserId + ")");
        //dirsearcher.PropertiesToLoad.Add("displayName");
        //dirsearcher.PropertiesToLoad.Add("cn");
        dirsearcher.SearchScope = SearchScope.Subtree;
        try
        {
            SearchResult results = dirsearcher.FindOne();
            if (results != null)
            {
                sMessage = "";
            }
        }
        catch (DirectoryServicesCOMException ex)
        {
            sMessage = "AD認證: 帳號或密碼錯誤。" + ex.Message;
            sMessage = ex.Message;
        }
        catch (Exception ex2)
        {
            sMessage = "AD認證失敗。" + ex2.Message;
        }
        return sMessage;

    }

    public static string ConfirmRegistration(String RegistID,String UserId)
    {
        string sMessage = string.Empty;
        string result = "";
        string sConn = ConfigurationManager.ConnectionStrings["CHB_DBS"].ConnectionString;
        SqlConnection conn = new SqlConnection(sConn);
        conn.Open();
        try
        {
            string sCmd = @"select ID [員工編號]
            from[dbo].[V_Man_Reg] where (Cancel_RegDate is null and Reg_RNO = @RegistID) or (Cancel_PPTDate is null and PPT_RNO = @RegistID)";
            SqlCommand cmd = new SqlCommand(sCmd, conn);
            cmd.Parameters.AddWithValue("RegistID", RegistID);
            result = cmd.ExecuteScalar().ToString();
            if (result == UserId)
            {
                sMessage = "";
            }
            else
            {
                sMessage = "登錄證字號認證錯誤。";
            }
        }
        catch (Exception ex)
        {
            sMessage = ex.Message;
        }
        finally
        {
            conn.Close();
            conn.Dispose();
        }
        return sMessage;

    }
}