﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OleDb;
using System.Collections;

/// <summary>
/// clsExcel 的摘要描述
/// </summary>
public class clsExcel
{

    private string _FileName;
    private string _ConnectionString;
    private bool _isError;
    private string _ErrorMessage;

	public clsExcel(string xlsFn, bool HasHeader)
	{
		//
		// TODO: 在此加入建構函式的程式碼
		//
        _FileName = xlsFn;

        string sHeader = "No";
        if (HasHeader){ sHeader = "Yes";}

        if (_FileName.ToLower().EndsWith(".xlsx"))
        {
            _ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0" + 
                       ";Data Source=" + _FileName + 
                       ";Extended Properties=\"Excel 12.0 Xml;HDR=" + sHeader + 
                       ";IMEX=1\"";

        }
        else
        {
            _ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0" +
                            ";Data Source=" + _FileName +
                            ";Extended Properties=\"Excel 8.0;HDR=" + sHeader +
                            ";IMEX=1\"";
        
        }
	}

    public ArrayList GetSheetList()
    {
        ArrayList sn = new ArrayList();
        //取得Sheet Name
        OleDbConnection conn = new OleDbConnection(_ConnectionString);
        conn.Open();

        //讀取SCHEMA
        DataTable tb = null;
        //= rdr.GetSchemaTable
        tb = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
        if ((tb != null))
        {
            // tb.Select("substring(TABLE_NAME,len(TABLE_NAME),1)='_'")
            foreach (DataRow row in tb.Rows)
            {
                sn.Add(row[2]);
            }
        }
        conn.Close();
        return sn;
    }

    public DataTable GetDataFromSheet(string sheetname)
    {
        OleDbConnection conn = new OleDbConnection(_ConnectionString);
        conn.Open();
        OleDbDataAdapter da = new OleDbDataAdapter("Select * From [" + sheetname + "] ", conn);
        DataSet ds = new DataSet();
        da.Fill(ds);

        conn.Close();

        return ds.Tables[0];
    }

       

  
}