﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Text;

/// <summary>
/// 單位組織人員判斷
/// </summary>
public class RuleDetermine
{
    [Flags]
    public enum UserPostionTypeEnum
    {
        分行負责人以上 = 0,
        CRC = 1,
        總行 = 2,
        分行經辦 = 3
    };

    private DataAccessLayerChb_pub1 chb_Pub1;
    public RuleDetermine()
    {
        chb_Pub1 = new DataAccessLayerChb_pub1();
    }


    /// <summary>
    /// 判斷使用者身分
    /// </summary>
    /// <param name="empid">The empid.</param>
    /// <returns></returns>
    public RuleDetermine.UserPostionTypeEnum DetermineRule(string empid)
    {
        if (chb_Pub1.GetQueryResultSingleValue(DetermineBrnoMgr(empid), null) == "1")
        {
            return UserPostionTypeEnum.分行負责人以上;
        }
        else if (chb_Pub1.GetQueryResultSingleValue(DetermineCrc(empid), null) == "1")
        {
            return UserPostionTypeEnum.CRC;
        }
        else if (chb_Pub1.GetQueryResultSingleValue(DetermineMain(empid), null) == "1")
        {
            return UserPostionTypeEnum.總行;
        }
        else
        {
            return UserPostionTypeEnum.分行經辦;
        }
    }

    public bool DeterminePrivilege(string empid, string brno)
    {
        RuleDetermine rule = new RuleDetermine();
        if (rule.DetermineRule(empid) == RuleDetermine.UserPostionTypeEnum.CRC)
        {
            return (chb_Pub1.GetQueryResultSingleValue(DetermineCRCPrivilege(empid), null) == "1") ? true : false;

        }
        if (rule.DetermineRule(empid) == RuleDetermine.UserPostionTypeEnum.總行)
        {
            if (brno == "0051" || brno == "0201")
            {
                return true;
            }
            else if (brno == "0301" || brno == "2113")
            {
                return (chb_Pub1.GetQueryResultSingleValue(DetermineMainPrivilege(empid), null) == "1") ? true : false;
            }
            else
            {
                return false;
            }
        }
        return true;
    }



    /// <summary>
    /// Determines the brno MGR.
    /// </summary>
    /// <returns></returns>
    private string DetermineBrnoMgr(string empid)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(@"SELECT count(1) AS 是否為分行負責人");
        sb.AppendLine(@"FROM");
        sb.AppendLine(@" chb_pub.dbo.EMPLOYEE");
        sb.AppendLine(@"WHERE");
        sb.AppendLine(@" STAFF = '" + empid + "' ");
        sb.AppendLine(@" AND POST IN (SELECT POST");
        sb.AppendLine(@"     FROM");
        sb.AppendLine(@"      POSITION");
        sb.AppendLine(@"     WHERE");
        sb.AppendLine(@"      POST_NAME LIKE '%經理%'");
        sb.AppendLine(@"      OR POST_NAME LIKE '%襄理%'");
        sb.AppendLine(@"      OR POST_NAME LIKE '%副理%')");
        sb.AppendLine(@" AND BRNO IN (SELECT BRNO");
        sb.AppendLine(@"     FROM");
        sb.AppendLine(@"      BRANCH");
        sb.AppendLine(@"     WHERE");
        sb.AppendLine(@"      BRNAME LIKE '%分行%'  or BRNO='2200') ");
        return sb.ToString();
    }

    /// <summary>
    /// Determines the CRC.
    /// </summary>
    /// <param name="empid">The empid.</param>
    /// <returns></returns>
    private string DetermineCrc(string empid)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(@"SELECT count(1) AS 是否為CRC");
        sb.AppendLine(@"FROM");
        sb.AppendLine(@" chb_pub.dbo.EMPLOYEE");
        sb.AppendLine(@"WHERE");
        sb.AppendLine(@" STAFF = '" + empid + "' ");
        sb.AppendLine(@" AND BRNO IN (SELECT DISTINCT CRCNO");
        sb.AppendLine(@"     FROM");
        sb.AppendLine(@"      crc_rel_br)");
        return sb.ToString();
    }

    private string DetermineCRCPrivilege(string empid)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(@"SELECT count(1) AS total");
        sb.AppendLine(@"FROM");
        sb.AppendLine(@" EMPLOYEE");
        sb.AppendLine(@"WHERE");
        sb.AppendLine(@" JOBCODE IN ('510000', '511000', '511001', '511002', '512000', '512001', '513000', '513001', '513002', '513003')");
        sb.AppendLine(@" AND STAFF = '" + empid + "'");
        return sb.ToString();
    }

    private string DetermineMain(string empid)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(@"SELECT count(1) AS 是否為總行");
        sb.AppendLine(@"FROM");
        sb.AppendLine(@" chb_pub.dbo.EMPLOYEE");
        sb.AppendLine(@"WHERE");
        sb.AppendLine(@" STAFF = '" + empid + "' ");
        sb.AppendLine(@" AND BRNO IN (SELECT BRNO");
        sb.AppendLine(@"     FROM");
        sb.AppendLine(@"      BRANCH");
        sb.AppendLine(@"     WHERE");
        sb.AppendLine(@"      BRNAME NOT LIKE '%分行%'");
        sb.AppendLine(@"      AND BRNO <> '0000'  AND BRNO <>'2200'  )");
        return sb.ToString();
    }

    private string DetermineMainPrivilege(string empid)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(@"SELECT count(1) AS total ");
        sb.AppendLine(@"FROM");
        sb.AppendLine(@" EMPLOYEE");
        sb.AppendLine(@"WHERE");
        sb.AppendLine(@" JOBCODE IN ('190000', '190001', '250003', '251300', '251301', '251303')");
        sb.AppendLine(@" AND STAFF = '" + empid + "'");
        return sb.ToString();
    }


    public class DataAccessLayerChb_pub1
    {

        private readonly string constringWebSchool = ConfigurationManager.ConnectionStrings["chb_pub1"].ToString();
        private string constring;
        public DataAccessLayerChb_pub1()
        {
            constring = constringWebSchool;

        }


        private void PrepareCommand(ref SqlCommand cmd, SqlConnection conn, string cmdtext, SqlParameter[] cmdparams)
        {
            if ((conn.State != ConnectionState.Open))
            {
                conn.Open();
            }
            cmd.Connection = conn;
            cmd.CommandText = cmdtext;
            cmd.CommandType = CommandType.Text;
            if ((cmdparams != null))
            {
                foreach (SqlParameter paraitem in cmdparams)
                {
                    cmd.Parameters.Add(paraitem);
                }
            }
        }

        private void PrepareCommand(ref SqlCommand cmd, SqlConnection conn, string cmdtext, SqlParameter[] cmdparams, CommandType cmdtypes)
        {
            if ((conn.State != ConnectionState.Open))
            {
                conn.Open();
            }
            cmd.Connection = conn;
            cmd.CommandText = cmdtext;
            cmd.CommandType = cmdtypes;
            if ((cmdparams != null))
            {
                foreach (SqlParameter paraitem in cmdparams)
                {
                    cmd.Parameters.Add(paraitem);
                }
            }
        }
        //取得查詢的結果(輸出Datatable)

        public DataTable GetQueryResultToDataTable(string sqlcmd, SqlParameter[] sqlparams)
        {
            DataTable dtResult = new DataTable();
            using (SqlConnection Sql_Conn = new SqlConnection(constring))
            {
                try
                {
                    SqlCommand Sql_Command = new SqlCommand(sqlcmd, Sql_Conn);
                    PrepareCommand(ref Sql_Command, Sql_Conn, sqlcmd, sqlparams);
                    SqlDataAdapter Sql_dataaddapter = new SqlDataAdapter(Sql_Command);
                    Sql_dataaddapter.Fill(dtResult);
                    Sql_dataaddapter.Dispose();
                    Sql_Command.Dispose();
                    return dtResult;

                }
                catch (Exception ex)
                {
                    return dtResult;
                }

            }
        }

        //取得查詢的結果(輸出DataSet)  
        public DataSet GetQueryResultToDataset(string sqlcmd,
    SqlParameter[] sqlparams)
        {
            DataSet dtResult = new DataSet();
            using (SqlConnection Sql_Conn = new SqlConnection(constring))
            {
                try
                {
                    SqlCommand Sql_Command = new SqlCommand(sqlcmd, Sql_Conn);
                    PrepareCommand(ref Sql_Command, Sql_Conn, sqlcmd, sqlparams);
                    SqlDataAdapter Sql_dataaddapter = new SqlDataAdapter(Sql_Command);
                    Sql_dataaddapter.Fill(dtResult);
                    Sql_dataaddapter.Dispose();
                    Sql_Command.Dispose();
                    return dtResult;
                }
                catch (Exception ex)
                {
                    return dtResult;
                }
            }
            return dtResult;
        }

        //取得查詢的結果(輸出單個資料)    
        public string GetQueryResultSingleValue(string sqlcmd, SqlParameter[] sqlparams)
        {
            using (SqlConnection Sql_Conn = new SqlConnection(constring))
            {

                try
                {
                    SqlCommand Sql_Command = new SqlCommand(sqlcmd, Sql_Conn);
                    PrepareCommand(ref Sql_Command, Sql_Conn, sqlcmd, sqlparams);
                    return (Sql_Command.ExecuteScalar() == null) ? string.Empty : Sql_Command.ExecuteScalar().ToString();
                }
                catch (Exception ex)
                {
                    return string.Empty;
                }

            }
            return string.Empty;
        }

        //執行sql指令(沒包Transaction)    
        public string NonQueryResultNoTranc(string sqlcmd, SqlParameter[] sqlparams)
        {
            using (SqlConnection Sql_Conn = new SqlConnection(constring))
            {
                try
                {
                    SqlCommand Sql_Command = new SqlCommand(sqlcmd, Sql_Conn);
                    PrepareCommand(ref Sql_Command, Sql_Conn, sqlcmd, sqlparams);
                    Sql_Command.ExecuteNonQuery();
                    Sql_Command.Dispose();
                    return "OK";
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }
            return "OK";
        }

        //執行sql指令(包Transaction)    
        public string NonQueryResultTranc(string sqlcmd, SqlParameter[] sqlparams)
        {
            using (SqlConnection Sql_Conn = new SqlConnection(constring))
            {
                SqlCommand Sql_Command = new SqlCommand(sqlcmd, Sql_Conn);
                PrepareCommand(ref Sql_Command, Sql_Conn, sqlcmd, sqlparams);
                SqlTransaction Sql_Transaction;
                Sql_Transaction = Sql_Conn.BeginTransaction();
                Sql_Command.Transaction = Sql_Transaction;
                try
                {
                    Sql_Command.ExecuteNonQuery();
                    Sql_Transaction.Commit();
                    return "OK";
                }
                catch (Exception ex)
                {
                    Sql_Transaction.Rollback();
                    return ex.ToString();
                }

            }
        }
    }
}