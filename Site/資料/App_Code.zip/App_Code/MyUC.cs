﻿using System;
using System.Collections.Generic;
using System.Web;

namespace eform.uc {
    public class MyRadioButtonList : System.Web.UI.WebControls.RadioButtonList
    {
        protected override void OnPreRender(System.EventArgs e)
        {
            base.OnPreRender(e);
            if (!this.Enabled)
            {
                base.Enabled = true;
                DisableRadioButtonList(this);
            }
        }
        protected void DisableRadioButtonList(System.Web.UI.WebControls.RadioButtonList rbl)
        {
            rbl.Attributes.Add("onclick", "return false;");
            foreach (System.Web.UI.WebControls.ListItem li in rbl.Items)
            {
                li.Enabled = li.Selected ? true : false;
            }
        }
    }
}
