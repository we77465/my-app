﻿using System.Data;
using System.Data.SqlClient;
using Microsoft.VisualBasic;
using System.Collections.Generic;
using System;

public class clsSQLAgent
{

    public int RowCount;
    public int PC;

    public string Message;
    public List<SqlCommand> CommandCollection;

    public List<string> CommandName;
    public List<DataTable> BulkCopyDataTable;

    public List<string> BulkCopyTableName;

    private string _ConnectionString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["eFormsDB"].ConnectionString;

    public clsSQLAgent()
    {
        string ServerName = System.Web.Configuration.WebConfigurationManager.AppSettings["ServerName"].ToString();
        if (ServerName.Substring(ServerName.Length - 2, 2) == "02")
        {
            _ConnectionString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString;
        }

        CommandCollection = new List<SqlCommand>();
        CommandName = new List<string>();
        BulkCopyDataTable = new List<DataTable>();
        BulkCopyTableName = new List<string>();
    }

    public clsSQLAgent(string connStr)
    {
        _ConnectionString = connStr;
        CommandCollection = new List<SqlCommand>();
        CommandName = new List<string>();
        BulkCopyDataTable = new List<DataTable>();
        BulkCopyTableName = new List<string>();
    }


    public void ExecuteAllCommand()
    {
        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();
        SqlTransaction tran = conn.BeginTransaction();

        int count = 0;
        //Dim Pstr As String
        int AffectRows = 0;
        try
        {
            foreach (SqlCommand cmd in CommandCollection)
            {
                count += 1;
                cmd.Connection = conn;
                cmd.Transaction = tran;
                AffectRows = cmd.ExecuteNonQuery();
            }
            tran.Commit();
        }
        catch (Exception ex)
        {
            tran.Rollback();
            throw new Exception("執行" + CommandName[count - 1] + "時發生錯誤！錯誤訊息：" + ex.Message);
        }
        finally
        {
            conn.Close();
            foreach (SqlCommand cmd in CommandCollection)
            {
                cmd.Dispose();
            }
            tran.Dispose();

            CommandCollection.Clear();
            CommandName.Clear();
        }

    }


    public void ExecuteAllCommandAndInsertFromDataTable()
    {
        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();
        SqlTransaction tran = conn.BeginTransaction();
        SqlBulkCopy bulkCpy = new SqlBulkCopy(conn, SqlBulkCopyOptions.KeepIdentity, tran);

        int count = 0;
        int BulkCount = 0;
        int AffectRows = 0;


        try
        {
            foreach (SqlCommand cmd in CommandCollection)
            {
                count += 1;
                cmd.Connection = conn;
                cmd.Transaction = tran;
                AffectRows = cmd.ExecuteNonQuery();
            }

            foreach (DataTable tb in BulkCopyDataTable)
            {
                BulkCount += 1;
                bulkCpy.BulkCopyTimeout = 300;
                bulkCpy.DestinationTableName = "dbo.[" + BulkCopyTableName[BulkCount - 1] + "]";
                bulkCpy.WriteToServer(tb);
            }

            tran.Commit();

        }
        catch (Exception ex)
        {
            tran.Rollback();
            throw new Exception("執行時發生錯誤！錯誤訊息：" + ex.Message);
        }
        finally
        {
            conn.Close();
            foreach (SqlCommand cmd in CommandCollection)
            {
                cmd.Dispose();
            }
            foreach (DataTable tb in BulkCopyDataTable)
            {
                tb.Dispose();
            }
            tran.Dispose();
            CommandCollection.Clear();
            CommandName.Clear();
            BulkCopyDataTable.Clear();
            BulkCopyTableName.Clear();
        }

    }


    public void ExecuteCommand(SqlCommand cmd)
    {
        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();

        try
        {
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            conn.Close();
            cmd.Dispose();
        }
    }

    public void AddCommand(SqlCommand cmd, string cmdName)
    {
        CommandCollection.Add(cmd);
        CommandName.Add(cmdName);
    }

    public void AddDataTable(DataTable tb, string tbName)
    {
        BulkCopyDataTable.Add(tb);
        BulkCopyTableName.Add(tbName);
    }

    /// <summary>
    /// 執行SQL命令，並傳回執行影響筆數
    /// </summary>
    /// <param name="cmd"></param>
    /// <returns>執行影響筆數</returns>
    /// <remarks></remarks>
    public int ExecuteSQL(SqlCommand cmd)
    {
        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();

        cmd.Connection = conn;

        int rtnValue = -1;

        try
        {
            rtnValue = cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            conn.Close();
            cmd.Dispose();
        }

        return rtnValue;

    }

    /// <summary>
    /// 執行SQL命令，並傳回執行影響筆數
    /// </summary>
    /// <returns>執行影響筆數</returns>
    /// <remarks></remarks>
    public int ExecuteSQL(string SQLString)
    {

        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand(SQLString, conn);
        cmd.Connection = conn;

        int rtnValue = -1;

        try
        {
            rtnValue = cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            conn.Close();
            cmd.Dispose();
        }

        return rtnValue;

    }

    /// <summary>
    /// 執行SQL命令，並取得傳回之第一行第一列位置的資料
    /// </summary>
    /// <param name="Cmd">SQL命令</param>
    /// <returns>傳回之第一行第一列位置的資料</returns>
    /// <remarks></remarks>
    public string ExecuteScalar(SqlCommand Cmd)
    {

        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();

        Cmd.Connection = conn;

        try
        {
            return Cmd.ExecuteScalar().ToString();
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
        finally
        {
            conn.Close();
            Cmd.Dispose();
        }

    }

    /// <summary>
    /// 執行SQL命令，並取得傳回之第一行第一列位置的資料
    /// </summary>
    /// <param name="SQLString">SQL命令</param>
    /// <returns>傳回之第一行第一列位置的資料</returns>
    /// <remarks></remarks>
    public string ExecuteScalar(string SQLString)
    {

        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();
        SqlCommand Cmd = new SqlCommand(SQLString, conn);

        try
        {
            return Cmd.ExecuteScalar().ToString();
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
        finally
        {
            conn.Close();
            Cmd.Dispose();
        }

    }

    public int InsertFromDataTable_New(string TableName, DataTable dt)
    {

        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();
        SqlTransaction trans = conn.BeginTransaction();
        SqlBulkCopy bulkCpy = new SqlBulkCopy(conn, SqlBulkCopyOptions.KeepIdentity, trans);


        try
        {
            bulkCpy.BulkCopyTimeout = 300;
            bulkCpy.DestinationTableName = "dbo.[" + TableName + "]";
            bulkCpy.WriteToServer(dt);

            trans.Commit();
            Message = "成功!";
        }
        catch (Exception ex)
        {
            trans.Rollback();
            throw new Exception(ex.Message);
        }
        finally
        {
            conn.Close();
            trans.Dispose();

        }
        return 1;
    }

    public int InsertFromDataTable(string TableName, DataTable dt)
    {

        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();

        SqlCommand cmd = default(SqlCommand);

        //刪除目標資料表
        cmd = new SqlCommand("Truncate table " + TableName, conn);
        cmd.ExecuteNonQuery();

        //建立Insert Command
        cmd.CommandText = "Insert into " + TableName;

        string s1 = "";
        string s2 = "";


        try
        {

            foreach (DataColumn col in dt.Columns)
            {
                if (!string.IsNullOrEmpty(s1))
                    s1 += ",";
                s1 += "[" + col.ColumnName + "]";

                if (!string.IsNullOrEmpty(s2))
                    s2 += ",";
                s2 += "@" + col.ColumnName;

                cmd.Parameters.Add(col.ColumnName, GetSQLDbType(col.DataType.ToString()));
            }

            cmd.CommandText += "(" + s1 + ") Values (" + s2 + ")";

            int colCount = cmd.Parameters.Count;
            RowCount = dt.Rows.Count;
            PC = 0;

            //設定欄位值
            foreach (DataRow row in dt.Rows)
            {
                PC += 1;
                for (int i = 0; i <= colCount - 1; i++)
                {
                    if (Convert.IsDBNull(row[i]))
                    {
                        cmd.Parameters[i].Value = DBNull.Value;
                    }
                    else
                    {
                        cmd.Parameters[i].Value = row[i].ToString();
                    }
                }
                //執行Insert
                cmd.ExecuteNonQuery();
            }
            //MsgBox("Insert Completed")
            //MsgBox(cmd.CommandText)
            Message = "完成！";
        }
        catch (Exception ex)
        {
            Message = ex.Message;
        }
        finally
        {
            conn.Close();
            cmd.Dispose();
        }

        return PC;

    }

    /// <summary>
    /// 取得資料表清單
    /// </summary>
    /// <returns>資料表清單</returns>
    /// <remarks></remarks>
    public DataTable GetTableList()
    {
        return GetDataTableBySQL("SELECT name as TableName\tFROM sysobjects\tWHERE xtype = 'U' order by 1");
    }

    public System.Data.DataTable GetDataTableBySQL(SqlCommand SqlCmd)
    {

        SqlConnection conn = new SqlConnection(ConnectionString);
        SqlCmd.Connection = conn;
        System.Data.DataSet ds = new System.Data.DataSet();

        try
        {
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(SqlCmd);

            da.Fill(ds);

        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            if (conn != null)
                conn.Close();
        }

        return ds.Tables[0];

    }

    public System.Data.DataTable GetDataTableBySQL(string SqlStr)
    {

        SqlConnection conn = new SqlConnection(ConnectionString);
        SqlCommand SqlCmd = new SqlCommand(SqlStr, conn);
        System.Data.DataSet ds = new System.Data.DataSet();

        try
        {
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(SqlCmd);

            da.Fill(ds);

        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            if (conn != null)
                conn.Close();
        }

        return ds.Tables[0];

    }

    public SqlDbType GetSQLDbType(string sType)
    {

        switch (sType.ToLower().Replace("system.", ""))
        {
            case "string":
                return SqlDbType.VarChar;
            case "double":
            case "decimal":
                return SqlDbType.Decimal;
            case "boolean":
                return SqlDbType.Bit;
            case "int16":
            case "int32":
            case "byte":
                return SqlDbType.Int;
            case "datetime":
                return SqlDbType.DateTime;
            default:
                throw new Exception("Unknown Type!" + sType);
        }
    }

    public string ConnectionString
    {
        get { return _ConnectionString; }
        set { _ConnectionString = value; }
    }

}
