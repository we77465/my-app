﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using DataAccessLayer.DALC;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Threading.Tasks;

/// <summary>
/// 電子表單商業流程
/// </summary>
public class EfromBI
{
    //流程狀態顯示
    [Flags]
    public enum FlowStatusEnum
    {
        總行退件 = -1,
        退回 = 0,
        待簽核 = 1,
        待決行 = 2,
        已決行 = 3,
        已確認 = 4,
    };
    //連線字串:chb_iom
    private static readonly string connectString = ConfigurationManager.ConnectionStrings["chb_iom"].ToString();
    public EfromBI()
    {
        //
        // TODO: 在此加入建構函式的程式碼
        //
    }
    /// <summary>
    /// 修正流程狀態(當流程狀態分兩張表儲存時 ex.  tblLogDetail及tblRisk都存作業人員的流程狀態)
    /// </summary>
    /// <param name="docno">申請單單號</param>
    /// <param name="status">流程狀態(資料表本身,非tblLogDetail)</param>
    /// <returns></returns>
    public string CorrectStatus(string docno, string status)
    {
        string msg = string.Empty;
        DataSet dsSelect = new DataSet();
        using (Bussiness applc = new Bussiness())
        {
            dsSelect = applc.select("select FlowStatus from tblLogDetail where DocNo='" + docno + "' ", connectString);
        }
        if (dsSelect.Tables[0].Rows.Count > 0)
        {
            if (string.Compare(status, dsSelect.Tables[0].Rows[0]["FlowStatus"].ToString()) == 0)
            {
                msg = "同步成功!";
            }
            else
            {
                Boolean bl = false;
                using (Bussiness applc = new Bussiness())
                {
                    bl = applc.execute("update tblLogDetail set FlowStatus='" + status + "' where DocNo='" + docno + "' ", connectString);
                }
                msg = (bl == true) ? "修改同步成功!" : "修改同步失敗!";
            }
        }
        return msg;
    }
    
    /// <summary>
    /// 顯示流程狀態
    /// </summary>
    /// <param name="docno">申請單單號</param>
    /// <returns></returns>
    public string DisplayFlowStatus(string docno)
    {
        string msg = string.Empty;
        DataSet dsSelect = new DataSet();
        using (Bussiness applc = new Bussiness())
        {
            dsSelect = applc.select("select FlowStatus from tblLogDetail where DocNo='" + docno + "' ", connectString);
        }
        if (dsSelect.Tables[0].Rows.Count > 0)
        {
            int result ;
            if (int.TryParse(dsSelect.Tables[0].Rows[0]["FlowStatus"].ToString().Trim(), out result) == true)
            {
                msg = ((FlowStatusEnum)result).ToString();
            }
            else
            {
                msg = "無此流程狀態!";
            }
        }
        else
        {
            msg = "新增";
        }
        return msg;
    }

    /// <summary>
    /// 顯示流程狀態
    /// </summary>
    /// <param name="docno">申請單單號</param>
    /// <returns></returns>
    public string DisplayFlowStatus(int status)
    {
        try
        {
            return ((FlowStatusEnum)status).ToString();
        }
        catch (Exception)
        {
            return "無此流程狀態!";
        }
    }

    /// <summary>
    /// 決定新的表單編號.
    /// </summary>    
    /// <param name="docType">Type of the doc.</param>
    /// <param name="brno">The brno.</param>
    /// <param name="year">The year.</param>
    /// <returns></returns>
    public string DecideNo( string docType, string brno, string year)
    {
        DataSet dsSelect, ds2;
        string tablename = string.Empty;
        int no;
        using (Bussiness applc = new Bussiness())
        {
            dsSelect = applc.select(" select TabName from MgrTableMapping where DocType='"+docType+"' ", connectString);
        }
        tablename = dsSelect.Tables[0].Rows[0]["TabName"].ToString().Trim();
        using (Bussiness applc = new Bussiness())
        {
            ds2 = applc.select("select top 1 DOCNO from " + tablename + " where BRNO='" + brno + "'  and substring(DOCNO,3,3)='"+year+"' order by DOCNO desc", connectString); //
        }
        if (ds2.Tables[0].Rows.Count != 0)
        {
            no = int.Parse(ds2.Tables[0].Rows[0]["DOCNO"].ToString().Substring(9, 3)) + 1;
            return ds2.Tables[0].Rows[0]["DOCNO"].ToString().Substring(0, 9) + no.ToString().PadLeft(3, '0');
        }
        else
        {
            return docType+ year + brno + "001";
        }
    }

    /// <summary>
    /// Dels the log detail.
    /// </summary>
    /// <param name="docno">The docno.</param>
    public void DelLogDetail(string docno)
    {
        bool bl;
        using (Bussiness applc = new Bussiness())
        {
            bl = applc.execute(" Delete from tblLogDetail where DocNo='"+docno+"' ",connectString);                        
        }
    }

    /// <summary>
    /// OA共用參數檔：查詢參數名稱
    /// </summary>
    /// <param name="DocType">目錄名稱</param>
    /// <param name="Item">項目</param>
    /// <param name="RefNo">參數代號</param>
    /// <returns>RefName參數名稱</returns>
    public static string OARefName(string DocType, string Item, string RefNo)
    {
        string result = string.Empty;
        try
        {
            using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_iom"].ToString()))
            {
                cn.Open();
                string SqlCmd = "SELECT RefName FROM OARef WHERE (DocType = @DocType) and (Item = @Item) and (RefNo = @RefNo)";
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    cmd.Parameters.AddWithValue("@DocType", DocType);
                    cmd.Parameters.AddWithValue("@Item", Item);
                    cmd.Parameters.AddWithValue("@RefNo", RefNo);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            result = dr[0].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            result = "error:" + e.Message;
        }
        return result;
    }

    /// <summary>
    /// OA共用參數檔：OA共用參數檔DataTable
    /// </summary>
    /// <param name="DocType">目錄名稱</param>
    /// <param name="Item">項目</param>
    /// <returns>DataTable(RefNo,RefName,RefCode,RefDetail)</returns>
    public static DataTable OARefDataTable(string DocType, string Item)
    {
        DataTable result = new DataTable();
        result.Columns.AddRange(new DataColumn[4] { new DataColumn("RefNo", typeof(string)),
                    new DataColumn("RefName", typeof(string)),
                    new DataColumn("RefCode", typeof(string)),
                    new DataColumn("RefDetail",typeof(string)) });
        try
        {
            using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_iom"].ToString()))
            {
                cn.Open();
                string SqlCmd = "SELECT RefNo,RefName,RefCode,RefDetail FROM OARef WHERE (DocType = @DocType) and (Item = @Item)";
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    cmd.Parameters.AddWithValue("@DocType", DocType);
                    cmd.Parameters.AddWithValue("@Item", Item);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            result.Load(dr);
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            DataRow rRow = result.NewRow();
            rRow[1] = "error:" + e.Message;
            result.Rows.Add(rRow);
        }
        return result;
    }

    /// <summary>
    /// OA共用參數檔：OA共用參數檔DataTable並排序
    /// </summary>
    /// <param name="DocType">目錄名稱</param>
    /// <param name="Item">項目</param>
    /// <param name="Order">排序欄位(RefNo,RefName,RefCode,RefDetail)</param>
    /// <returns>DataTable(RefNo,RefName,RefCode,RefDetail)</returns>
    public static DataTable OARefDataTableOrder(string DocType, string Item, string Order)
    {
        DataTable result = new DataTable();
        result.Columns.AddRange(new DataColumn[4] { new DataColumn("RefNo", typeof(string)),
                    new DataColumn("RefName", typeof(string)),
                    new DataColumn("RefCode", typeof(string)),
                    new DataColumn("RefDetail",typeof(string)) });
        try
        {
            using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_iom"].ToString()))
            {
                cn.Open();
                string SqlCmd = "SELECT RefNo,RefName,RefCode,RefDetail FROM OARef WHERE (DocType = @DocType) and (Item = @Item)";
                switch (Order)
                {
                    case "RefCode":
                        SqlCmd = "SELECT RefNo,RefName,RefCode,RefDetail FROM OARef WHERE (DocType = @DocType) and (Item = @Item) order by RefCode";
                        break;
                    case "RefNo":
                        SqlCmd = "SELECT RefNo,RefName,RefCode,RefDetail FROM OARef WHERE (DocType = @DocType) and (Item = @Item) order by RefNo";
                        break;
                    case "RefName":
                        SqlCmd = "SELECT RefNo,RefName,RefCode,RefDetail FROM OARef WHERE (DocType = @DocType) and (Item = @Item) order by RefName";
                        break;
                    case "RefDetail":
                        SqlCmd = "SELECT RefNo,RefName,RefCode,RefDetail FROM OARef WHERE (DocType = @DocType) and (Item = @Item) order by RefDetail";
                        break;
                    default:
                        break;
                }
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    cmd.Parameters.AddWithValue("@DocType", DocType);
                    cmd.Parameters.AddWithValue("@Item", Item);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            result.Load(dr);
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            DataRow rRow = result.NewRow();
            rRow[1] = "error:" + e.Message;
            result.Rows.Add(rRow);
        }
        return result;
    }

    /// <summary>OA共用參數檔：從OA共用參數檔塞值到DropDownList</summary>
    /// <param name="DDL">DropDownList名稱</param>
    /// <param name="DocType">表單代號</param>
    /// <param name="Item">項目</param>
    public static void OARefDropDownList(DropDownList DDL, string DocType, string Item)
    {
        DDL.DataSource = EfromBI.OARefDataTable(DocType, Item);
        DDL.DataTextField = "RefName";
        DDL.DataValueField = "RefNo";
        DDL.DataBind();
    }

    /// <summary>OA共用參數檔：從OA共用參數檔塞值到DropDownList並排序</summary>
    /// <param name="DDL">DropDownList名稱</param>
    /// <param name="DocType">表單代號</param>
    /// <param name="Item">項目</param>
    /// <param name="Order">排序欄位(RefNo,RefName,RefCode,RefDetail)</param>
    public static void OARefDropDownListOrder(DropDownList DDL, string DocType, string Item, string Order)
    {
        DDL.DataSource = EfromBI.OARefDataTableOrder(DocType, Item, Order);
        DDL.DataTextField = "RefName";
        DDL.DataValueField = "RefNo";
        DDL.DataBind();
    }

    /// <summary>OA共用參數檔：從OA共用參數檔塞值到CheckBoxList</summary>
    /// <param name="DDL">CheckBox名稱</param>
    /// <param name="DocType">表單代號</param>
    /// <param name="Item">項目</param>
    public static void OARefCheckBoxList(CheckBoxList DDL, string DocType, string Item)
    {
        DDL.DataSource = EfromBI.OARefDataTable(DocType, Item);
        DDL.DataTextField = "RefName";
        DDL.DataValueField = "RefNo";
        DDL.DataBind();
    }

    /// <summary>OA共用參數檔：從OA共用參數檔塞值到CheckBoxList並排序</summary>
    /// <param name="DDL">CheckBox名稱</param>
    /// <param name="DocType">表單代號</param>
    /// <param name="Item">項目</param>
    /// <param name="Order">排序欄位(RefNo,RefName,RefCode,RefDetail)</param>
    public static void OARefCheckBoxListOrder(CheckBoxList DDL, string DocType, string Item, string Order)
    {
        DDL.DataSource = EfromBI.OARefDataTableOrder(DocType, Item, Order);
        DDL.DataTextField = "RefName";
        DDL.DataValueField = "RefNo";
        DDL.DataBind();
    }

    /// <summary>OA共用參數檔：從OA共用參數檔塞值到RadioButtonList</summary>
    /// <param name="RB">RadioButtonList名稱</param>
    /// <param name="DocType">表單代號</param>
    /// <param name="Item">項目</param>
    public static void OARefRadioButton(RadioButtonList RB, string DocType, string Item)
    {
        RB.DataSource = EfromBI.OARefDataTable(DocType, Item);
        RB.DataTextField = "RefName";
        RB.DataValueField = "RefNo";
        RB.DataBind();
    }

    /// <summary>OA共用參數檔：從OA共用參數檔塞值到RadioButtonList並排序</summary>
    /// <param name="RB">RadioButtonList名稱</param>
    /// <param name="DocType">表單代號</param>
    /// <param name="Item">項目</param>
    /// <param name="Order">排序欄位(RefNo,RefName,RefCode,RefDetail)</param>
    public static void OARefRadioButtonOrder(RadioButtonList RB, string DocType, string Item, string Order)
    {
        RB.DataSource = EfromBI.OARefDataTableOrder(DocType, Item, Order);
        RB.DataTextField = "RefName";
        RB.DataValueField = "RefNo";
        RB.DataBind();
    }

    /// <summary>
    /// OA共用參數檔：新增OA共用參數資料
    /// </summary>
    /// <param name="DocType">表單代號</param>
    /// <param name="Item">項目</param>
    /// <param name="RefNo">參數代號</param>
    /// <param name="RefName">參數名稱</param>
    /// <param name="RefCode">參數參照碼</param>
    /// <param name="RefDetail">參數詳細內容</param>
    /// <param name="UpdateUser">最後更新人</param>
    /// <returns>成功：成功，失敗：錯誤訊息</returns>
    public static string OARefAdd(string DocType, string Item, string RefNo, string RefName, string RefCode, string RefDetail, string UpdateUser)
    {
        string success = "成功";
        try
        {
            using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_iom"].ToString()))
            {
                cn.Open();
                string SqlCmd = "DELETE FROM OARef WHERE (DocType = @DocType) AND (Item = @Item) AND (RefNo = @RefNo);" +
                    "INSERT INTO OARef(DocType, Item, RefNo, RefName, RefCode, RefDetail, UpdateUser) VALUES (@DocType, @Item, @RefNo, @RefName, @RefCode, @RefDetail, @UpdateUser)";
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    cmd.Parameters.AddWithValue("@DocType", DocType);
                    cmd.Parameters.AddWithValue("@Item", Item);
                    cmd.Parameters.AddWithValue("@RefNo", RefNo);
                    cmd.Parameters.AddWithValue("@RefName", RefName);
                    cmd.Parameters.AddWithValue("@RefCode", RefCode);
                    cmd.Parameters.AddWithValue("@RefDetail", RefDetail);
                    cmd.Parameters.AddWithValue("@UpdateUser", UpdateUser);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            success = "失敗：" + ex.Message;
        }
        return success;
    }
    /// <summary>
    /// OA：表單編號產生
    /// </summary>
    /// <param name="DocType">表單代號</param>
    /// <param name="YYMM">表單期別</param>
    /// <param name="Brno">單位代號</param>
    /// <returns>DocNo表單編號</returns>
    public static string DocNoGen(string DocType, string YYMM, string Brno)
    {
        //產生表單編號，若舊表單編號大於或等於本年第一號，則使用舊表單編號 + 1
        string DocNo = DocType + YYMM + Brno + "01";
        string OldDocNo = DocNo;

        try
        {
            using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_iom"].ToString()))
            {
                cn.Open();
                string SqlCmd = "SELECT MAX(DocNo) AS MAXDocNo FROM ApproveDetail WHERE (DocType=@DocType) and (BrNo = @BrNo) and (YYMM=@YYMM)";
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    cmd.Parameters.AddWithValue("@DocType", DocType);
                    cmd.Parameters.AddWithValue("@BrNo", Brno);
                    cmd.Parameters.AddWithValue("@YYMM", YYMM);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            DataTable result = new DataTable();
                            result.Load(dr);
                            OldDocNo = result.Rows[0][0].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            DocNo = DocNo + "——>查詢表單編號錯誤，錯誤訊息：" + ex;
        }
        if (String.Compare(OldDocNo, DocNo) != -1)  //舊表單編號不大於新表單編號
        {
            int DocNoNo = Convert.ToInt32(OldDocNo.Substring(OldDocNo.Length - 2, 2)) + 1;
            DocNo = DocType + YYMM + Brno + DocNoNo.ToString("00");
        }
        return DocNo;
    }

    /// <summary>
    /// OA：表單編號產生-自訂單位代號版
    /// </summary>
    /// <param name="DocType">表單代號</param>
    /// <param name="YYMM">表單期別</param>
    /// <param name="Brno">單位代號</param>
    /// <param name="BrnoStart">單位代號起始位置</param>
    /// <param name="BrnoLength">單位代號長度</param>
    /// <returns>DocNo表單編號</returns>
    public static string DocNoGenByDefine(string DocType, string YYMM, string Brno, int BrnoStart, int BrnoLength)
    {
        //產生表單編號，若舊表單編號大於或等於本年第一號，則使用舊表單編號 + 1
        string DocNo = DocType + YYMM + Brno + "01";
        string OldDocNo = DocNo;

        try
        {
            using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_iom"].ToString()))
            {
                cn.Open();
                string SqlCmd = "SELECT MAX(DocNo) AS MAXDocNo FROM ApproveDetail WHERE (DocType=@DocType) and (SUBSTRING(DocNo,@BrnoStart,@BrnoLength) = @BrNo) and (YYMM=@YYMM)";
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    cmd.Parameters.AddWithValue("@DocType", DocType);
                    cmd.Parameters.AddWithValue("@BrNo", Brno);
                    cmd.Parameters.AddWithValue("@YYMM", YYMM);
                    cmd.Parameters.AddWithValue("@BrnoStart", BrnoStart);
                    cmd.Parameters.AddWithValue("@BrnoLength", BrnoLength);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            DataTable result = new DataTable();
                            result.Load(dr);
                            OldDocNo = result.Rows[0][0].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            DocNo = DocNo + "——>查詢表單編號錯誤，錯誤訊息：" + ex;
        }
        if (String.Compare(OldDocNo, DocNo) != -1)  //舊表單編號不大於新表單編號
        {
            int DocNoNo = Convert.ToInt32(OldDocNo.Substring(OldDocNo.Length - 2, 2)) + 1;
            DocNo = DocType + YYMM + Brno + DocNoNo.ToString("00");
        }
        return DocNo;
    }


    /// <summary>
    /// OA：本期表單狀態
    /// </summary>
    /// <param name="DocType">表單代號</param>
    /// <param name="YYMM">表單期別</param>
    /// <param name="Brno">單位代號</param>
    /// <returns>DocStatus表單流程狀態代碼</returns>
    public static string DocStatus(string DocType, string YYMM, string Brno)
    {
        string DocStatus = "0";

        try
        {
            using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_iom"].ToString()))
            {
                cn.Open();
                string SqlCmd = "SELECT FlowStatus FROM ApproveDetail WHERE (DocType = @DocType) AND (BrNo = @BrNo) AND (YYMM = @YYMM) order by DocNo desc";
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    cmd.Parameters.AddWithValue("@DocType", DocType);
                    cmd.Parameters.AddWithValue("@BrNo", Brno);
                    cmd.Parameters.AddWithValue("@YYMM", YYMM);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            DataTable result = new DataTable();
                            result.Load(dr);
                            DocStatus = result.Rows[0][0].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            DocStatus = "——>查詢表單錯誤，錯誤訊息：" + ex;
        }
        return DocStatus;
    }

    /// <summary>
    /// OA：本期表單狀態顯示給User的訊息，可直接放在msg.text
    /// </summary>
    /// <param name="DocType">表單代號</param>
    /// <param name="YYMM">表單期別</param>
    /// <param name="Brno">單位代號</param>
    /// <returns>message表單流程狀態顯示給User的訊息</returns>
    public static string DocStatusMessage(string DocType, string YYMM, string Brno)
    {
        string message = "", DocStatus = "";

        DocStatus = EfromBI.DocStatus(DocType, YYMM, Brno);


        if (DocStatus != "0")
        {
            message = "本期已填報";
            if (DocStatus == "1")
                message = "本期填報資料待放行";
            else if (DocStatus == "2")
                message = "本期填報資料待決行";
        }
        return message;
    }

    /// <summary>
    /// OA：本期表單狀態顯示給User的訊息-自訂單位代號版
    /// </summary>
    /// <param name="DocType">表單代號</param>
    /// <param name="YYMM">表單期別</param>
    /// <param name="Brno">單位代號</param>
    /// <param name="BrnoStart">單位代號起始位置</param>
    /// <param name="BrnoLength">單位代號長度</param>
    /// <returns>DocStatus表單流程狀態代碼</returns>
    public static string DocStatusMessageByDefine(string DocType, string YYMM, string Brno, int BrnoStart, int BrnoLength)
    {
        string message = "";
        string DocStatus = "0";

        try
        {
            using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_iom"].ToString()))
            {
                cn.Open();
                string SqlCmd = "SELECT FlowStatus FROM ApproveDetail WHERE (DocType = @DocType) AND (SUBSTRING(DocNo,@BrnoStart,@BrnoLength) = @BrNo) AND (YYMM = @YYMM) order by DocNo desc";
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    cmd.Parameters.AddWithValue("@DocType", DocType);
                    cmd.Parameters.AddWithValue("@BrNo", Brno);
                    cmd.Parameters.AddWithValue("@YYMM", YYMM);
                    cmd.Parameters.AddWithValue("@BrnoStart", BrnoStart);
                    cmd.Parameters.AddWithValue("@BrnoLength", BrnoLength);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            DataTable result = new DataTable();
                            result.Load(dr);
                            DocStatus = result.Rows[0][0].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            DocStatus = "——>查詢表單錯誤，錯誤訊息：" + ex;
            return DocStatus;
        }
        if (DocStatus != "0")
        {
            message = "本期已填報";
            if (DocStatus == "1")
                message = "本期填報資料待放行";
            else if (DocStatus == "2")
                message = "本期填報資料待決行";
        }
        return message;
    }
    /// <summary>
    /// OA：新增LogDetail並新增待辦事項通知負責人
    /// </summary>
    /// <param name="DocType">表單代號</param>
    /// <param name="DocNo">表單編號</param>
    /// <param name="Brno">單位代號</param>
    /// <param name="EmpId">填報人員編</param>
    /// <param name="YYMM">表單期別</param>
    /// <param name="CheckRepeat">是否檢核期別重複</param>
    /// <returns>成功：Y，失敗：錯誤訊息</returns>
    public static string NewLogDetail(string DocType, string DocNo, string Brno, string EmpId, string YYMM, bool CheckRepeat)
    {
        string success = "Y";
        //先查詢本期表單狀態，0代表未填報或已退回，此時可新增LogDetail
        string DocStatus = EfromBI.DocStatus(DocType, YYMM, Brno);

        if (DocStatus == "0" || CheckRepeat == false)
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_iom"].ToString()))
                {
                    cn.Open();
                    string SqlCmd = "INSERT INTO ApproveDetail(DocType, DocNo, BrNo, EmpId, RecordDate, YYMM, FlowStatus, DataFlag) VALUES (@DocType, @DocNo, @BrNo, @EmpId, getdate(), @YYMM, @FlowStatus, @DataFlag)";
                    using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                    {
                        cmd.Parameters.AddWithValue("@DocType", DocType);
                        cmd.Parameters.AddWithValue("@DocNo", DocNo);
                        cmd.Parameters.AddWithValue("@BrNo", Brno);
                        cmd.Parameters.AddWithValue("@EmpId", EmpId);
                        cmd.Parameters.AddWithValue("@YYMM", YYMM);
                        cmd.Parameters.AddWithValue("@FlowStatus", "1");
                        cmd.Parameters.AddWithValue("@DataFlag", "");
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                success = ex.Message;
            }
        }
        else
        {
            success = "您已填報過本期表單";
        }
        if (success == "Y")
        {   //新增待辦事項Thread
            var tsk = Task.Factory.StartNew(() => TodoSendThread(DocNo, "0", DocType));
            //Task.WaitAll(tsk);
            //DataTable table = tsk.Result;
            //Thread doTodoSendThread = new Thread(() => TodoSendThread(DocNo, "0"));
            //doTodoSendThread.Start();
            //doTodoSendThread.Join();
        }
        return success;
    }
    private static void TodoSendThread(string DocNo, string ManagerPage,string Tid)
    {
        //傳送待辦事項
        string TodoReturn;
        Todolist Todolist = new Todolist();
        TodoReturn = Todolist.DefaultSend(DocNo, ManagerPage, Tid);
    }
    /// <summary>
    /// 抓第一筆資料某欄位的值
    /// </summary>
    /// <param name="ds">SqlDataSource名稱</param>
    /// <param name="Field">欄位名稱</param>
    /// <returns>第一筆資料欄位的值</returns>
    public static string SelectDSField(SqlDataSource ds, string Field)
    {
        string returnvalue = "";
        using (DataView dv = ds.Select(new DataSourceSelectArguments()) as DataView)
        {
            if (dv != null && dv.Table.Rows.Count > 0)
            {
                returnvalue = dv[0][Field].ToString();
                dv.Dispose();
            }
        }
        return returnvalue;
    }

    /// <summary>
    /// 抓第一筆資料的值
    /// </summary>
    /// <param name="ds">SqlDataSource名稱</param>
    /// <returns>第一筆資料的值[]</returns>
    public static string[] SelectDSFirstRecord(SqlDataSource ds)
    {
        string[] returnvalue;
        using (DataView dv = ds.Select(new DataSourceSelectArguments()) as DataView)
        {
            if (dv != null && dv.Table.Rows.Count > 0)
            {
                returnvalue = new string[dv.Table.Columns.Count];
                for (int i = 0; i < dv.Table.Columns.Count; i++)
                {
                    returnvalue[i] = dv[0][i].ToString();
                }
                dv.Dispose();
            }
            else
                returnvalue = new string[1];
        }
        return returnvalue;
    }

    /// <summary>
    /// OA：抓現在填報年月
    /// </summary>
    /// <param name="Period">期間：m月、y年、Y不帶00的年、s季</param>
    /// <param name="MinusMonth">1前期、0本期</param>
    /// <returns>YYMM填報年月</returns>
    public static string GetYYMM(string Period, string MinusMonth)
    {
        string YYMM = (int.Parse(DateTime.Now.ToString("yyyy")) - 1911).ToString();
        switch (Period)
        {
            case "y":
                if (MinusMonth == "1")
                    YYMM = (int.Parse(DateTime.Now.AddYears(-1).ToString("yyyy")) - 1911).ToString() + "00";
                else
                    YYMM = (int.Parse(DateTime.Now.ToString("yyyy")) - 1911).ToString() + "00";
                break;
            case "Y":
                if (MinusMonth == "1")
                    YYMM = (int.Parse(DateTime.Now.AddYears(-1).ToString("yyyy")) - 1911).ToString();
                else
                    YYMM = (int.Parse(DateTime.Now.ToString("yyyy")) - 1911).ToString();
                break;
            case "s":
                int MonthNow = int.Parse(DateTime.Now.ToString("MM"));
                if (MonthNow < 4)
                {
                    YYMM = (int.Parse(DateTime.Now.ToString("yyyy")) - 1911).ToString() + "01";
                }
                else if (MonthNow < 7)
                {
                    YYMM = (int.Parse(DateTime.Now.ToString("yyyy")) - 1911).ToString() + "04";
                }
                else if (MonthNow < 10)
                {
                    YYMM = (int.Parse(DateTime.Now.ToString("yyyy")) - 1911).ToString() + "07";
                }
                else
                {
                    YYMM = (int.Parse(DateTime.Now.ToString("yyyy")) - 1911).ToString() + "10";
                }
                break;
            default:
                if (MinusMonth == "1")
                    YYMM = DateTimeUtility.GetTaiwanYYMM(DateTime.Now.AddMonths(-1));
                else
                    YYMM = DateTimeUtility.GetTaiwanYYMM(DateTime.Now);
                break;
        }
        return YYMM;
    }

    /// <summary>
    /// 將SqlDataSource的資料轉換成直式DataTable
    /// </summary>
    /// <param name="DS">SqlDataSource名稱</param>
    /// <returns>直式DataTable，直接下GridView.DataSource = 直式DataTable;GridView.DataBind();即可顯示在GridView</returns>
    public static DataTable DSVertical(SqlDataSource DS)
    {
        using (DataView dv = DS.Select(new DataSourceSelectArguments()) as DataView)
        {
            DataTable dt = new DataTable(); ;
            if (dv != null && dv.Table.Rows.Count > 0)
            {
                dt = dv.Table;
            }
            DataTable showTB = new DataTable();
            showTB.Columns.Add("表頭");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                showTB.Columns.Add("資料" + (i + 1).ToString());
            }
            //以下迴圈針對Column做轉向處理
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                DataRow dr = showTB.NewRow();
                dr["表頭"] = dt.Columns[i].Caption;
                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    dr["資料" + (j + 1).ToString()] = dt.Rows[j][i].ToString();
                }
                showTB.Rows.Add(dr);
            }
            return showTB;
        }
    }
}