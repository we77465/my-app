﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;

/// <summary>
/// RegExp 的摘要描述
/// </summary>
public class RegExp
{
	public RegExp()
	{

	}
    public static string CheckDateValue(string InString, string[] delimiter)
    {
        bool cont = false;
        for (int i = 0; i < delimiter.Length; i++)
        {
            if (InString.LastIndexOf(delimiter[i]) != -1)
                cont = true;
        }

        if (cont == true)
        {
            //string[] sep = new string[] { "/" };
            string[] temp = InString.Trim().Split(delimiter, StringSplitOptions.RemoveEmptyEntries);
            DateTime a = new DateTime(int.Parse(temp[0]), int.Parse(temp[1]), int.Parse(temp[2]), 0, 0, 0);
            return a.AddYears(-1911).ToString("yyyMMdd");
        }
        else return InString;
    }


    /// <summary>
    /// 檢查是否為數字
    /// </summary>
    /// <param name="strToCheck"></param>
    /// <returns></returns>
    public static bool IsAlphaNumeric(String strToCheck)
    {
        Regex objAlphaNumericPattern = new Regex("[^a-zA-Z0-9]");
        return !objAlphaNumericPattern.IsMatch(strToCheck);
    }

    /// <summary>
    /// 檢查是否為正整數包括零
    /// </summary>
    /// <param name="strNumber"></param>
    /// <returns></returns>
    public static bool IsWholeNumber(String strNumber)
    {
        Regex objNotWholePattern = new Regex("[^0-9]");
        return !objNotWholePattern.IsMatch(strNumber);
    }

    /// <summary>
    /// 檢查自然數包括實數
    /// </summary>
    /// <param name="strNumber"></param>
    /// <returns></returns>
    public static bool IsPositiveNumber(String strNumber)
    {
        Regex objNotPositivePattern = new Regex("[^0-9.]");
        Regex objPositivePattern = new Regex("^[.][0-9]+$|[0-9]*[.]*[0-9]+$");
        Regex objTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*");
        return !objNotPositivePattern.IsMatch(strNumber) &&
        objPositivePattern.IsMatch(strNumber) &&
        !objTwoDotPattern.IsMatch(strNumber);
    }
    /// <summary>
    /// 檢查是否為合法email
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsEmail(string inputEmail)
    {
        string strRegex = @"^\w+((-\w+)|(\.\w+))*\@\w+((\.|-)\w+)*\.\w+$";
        //string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查輸入數字是否位數符合
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <param name="median"></param>
    /// <returns></returns>
    public static bool IsNumberMedianMatch(string inputEmail, int median)
    {
        string strRegex = @"^\d{" + median.ToString() + "}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查輸入數字是否最少為n位數
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <param name="median">n</param>
    /// <returns></returns>
    public static bool IsNumberMedianMatchlast(string inputEmail, int median)
    {
        string strRegex = @"^\d{" + median.ToString() + ",}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查輸入數字是否在MAX到MIN位數
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <param name="Max">最大位數</param>
    /// <param name="Min">最小位數</param>
    /// <returns></returns>
    public static bool IsNumberInRange(string inputEmail, int Max, int Min)
    {
        string strRegex = @"^\d{" + Max.ToString() + "," + Min.ToString() + "}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為金額 小數固定為兩位
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsAmount(string inputEmail)
    {
        string strRegex = "^[0-9]+(.[0-9]{2})?$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為金額 小數為一位或兩位
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsAmountLast(string inputEmail)
    {
        string strRegex = "^[0-9]+(.[0-9]{1,2})?$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為非零的正整數
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsPositiveInteger(string inputEmail)
    {
        string strRegex = @"^\+?[1-9][0-9]*$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為非零的負整數
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsNegativeInteger(string inputEmail)
    {
        string strRegex = @"^\-?[1-9][0-9]*$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查字串是否符合長度
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <param name="median"></param>
    /// <returns></returns>
    public static bool IsStringMatchLength(string inputEmail, int median)
    {
        string strRegex = "^.{" + median.ToString() + "}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 是否為符合型式的密碼,字母開頭,長度6~18,字母及數字和下底線混合
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsValidPassword(string inputEmail)
    {
        string strRegex = @"^[a-zA-Z]\w{5,17}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為網址
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsWebSite(string inputEmail)
    {
        string strRegex = @"^http://([\w-]+\.)+[\w-]+(/[\w-./?%&=]*)?$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為月份 01~09 , 1~12
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsMonth(string inputEmail)
    {
        string strRegex = "^(0?[1-9]|1[0-2])$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為日期 01~09 , 1~31
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsDay(string inputEmail)
    {
        string strRegex = "^((0?[1-9])|((1|2)[0-9])|30|31)$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }

    /// <summary>
    /// 檢查是否有下列符號 ^%&’,;=?$\"
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsDelimiter(string inputEmail)
    {
        string strRegex = "[^%&’,;=?$\x22]+";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }

    /// <summary>
    /// 檢查是否有逗點分割的字串
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsDotString(string inputEmail)
    {
        string strRegex = @"^([\w\d\u4e00-\u9fa5],?)+$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為漢字
    /// </summary>
    /// <param name="inputEmail"></param>
    /// <returns></returns>
    public static bool IsChiWord(string inputEmail)
    {
        string strRegex = "^[\u4e00-\u9fa5]{0,}$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
    /// <summary>
    /// 檢查是否為身分證字號
    /// </summary>
    /// <param name="ID"></param>
    /// <returns></returns>
    public static bool CHECKID(string ID)
    {
        if (ID.Length != 10) return false;
        string NEWID = "";
        int[] MULT = new int[] { 1, 9, 8, 7, 6, 5, 4, 3, 2, 1, 1 };
        int SUM = 0;
        bool RESULT = true;
        switch (ID.Substring(0, 1).ToUpper())
        {
            case "A":
                NEWID = "10";
                break;
            case "B":
                NEWID = "11";
                break;
            case "C":
                NEWID = "12";
                break;
            case "D":
                NEWID = "13";
                break;
            case "E":
                NEWID = "14";
                break;
            case "F":
                NEWID = "15";
                break;
            case "G":
                NEWID = "16";
                break;
            case "H":
                NEWID = "17";
                break;
            case "J":
                NEWID = "18";
                break;
            case "K":
                NEWID = "19";
                break;
            case "L":
                NEWID = "20";
                break;
            case "M":
                NEWID = "21";
                break;
            case "N":
                NEWID = "22";
                break;
            case "P":
                NEWID = "23";
                break;
            case "Q":
                NEWID = "24";
                break;
            case "R":
                NEWID = "25";
                break;
            case "S":
                NEWID = "26";
                break;
            case "T":
                NEWID = "27";
                break;
            case "U":
                NEWID = "28";
                break;
            case "V":
                NEWID = "29";
                break;
            case "X":
                NEWID = "30";
                break;
            case "Y":
                NEWID = "31";
                break;
            case "W":
                NEWID = "32";
                break;
            case "Z":
                NEWID = "33";
                break;
            case "I":
                NEWID = "34";
                break;
            case "O":
                NEWID = "35";
                break;
            default:
                return false;
            // break;
        }
        NEWID += ID.Substring(1, 9);
        for (int i = 0; i < NEWID.Length; i++)
        {
            SUM += int.Parse(NEWID.Substring(i, 1)) * MULT[i];
        }
        if (SUM % 10 != 0) RESULT = false;
        return RESULT;
    }
    /// <summary>
    /// Format the string to meet the right format. Algins to left, padding on the right with the padchar/
    /// </summary>
    /// <param name="value">要格式的字串</param>
    /// <param name="totallength">全部長度</param>
    /// <param name="padchar">要補齊的字元</param>
    /// <returns>已格式的字串</returns>
    public static string StringPadRight(string value, int totallength, char padchar)
    {
        if (value == null)
            value = "";

        if (value.Length > totallength)
            value = value.Substring(0, totallength);
        return value.PadRight(totallength, padchar);
    }

    /// <summary>
    /// Format the string to meet the left format. Algins to right, padding on the left with the padchar/
    /// </summary>
    /// <param name="value">要格式的字串</param>
    /// <param name="totallength">全部長度</param>
    /// <param name="padchar">要補齊的字元</param>
    /// <returns>已格式的字串</returns>
    public static string StringPadLeft(string value, int totallength, char padchar)
    {
        if (value == null)
            value = "";

        if (value.Length > totallength)
            value = value.Substring(0, totallength);
        return value.PadLeft(totallength, padchar);
    }
}
