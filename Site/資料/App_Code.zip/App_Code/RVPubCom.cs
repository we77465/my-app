﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// RVPubCom 的摘要描述
/// </summary>
public class RVPubCom
{
	public RVPubCom()
	{
		//
		// TODO: 在這裡新增建構函式邏輯
		//
	}
    #region 限定ReportViewer匯出格式
    private string mRVExpFmt;
    public void RVExport(System.Web.UI.Control reportControl, string ExpFmt)
    {
        foreach (System.Web.UI.Control childControl in reportControl.Controls)
        {
            if (childControl.GetType() == typeof(System.Web.UI.WebControls.DropDownList))
            {
                mRVExpFmt = set_mRVExpFmt(ExpFmt);
                System.Web.UI.WebControls.DropDownList ddList = (System.Web.UI.WebControls.DropDownList)childControl;
                ddList.PreRender += new EventHandler(ddList_PreRender);
            }
            if (childControl.Controls.Count > 0)
            {
                RVExport(childControl, ExpFmt);
            }
        }
    }
    private string set_mRVExpFmt(string strFormat)
    {
        strFormat = "選取格式|Select a format|" + strFormat;
        char[] separator1 = new char[] { '|' };
        string[] FormatList = strFormat.Split(separator1);
        for (int i = 0; i < FormatList.Length; i++)
        {
            switch (FormatList[i].ToUpper())
            {
                case "PDF":
                    FormatList[i] = "Acrobat(PDF)檔案|";
                    break;
                case "EXCEL":
                    FormatList[i] = "Excel|";
                    break;
                case "WORD":
                    FormatList[i] = "Word|";
                    break;
                case "CSV":
                    FormatList[i] = "CSV(逗號分隔)|";
                    break;
                case "XML":
                    FormatList[i] = "包含報表資料的XML檔|";
                    break;
                case "MHTML":
                    FormatList[i] = "MHTML(網頁封存)|";
                    break;
                case "TIFF":
                    FormatList[i] = "TIFF檔案";
                    break;
            }
        }
        return String.Join("|", FormatList);
    }
    private void ddList_PreRender(object sender, EventArgs e)
    {
        if (sender.GetType() == typeof(System.Web.UI.WebControls.DropDownList))
        {
            System.Web.UI.WebControls.DropDownList ddList = (System.Web.UI.WebControls.DropDownList)sender;
            System.Web.UI.WebControls.ListItemCollection listItems = ddList.Items;
            if ((listItems != null) && (listItems.Count > 0) && ((listItems.FindByText("選取格式") != null) ||
                (listItems.FindByText("Select a format") != null)))
            {
                foreach (System.Web.UI.WebControls.ListItem list in listItems)
                {
                    if (mRVExpFmt.IndexOf(list.Text) < 0)
                    {
                        list.Enabled = false;
                    }
                }
            }
        }
    }
    #endregion
}