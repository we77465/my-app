using System;
// 2012/4/12 �ץ�connectionstring���V���s�b���W��
// 2017/09/30 153508
// 2023/11/22  176752 Modify�GVB TO C��

using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using Microsoft.VisualBasic.CompilerServices; // Install-Package Microsoft.VisualBasic

/// <summary>
/// �O�޽c�t�θ�Ʈw�s��
/// </summary>
public partial class DBAccess
{

    public int RowCount;
    public int PC;
    public string Message;

    public List<SqlCommand> CommandCollection;
    public List<string> CommandName;

    public List<DataTable> BulkCopyDataTable;
    public List<string> BulkCopyTableName;
    public List<bool> BulkCopyTruncateTb;

    private string _ConnectionString = WebConfigurationManager.ConnectionStrings["MBoxConnectionString"].ConnectionString;

    public DBAccess()
    {
        CommandCollection = new List<SqlCommand>();
        CommandName = new List<string>();
        BulkCopyDataTable = new List<DataTable>();
        BulkCopyTableName = new List<string>();
        BulkCopyTruncateTb = new List<bool>();
    }

    public DBAccess(string connStr)
    {
        _ConnectionString = connStr;
        CommandCollection = new List<SqlCommand>();
        CommandName = new List<string>();
        BulkCopyDataTable = new List<DataTable>();
        BulkCopyTableName = new List<string>();
        BulkCopyTruncateTb = new List<bool>();
    }

    /// <summary>
    /// ����SQL�R�O
    /// </summary>
    /// <param name="cmd"></param>
    public void ExecuteCommand(SqlCommand cmd)
    {

        var conn = new SqlConnection(ConnectionString);
        conn.Open();

        try
        {
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            conn.Close();
            cmd.Dispose();
        }
    }

    /// <summary>
    /// ����Ҧ�SQL�R�O
    /// </summary>
    public void ExecuteAllCommand()
    {

        var conn = new SqlConnection(ConnectionString);
        conn.Open();
        var tran = conn.BeginTransaction();

        int count = 0;
        // Dim Pstr As String
        int AffectRows;
        try
        {
            foreach (SqlCommand cmd in CommandCollection)
            {
                count += 1;
                cmd.Connection = conn;
                cmd.Transaction = tran;
                AffectRows = cmd.ExecuteNonQuery();
            }
            tran.Commit();
        }
        catch (Exception ex)
        {
            tran.Rollback();
            throw new Exception("����" + CommandName[count - 1] + "�ɵo�Ϳ��~�I���~�T���G" + ex.Message);
        }
        finally
        {
            conn.Close();
            foreach (SqlCommand cmd in CommandCollection)
                cmd.Dispose();
            tran.Dispose();

            CommandCollection.Clear();
            CommandName.Clear();
        }
    }

    /// <summary>
    /// ����Ҧ�SQL��BulkCopy�R�O
    /// </summary>
    /// <remarks></remarks>
    public void ExecuteAllCommandAndInsertFromDataTable()
    {

        var conn = new SqlConnection(ConnectionString);
        conn.Open();
        var tran = conn.BeginTransaction();


        try
        {

            var bulkCpy = new SqlBulkCopy(conn, SqlBulkCopyOptions.KeepIdentity, tran);

            int count = 0;
            int BulkCount = 0;
            int AffectRows;

            foreach (SqlCommand cmd in CommandCollection)
            {
                count += 1;
                cmd.Connection = conn;
                cmd.Transaction = tran;
                AffectRows = cmd.ExecuteNonQuery();
            }

            foreach (DataTable tb in BulkCopyDataTable)
            {

                BulkCount += 1;

                // �YTruncate���O=True
                if (BulkCopyTruncateTb[BulkCount - 1])
                {
                    // ����M�Ÿ�ƪ�
                    var TruncateTbCmd = new SqlCommand("Truncate table " + BulkCopyTableName[BulkCount - 1], conn, tran);
                    TruncateTbCmd.ExecuteNonQuery();
                }

                // �qDataTable�N��ƶפJ�ܸ�ƪ�
                bulkCpy.BulkCopyTimeout = 300;
                bulkCpy.DestinationTableName = "dbo.[" + BulkCopyTableName[BulkCount - 1] + "]";
                bulkCpy.WriteToServer(tb);
            }

            tran.Commit();
        }

        catch (Exception ex)
        {
            tran.Rollback();
            throw new Exception("����ɵo�Ϳ��~�I���~�T���G" + ex.Message);
        }
        finally
        {
            conn.Close();
            foreach (SqlCommand cmd in CommandCollection)
                cmd.Dispose();
            foreach (DataTable tb in BulkCopyDataTable)
                tb.Dispose();
            tran.Dispose();
            CommandCollection.Clear();
            CommandName.Clear();
            BulkCopyDataTable.Clear();
            BulkCopyTableName.Clear();
            BulkCopyTruncateTb.Clear();
        }

    }

    /// <summary>
    /// ����SQL�R�O�A�öǦ^����v�T����
    /// </summary>
    /// <param name="cmd"></param>
    /// <returns>����v�T����</returns>
    /// <remarks></remarks>
    public int ExecuteSQL(SqlCommand cmd)
    {

        var conn = new SqlConnection(ConnectionString);
        conn.Open();

        cmd.Connection = conn;

        int rtnValue = -1;

        try
        {
            rtnValue = cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            conn.Close();
            cmd.Dispose();
        }

        return rtnValue;

    }

    /// <summary>
    /// ����SQL�R�O�A�öǦ^����v�T����
    /// </summary>
    /// <returns>����v�T����</returns>
    /// <remarks></remarks>
    public int ExecuteSQL(string SQLString)
    {

        var conn = new SqlConnection(ConnectionString);
        conn.Open();
        var cmd = new SqlCommand(SQLString, conn);
        cmd.Connection = conn;

        int rtnValue = -1;

        try
        {
            rtnValue = cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            conn.Close();
            cmd.Dispose();
        }

        return rtnValue;

    }

    /// <summary>
    /// ����SQL�R�O�A�è��o�Ǧ^���Ĥ@��Ĥ@�C��m�����
    /// </summary>
    /// <param name="Cmd">SQL�R�O</param>
    /// <returns>�Ǧ^���Ĥ@��Ĥ@�C��m�����</returns>
    /// <remarks></remarks>
    public string ExecuteScalar(SqlCommand Cmd)
    {

        var conn = new SqlConnection(ConnectionString);
        conn.Open();

        Cmd.Connection = conn;

        try
        {
            return Conversions.ToString(Cmd.ExecuteScalar());
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
        finally
        {
            conn.Close();
            Cmd.Dispose();
        }

    }

    /// <summary>
    /// ����SQL�R�O�A�è��o�Ǧ^���Ĥ@��Ĥ@�C��m�����
    /// </summary>
    /// <param name="SQLString">SQL�R�O</param>
    /// <returns>�Ǧ^���Ĥ@��Ĥ@�C��m�����</returns>
    /// <remarks></remarks>
    public string ExecuteScalar(string SQLString)
    {

        var conn = new SqlConnection(ConnectionString);
        conn.Open();
        var Cmd = new SqlCommand(SQLString, conn);

        try
        {
            return Conversions.ToString(Cmd.ExecuteScalar());
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
        finally
        {
            conn.Close();
            Cmd.Dispose();
        }

    }

    public int InsertFromDataTable(string TableName, DataTable dt, bool TruncateTable = false)
    {

        var conn = new SqlConnection(ConnectionString);
        conn.Open();
        var trans = conn.BeginTransaction();

        var cmd = new SqlCommand("Truncate table " + TableName, conn, trans);
        var bulkCpy = new SqlBulkCopy(conn, SqlBulkCopyOptions.KeepIdentity, trans);

        try
        {
            if (TruncateTable)
                cmd.ExecuteNonQuery();

            bulkCpy.BulkCopyTimeout = 300;
            bulkCpy.DestinationTableName = "dbo." + TableName;
            bulkCpy.WriteToServer(dt);

            trans.Commit();

            Message = "���榨�\�I";

            return 1;
        }

        catch (Exception ex)
        {
            // Message = ex.Message
            trans.Rollback();
            throw new Exception("����ɵo�Ϳ��~�I���~�T���G" + ex.Message);
        }
        finally
        {
            conn.Close();
            trans.Dispose();
        }
    }

    /// <summary>
    /// ���o��ƪ��M��
    /// </summary>
    /// <returns>��ƪ��M��</returns>
    /// <remarks></remarks>
    public DataTable GetTableList()
    {
        return GetDataTableBySQL("SELECT name as TableName	FROM sysobjects	WHERE xtype = 'U' order by 1");

    }

    public DataTable GetDataTableBySQL(SqlCommand SqlCmd)
    {

        var conn = new SqlConnection(ConnectionString);
        SqlCmd.Connection = conn;
        var ds = new DataSet();

        try
        {
            conn.Open();
            var da = new SqlDataAdapter(SqlCmd);

            da.Fill(ds);
        }

        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            if (conn != null)
                conn.Close();
        }

        return ds.Tables[0];

    }

    public DataTable GetDataTableBySQL(string SqlStr)
    {

        var conn = new SqlConnection(ConnectionString);
        var SqlCmd = new SqlCommand(SqlStr, conn);
        var ds = new DataSet();

        try
        {
            conn.Open();
            var da = new SqlDataAdapter(SqlCmd);

            da.Fill(ds);
        }

        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        finally
        {
            if (conn != null)
                conn.Close();
        }

        return ds.Tables[0];

    }

    public DataSet GetDataSetBySQL(SqlCommand sqlcmd)
    {

        var conn = new SqlConnection(ConnectionString);
        var ds = new DataSet();

        try
        {

            sqlcmd.Connection = conn;
            conn.Open();

            var da = new SqlDataAdapter(sqlcmd);
            da.Fill(ds);

            return ds;
        }

        catch (Exception ex)
        {

            throw new Exception(ex.Message);
        }
        finally
        {

            conn.Close();

        }

    }

    public SqlDbType GetSQLDbType(string sType)
    {
        switch (sType.ToLower().Replace("system.", "") ?? "")
        {
            case "string":
                {
                    return SqlDbType.VarChar;
                }

            case "double":
            case "decimal":
                {
                    return SqlDbType.Decimal;
                }
            case "boolean":
                {
                    return SqlDbType.Bit;
                }
            case "int16":
            case "int32":
            case "byte":
                {
                    return SqlDbType.Int;
                }
            case "datetime":
                {
                    return SqlDbType.DateTime;
                }

            default:
                {
                    throw new Exception("Unknown Type!" + sType);
                }
        }

    }

    public void AddCommand(SqlCommand cmd, string cmdName)
    {
        CommandCollection.Add(cmd);
        CommandName.Add(cmdName);
    }

    public void AddDataTable(DataTable tb, string tbName, bool TruncateTable = false)
    {
        BulkCopyDataTable.Add(tb);
        BulkCopyTableName.Add(tbName);
        BulkCopyTruncateTb.Add(TruncateTable);
    }

    public string ConnectionString
    {
        get
        {
            return _ConnectionString;
        }
        set
        {
            _ConnectionString = value;
        }
    }


}