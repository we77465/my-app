﻿using IBM.WMQ;
using System;
using System.Configuration;
using System.Collections;
/// <summary>
/// MQDlvComNow 的摘要描述
/// </summary>
public class MQDlvComNow
{
    #region EAI連接資訊
    //EAI連件資訊

    static string QueueManagerName = ConfigurationManager.AppSettings["QueueManagerName"];
    static string QueueChannelName = ConfigurationManager.AppSettings["QueueChannelName"];
    static string QueueConnectionName = ConfigurationManager.AppSettings["QueueConnectionName"];
    static string QueueNameAq = ConfigurationManager.AppSettings["QueueNameAq"];
    static string QueueNameAs = ConfigurationManager.AppSettings["QueueNameAs"];
    static MQQueueManager s_queueManager = null;
    #endregion

    public MQDlvComNow()
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
    }

    //寫入MQ
    public static string WriteMQMsg(string QueueName, string message, byte[] PmtID)
    {
        string strReturn = "";
        MQQueueManager queueManager;
        try
        {
            queueManager = new MQQueueManager(QueueManagerName, QueueChannelName, QueueConnectionName);
            if (s_queueManager != null && s_queueManager.IsConnected)
            {
                //s_queueManager.Disconnect();
                //s_queueManager = null;
            }
            s_queueManager = queueManager;
        }
        catch (MQException exp)
        {
            queueManager = s_queueManager;
            //strReturn = "WriteMQMsg Exception: " + exp.Message;
            //return strReturn;
        }

        try
        {
            //送出rq
            MQQueue queue = queueManager.AccessQueue(QueueNameAq, MQC.MQOO_OUTPUT + MQC.MQOO_FAIL_IF_QUIESCING + MQC.MQOO_SET_IDENTITY_CONTEXT);
            MQMessage queueMessage = new MQMessage();
            queueMessage.MessageId = PmtID;

            String RQText;
            RQText = message;

            queueMessage.Encoding = 546;
            queueMessage.CharacterSet = 1208;

            queueMessage.WriteString(RQText);
            queueMessage.Format = MQC.MQFMT_STRING;
            queueMessage.MessageType = MQC.MQMT_REQUEST;
            queueMessage.ReplyToQueueName = QueueNameAs;
            MQPutMessageOptions queuePutMessageOptions = new MQPutMessageOptions();
            queue.Put(queueMessage, queuePutMessageOptions);
            queue.Close();
            strReturn = "OK";

        }
        catch (MQException MQexp)
        {
            strReturn = "write ExceptionMQ: " + MQexp.Message;
        }
        catch (Exception exp)
        {
            strReturn = "write Exception: " + exp.Message;
        }

        if (s_queueManager == queueManager)
        {
            queueManager.Disconnect();
            s_queueManager = null;
        }

        return strReturn;
    }

    //讀取MQ
    public static string ReadMQMsg(string QueueName, string message, byte[] PmtID)
    {
        string strReturn = "";
        MQQueueManager queueManager;
        try
        {
            queueManager = new MQQueueManager(QueueManagerName, QueueChannelName, QueueConnectionName);
            if (s_queueManager != null && s_queueManager.IsConnected)
            {
                //s_queueManager.Disconnect();
                //s_queueManager = null;
            }
            s_queueManager = queueManager;
        }
        catch (MQException exp)
        {
            queueManager = s_queueManager;
            //strReturn = "ReadMQMsg Exception: " + exp.Message;
            //return strReturn;
        }

        try
        {
            //接收rs
            MQQueue Squeue = queueManager.AccessQueue(QueueNameAs, MQC.MQOO_INPUT_AS_Q_DEF + MQC.MQOO_FAIL_IF_QUIESCING + MQC.MQOO_OUTPUT);
            MQMessage SqueueMessage = new MQMessage();
            SqueueMessage.MessageId = PmtID;

            SqueueMessage.Encoding = 546;
            SqueueMessage.CharacterSet = 1208;

            MQGetMessageOptions queueGetMessageOptions = new MQGetMessageOptions();
            queueGetMessageOptions.Options = MQC.MQGMO_WAIT | MQC.MQGMO_CONVERT;                                 // tell get to wait
            queueGetMessageOptions.WaitInterval = 60 * 1000;
            Squeue.Get(SqueueMessage, queueGetMessageOptions);
            strReturn = SqueueMessage.ReadString(SqueueMessage.MessageLength);
            strReturn = strReturn + "</OK/>";
            Squeue.Close();
        }
        catch (MQException MQexp)
        {
            strReturn = "read ExceptionMQ : " + MQexp.Message;
        }
        catch (Exception exp)
        {
            strReturn = "read Exception: " + exp.Message;
        }

        if (s_queueManager == queueManager)
        {
            queueManager.Disconnect();
            s_queueManager = null;
        }

        return strReturn;
    }

    //寫入MQ回傳的資訊
    public static void RsLog(string RS, string PmtID)
    {
        //代碼不能為空值
        if (PmtID == "") return;

        string sql = "", v = "", s = "";
        sql = "Update BillReview_MQ set RsLog=@Rs ,RsDate=GetDate() where PmtID=@PmtID";
        v = RS.Replace(",", "|") + "," + PmtID;  //逗號取代成| 已防錯誤 Eric 20171108
        MQSqlClass.GetData(sql, "@Rs,@PmtID", v);
    }
}