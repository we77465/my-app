﻿using System;
using System.Collections.Generic;
using System.Web;
using System.IO;

/// <summary>
/// ZipUtility 的摘要描述
/// </summary>
public class ZipUtility
{
//    private string exefileFullpath = "C:\\Program Files (x86)\\7-Zip\\7z.exe";
    private string exefileFullpath = "C:\\Program Files\\7-Zip\\7z.exe";
    private string sourceFilePath = "E:\\ZipField\\source\\";
    private string destFilePath = "E:\\ZipField\\dest";
    public ZipUtility()
    {
        if (Directory.Exists(sourceFilePath) == false)
        {
            Directory.CreateDirectory(sourceFilePath);
        }
        if (Directory.Exists(destFilePath) == false)
        {
            Directory.CreateDirectory(destFilePath);
        }
        //
        // TODO: 在此加入建構函式的程式碼
        //
    }
    public void ExtractFile(string filename)
    {
        string sourcePath = sourceFilePath + filename;
        UnZipFile(sourceFilePath, destFilePath);
    }
    /// <summary>
    /// 解壓縮
    /// </summary>
    /// <param name="zipFile">來源</param>
    /// <param name="dstFile">目的</param>

    public static void UnZipFile(string zgetIPFile, string dstFile)
    {
        //聲明一個程式資訊類
        System.Diagnostics.ProcessStartInfo Info = new System.Diagnostics.ProcessStartInfo();

        //聲明一個程式類
        System.Diagnostics.Process Proc;

        try
        {            
            //啟動外部程式            
            //Proc = System.Diagnostics.Process.Start("C:\\Program Files (x86)\\7-Zip\\7z.exe", "x " + zgetIPFile + " -r -y -o" + dstFile);
Proc = System.Diagnostics.Process.Start("C:\\Program Files\\7-Zip\\7z.exe", "x " + zgetIPFile + " -r -y -o" + dstFile);
            Proc.WaitForExit();
        }
        catch (System.ComponentModel.Win32Exception ex)
        {
            throw ex;
        }
    }    
}