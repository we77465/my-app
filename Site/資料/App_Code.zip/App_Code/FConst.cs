﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


/// <summary>
/// FConst 的摘要描述
/// </summary>
public static class FConst
{
    
    public static string getFlowStatus(string value) 
    {
        switch (value) 
        {
           case "-1" :
               return "退回";               
           case "2":
               return "核可";               
           case "1":
               return "待簽核";               
           case "3":
               return "已決行";               
           case "4":
               return "總行確認";
           default:
               return "";
           
        }
    }

    public static string getTblLogDetailValue(string docNo,string cnnString,string field) 
    {
        SqlConnection cnn = new SqlConnection(cnnString);
        cnn.Open();
        SqlCommand cmd = new SqlCommand("select "+ field + " from tblLogDetail where DocNo='" + docNo + "'", cnn);

        string value;

        switch (field)
        {
            case "DataFlag":
                value = (cmd.ExecuteScalar() == null) ? "N" : (cmd.ExecuteScalar().ToString()=="N")?"N":"Y";
                break;
            case "FlowStatus":
                value = (cmd.ExecuteScalar() == null) ? "1" : cmd.ExecuteScalar().ToString();
                break;
            default:
                value = (cmd.ExecuteScalar() == null) ? "": cmd.ExecuteScalar().ToString();
                break;
                
        }        
       
        
        cnn.Close();
        cmd.Dispose();
              

        return value;
    }

    public static void setGridViewReadOnly(bool isReadOnly, GridView GV)
    {
        foreach (GridViewRow GVR in GV.Rows)
        {
            foreach (TableCell TC in GVR.Cells)
            {
                foreach (Control c in TC.Controls)
                {
                    if (c is TextBox)
                        ((TextBox)c).ReadOnly = isReadOnly;

                    if (c is DropDownList)
                        ((DropDownList)c).Enabled = !(isReadOnly);
                }
            }
        }
    }

    
}
