﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

/// <summary>
/// RNGUtility 的摘要描述
/// </summary>
public static class RNGUtility
{
    private static RNGCryptoServiceProvider rngp = new RNGCryptoServiceProvider();
    private static byte[] rb = new byte[4];
    #region 亂數函數處理
    /// <summary>
    /// 取得亂數所產生的英文字母大小寫與數字組合的字串,false表示不隨機產生
    /// </summary>
    /// <param name="length">要產生的亂數字串長度</param>
    /// <param name="HaveGuid">亂數種子隨索引改變</param>
    /// <returns>亂數字串</returns>
    public static string GetRandomString(int length, bool HaveGuid )
    {
        try
        {
            Random r;
            if (HaveGuid == false)
                r = new Random();
            else
                //r = new Random(DateTime.Now.Millisecond + seed);//由時間產生
                //r = new Random(unchecked((int)DateTime.Now.Ticks));//MSDN範例
                r = new Random(Guid.NewGuid().GetHashCode());//由Guid產生
            string code = "";
            for (int i = 0; i < length; i++)
            {
                switch (r.Next(0, 3))
                {
                    case 0: code += r.Next(0, 10); break;
                    case 1: code += (char)r.Next(65, 91); break;
                    case 2: code += (char)r.Next(97, 122); break;

                }
            }
            return code;
        }
        catch (Exception e)
        {            
            return null;
        }
    }
    /// <summary>
    /// 取得亂數所產生的BIG5中文字組合的字串,false表示不隨機產生種子
    /// </summary>
    /// <param name="length">要產生的亂數字串長度</param>
    /// <param name="HaveGuid">亂數種子隨索引改變</param>
    /// <returns>亂數字串</returns>
    public static string GetRandomChiString(int length, bool HaveGuid )
    {
        try
        {
            Random r;
            if (HaveGuid == false)
                r = new Random();
            else
                //r = new Random(DateTime.Now.Millisecond + seed);
                r = new Random(Guid.NewGuid().GetHashCode());//由Guid產生
            byte[] codetemp = new byte[2 * length];
            for (int i = 0; i < 2 * length; i += 2)
            {
                bool cont = true;
                do
                {
                    codetemp[i] = (byte)r.Next(0, 255);
                    codetemp[i + 1] = (byte)r.Next(0, 255);
                    byte[] temp1 = new byte[2] { codetemp[i], codetemp[i + 1] };
                    string temp2 = Encoding.GetEncoding("Big5").GetString(temp1);
                    int iCode = codetemp[i] * 256 + codetemp[i + 1];

                    if ((iCode >= 42048 && iCode <= 50814) || (iCode >= 51520 && iCode <= 63957))
                    {
                        if (temp2 == "?")

                            cont = true;
                        else
                            // chinese char big5 
                            cont = false;
                    }
                    else cont = true;

                } while (cont == true);
            }
            string strResult = Encoding.GetEncoding("Big5").GetString(codetemp);
            return strResult;
        }
        catch (Exception e)
        {            
            return null;
        }
    }

    /// <summary>
    /// 產生不重複的亂數陣列.
    /// </summary>
    /// <param name="intLower">The int lower.</param>
    /// <param name="intUpper">The int upper.</param>
    /// <param name="intNum">The int num.</param>
    /// <returns></returns>
    public static System.Collections.ArrayList MakeRandNoDuplicate(int intLower, int intUpper, int intNum)
    {

        /* 用法
         * private void btnMakeRand_Click(object sender, EventArgs e) 
         { 
            // txtLower 為 TextBox 控制項，讓使用者輸入亂數範圍下限 
            // txtUpper 為 TextBox 控制項，讓使用者輸入亂數範圍上限 
            // txtNum   為 TextBox 控制項，讓使用者輸入亂數範圍數量 
            lstboxRand.Items.Clear(); 
            System.Collections.ArrayList rnd = MakeRand(int.Parse(txtLower.Text), int.Parse(txtUpper.Text), int.Parse(txtNum.Text)); 
            lstboxRand.Items.AddRange(rnd.ToArray()); 
         }*/
        try
        {
            if (intNum > (intUpper - intLower + 1))
                return null;
            else if (intLower > intUpper)
                return null;
            else
            {
                System.Collections.ArrayList arrayRand = new System.Collections.ArrayList();
                Random random = new Random((int)DateTime.Now.Ticks);
                int intRnd;
                while (arrayRand.Count < intNum)
                {
                    intRnd = random.Next(intLower, intUpper + 1);
                    if (!arrayRand.Contains(intRnd))
                    {
                        arrayRand.Add(intRnd);
                    }
                }
                return arrayRand;
            }
        }
        catch (Exception e)
        {
            System.Collections.ArrayList arrayRand = new System.Collections.ArrayList();            
            return arrayRand;
        }
    }

    /* public static string GetRandomStringMix(int CodeLength, int seed)
     {
         try
         {
             Random r;
             if (seed.ToString() == "-1")
                 r = new Random();
             else
                 r = new Random(DateTime.Now.Millisecond + seed);
             string result = "";
             for (int i = 0; i < CodeLength; i++)
             {
                 switch (r.Next(0, 1))
                 {
                     case 0: result += NewMediaTest1.Model.Utility.RanGenerator.GetRandomString(1, i);
                             break;
                     case 1: result += NewMediaTest1.Model.Utility.RanGenerator.GetRandomChiString(1, i);
                             break;
                 }
             }
             byte[] aa = Encoding.Default.GetBytes(result);
             return Encoding.GetEncoding("Big5").GetString(aa);
         }
         catch (Exception e)
         {
             NewMediaTest1.Model.ExceptionClass.ShowMsg("RanGenerator", "GetRandomStringMix", e);
             return null;
         }
     }*/
    /// <summary>
    /// Randoms the specified rand.
    /// </summary>
    /// <param name="rand">The rand.</param>
    /// <returns></returns>
    public static int random(int rand)
    {
        try
        {
            if (rand < 1)
                return 0;
            Random random = new Random(Guid.NewGuid().GetHashCode());
            return random.Next(rand);
        }
        catch (Exception e)
        {            
            return 0;
        }
    }


    /// <summary>
    /// 由Guid產生亂數.
    /// </summary>
    /// <param name="TotalNumber">The total number.</param>
    /// <param name="choose">The choose.</param>
    /// <returns></returns>

    public static List<string> RandNumGuid(int TotalNumber, string choose)
    {
        try
        {
            List<string> result = new List<string>();
            switch (choose)
            {
                case "N": for (int i = 0; i < TotalNumber; i++)//32 位數字
                        result.Add(System.Guid.NewGuid().ToString("N"));
                    break;
                case "D": for (int i = 0; i < TotalNumber; i++)//以連字號分隔的 32 位數字
                        result.Add(System.Guid.NewGuid().ToString("D"));
                    break;
                case "B": for (int i = 0; i < TotalNumber; i++)//以連字號分隔並以大括號括起來的 32 位數字
                        result.Add(System.Guid.NewGuid().ToString("B"));
                    break;
                case "P": for (int i = 0; i < TotalNumber; i++)//以連字號分隔並以括號括起來的 32 位數字
                        result.Add(System.Guid.NewGuid().ToString("P"));
                    break;
                default: break;
            }
            return result;
        }
        catch (Exception e)
        {            
            return null;
        }
    }
    /// <summary>
    /// 產生亂數陣列大小為start-end。
    /// </summary>
    /// <param name="start">起始數字。</param>
    /// <param name="end">結束數字。</param>        
    public static int[] GenerateRandom(int start, int end)
    {
        int iLength = end - start + 1;
        int[] arrList = new int[iLength];
        for (int N1 = 0; N1 < iLength; N1++)
        {
            arrList[N1] = N1 + start;
        }

        arrList = Shuffle<int>(arrList);
        return arrList;
    }

    //洗牌。
    public static T[] Shuffle<T>(IEnumerable<T> values)
    {
        List<T> list = new List<T>(values);
        T tmp;
        int iS;
        Random r = new Random();
        for (int N1 = 0; N1 < list.Count; N1++)
        {
            iS = r.Next(N1, list.Count);
            tmp = list[N1];
            list[N1] = list[iS];
            list[iS] = tmp;
        }
        return list.ToArray();
    }
    #endregion
    /// <summary>  
    /// 產生一個非負數的亂數  
    /// </summary>  
    public static int Next()
    {
        rngp.GetBytes(rb);
        int value = BitConverter.ToInt32(rb, 0);
        if (value < 0) value = -value;
        return value;
    }

    /// <summary>  
    /// 產生一個非負數且最大值 max 以下的亂數  
    /// </summary>  
    /// <param name="max">最大值</param>  
    public static int Next(int max)
    {
        rngp.GetBytes(rb);
        int value = BitConverter.ToInt32(rb, 0);
        value = value % (max + 1);
        if (value < 0) value = -value;
        return value;
    }

    /// <summary>  
    /// 產生一個非負數且最小值在 min 以上最大值在 max 以下的亂數  
    /// </summary>  
    /// <param name="min">最小值</param>  
    /// <param name="max">最大值</param>  
    public static int Next(int min, int max)
    {
        int value = Next(max - min) + min;
        return value;
    }
}
