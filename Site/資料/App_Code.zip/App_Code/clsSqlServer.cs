﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Data.SqlClient;
//using System.Linq;

/// <summary>
/// clsSQL 的摘要描述
/// </summary>
public class clsSqlServer : clsIntraMaintainDBHandler
{

    public clsSqlServer()
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
    }

    public clsSqlServer(string ip, string dbn, string uid, string pwd)
    {
        ConnectionStringWithNoDefaultDBName = "Data Source=" + ip +
                                                ";Persist Security Info=True" +
                                                ";User ID=" + uid +
                                                ";Password=" + pwd;
        ConnectionString = ConnectionStringWithNoDefaultDBName + ";Initial Catalog=" + dbn;
    }

    public override DataTable GetTableList(string sType, string sCategory)
    {
        //select name from master.dbo.sysdatabases 
        //return GetDataTableFromSQL("SELECT distinct name FROM sysobjects WHERE xtype = 'U'","");
        return GetDataTableFromSQL("SELECT * FROM sysobjects WHERE xtype = '" + sType + "' and category = '" + sCategory + "' order by name", -1);
    }

    public override DataTable GetDataTableFromSQL(string sql, int MaxRowCount)
    {

        DataTable dt = null;
        DataRow dRow;
        int cnt = 0;

        SqlConnection conn = new SqlConnection(ConnectionString);
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        try
        {
            conn.Open();
            cmd = new SqlCommand(sql, conn);

            using (dr = cmd.ExecuteReader())
            {
                //建立datatable
                dt = new DataTable();

                DataTable dtSchema = dr.GetSchemaTable();
                if (dtSchema != null)
                {
                    foreach (DataRow drow in dtSchema.Rows)
                    {
                        string columnName = System.Convert.ToString(drow["ColumnName"]);
                        DataColumn column = new DataColumn(columnName, (Type)(drow["DataType"]));
                        dt.Columns.Add(column);
                    }
                }

                //foreach (DataRow sdrow in sdt.Rows)
                //{

                //    Type tp;


                //    switch (sdrow["DataTypeName"].ToString())
                //    {
                //        case "int":
                //            tp = Type.GetType("System.Int32");
                //            break;
                //        case "smallint":
                //            tp = Type.GetType("System.Int32");
                //            break;
                //        case "bigint":
                //            tp = Type.GetType("System.Int32");
                //            break;
                //        case "datetime":
                //            tp = Type.GetType("System.DateTime");
                //            break;
                //        case "date":
                //            tp = Type.GetType("System.DateTime");
                //            break;
                //        case "tinyint":
                //            tp = Type.GetType("System.Int32");
                //            break;
                //        case "decimal":
                //            tp = Type.GetType("System.Double");
                //            break;
                //        case "bit":
                //            tp = Type.GetType("System.Boolean");
                //            break;
                //        case "money":
                //            tp = Type.GetType("System.Double");
                //            break;
                //        default:
                //            tp = Type.GetType("System.String");
                //            break;


                //    }


                //    dt.Columns.Add(sdrow[0].ToString(), tp);
                //}

                //


                while (dr.Read())
                {

                    cnt += 1; //計算筆數

                    dRow = dt.NewRow();

                    for (int i = 0; i < dr.FieldCount; i++)
                    {
                        dRow[i] = dr[i];
                    }
                    dt.Rows.Add(dRow);

                    if (cnt >= MaxRowCount && MaxRowCount > 0) //超過自訂筆數就跳出
                        break;

                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception(ex.ToString());
        }
        finally
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
                cmd.Dispose();
                if (dr != null)
                    dr.Dispose();
            }



        }




        return dt;




        //    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
        //DataSet ds = new DataSet();
        //da.Fill(ds);
        //DataTable dt = ds.Tables[0];
        //DataTable dtTop1000 = dt.Rows.Cast<DataRow>().Take(1000).CopyToDataTable();
        ////DataTable dtTop100 = dt.AsEnumerable().Take(1000)
        ////return ds.Tables[0];
        //return dtTop1000;
    }

    public override int ExecuteNonQuery(string sql)
    {
        int rtnValue;

        SqlConnection conn = new SqlConnection(ConnectionString);
        try
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            rtnValue = cmd.ExecuteNonQuery();

            if (rtnValue == -1)
            {
                rtnValue = 0;
            }
        }
        catch (Exception ex)
        {
            rtnValue = -1;
            Message = ex.Message;
        }
        finally
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }

        return rtnValue;
    }

    public override bool isConnected()
    {
        SqlConnection conn = new SqlConnection(ConnectionStringWithNoDefaultDBName);
        bool isOK;
        try
        {
            conn.Open();
            isOK = true;
            Message = "";
        }
        catch (Exception ex)
        {
            isOK = false;
            Message = ex.Message;
        }
        return isOK;
    }

    /// <summary>
    /// 整批寫入資料表
    /// </summary>
    /// <param name="TableName">目地資料表名稱</param>
    /// <param name="dt">來源(Datatable)</param>
    /// <param name="TruncateTable">是否清空目地資料表</param>
    /// <returns></returns>
    public int InsertFromDataTable(string TableName, DataTable dt, bool TruncateTable)
    {

        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();
        SqlTransaction trans = conn.BeginTransaction();
        SqlBulkCopy bulkCpy = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, trans);

        SqlCommand cmd = new SqlCommand("Truncate table [" + TableName + "]", conn, trans);


        try
        {
            if (TruncateTable == true)
                cmd.ExecuteNonQuery();

            bulkCpy.BulkCopyTimeout = 300;
            bulkCpy.DestinationTableName = "dbo.[" + TableName + "]";
            bulkCpy.WriteToServer(dt);

            trans.Commit();
            Message = "成功!";
        }
        catch (Exception ex)
        {
            trans.Rollback();
            throw new Exception(ex.Message);
        }
        finally
        {
            conn.Close();
            trans.Dispose();

        }
        return 1;
    }


    /// <summary>
    /// 批次寫入資料表
    /// </summary>
    /// <param name="TableName">目地資料表名稱</param>
    /// <param name="dt">來源(Datatable)</param>
    /// <param name="TruncateTable">是否清空目地資料表</param>
    /// <param name="BatchRds">設定批次寫入資料列筆數</param>
    /// <returns></returns>
    public int InsertFromDataTable(string TableName, DataTable dt, bool TruncateTable, int BatchRds)
    {

        SqlConnection conn = new SqlConnection(ConnectionString);
        conn.Open();
        SqlTransaction trans = conn.BeginTransaction();
        SqlBulkCopy bulkCpy = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, trans);

        SqlCommand cmd = new SqlCommand("Truncate table [" + TableName + "]", conn, trans);


        try
        {
            if (TruncateTable == true)

                cmd.ExecuteNonQuery();
            bulkCpy.BatchSize = BatchRds;//批次寫入資料列筆數
            bulkCpy.BulkCopyTimeout = 1800; //設定1800秒逾時
            bulkCpy.DestinationTableName = "dbo.[" + TableName + "]";
            bulkCpy.WriteToServer(dt);

            trans.Commit();
            Message = "成功!";
        }
        catch (Exception ex)
        {
            trans.Rollback();
            throw new Exception(ex.Message);
        }
        finally
        {
            conn.Close();
            trans.Dispose();

        }
        return 1;
    }



    public override void GenerateDataReader(string sql)
    {
        throw new NotImplementedException();
    }

    public override DataTable ReadToDatatable()
    {
        throw new NotImplementedException();
    }

    public override string ExecuteScale(string sql)
    {
        string rtnValue;

        SqlConnection conn = new SqlConnection(ConnectionString);
        try
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            rtnValue = cmd.ExecuteScalar().ToString();
        }
        catch (Exception ex)
        {
            rtnValue = "";
            Message = ex.Message;
        }
        finally
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }

        return rtnValue;

    }
}
