﻿//Author:153508
//Create date:2019/12/16
//Description:Log
//Modify:

using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

/// <summary>
/// 
/// </summary>
public class clsIntraMaintainLog
{
    string ConnStr = ConfigurationManager.ConnectionStrings["chb_iom"].ToString();


    public clsIntraMaintainLog()
    {

    }

    public void InsIntraMaintainLog(string LogDesc, string IP = "")
    {

        using (SqlConnection Conn = new SqlConnection(ConnStr))
        {
            Conn.Open();


            using (SqlCommand Cmd = new SqlCommand())
            {

                Cmd.CommandText = "INSERT INTO [dbo].[IntraMaintain_Log] ([PageName],[LogDesc],[IP]) VALUES (@PageName,@LogDesc,@IP)";
                Cmd.Parameters.AddWithValue("@PageName", GetCurrentPageName());
                Cmd.Parameters.AddWithValue("@LogDesc", LogDesc);
                if (string.IsNullOrEmpty(IP))
                {
                    Cmd.Parameters.AddWithValue("@IP", DBNull.Value);
                }
                else
                {
                    Cmd.Parameters.AddWithValue("@IP", IP);
                }

                Cmd.Connection = Conn;
                Cmd.ExecuteNonQuery();

            }
        }


    }

    public string GetCurrentPageName()
    {
        string sPath = System.Web.HttpContext.Current.Request.Url.AbsolutePath;
        FileInfo oInfo = new System.IO.FileInfo(sPath);
        string sRet = oInfo.Name;
        return sRet;
    }

}