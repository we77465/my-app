﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;

/// <summary>
/// MQSqlClass 的摘要描述
/// </summary>
public class MQSqlClass
{
    
    private static string chb_iom = ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString;

    public MQSqlClass()
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
    }
    

    //---------------------------------------------------------------------
    //取得資料
    public static String GetData(String SQL, String Paras, String Values)
    {

        if (SQL == "" || Paras == "" || Values == "") return "";
        if (MQSqlClass.CheckAttact(SQL, false)) return ""; //隱碼攻擊不執行
        if (HttpContext.Current != null)
        {
            Page page = (Page)HttpContext.Current.Handler;

            if (page.User.Identity.IsAuthenticated)
            {
                if (page.User.Identity.Name == "") return ""; //異常登入不執行
            }
        }
        String s = "";
        //SQL = SQLStrDeCode(Microsoft.Security.Application.Encoder.HtmlEncode(SQL));

        using (SqlConnection conn = new SqlConnection(chb_iom))
        {
            conn.Open();
            using (SqlCommand CMD = new SqlCommand(SQL, conn))
            {
                string[] v;

                char c = Convert.ToChar(8);
                if (Values.IndexOf(c) > 0) v = Values.Split(c);
                else v = Values.Split(',');


                string[] p;
                p = Paras.Split(',');

                for (int i = 0; i <= v.Length - 1; i++)
                {
                    CMD.Parameters.AddWithValue(p[i].ToString().Trim(), v[i].ToString());
                }
                SqlDataReader dr = CMD.ExecuteReader();
                dr.Read();
                if (dr.HasRows) s = dr.GetValue(0).ToString();
                dr.Close(); //務必釋放
            }
        }
        return s;
    }

    //---------------------------------------------------------------------

    //取得資料
    public static String GetData(String SQL)
    {
        return GetData(SQL, "", "");
    }
    //---------------------------------------------------------------------

    //---------------------------------------------------------------------
    //檢測是否為隱碼攻擊
    public static bool CheckAttact(string s, bool Enhance)
    {
        bool y = false;
        s = s.ToLower();
        if (s.Contains("--") || s.Contains(";")) y = true;
        else if (s.Contains("<script")) y = true;  //by Jeff 2015/11/11 script / iframe　/ frameset 
        else if (s.Contains("<iframe")) y = true;
        else if (s.Contains("<frameset")) y = true;

        if (Enhance)
        {
            if (s.Contains(" or ")) y = true;
        }
        return y;
    }


    //使用HtmlEncode 資料庫要轉換的字元
    public static string SQLStrDeCode(string SQL)//Eric  2016/10/4
    {
        SQL = SQL.Replace("&#39;", "'");
        SQL = SQL.Replace("~gt~", @">").Replace("&gt;", @">");
        SQL = SQL.Replace("~lt~", @"<").Replace("&lt;", @"<");
        SQL = SQL.Replace("~amp~", @"&").Replace("&amp;", @"&");
        SQL = SQL.Replace("&#8364;", @"€");
        SQL = SQL.Replace("~quot~", @"""").Replace("&quot;", @"""");
        SQL = SQL.Replace("&#13;", @" ").Replace("&#10;", @" ");
        SQL = SQL.Replace("&#9;", @"	");
        SQL = SQL.Replace("&#160;", @" ");

        return SQL;
    }
}