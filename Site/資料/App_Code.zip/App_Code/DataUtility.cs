﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Reflection;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Script.Serialization;




/// <summary>
/// DataUtility 的摘要描述
/// </summary>
public static class DataUtility
{
    
    
    //public DataUtility()
    //{
    //    //
    //    // TODO: 在此加入建構函式的程式碼
    //    //
    //}    
    /// <summary>
    /// Gets the query result.
    /// </summary>
    /// <param name="connectString">The connect string.</param>
    /// <param name="SqlCmd">The SQL CMD.</param>
    /// <returns></returns>
    /// 
    public static DataTable GetQueryResult(string SelectDb, string SqlCmd)
    {              
        DataTable dt = new DataTable();
        string connectString = string.Empty;
        if (SelectDb != string.Empty)
        {
            switch (SelectDb)
            {
                case "chb_eform": connectString = ConfigurationManager.ConnectionStrings["chb_eform"].ToString();
                    break;
                case "chb_pub": connectString = ConfigurationManager.ConnectionStrings["chb_pub"].ToString();
                    break;
                case "chb_iom": connectString = ConfigurationManager.ConnectionStrings["chb_iom"].ToString();
                    break;
                case "chb_pub1": connectString = ConfigurationManager.ConnectionStrings["chb_pub1"].ToString();
                    break;
                default: break;
            }
        }
        try
        {
            using (SqlConnection cn = new SqlConnection(connectString))
            {
                cn.Open();
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            return dt;
        }
        catch (Exception k)
        {
            return null;
        }
    }
    public static DataSet GetQueryResultDataSet(string SelectDb, string SqlCmd)
    {
        DataSet ds = new DataSet();
        string connectString = string.Empty;
        if (SelectDb != string.Empty)
        {
            switch (SelectDb)
            {
                case "chb_eform": connectString = ConfigurationManager.ConnectionStrings["chb_eform"].ToString();
                    break;
                case "chb_pub": connectString = ConfigurationManager.ConnectionStrings["chb_pub"].ToString();
                    break;
                case "chb_iom": connectString = ConfigurationManager.ConnectionStrings["chb_iom"].ToString();
                    break;
                case "chb_pub1": connectString = ConfigurationManager.ConnectionStrings["chb_pub1"].ToString();
                    break;
                default: break;
            }
        }
        try
        {
            using (SqlConnection cn = new SqlConnection(connectString))
            {
                cn.Open();
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    using (SqlDataAdapter sd = new SqlDataAdapter(SqlCmd,connectString))
                    {
                        sd.Fill(ds);
                    }
                }
            }
            return ds;
        }
        catch (Exception k)
        {
            return null;
        }
    }
    /// <summary>
    /// Nons the query result.
    /// </summary>
    /// <param name="SelectDb">The select db.</param>
    /// <param name="SqlCmd">The SQL CMD.</param>
    /// <returns></returns>
    public static bool NonQueryResult(string SelectDb, string SqlCmd)
    {        
        string connectString = string.Empty;
        if (SelectDb != string.Empty)
        {
            switch (SelectDb)
            {
                case "chb_eform": connectString = ConfigurationManager.ConnectionStrings["chb_eform"].ToString();
                    break;
                case "chb_pub": connectString = ConfigurationManager.ConnectionStrings["chb_pub"].ToString();
                    break;
                case "chb_iom": connectString = ConfigurationManager.ConnectionStrings["chb_iom"].ToString();
                    break;
                case "chb_pub1": connectString = ConfigurationManager.ConnectionStrings["chb_pub1"].ToString();
                    break;
                default: break;
            }
        }
        try
        {
            using (SqlConnection cn = new SqlConnection(connectString))
            {
                cn.Open();
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {                    
                    cmd.ExecuteNonQuery();
                }
            }
            return true;
        }
        catch(Exception k)
        {
            return false;
        }
    }
    /// <summary>
    /// 建立datatable
    /// </summary>
    /// <param name="ColumnName">欄位名</param>
    /// <param name="value">data陣列 , rowmajor</param>
    /// <returns>DataTable</returns>
    public static DataTable CreateDataTable(string[] ColumnName, string[,] value)
    {
        /*  輸入範例
        string[] cname = new string[]{"name", "sex "};
        string[,] aaz = new string[4, 2];
        for (int q = 0; q < 4; q++)
            for (int r = 0; r < 2; r++)
                aaz[q, r] = "1";
        dataGridView1.DataSource = DataUtility.CreateDataTable(cname, aaz);
        */
        int i, j;
        DataTable kk = new DataTable();
        for (i = 0; i < ColumnName.Length; i++)
        {
            DataColumn c1 = new DataColumn(ColumnName[i].ToString().Trim(), typeof(string));
            kk.Columns.Add(c1);
        }
        if (value != null)
        {
            for (i = 0; i < value.GetLength(0); i++)
            {
                DataRow newrow = kk.NewRow();
                for (j = 0; j < ColumnName.Length; j++)
                {
                    newrow[j] = string.Copy(value[i, j].ToString());

                }
                kk.Rows.Add(newrow);
            }
        }
        return kk;
    }
    /// <summary>
    /// 將SqlDataSource select之後的資料轉成DataTable
    /// </summary>
    /// <param name="Source">The source.</param>
    /// <returns></returns>
    public static DataTable SqlDataSourceToDataTable(SqlDataSource Source)
    {
        DataView dv = (DataView)Source.Select(DataSourceSelectArguments.Empty);
        return dv.Table;
    }
    /// <summary>
    /// 建立空的DataTable從資料庫的表格定義
    /// </summary>
    /// <param name="connectString">The connect string.</param>
    /// <param name="TableName">Name of the table.</param>
    /// <returns></returns>
    public static DataTable CreateEmptyDataTableFromDb(string connectString, string TableName)
    {
        DataTable dt = new DataTable();
        string SqlCmd = "Select * from " + TableName + " where 1 <> 1";
        using (SqlConnection cn = new SqlConnection(connectString))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    dt.Load(dr);
                }
            }
        }
        return dt;
    }
    /// <summary>
    /// 將兩張datatable合併輸出(欄位名稱不相同)
    /// </summary>
    /// <param name="hostDt">要被加入的datatable</param>
    /// <param name="clientDt">來源datatable</param>
    /// <returns>合併結果table</returns>
    public static DataTable AppendDataTable(DataTable hostDt, DataTable clientDt)
    {
        if (hostDt != null && hostDt.Rows.Count > 0)
        {
            DataRow dr;

            for (int i = 0; i < clientDt.Columns.Count; i++)
            {
                hostDt.Columns.Add(new DataColumn(clientDt.Columns[i].ColumnName));

                if (clientDt.Rows.Count > 0)
                    for (int j = 0; j < clientDt.Rows.Count; j++)
                    {
                        dr = hostDt.Rows[j];
                        dr[hostDt.Columns.Count - 1] = clientDt.Rows[j][i];
                        dr = null;
                    }
            }
        }

        return hostDt.Copy();
    }
    /// <summary>
    /// 將DataTable中選取的列轉為字串陣列
    /// </summary>
    /// <param name="dt">The dt.</param>
    /// <param name="SelectIndex">Index of the select.</param>
    /// <returns></returns>
    public static string[] DataTableRowToString(DataTable dt, int SelectIndex)
    {
        try
        {
            string[] result = new string[dt.Columns.Count];
            for (int i = 0; i < dt.Columns.Count; i++)
                result[i] = dt.Rows[SelectIndex][i].ToString();
            return result;
        }
        catch (Exception e)
        {
            return null;
        }
    }
    /// <summary>
    /// 將字串陣列轉為DataRow根據DataTable定義
    /// </summary>
    /// <param name="dt">The dt.</param>
    /// <param name="InputData">The input data.</param>
    /// <returns></returns>
    public static DataRow StringToDataRow(DataTable dt, string[] InputData)
    {
        try
        {
            DataRow a = dt.NewRow();
            for (int i = 0; i < dt.Columns.Count; i++)
                a[i] = string.Copy(InputData[i]);
            return a;
        }
        catch (Exception e)
        {
            return null;
        }
    }
    /// <summary>
    /// 選出DataRow從DataTable
    /// </summary>
    /// <param name="dt">The dt.</param>
    /// <param name="Condition">The condition.</param>
    /// <returns></returns>
    public static DataRow[] SelectFromDataTable(DataTable dt, string Condition)
    {
        if (Condition != string.Empty)
            return dt.Select(Condition);
        else
            return dt.Select();
    }
    /// <summary>
    /// 將DataTable根據欄位名稱順向排序
    /// </summary>
    /// <param name="dt">The dt.</param>
    /// <param name="ColumnName">Name of the column.</param>
    /// <returns></returns>
    public static DataRow[] SortDataTableAsc(DataTable dt, string ColumnName)
    {
        return dt.Select("", ColumnName + " Asc");
    }
    /// <summary>
    /// 將DataTable根據欄位名稱逆向排序
    /// </summary>
    /// <param name="dt">The dt.</param>
    /// <param name="ColumnName">Name of the column.</param>
    /// <returns></returns>
    public static DataRow[] SortDataTableDesc(DataTable dt, string ColumnName)
    {
        return dt.Select("", ColumnName + " desc");
    }
    /// <summary>
    /// 將DataTable欄位名稱位置交換
    /// </summary>
    /// <param name="dtSource">The dt source.</param>
    /// <param name="ColumnName">Name of the column.</param>
    /// <param name="ColumnIndex">Index of the column.</param>
    /// <returns></returns>
    public static DataTable ExchangeDataColumn(DataTable dtSource, string ColumnName, string ColumnIndex)
    {
        DataTable dt = new DataTable();
        dt = dtSource;
        //變更欄位
        dt.Columns[ColumnName].SetOrdinal(Convert.ToInt16(ColumnIndex));
        return dt;
    }
    /// <summary>
    /// 從DataTable找單主鍵值符合的資料.
    /// </summary>
    /// <param name="dtSource">The dt source.</param>
    /// <param name="ColumnName">Name of the column.</param>
    /// <param name="ColumnValue">The column value.</param>
    /// <returns></returns>
    public static DataTable FindDataTableSingleKey(DataTable dtSource, string ColumnName, string ColumnValue)
    {
        DataTable dt = dtSource;
        //1.設定主鍵
        dt.PrimaryKey = new DataColumn[] { dt.Columns[ColumnName] };
        //2.搜尋DataRow
        DataRow dr = dt.Rows.Find(ColumnValue);
        if (dr != null)
        {
            //3.將找到的資料放到另一個DataTable
            DataTable newdt = new DataTable();
            foreach (DataColumn column in dt.Columns)
            {
                newdt.Columns.Add(column.ToString());
            }
            DataRow newdr = newdt.NewRow();
            int i = 0;
            //讀取過濾的資料
            newdr = newdt.NewRow();

            foreach (object item in dr.ItemArray)
            {
                newdr[i] = dr.ItemArray[i];
                i++;
            }
            newdt.Rows.Add(newdr);
            return newdt;
        }
        else
        {
            return null;
        }
    }
    /// <summary>
    /// 從DataTable找多重主鍵值符合的資料.
    /// </summary>
    /// <param name="dtSource">The dt source.</param>
    /// <param name="ColumnName">Name of the column.</param>
    /// <param name="ColumnValue">The column value.</param>
    /// <returns></returns>
    public static DataTable FindDataTableMultiKey(DataTable dtSource, string[] ColumnName, string[] ColumnValue)
    {
        DataTable dt = dtSource;
        //1.設定多個主鍵
        DataColumn[] MultiKey = new DataColumn[ColumnName.Length];
        for (int j = 0; j < ColumnName.Length; j++)
            MultiKey[j] = dt.Columns[ColumnName[j].ToString()];
        dt.PrimaryKey = MultiKey;

        //2.欲查詢的資料
        object[] search = new object[ColumnValue.Length];
        for (int i = 0; i < search.Length; i++)
        {
            search[i] = string.Copy(ColumnValue[i]);
        }
        //3.搜尋DataRow
        DataRow dr = dt.Rows.Find(search);
        if (dr != null)
        {
            //4.將找到的資料放到另一個DataTable
            DataTable newdt = new DataTable();
            foreach (DataColumn column in dt.Columns)
            {
                newdt.Columns.Add(column.ToString());
            }
            DataRow newdr = newdt.NewRow();
            int i = 0;
            //讀取過濾的資料
            newdr = newdt.NewRow();

            foreach (object item in dr.ItemArray)
            {
                newdr[i] = dr.ItemArray[i];
                i++;
            }
            newdt.Rows.Add(newdr);
            return newdt;
        }
        else
        {
            return null;
        }
    }
    /// <summary>
    /// 將DataRow加入DataTable.
    /// </summary>
    /// <param name="dtSource">The dt source.</param>
    /// <param name="dr">The dr.</param>
    /// <returns></returns>
    public static DataTable MergeSearchDataToTable(DataTable dtSource, DataRow[] dr)
    {
        //建立新的DataTable    
        DataTable dt = new DataTable();
        //建立新的DataTable Columns    
        foreach (DataColumn dc in dtSource.Columns)
        {
            dt.Columns.Add(dc.ToString());
            dt.Columns[dc.ToString()].DataType = dc.DataType;
        }
        int i = 0;    //讀取過濾的資料    
        foreach (DataRow item in dr)
        {
            DataRow row = dt.NewRow();
            i = 0;
            foreach (DataColumn dc in dtSource.Columns)
            {
                //建立DataRow的資料            
                row[dc.ToString()] = item.ItemArray[i];
                i++;
            }
            dt.Rows.Add(row);
        }
        return dt;
    }
    #region DataSet操作
    /// <summary> 
    /// 依List物件反轉成DataSet 
    /// </summary> 
    /// <param name="objs"></param> 
    /// <returns></returns> 
    public static DataSet GetDataSetByObjects(object[] objs)
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        ds.Tables.Add(dt);
        Type objType = objs[0].GetType();//取得物件的型別 
        PropertyInfo[] ps = objType.GetProperties();//依型別取得所有屬性資訊 

        //產生DataTable 的欄位 
        foreach (PropertyInfo p in ps)//循繞所有屬性 
            dt.Columns.Add(p.Name, p.PropertyType);


        foreach (object obj in objs)//將資料塞到DataTable 
        {
            DataRow row = dt.NewRow();
            foreach (PropertyInfo p in ps)//循繞所有屬性 
            {
                object o = p.GetValue(obj, null);//取得值 
                row[p.Name] = o;
            }
            dt.Rows.Add(row);
        }

        return ds;
    }

    /// <summary> 
    /// 依物件產生DataSetSchema 
    /// </summary> 
    /// <param name="obj">物件 例new Member()</param> 
    /// <param name="fullPathName">完整檔案路徑 例:c:\DataSet.xsd</param> 
    public static void ObjectToDataSetSchema(object obj, string fullFilePath)
    {
        Type objType = obj.GetType();
        PropertyInfo[] ps = objType.GetProperties();
        DataSet ds = new DataSet("DataSet");
        DataTable dt = new DataTable(objType.Name);
        ds.Tables.Add(dt);
        foreach (PropertyInfo p in ps)
        {
            dt.Columns.Add(new DataColumn(p.Name, p.PropertyType));
        }
        ds.WriteXmlSchema(fullFilePath);

    }

    /// <summary> 
    /// DataSetXml反轉成DataSet 
    /// </summary> 
    /// <param name="xmlStr">xml字串</param> 
    /// <returns></returns> 
    public static DataSet DataSetXmlToDataSet(string xmlStr)
    {
        DataSet ds = new DataSet();
        StringReader reader = new StringReader(xmlStr);
        ds.ReadXml(reader);
        return ds;
    }

    /// <summary> 
    /// DataSetXml反轉成List物件 
    /// </summary> 
    /// <param name="xmlStr">xml字串</param> 
    /// <param name="type">物件型別 例typeof(Member)</param> 
    /// <returns></returns> 
    public static object[] DataSetXmlToObjects(string xmlStr, Type type)
    {
        DataSet ds = new DataSet();
        StringReader reader = new StringReader(xmlStr);
        ds.ReadXml(reader);

        ArrayList result = new ArrayList();
        PropertyInfo[] ps = type.GetProperties();
        foreach (DataRow row in ds.Tables[0].Rows)
        {
            object item = System.Activator.CreateInstance(type);//依型別建立物件 
            foreach (PropertyInfo p in ps)
            {
                p.SetValue(item, row[p.Name], null);
            }
            result.Add(item);
        }

        return (object[])result.ToArray(type);

    }
    #endregion
    #region Dataview轉DataTable
    /// <summary>
    /// Transes from data view.
    /// </summary>
    /// <param name="Source">The source.</param>
    /// <param name="Condition">The condition.</param>
    /// <param name="SortColumnName">Name of the sort column.</param>
    /// <returns></returns>
    public static DataTable TransFromDataView(DataTable Source, string Condition, params string[] SortColumnName)
    {
        DataView dv = Source.DefaultView;
        string ColumnName = string.Join(",", SortColumnName);
        dv.Sort = ColumnName;
        dv.RowFilter = Condition;
        return dv.ToTable();
    }
    /// <summary>
    /// Makes the relation tables.
    /// </summary>
    /// <param name="ds">The ds.</param>
    /// <param name="JoinColumnName">Name of the join column.</param>
    /// <param name="FirstTableName">First name of the table.</param>
    /// <param name="SecondTableName">Name of the second table.</param>
    /// <param name="Condition">The condition.</param>
    /// <param name="SortColumnName">Name of the sort column.</param>
    /// <returns></returns>
    public static DataTable MakeRelationTables(DataSet ds, string JoinColumnName, string FirstTableName, string SecondTableName,
        string Condition, params string[] SortColumnName)
    {
        DataTable StudentTable;
        DataTable ScoreTable;
        if (FirstTableName != string.Empty && SecondTableName != string.Empty)
        {
            StudentTable = ds.Tables[FirstTableName];
            ScoreTable = ds.Tables[SecondTableName];
        }
        else
        {
            StudentTable = ds.Tables[0];
            ScoreTable = ds.Tables[1];
        }

        // 在「學生」與「成績」資料表之間建立一個關聯性連結
        DataRelation SchoolRel = ds.Relations.Add("SchoolRel", StudentTable.Columns[JoinColumnName], ScoreTable.Columns[JoinColumnName]);
        string ColumnName = string.Join(",", SortColumnName);
        // 替「學生」與「成績」資料表分別建立一個 DataView
        DataView StudentView = new DataView(StudentTable, Condition, ColumnName, DataViewRowState.CurrentRows);
        DataView ScoreView = new DataView();

        // 接下來要循序處理內含學生資料的 DataView		    		    
        foreach (DataRowView StudentDRV in StudentView)
        {
            // 替子資料表（也就是「成績」資料表）建立一個 DataView
            ScoreView = StudentDRV.CreateChildView(SchoolRel);
            ScoreView.Sort = ColumnName;
        }
        return ScoreView.ToTable();
    }
    #endregion

    #region DataTable 轉換為Json 字符串
    /// <summary>
    /// DataTable 對象 轉換為Json 字符串
    /// </summary>
    /// <param name="dt"></param>
    /// <returns></returns>
    public static string ToJson(this DataTable dt)
    {
        JavaScriptSerializer javascriptSerializer = new JavaScriptSerializer();
        javascriptSerializer.MaxJsonLength = Int32.MaxValue; //取得最大數值
        ArrayList arrayList = new ArrayList();
        foreach (DataRow dataRow in dt.Rows)
        {
            Dictionary<string, object> dictionary = new Dictionary<string, object>();  //實例化一個參數集合
            foreach (DataColumn dataColumn in dt.Columns)
            {
                dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName].ToString());
            }
            arrayList.Add(dictionary); //ArrayList集合中添加鍵值
        }
        return javascriptSerializer.Serialize(arrayList);  //返回一個json字符串
    }
    #endregion

    #region Json 字符串 轉換為 DataTable數據集合
    /// <summary>
    /// Json 字符串 轉換為 DataTable數據集合
    /// </summary>
    /// <param name="json"></param>
    /// <returns></returns>
    public static DataTable ToDataTable(this string json)
    {
        DataTable dataTable = new DataTable();  //實例化
        DataTable result;
        //try
        //{
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = Int32.MaxValue; //取得最大數值
            ArrayList arrayList = javaScriptSerializer.Deserialize<ArrayList>(json);
            if (arrayList.Count > 0)
            {
                foreach (Dictionary<string, object> dictionary in arrayList)
                {
                    if (dictionary.Keys.Count<string>() == 0)
                    {
                        result = dataTable;
                        return result;
                    }
                    if (dataTable.Columns.Count == 0)
                    {
                        foreach (string current in dictionary.Keys)
                        {
                            dataTable.Columns.Add(current, dictionary[current].GetType());
                        }
                    }
                    DataRow dataRow = dataTable.NewRow();
                    foreach (string current in dictionary.Keys)
                    {
                        dataRow[current] = dictionary[current];
                    }

                    dataTable.Rows.Add(dataRow); //循環添加行到DataTable中
                }
            }
        //}
        //catch
        //{
        //}
        result = dataTable;
        return result;
    }
    #endregion
}
