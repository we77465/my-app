﻿using System;
using System.IO;
using System.Text;
using System.Data;

/// <summary>
/// clsTXT 的摘要描述
/// </summary>
public class clsTXT
{
    private string _FileName;

    public clsTXT(string fn)
    {
        _FileName = fn;
    }

    public DataTable GetDataTable(DataTable FieldSetting, string splitString)
    {
        int Def_Len = 0; // 定義的總長度

        // 產生空白的Datatable
        DataTable dt = new DataTable();
        foreach (DataRow row in FieldSetting.Rows)
        {
            // row(0) : 欄位名稱
            // row(1) : 欄位大小
            dt.Columns.Add(row[0].ToString(), typeof(string));

            Def_Len += Convert.ToInt32(row[1]); // 加總定義長度
        }

        // 設定分隔符號
        string s;
        s = splitString;
        //switch (splitString.ToUpper())
        //{
        //    case "TAB":
        //        {
        //            //s = Constants.vbTab;
        //            s = "\\t";
        //            break;
        //        }

        //    default:
        //        {
        //            s = splitString;
        //            break;
        //        }
        //}

        // 讀檔
        StreamReader sr = new StreamReader(_FileName, Encoding.GetEncoding(950), true);



        //try
        //{

            // 檢查編碼
            if (sr.CurrentEncoding.BodyName != Encoding.GetEncoding(950).BodyName)
                throw new Exception("文字檔編碼必須是BIG5!");

            if (splitString != "")
            {
                // 用分隔符號
                string str;
                while (!sr.EndOfStream)
                {
                    DataRow row = dt.NewRow();
                    int pc = 0;
                    str = sr.ReadLine();
                    // 若是空字串，則勿略
                    if (str.Trim() != "")
                    {
                        string[] ReadStrings = str.Split(Convert.ToChar(s));
                        //if (ReadStrings.Length != dt.Columns.Count)
                        //    throw new Exception("第" + pc + 1 + "行欄位數量不等於" + dt.Columns.Count + "個欄位，請檢查後再重新上傳!");

                        foreach (string v in ReadStrings)
                        {
                            row[pc] = v;
                            pc += 1;
                        }

                        dt.Rows.Add(row);
                    }
                }
            }
            else
            {
                // 固定間隔
                string str;
                byte[] b;
                int RowIndex = 0;
                while (!sr.EndOfStream)
                {
                    RowIndex += 1;
                    str = sr.ReadLine().Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                    // 若是空字串，則勿略
                    if (str.Trim() != "")
                    {
                        b = System.Text.Encoding.Default.GetBytes(str);
                        //if (b.Length != Def_Len)
                        //    throw new Exception("第" + RowIndex + "行長度不等於" + Def_Len + "，請檢查後再重新上傳!");

                        DataRow row = dt.NewRow();
                        int pos = 0; // 指出在b()陣列的位置
                        int length = 0; // 欄位大小

                        for (int i = 0; i <= FieldSetting.Rows.Count - 1; i++)
                        {
                            length = Convert.ToInt16(FieldSetting.Rows[i][1].ToString());
                            row[i] = GetStringFromByte(b, pos, length);
                            pos += length;
                        }

                        dt.Rows.Add(row);
                    }
                }
            }
        //}
        //catch (Exception ex)
        //{
        //    throw new Exception(ex.Message);
        //}

        //finally
        //{
            sr.Close();
        //}




        return dt;
    }


    public string GetStringFromByte(byte[] src, int pos, int length)
    {
        byte[] b = new byte[length - 1 + 1];
        for (int i = 0; i <= length - 1; i++)
            b[i] = src[pos + i];

        return System.Text.Encoding.Default.GetString(b);
    }

    public Encoding CurrentEncoding()
    {
        StreamReader sr = new StreamReader(_FileName, Encoding.GetEncoding(950), true);
        try
        {
            sr.Read();
            return sr.CurrentEncoding;
        }
        catch (Exception ex)
        {
            return null;
        }
        finally
        {
            sr.Close();
        }
    }
}