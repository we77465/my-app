﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using Microsoft.VisualBasic;
using System.Collections.Generic;

/// <summary>
/// StringUtility 的摘要描述
/// </summary>
public class StringUtility
{
	public StringUtility()
	{
		//
		// TODO: 在此加入建構函式的程式碼
		//
	}
    #region 字串斷行處理範例
    /*// =============== TextBox 斷行 (下一行)================== 
        // 使用 \r\n 
        textBox1.Multiline = true; 
        textBox1.Text = "textBox1\r\nLine One\r\nLine Two\r\n"; 

        // 使用 string陣列 
        textBox2.Multiline = true; 
        string [] tb2 = ...{"textBox2","Line One","Line Two"}; 
        textBox2.Lines = tb2; 

        // 使用 System.Environment.NewLine 
        textBox3.Multiline = true; 
        textBox3.Text = "textBox3" + System.Environment.NewLine + "Line One" + System.Environment.NewLine + "Line Two"; 

        // 使用 StringBuilder.AppendLine 
        StringBuilder tb4 = new StringBuilder(); 
        tb4.AppendLine("textBox4"); 
        tb4.AppendLine("Line One"); 
        tb4.AppendLine("Line Two"); 
        textBox4.Text = tb4.ToString(); 

        // =============== RichTextBox 斷行 (下一行)================== 
        // 使用 \r\n 
        richTextBox1.Text = "richTextBox1\r\nLine One\r\nLine Two\r\n"; 
   
        // 使用 string陣列 
        string[] rtb2 = ...{ "richTextBox2" , "Line One", "Line Two" }; 
        richTextBox2.Lines = rtb2; 

        // 使用 System.Environment.NewLine 
        richTextBox3.Text = "richTextBox3" + System.Environment.NewLine + "Line One" + System.Environment.NewLine + "Line Two"; 

        // 使用 StringBuilder.AppendLine 
        StringBuilder rtb4 = new StringBuilder(); 
        rtb4.AppendLine("richTextBox4"); 
        rtb4.AppendLine("Line One"); 
        rtb4.AppendLine("Line Two"); 
        richTextBox4.Text = rtb4.ToString();*/
    #endregion
    #region 字串處理

    /// <summary>
    /// Converts the string array to list.
    /// </summary>
    /// <param name="Source">The source.</param>
    /// <returns></returns>
    public static List<string> ConvertStringArrayToList(string[] Source)
    {
        List<string> Result = new List<string>(Source.Length);
        Result.AddRange(Source);
        return Result;
    }
    /// <summary>
    /// Splits the string.
    /// </summary>
    /// <param name="strData">The STR data.</param>
    /// <param name="Format">The format.</param>
    /// <returns></returns>
    public static List<string> SplitString(string strData, int[] Format)
    {
        string strResult = "";
        List<string> result = new List<string>();
        int IndexCount = 0;
        int intLoop;
        int intPos = 0;
        int intNext;
        byte[] byt = Encoding.Default.GetBytes(strData);
        for (intLoop = 0; intLoop <= byt.Length - 1; intLoop++)
        {
            if (byt[intLoop] >= 128)
            {
                intNext = 2;
            }
            else
            {
                intNext = 1;
            }
            strResult += Encoding.Default.GetString(byt, intLoop, intNext);
            if (intNext == 2)
            {
                intLoop += 1;
            }
            intPos += intNext;
            if (intPos >= int.Parse(Format[IndexCount].ToString()))
            {
                result.Add(strResult);
                strResult = "";
                intPos = 0;
                IndexCount++;

            }
        }
        return result;
    }

    /// <summary>
    /// Subs the string.
    /// </summary>
    /// <param name="strData">The STR data.</param>
    /// <param name="From">From.</param>
    /// <param name="Length">The length.</param>
    /// <returns></returns>
    public static string SubString(string strData, int From, int Length, string OverFlowPadChar, bool IsLeftSide)
    {
        if (strData != string.Empty)
        {
            int ResultLength = Length;

            string PadBlank = "";
            byte[] byt = Encoding.Default.GetBytes(strData);
            if (Length > byt.Length)
            {
                ResultLength = byt.Length;
                for (int i = 0; i < Length - byt.Length; i++)
                    PadBlank += OverFlowPadChar;
                for (int j = 0; j < From; j++)
                    PadBlank += OverFlowPadChar;
            }
            int RestLength = byt.Length - ResultLength;
            int[] Size;
            if (From != 0)
            {
                if (RestLength > 0)
                    Size = new int[] { From, ResultLength, RestLength };
                else
                    Size = new int[] { From, ResultLength - From };
            }
            else
            {
                if (RestLength > 0)
                    Size = new int[] { ResultLength, RestLength };
                else
                    Size = new int[] { ResultLength };
            }
            List<string> a = SplitString(strData, Size);
            if (From != 0)
            {
                if (IsLeftSide)
                    return PadBlank + a[1].ToString();
                else
                    return a[1].ToString() + PadBlank;
            }
            else
            {
                if (IsLeftSide)
                    return PadBlank + a[0].ToString();
                else
                    return a[0].ToString() + PadBlank;
            }
        }
        else
        {
            string PadBlank = string.Empty;
            for (int i = 0; i < Length; i++)
                PadBlank += OverFlowPadChar;
            return PadBlank;
        }
    }

    /// <summary>
    /// Compares the alpha ignore up low.
    /// </summary>
    /// <param name="Source1">The source1.</param>
    /// <param name="Source2">The source2.</param>
    /// <returns></returns>
    public static bool CompareAlphaIgnoreUpLow(string Source1, string Source2)
    {
        return (string.Compare(Source1, Source2, true) == 0) ? true : false;
    }
    //半形轉全形
    /// <summary>
    /// Halfs the word to full word.
    /// </summary>
    /// <param name="data">The data.</param>
    /// <returns></returns>
    public static string HalfWordToFullWord(string data)
    {

        StringBuilder sb = new StringBuilder();


        int ascInteger = 0;
        int ascii = 0;

        foreach (char c in data.ToCharArray())
        {
            ascii = Convert.ToInt32(c);

            if (ascii == 32)
            {

                sb.Append(Convert.ToChar(12288));

            }
            else
            {

                if (ascii < 127)
                {

                    ascInteger = 65248;

                }
                else
                {

                    ascInteger = 0;

                }
                sb.Append(Convert.ToChar(ascii + ascInteger));

            }

        }

        return sb.ToString();

    }
    //判斷為難字
    /// <summary>
    /// Determines to NCR.
    /// </summary>
    /// <param name="rawString">The raw string.</param>
    /// <returns></returns>
    public static int DetermineToNCR(string rawString)
    {
        StringBuilder sb = new StringBuilder();
        Encoding big5 = Encoding.GetEncoding("big5");
        int length = 0;
        foreach (char c in rawString)
        {            //強迫轉碼成Big5，看會不會變成問號         
            string cInBig5 = big5.GetString(big5.GetBytes(new char[] { c }));
            //原來不是問號，轉碼後變問號，判定為難字  
            if (cInBig5 == "?")
            {
                length = length + 1;
            }
        }
        return length;
    }
    /// <summary>
    /// Checks if text is numeric.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <returns></returns>
    public static bool CheckIfTextIsNumeric(string input)
    {
        int intNum1;
        return (int.TryParse(input, out intNum1)) ? true : false;

    }
    /// <summary>
    /// Cuts the string.
    /// </summary>
    /// <param name="inputString">The input string.</param>
    /// <param name="len">The len.</param>
    /// <returns></returns>
    public static string CutString(string inputString, int len)
    {
        ASCIIEncoding ascii = new ASCIIEncoding();
        int tempLen = 0;
        string tempString = "";
        byte[] s = ascii.GetBytes(inputString);
        for (int i = 0; i < s.Length; i++)
        {
            if ((int)s[i] == 63)
            {
                tempLen += 2;
            }
            else
            {
                tempLen += 1;
            }

            try
            {
                tempString += inputString.Substring(i, 1);
            }
            catch
            {
                break;
            }
            if (tempLen > len)
                break;
        }
        //如果截斷要加上省略號
        byte[] mybyte = System.Text.Encoding.Default.GetBytes(inputString);
        if (mybyte.Length > len)
            tempString += "…";


        return tempString;
    }
    /// <summary>
    /// Uppers the case text box.
    /// </summary>
    /// <param name="t1">The t1.</param>
    /// <returns></returns>
    public static void UpperCaseTextBox(TextBox t1)
    {
        // http://msdn.microsoft.com/zh-tw/library/system.string.toupper(VS.80).aspx 
        string temp = t1.Text.ToUpper();
        t1.Text = temp;
    }

    /// <summary>
    /// Lowers the case text box.
    /// </summary>
    /// <param name="t1">The t1.</param>
    public static void LowerCaseTextBox(TextBox t1)
    {
        // http://msdn.microsoft.com/zh-tw/library/system.string.tolower(VS.80).aspx 
        string temp = t1.Text.ToLower();
        t1.Text = temp;
    }


    /// <summary>
    /// ASCII轉成字串
    /// </summary>
    /// <param name="bt">byte陣列</param>
    /// <returns>字串</returns>
    public static string ASCIIToString(byte[] bt)
    {
        ASCIIEncoding asc = new ASCIIEncoding();
        return asc.GetString(bt);
    }
    /// <summary>
    /// byte陣列轉字串用預設編碼方式
    /// </summary>
    /// <param name="bt">byte陣列</param>
    /// <returns>字串</returns>
    public static string ByteToString(byte[] bt)
    {
        return System.Text.Encoding.Default.GetString(bt);

    }

    /// <summary>
    /// 字串轉byte陣列用預設編碼方式
    /// </summary>
    /// <param name="bt">字串</param>
    /// <returns>byte陣列</returns>
    public static byte[] StringToByte(string str)
    {
        return System.Text.Encoding.Default.GetBytes(str);
    }

    /// <summary>
    /// 將位元流轉成字串
    /// </summary>
    /// <param name="bt">byte陣列</param>
    /// <returns>字串</returns>
    public static string ReadStreamToString(byte[] bt)
    {
        MemoryStream memStream = new MemoryStream(bt);
        XmlTextReader reader = new XmlTextReader(memStream);
        XmlDocument doc = new XmlDocument();
        doc.Load(reader);
        return doc.OuterXml;
    }

    /// <summary>
    /// 將字串轉成byte陣列
    /// </summary>
    /// <param name="strValue">字串</param>
    /// <returns>byte陣列</returns>
    public static byte[] StringToByteBig5(string strValue)
    {
        Encoding enc = Encoding.GetEncoding("big5");
        return enc.GetBytes(strValue);
    }

    /// <summary>
    /// Format the string to meet the right format. Algins to left, padding on the right with the padchar/
    /// </summary>
    /// <param name="value">要格式的字串</param>
    /// <param name="totallength">全部長度</param>
    /// <param name="padchar">要補齊的字元</param>
    /// <returns>已格式的字串</returns>
    public static string StringPadRight(string value, int totallength, char padchar)
    {
        /* if (value == null)
             value = "";

         if (value.Length > totallength)
             value = value.Substring(0, totallength);
         return value.PadRight(totallength, padchar);*/
        String sResult;

        Encoding cp950 = System.Text.Encoding.Default;
        // byte[] BYT = cp950.GetBytes(sTemp.Trim());
        // String strBig5=ToWchr(ConvertBig5(sTemp.Trim()));
        String strBig5 = value.Replace("\0", "");
        sResult = strBig5;
        int strLength = getCharStringLength(sResult);
        //若欄位長度大於最長之限制,則截取最長之長度
        if (strLength > totallength)
        {
            sResult = getSubString(sResult, 0, totallength);
        }
        for (int i = strLength; i < totallength; i++)
        {
            sResult += padchar.ToString();

        }

        return sResult;
    }

    /// <summary>
    /// Format the string to meet the left format. Algins to right, padding on the left with the padchar/
    /// </summary>
    /// <param name="value">要格式的字串</param>
    /// <param name="totallength">全部長度</param>
    /// <param name="padchar">要補齊的字元</param>
    /// <returns>已格式的字串</returns>
    public static string StringPadLeft(string value, int totallength, char padchar)
    {
        /* if (value == null)
             value = "";

         if (value.Length > totallength)
             value = value.Substring(0, totallength);
            
         return value.PadLeft(totallength, padchar);*/
        String sResult;
        String sLeftResult;
        String PadChar = "";

        Encoding cp950 = System.Text.Encoding.Default;
        // byte[] BYT = cp950.GetBytes(sTemp.Trim());
        // String strBig5=ToWchr(ConvertBig5(sTemp.Trim()));
        String strBig5 = value.Replace("\0", "");
        sResult = strBig5;
        int strLength = getCharStringLength(sResult);
        //若欄位長度大於最長之限制,則截取最長之長度
        if (strLength > totallength)
        {
            sResult = getSubString(sResult, 0, totallength);
        }
        for (int i = strLength; i < totallength; i++)
        {
            PadChar += padchar.ToString();

        }
        sLeftResult = PadChar + sResult;
        return sLeftResult;

    }
    /// <summary>
    /// Pads the half blank.
    /// </summary>
    /// <param name="length">The length.</param>
    /// <returns></returns>
    public static string PadHalfBlank(int length)
    {
        string temp = "";
        for (int i = 0; i < length; i++)
            temp += ' ';
        return temp;
    }

    /// <summary>
    /// Pads the symbol.
    /// </summary>
    /// <param name="length">The length.</param>
    /// <param name="PadString">The pad string.</param>
    /// <returns></returns>
    public static string PadSymbol(int length, string PadString)
    {
        string temp = "";
        for (int i = 0; i < length; i++)
            temp += PadString;
        return temp;
    }


   

    /// <summary>
    /// Finds the match string position.
    /// </summary>
    /// <param name="Source">The source.</param>
    /// <param name="SeekItem">The seek item.</param>
    /// <returns></returns>
    public static List<string> FindMatchStringPosition(string Source, string SeekItem)
    {
        // 使用System.Text.RegularExpressions來搜尋指定字串            
        List<string> result = new List<string>();
        System.Text.RegularExpressions.MatchCollection matches = System.Text.RegularExpressions.Regex.Matches(Source, SeekItem);
        foreach (System.Text.RegularExpressions.Match m in matches)
        {
            result.Add(m.Index.ToString());  // 將搜尋結果index加入list
        }
        return result;
    }
    /// <summary>
    /// Checks if contain string.
    /// </summary>
    /// <param name="Source">The source.</param>
    /// <param name="SeekItem">The seek item.</param>
    /// <returns></returns>
    public static bool CheckIfContainString(string[] Source, string SeekItem)
    {
        return (((System.Collections.IList)Source).Contains(SeekItem)) ? true : false;
    }

    #endregion
    #region getSubStringNotTrim
    //計算長度
    /// <summary>
    /// Gets the sub string not trim.
    /// </summary>
    /// <param name="sTemp">The s temp.</param>
    /// <param name="start">The start.</param>
    /// <param name="count">The count.</param>
    /// <returns></returns>
    public static String getSubStringNotTrim(String sTemp, int start, int count)
    {
        String strSubString = "";
        //字串實際長度    
        Encoding cp950 = System.Text.Encoding.GetEncoding(950);

        byte[] BYT = cp950.GetBytes(sTemp);
        strSubString = cp950.GetString(BYT, start, count).ToString();
        return strSubString;

    }
    #endregion
    #region getSubString
    //計算長度
    /// <summary>
    /// Gets the sub string.
    /// </summary>
    /// <param name="sTemp">The s temp.</param>
    /// <param name="start">The start.</param>
    /// <param name="count">The count.</param>
    /// <returns></returns>
    public static String getSubString(String sTemp, int start, int count)
    {
        String strSubString = "";
        //字串實際長度    
        Encoding cp950 = System.Text.Encoding.GetEncoding(950);

        byte[] BYT = cp950.GetBytes(sTemp);
        strSubString = cp950.GetString(BYT, start, count).ToString();
        return strSubString;

    }
    #endregion
    #region getCharPadRight
    /// <summary>
    /// Gets the char pad right.
    /// </summary>
    /// <param name="sTemp">The s temp.</param>
    /// <param name="iLength">Length of the i.</param>
    /// <returns></returns>
    public static String getCharPadRight(String sTemp, int iLength)
    {

        String sResult;

        Encoding cp950 = System.Text.Encoding.Default;
        // byte[] BYT = cp950.GetBytes(sTemp.Trim());
        // String strBig5=ToWchr(ConvertBig5(sTemp.Trim()));
        String strBig5 = sTemp.Replace("\0", "");
        sResult = strBig5;
        int strLength = getCharStringLength(sResult);
        //若欄位長度大於最長之限制,則截取最長之長度
        if (strLength > iLength)
        {
            sResult = getSubString(sResult, 0, iLength);
        }
        for (int i = strLength; i < iLength; i++)
        {
            sResult += ' ';

        }

        return sResult;

    }
    #region getCharType
    //計算長度
    /// <summary>
    /// Gets the type of the char.
    /// </summary>
    /// <param name="sTemp">The s temp.</param>
    /// <returns></returns>
    public static bool getCharType(String sTemp)
    {


        if (sTemp.Length > 0)
        {
            System.Text.ASCIIEncoding objAscII = new System.Text.ASCIIEncoding();
            byte[] ary_bteStringBuffer = objAscII.GetBytes(sTemp);

            if (ary_bteStringBuffer[0] == 63) //判斷是否為中文字或全型符號          
            {
                return true;
            }


        }
        return false;

    }
    #endregion

    #region getCharStringLength

    /// <summary>
    /// Gets the length of the char string.
    /// </summary>
    /// <param name="sTemp">The s temp.</param>
    /// <returns></returns>
    public static int getCharStringLength(String sTemp)
    {
        int intStringLength = 0;
        //字串實際長度    
        if (sTemp.Length > 0)
        {
            System.Text.ASCIIEncoding objAscII = new System.Text.ASCIIEncoding();
            byte[] ary_bteStringBuffer = objAscII.GetBytes(sTemp);
            for (int i = 0; i <= ary_bteStringBuffer.Length - 1; i++)
            {

                if (ary_bteStringBuffer[i] == 63) //判斷是否為中文字或全型符號          
                {
                    intStringLength++;
                }
                intStringLength++;
            }
        }
        //若判斷資料中有?號者為難字,則長度須再減掉?號個數
        intStringLength = intStringLength - DetermineToNCR(sTemp);
        return intStringLength;

    }

    #endregion
    #endregion
    #region getCharPadRightWithItem
    /// <summary>
    /// Gets the char pad right with item.
    /// </summary>
    /// <param name="sTemp">The s temp.</param>
    /// <param name="iLength">Length of the i.</param>
    /// <returns></returns>
    public static String getCharPadRightWithItem(String sTemp, int iLength)
    {

        String sResult = "";

        Encoding cp950 = System.Text.Encoding.Default;
        // byte[] BYT = cp950.GetBytes(sTemp.Trim());
        // String strBig5=ToWchr(ConvertBig5(sTemp.Trim()));
        String strBig5 = sTemp.Trim().Replace("\0", "");
        sResult = strBig5;
        int strLength = getCharStringLength(sResult);
        //若欄位長度大於最長之限制,則截取最長之長度
        if (sTemp.Trim().Length > 0)
        {
            if (strLength > iLength)
            {
                sResult = getSubString(sResult, 0, iLength);
            }
            for (int i = strLength; i < iLength; i = i + 2)
            {
                sResult += '‧';


            }
            if (getCharStringLength(sResult.Trim()) > 20)
            {

                sResult = getSubString(sResult, 0, getCharStringLength(sResult.Trim()) - 2);

            }
        }
        return sResult;

    }
    #endregion
    #region TrimChars
    /// <summary>將輸入字串中指定的字元過濾掉。</summary>
    /// <param name="strOriginalText">輸入字串</param>
    /// <param name="strDelimChars">指定要過濾的字元字串，如要過濾多個字元，可將多個字元組成連續的字串即可</param>
    /// <returns></returns>
    public static string TrimChars(string strOriginalText, string strDelimChars)
    {
        return string.Join("", strOriginalText.Split(strDelimChars.ToCharArray()));
    }
    #endregion
    #region 數字金額處理

    /// <summary>
    /// Gets the nt amount format.
    /// </summary>
    /// <param name="Money">The money.</param>
    /// <returns></returns>
    public static string GetNtAmountFormat(string Money)
    {
        string format = "{0:NT$ #,### ; -NT$ #,###}"; //在這裡用分號區隔正數,負數,零時
        return string.Format(format, Money);
    }
    /// <summary>
    /// 是否為數字
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    public static Boolean IsNumeric(string value)
    {
        return System.Text.RegularExpressions.Regex.IsMatch(value, @"^[+-]?\d*[.]?\d*$");

    }

    /// <summary>
    /// Converts the decimal.
    /// </summary>
    /// <param name="sAmt">The s amt.</param>
    /// <returns></returns>
    public static String convertDecimal(String sAmt)
    {
        String returnString = "000000";
        sAmt = sAmt.Replace(",", "");
        if (sAmt.Trim().Length != 0)
        {

            if (sAmt.Substring(sAmt.Length - 1, 1) == "+")
            {

                returnString = sAmt.Substring(0, sAmt.Length - 1).PadLeft(6, '0');



            }
            else if (sAmt.Substring(sAmt.Length - 1, 1) == "-")
            {

                returnString = "-" + int.Parse(sAmt.Substring(0, sAmt.Length - 1)).ToString();

            }
            else if (int.Parse(sAmt) < 0)
            {

                returnString = sAmt.ToString();
            }
            else
            {

                returnString = sAmt.Trim().PadLeft(6, '0');
            }
        }

        return returnString;
    }
    //有帶正負號
    /// <summary>
    /// Converts the amt.
    /// </summary>
    /// <param name="sAmt">The s amt.</param>
    /// <returns></returns>
    public static String ConvertAmt(String sAmt)
    {
        String returnString = "00000+";
        sAmt = sAmt.Replace(",", "");
        if (IsNumeric(sAmt))
        {

            sAmt = int.Parse(sAmt).ToString();

        }
        if (sAmt.Trim().Length != 0)
        {

            if (sAmt.Substring(sAmt.Length - 1, 1) == "+")
            {

                returnString = sAmt.PadLeft(5, '0');



            }
            else if (sAmt.Substring(sAmt.Length - 1, 1) == "-")
            {

                returnString = sAmt.PadLeft(5, '0');

            }
            else if (int.Parse(sAmt) < 0)
            {

                returnString = sAmt.ToString().Substring(1, sAmt.Length - 1).PadLeft(5, '0') + "-";
            }
            else
            {

                returnString = sAmt.ToString().PadLeft(5, '0') + "+";
            }
        }

        return returnString;
    }
    /// <summary>
    /// Converts the minus.
    /// </summary>
    /// <param name="sAmt">The s amt.</param>
    /// <returns></returns>
    public static String ConvertMinus(String sAmt)
    {
        String returnString = "00000+";
        sAmt = sAmt.Replace(",", "");
        if (sAmt.Trim().Length > 0)
        {
            if (IsNumeric(sAmt))
            {

                sAmt = int.Parse(sAmt).ToString();

            }
            if (int.Parse(sAmt) < 0)
            {

                returnString = sAmt.ToString().Substring(1, sAmt.Length - 1).PadLeft(5, '0') + "-";
            }
            else
            {
                if (sAmt.Length == 6)
                {
                    returnString = sAmt;

                }
                else
                {
                    returnString = sAmt.ToString().PadLeft(5, '0') + "+";


                }
            }

        }
        return returnString;
    }
    /// <summary>
    /// Converts the amt1.
    /// </summary>
    /// <param name="sAmt">The s amt.</param>
    /// <returns></returns>
    public static String ConvertAmt1(String sAmt)
    {
        String returnString = "000000";
        sAmt = sAmt.Replace(",", "");
        if (sAmt.Trim().Length != 0)
        {

            if (sAmt.Substring(sAmt.Length - 1, 1) == "+")
            {
                returnString = sAmt.Substring(0, sAmt.Length - 1).PadLeft(6, '0');

            }
            else if (sAmt.Substring(sAmt.Length - 1, 1) == "-")
            {

                returnString = sAmt.Substring(0, sAmt.Length - 1).PadLeft(6, '0');

            }
            else if (sAmt.Substring(0, 1) == "-")
            {

                returnString = sAmt.Substring(1, sAmt.Length - 1).PadLeft(6, '0');

            }
            else
            {

                returnString = sAmt.PadLeft(6, '0');
            }
        }

        return returnString;
    }
    /// <summary>        
    /// 數值轉換無條件捨去        
    /// </summary>        
    /// <param name="Value">數值</param>        
    /// <param name="position">小數點位數</param>        
    /// <returns></returns>        
    public static float ConvertValueFloor(float Value, int position)
    {
        string ConvertPosition = "#";
        if (position > 0)
        {
            ConvertPosition += ".";
            for (int i = 2; i < position; i++)
                ConvertPosition += "#";
            ConvertPosition += "0";
        }
        return Single.Parse(Value.ToString(ConvertPosition));
    }
    /// <summary>        
    /// 數值轉換四捨五入        
    /// </summary>        
    /// <param name="Value">數值</param>        
    /// <param name="position">小數點位數</param>        
    /// <returns></returns>        
    public static float ConvertValueRound(float Value, int position)
    {
        Value = Value * (10 ^ position);
        if (Convert.ToInt32(Value.ToString().Substring(Value.ToString().IndexOf('.') + 1, 1)) > 4)
            Value++;
        Value = Value / (10 ^ position);
        string ConvertPosition = "#";
        if (position > 0)
        {
            ConvertPosition += ".";
            for (int i = 2; i < position; i++)
                ConvertPosition += "#";
            ConvertPosition += "0";
        }
        return Single.Parse(Value.ToString(ConvertPosition));
    }
    /// <summary>
    /// Converts to decimal.
    /// </summary>
    /// <param name="Money">The money.</param>
    /// <returns></returns>
    public static decimal ConvertToDecimal(string Money)
    {
        decimal aa = Decimal.Parse(Money);
        aa = aa / 100;//取兩位
        return aa;
    }
    #endregion    
    #region 金額字串轉換
    /// <summary>
    /// 金額轉成字串 格式aaa,bbb,ccc.zzz
    /// </summary>
    /// <param name="Value">金額</param>
    /// <returns>字串</returns>
    public static string decimalToString(decimal Value)
    {
        string strValue = String.Empty;
        string str = Value.ToString();
        if (str.Length > 3 && str.Substring(str.Length - 3, 1).Equals("."))
        {
            string[] objValue = Value.ToString().Split(new char[] { '.' });
            strValue = Convert.ToDecimal(objValue[0]).ToString("##,###,###,###,###,###,###") + "." + objValue[1].ToString();
        }
        else
        {
            if (Value == 0)
                strValue = "0.00";
            else
                strValue = Convert.ToDecimal(Value).ToString("##,###,###,###,###,###,###") + ".00";
        }
        return strValue;
    }

    /// <summary>
    /// 字串轉成金額
    /// </summary>
    /// <param name="Value">字串</param>
    /// <returns>金額</returns>
    public static string decimalStringFormat(string Value)
    {
        string strValue = String.Empty;
        try
        {

            if (Value == "0" || Value == "0.00")
                strValue = "0.00";
            else
                strValue = decimalToString(Convert.ToDecimal(Value));
        }
        catch
        { }
        return strValue;
    }
    /// <summary>
    /// 將數值轉為貨幣 ex 2500->2,500
    /// </summary>
    /// <param name="amount"></param>
    /// <returns></returns>
    public static string getCurrency(string amount, bool showZero)
    {
        if (amount == "")
        {
            if (showZero)
                return "0";
            else
                return "";
        }
        else if (amount == "0")
            return "0";
        else
            return Microsoft.VisualBasic.Strings.FormatCurrency(amount, 0, TriState.False, TriState.False, TriState.True).Replace("NT$", "").Replace("$", "");
    }

    /// <summary>
    /// 輸入金額回傳數值 ex 2,500-->2500
    /// </summary>
    /// <param name="currency"></param>
    /// <returns></returns>
    public static long getNum(string currency)
    {
        long num = (currency == "") ? long.Parse("0") : long.Parse(currency.Replace(",", ""));
        return num;
    }
    /// <summary>
    /// 輸入金額傳回金額
    /// </summary>
    /// <param name="currency"></param>
    /// <returns></returns>
    public static decimal getDec(string currency)
    {
        decimal num = (currency == "") ? decimal.Parse("0.00") : decimal.Parse(currency.Replace(",", ""));
        return num;
    }
    /// <summary>
    /// 顯示中文金額數字
    /// </summary>
    /// <param name="numValue">輸入金額</param>
    /// <returns>中文金額</returns>
    public static string MoneyShow(object numValue)
    {
        string strMoney = Convert.ToInt32(numValue).ToString();
        int i;
        int intZeroCount;
        int intLength;
        bool boolStart = false;
        string[] strArrayNum = new string[10] { "零", "壹", "貳", "參", "肆", "伍", "陸", "柒", "捌", "玖" };
        string[] strArrayUnit = new string[13] { "", "拾", "佰", "仟", "萬", "拾", "佰", "千", "億", "拾", "百", "千", "兆" };
        string strAnswer = "";
        string strAnswreTemp = "";
        string strTemp = "";
        string strZero = "";
        intZeroCount = 0;
        int intTemp = 0;
        intLength = strMoney.Length - 1;
        for (i = 0; i <= intLength; i++)
        {
            strTemp = strMoney.Substring(intLength - i, 1);
            intTemp = int.Parse(strTemp);
            //boolStart True:補零 False:不補零
            if (intTemp > 0)
            {
                if ((i == 5) || (i == 9))
                    if (intZeroCount >= 1)
                    {
                        if (boolStart == true)
                            strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strArrayUnit[i - 1] + strArrayNum[0] + strAnswer;
                        else
                            strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strArrayUnit[i - 1] + strAnswer;
                        intZeroCount = 0;
                    }
                    else
                        strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strAnswer;
                else
                {
                    if (intZeroCount >= 1)
                    {
                        if (boolStart == true)
                            strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strArrayNum[0] + strAnswreTemp + strAnswer;
                        else
                            if (i >= 3)
                                strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strAnswreTemp + strArrayNum[0] + strAnswer;
                            else
                                strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strAnswreTemp + strAnswer;
                        intZeroCount = 0;
                        strAnswreTemp = "";

                    }
                    else
                        strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strAnswer;
                }
                strZero = "";
                boolStart = true;
            }
            else
            {
                if ((i == 5) || (i == 9))
                {
                    strAnswreTemp = strArrayUnit[i - 1];         //萬與億是單位,既使是零也要寫入
                    boolStart = false;                         //不能補零
                }
                intZeroCount = intZeroCount + 1;
                strZero = strArrayNum[0];
            }
        }
        //例外處理
        if (strAnswer.Length > 0)
        {
            if (strAnswer.Substring(strAnswer.Length - 1, 1) == "零")     //尾數為零時刪除靈
                strAnswer = strAnswer.Substring(0, strAnswer.Length - 1);
            if (strAnswer.Length > 2)
                if (strAnswer.Substring(strAnswer.Length - 2, 2) == "億萬")   //尾數為億萬時刪除萬
                    strAnswer = strAnswer.Substring(0, strAnswer.Length - 1);
            //尾數加"元整"
        }
        else
        {
            strAnswer = "零";
        }
        strAnswer = strAnswer + "元整";
        return strAnswer;
    }
    #endregion
    #region List<string> 和 string[] 互轉
    /// <summary>
    /// Strings the array to list.
    /// </summary>
    /// <param name="value">The value.</param>
    /// <returns></returns>
    public static List<string> StringArrayToList(string[] value)
    {
        return new List<string>(value);
    }
    public static string[] StringListToArray(List<string> value)
    {
        return value.ToArray();
    }
    #endregion
}
