﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// overtime 的摘要描述
/// </summary>
public class overtime
{
	public overtime()
	{
		//
		// TODO: 在這裡新增建構函式邏輯
		//
	}

    #region 取得由SP傳回的多個Table(用DataSet包起來)
    public static string replaceSingleQuote(string Message)
    {
        string newMessage = string.Empty;

        /*
        for (int i = 0; i < Message.Length; i++)
        {
            if (Message.Substring(i, 1) != "'")
            {
                newMessage += Message.Substring(i, 1);
            }
        }
        */

        if (Message != "")
        {
            newMessage = Message.Replace("'", " ");
            newMessage = newMessage.Replace(Convert.ToChar(9), ' '); // 去掉Tab
            newMessage = newMessage.Replace(Convert.ToChar(10), ' '); // 去掉換行
            newMessage = newMessage.Replace(Convert.ToChar(13), ' '); // 去掉Enter
            newMessage = newMessage.Replace(" ", "").Trim();  // 去掉空白
        }

        return newMessage;
    }
    /// <summary>
    /// Converts a SqlDataReader to a DataSet
    /// 取得由SP傳回的多個Table(用DataSet包起來)
    /// <param name='reader'>
    /// SqlDataReader to convert.</param>
    /// <returns>
    /// DataSet filled with the contents of the reader.</returns>
    /// </summary>
    public static DataSet convertDataReaderToDataSet(SqlDataReader reader)
    {
        DataSet dataSet = new DataSet();

        do
        {
            // Create new data table
            DataTable schemaTable = reader.GetSchemaTable();
            DataTable dataTable = new DataTable();

            if (schemaTable != null)
            {
                // A query returning records was executed
                for (int i = 0; i < schemaTable.Rows.Count; i++)
                {
                    DataRow dataRow = schemaTable.Rows[i];

                    // Create a column name that is unique in the data table
                    string columnName = (string)dataRow["ColumnName"]; //+ "<C" + i + "/>";

                    // Add the column definition to the data table
                    DataColumn column = new DataColumn(columnName, (Type)dataRow["DataType"]);
                    dataTable.Columns.Add(column);
                }
                dataSet.Tables.Add(dataTable);

                // Fill the data table we just created
                while (reader.Read())
                {
                    DataRow dataRow = dataTable.NewRow();

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        dataRow[i] = reader.GetValue(i);
                    }

                    dataTable.Rows.Add(dataRow);
                }
            }
            else
            {
                // No records were returned
                DataColumn column = new DataColumn("RowsAffected");
                dataTable.Columns.Add(column);
                dataSet.Tables.Add(dataTable);
                DataRow dataRow = dataTable.NewRow();
                dataRow[0] = reader.RecordsAffected;
                dataTable.Rows.Add(dataRow);
            }
        }
        while (reader.NextResult());
        return dataSet;
    }
    /// <summary>
    /// 回傳訊息DataSet (此DataSet包含二個table: 一為DB查詢出的資料 ;一為狀態資料名稱為ProcessStatus, 只有一欄位, 名稱為Status)
    /// </summary>
    /// <param name="ds">欲回傳的DB查詢出的資料</param>
    /// <param name="m_message">欲回傳的訊息</param>
    /// <returns></returns>
    public static DataSet ReturnData(DataSet ds, string m_status, string m_message)
    {
        DataTable dt = new DataTable("status");
        DataColumn col = new DataColumn();
        col.DataType = System.Type.GetType("System.String");
        col.ColumnName = "status";
        dt.Columns.Add(col);
        col = new DataColumn();
        col.DataType = System.Type.GetType("System.String");
        col.ColumnName = "Message";
        dt.Columns.Add(col);

        DataRow row = dt.NewRow();
        row["status"] = m_status;
        row["Message"] = m_message;

        dt.Rows.Add(row);
        ds.Tables.Add(dt);
        return ds;
    }
    /// <summary>
    /// 回傳訊息DataSet
    /// </summary>
    /// <param name="m_status">狀態:成功(true); 失敗(false)</param>
    /// <param name="m_message">訊息：回傳訊息</param>
    /// <returns></returns>
    public static DataSet ReturnData(string m_status, string m_message)
    {
        DataSet ds = new DataSet("DS2");
        DataTable dt = new DataTable("status");
        DataColumn col = new DataColumn();
        col.DataType = System.Type.GetType("System.String");
        col.ColumnName = "status";
        dt.Columns.Add(col);
        col = new DataColumn();
        col.DataType = System.Type.GetType("System.String");
        col.ColumnName = "Message";
        dt.Columns.Add(col);

        DataRow row = dt.NewRow();
        row["status"] = m_status;
        row["Message"] = m_message;

        dt.Rows.Add(row);
        ds.Tables.Add(dt);
        return ds;
    }
    #endregion

    #region 共用資料
    private static string ATNS_AP_Test = ConfigurationManager.ConnectionStrings["ATNSConnectionString"].ConnectionString;
    private static string chb_pub = ConfigurationManager.ConnectionStrings["chb_pub"].ConnectionString;

    /// <summary>檢查使用單位，Brno：分行代號，UserId：使用者代號</summary>
    /// <param name="Brno">分行代號</param>
    /// <param name="UserId">使用者代號</param>
    /// <returns>成功回覆字串「1」，失敗回覆字串「0」</returns>
    public static string OvertimeUser(string Brno, string UserId)
    {
        string IsUser, IsUserCount, SqlCmd;
        IsUser = "0";
        IsUserCount = "0";

        try
        {
            using (SqlConnection cnn = new SqlConnection(WebConfigurationManager.ConnectionStrings["chb_pub1"].ToString()))
            {
                cnn.Open();
                SqlCmd = "SELECT count(1) FROM [chb_pub].[dbo].[crc_rel_br] WHERE BRNO=@Brno or CRCNO=@Brno"; //分行或CRC
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cnn))
                {
                    cmd.Parameters.AddWithValue("@Brno", Brno);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while ((dr.Read()))
                        {
                            IsUserCount = dr[0].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            IsUser = "——>查詢使用單位錯誤：" + ex.Message;
        }
        //20171226 新增 抓目前開啟的單位
        string overtime_type = WebConfigurationManager.AppSettings["overtime_tpye"];
        if (overtime_type == "off")//只開放分行
        {
            if (IsUserCount != "0" || Brno == "0180" || UserInfo.UserRoleContainIntraMaintain(UserId) || UserInfo.UserRoleContainControlAdmin(UserId) || Brno == "0208")  //是使用單位
            {
                IsUser = "1";
            }
        }
        if (Brno== overtime_type || UserInfo.UserRoleContainIntraMaintain(UserId) || UserInfo.UserRoleContainControlAdmin(UserId) || Brno == "0208" )//只開放固定單位
        {
            IsUser = "1";
        }
        if (overtime_type == "on")//開放全行
        {
            IsUser = "1";
        }
        //DataSet ds= funget_personnel(UserId, "ITManager");
        return IsUser;
    }

    /// <summary>產生表單編號</summary>
    /// <param name="DocType">號碼種類</param>
    /// <param name="YYMMDD">西元年月日</param>
    /// <param name="UserId">員工編號</param>
    /// <returns>表單編號</returns>
    public static string DocNo(string DocType,string YYMMDD, string UserId)
    {
        string DocNo, OldDocNo, SqlCmd;
        DocNo = DocType + YYMMDD + UserId + "1";
        OldDocNo = DocNo;
        try
        {
            using (SqlConnection cnn = new SqlConnection(WebConfigurationManager.ConnectionStrings["ATNSConnectionString"].ToString()))
            {
                cnn.Open();
                SqlCmd = "SELECT MAX(DocNo) AS MAXDocNo FROM OvertimeRequest WHERE (DocNo LIKE @DocNo)"; //取出表單編號最大值
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cnn))
                {
                    cmd.Parameters.AddWithValue("@DocNo", DocType + YYMMDD + UserId + "%");
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while ((dr.Read()))
                        {
                            OldDocNo = dr[0].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            DocNo = DocNo + "——>查詢表單編號錯誤：" + ex.Message;
        }
        if (String.Compare(OldDocNo, DocNo) != -1)  //舊表單編號不大於新表單編號
        {
            int DocNoNo = Convert.ToInt32(OldDocNo.Substring(17, 1)) + 1;
            DocNo = DocType + YYMMDD + UserId + DocNoNo.ToString("0");
        }
        return DocNo;
    }

    /// <summary>產生表單編號</summary>
    /// <param name="DocType">號碼種類</param>
    /// <param name="YYMMDD">西元年月日</param>
    /// <param name="UserId">員工編號</param>
    /// <returns>表單編號</returns>
    public static string DocNoRest(string DocType, string YYMMDD, string UserId)
    {
        string DocNo, OldDocNo, SqlCmd;
        DocNo = DocType + YYMMDD + UserId + "1";
        OldDocNo = DocNo;
        try
        {
            using (SqlConnection cnn = new SqlConnection(WebConfigurationManager.ConnectionStrings["ATNSConnectionString"].ToString()))
            {
                cnn.Open();
                SqlCmd = "SELECT MAX(DocNo) AS MAXDocNo FROM OvertimeExtraRest WHERE (DocNo LIKE @DocNo)"; //取出表單編號最大值
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cnn))
                {
                    cmd.Parameters.AddWithValue("@DocNo", DocType + YYMMDD + UserId + "%");
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while ((dr.Read()))
                        {
                            OldDocNo = dr[0].ToString();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            DocNo = DocNo + "——>查詢表單編號錯誤：" + ex.Message;
        }
        if (String.Compare(OldDocNo, DocNo) != -1)  //舊表單編號不大於新表單編號
        {
            int DocNoNo = Convert.ToInt32(OldDocNo.Substring(17, 1)) + 1;
            DocNo = DocType + YYMMDD + UserId + DocNoNo.ToString("0");
        }
        return DocNo;
    }
    ///// <summary>
    ///// 取號
    ///// </summary>
    ///// <param name="YYMMDD"></param>
    ///// <param name="ID"></param>
    ///// <returns></returns>
    //public static string DocNo(string YYMMDD, string ID)
    //{
    //    string DocNo, OldDocNo;
    //    DocNo = "VTR" + YYMMDD + ID + "1";
    //    OldDocNo = DocNo;
    //    SqlConnection conn = new SqlConnection(ATNS_AP_Test);
    //    try
    //    {
    //        string query = @"SELECT MAX(DocNo) AS MAXDocNo FROM OvertimeRequest WHERE (DocNo LIKE @DocNo) ";
    //        SqlCommand cmd = new SqlCommand(query, conn);
    //        cmd.CommandType = CommandType.Text;
    //        //將參數帶入queryString
    //        cmd.Parameters.Add(new SqlParameter("@DocNo", SqlDbType.VarChar, 18)).Value = "VTR" + YYMMDD + ID + "%";  //ID

    //        //開啟連線
    //        conn.Open();
    //        SqlDataReader dr = cmd.ExecuteReader();
    //        DataTable schemaTable = dr.GetSchemaTable();
    //        if (dr.HasRows)
    //        {
    //            dr.Read();
    //            if (dr[0].ToString().Trim() != "")
    //            {
    //                OldDocNo = dr[0].ToString().Trim();
    //                int DocNoNo = Convert.ToInt32(OldDocNo.Substring(17, 1)) + 1;
    //                DocNo = "VTR" + YYMMDD + ID + DocNoNo.ToString("0");
    //            }
    //            else
    //            {
    //                DocNo = "VTR" + YYMMDD + ID + "1";
    //            }
    //        }
    //        dr.Close();
    //    }
    //    catch (SqlException ex)
    //    {
    //        // handle error
    //        DocNo = "查詢表單編號錯誤：" + overtime.replaceSingleQuote(ex.Message);
    //    }
    //    catch (Exception ex)
    //    {
    //        DocNo = "查詢表單編號錯誤：" + overtime.replaceSingleQuote(ex.Message);
    //    }
    //    finally
    //    {
    //        conn.Close();
    //    }
    //    return DocNo;
    //}
    /// <summary>
    /// 抓是否有符合的狀態流程
    /// </summary>
    /// <param name="DocNo">編號:不含流水號碼</param>
    /// <param name="FlowStatus">用逗點分隔的狀態</param>
    /// <param name="YN">只放 "not" or "" 表示not in or in </param>
    /// <returns></returns>
    public static DataSet funget_FlowStatus(string DocNo, string FlowStatus, string YN)
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string[] fs = FlowStatus.Split(',');
            string query = @" select a.*,b.RefName,c.NAME,d.BRNAME from OvertimeRequest a
                                left join OvertimeRef b
                                on a.FlowStatus=b.[RefNo] and b.[Item]='FLOWSTATUS'
								left join [chb_pub].[dbo].[EMPLOYEE] c
								on c.STAFF=a.Staff
								left join [chb_pub].[dbo].[BRANCHTRANS]d
								on d.[BRNO]=a.Brno
                              where DocNo like @DocNo and FlowStatus ";
            query = query + YN + " in(";//not in or in
            for (int i = 0; i < fs.Length; i++)
            {
                query = query+ @" @FlowStatus" + i + ",";
            }
            query = query.Substring(0, query.Length - 1);
            query = query + ")";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入queryString
            cmd.Parameters.Add(new SqlParameter("@DocNo", SqlDbType.VarChar, 18)).Value = DocNo;  //ID
            for (int i = 0; i < fs.Length; i++)
            {
                int n = 0;
                if (int.TryParse(fs[i], out n))
                    cmd.Parameters.Add(new SqlParameter("@FlowStatus" + i, SqlDbType.Int)).Value = Convert.ToInt32(fs[i]);  //FlowStatus
                else
                    cmd.Parameters.Add(new SqlParameter("@FlowStatus" + i, SqlDbType.Int)).Value = 0;  //FlowStatus

            }
            //開啟連線
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "OvertimeRequest";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData:" + query);
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }
    /// <summary>
    /// 抓是否有符合的狀態流程
    /// </summary>
    /// <param name="DocNo">編號:不含流水號碼</param>
    /// <param name="FlowStatus">用逗點分隔的狀態</param>
    /// <param name="YN">只放 "not" or "" 表示not in or in</param>
    /// <returns></returns>
    public static DataSet funget_FlowStatusBrno(string DocNo, string FlowStatus, string YN,string Brno)
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string[] fs = FlowStatus.Split(',');
            string query = @" select a.*,b.RefName,c.NAME,d.BRNAME from OvertimeRequest a
                                left join OvertimeRef b
                                on a.FlowStatus=b.[RefNo] and b.[Item]='FLOWSTATUS'
								left join [chb_pub].[dbo].[EMPLOYEE] c
								on c.STAFF=a.Staff
								left join [chb_pub].[dbo].[BRANCHTRANS]d
								on d.[BRNO]=a.Brno
                              where a.Brno=@Brno and DocNo like @DocNo and FlowStatus ";
            query = query + YN + " in(";//not in or in
            for (int i = 0; i < fs.Length; i++)
            {
                query = query + @" @FlowStatus" + i + ",";
            }
            query = query.Substring(0, query.Length - 1);
            query = query + ")";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入queryString
            cmd.Parameters.Add(new SqlParameter("@DocNo", SqlDbType.VarChar, 18)).Value = DocNo;  //ID
            cmd.Parameters.Add(new SqlParameter("@Brno", SqlDbType.VarChar, 18)).Value = Brno;  //單位
            for (int i = 0; i < fs.Length; i++)
            {
                int n = 0;
                if (int.TryParse(fs[i], out n))
                    cmd.Parameters.Add(new SqlParameter("@FlowStatus" + i, SqlDbType.Int)).Value = Convert.ToInt32(fs[i].Trim());  //FlowStatus
                else
                    cmd.Parameters.Add(new SqlParameter("@FlowStatus" + i, SqlDbType.Int)).Value = 0;  //FlowStatus
            }
            //開啟連線
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "OvertimeRequest";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData");
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }
    /// <summary>
    /// 抓單位主管and 負責人名單
    /// </summary>
    /// <param name="BRNO">單位別</param>
    /// <returns></returns>
    public static DataSet funget_principal(string BRNO)
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string query = @"   SELECT [STAFF] ,''+[STAFF]+'/'+[NAME] as NAME,[BRNO] from [chb_pub].[dbo].[EMPLOYEETRANS]
                                where STATUS='1'and	JOBPAY >='1' AND BRNO=@BRNO ORDER BY JOBPAY,POST,STAFF desc ";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入queryString
            cmd.Parameters.Add(new SqlParameter("@BRNO", SqlDbType.VarChar, 6)).Value = BRNO;  //compin

            //開啟連線
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "principal";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData");
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }

    /// <summary>
    /// 抓單位主管人事管理名單
    /// </summary>
    /// <param name="UID">人員ID</param>
    /// <param name="ROL_ID">規則ID</param>
    /// <returns></returns>
    public static DataSet funget_personnel(string UID, string ROL_ID)
    {
        DataSet outds = new DataSet();
        string[] ps = UID.Split(',');
        SqlConnection conn = new SqlConnection(chb_pub);
        try
        {
            string query = @"  SELECT * FROM SC_ROL_USR WHERE USR_ID  ";
            query = query  + " in(";//not in or in
            for (int i = 0; i < ps.Length; i++)
            {
                query = query + @" @UID" + i + ",";
            }
            query = query.Substring(0, query.Length - 1);
            query = query + " ) and (ROL_ID=@ROL_ID ) ";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入queryString
            cmd.Parameters.Add(new SqlParameter("@ROL_ID", SqlDbType.VarChar, 50)).Value = ROL_ID;  //compin
            for (int i = 0; i < ps.Length; i++)
            {
                cmd.Parameters.Add(new SqlParameter("@UID" + i, SqlDbType.VarChar, 6)).Value = ps[i];  //FlowStatus
            }
            //開啟連線
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "personnel";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData");
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }

    /// <summary>
    /// 判斷是否為主管
    /// </summary>
    /// <param name="ID">人員ID</param>
    /// <returns></returns>
    public static string funget_JOBPAY(string ID)
    {
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        string Record = "";
        try
        {
            string query = @"   SELECT *  FROM [chb_pub].[dbo].[MANAGER]
                                where STAFF= @STAFF ";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入StoredProcedure
            cmd.Parameters.Add(new SqlParameter("@STAFF", SqlDbType.VarChar, 10)).Value = ID;//ID
            //開啟連線
            conn.Open();

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                if (dr[0].ToString().Trim() != "")
                {
                    Record = dr["JOBPAY"].ToString();
                }
                else
                {
                    Record = "false";
                }
            }
            else
            {
                Record = "false";
            }
            dr.Close();
        }
        catch (SqlException ex)
        {
            // handle error
            Record = "判斷主管錯誤：" + overtime.replaceSingleQuote(ex.Message);
        }
        catch (Exception ex)
        {
            Record = "判斷主管錯誤：" + overtime.replaceSingleQuote(ex.Message);            //num = "false" + overtime.replaceSingleQuote(ex.Message);
        }
        finally
        {
            conn.Close();
        }
        return Record;
    }
    /// <summary>
    /// 是否送出異常報表
    /// </summary>
    /// <param name="time"></param>
    /// <param name="Brno"></param>
    /// <returns></returns>
    public static string funget_OvertimeError(string Brno)
    {
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        string Record = "";
        try
        {
            string query = @"     select max([DocNo]) as [DocNo],max(SUBSTRING([DocNo],4,8))as yymmdd from [OvertimeErrorFlow]
                                  where DocNo like '%'+@Brno and [FlowStatus]='15' ";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入StoredProcedure
            cmd.Parameters.Add(new SqlParameter("@Brno", SqlDbType.VarChar, 10)).Value = Brno;//單位
            //開啟連線
            conn.Open();

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                if (dr[0].ToString().Trim() != "")
                {
                    Record = dr["yymmdd"].ToString();
                }
                else
                {
                    Record = "false";
                }
            }
            else
            {
                Record = "false";
            }
            dr.Close();
        }
        catch (SqlException ex)
        {
            // handle error
            Record = "判斷是否送出異常報表錯誤：" + overtime.replaceSingleQuote(ex.Message);
        }
        catch (Exception ex)
        {
            Record = "判斷是否送出異常報表錯誤：" + overtime.replaceSingleQuote(ex.Message);            //num = "false" + overtime.replaceSingleQuote(ex.Message);
        }
        finally
        {
            conn.Close();
        }
        return Record;
    }


    /// <summary>
    /// 抓刷退時間
    /// </summary>
    /// <param name="YYYYMMDD">時間</param>
    /// <param name="ID">人員</param>
    /// <returns></returns>
    public static string funget_RecordTime(string YYYYMMDD, string ID)
    {
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        string Record = "";
        try
        {
            string query = @"   select cast( datepart(hour,max(RecordTime)) as varchar) +':'+ cast(datepart(minute,max(RecordTime)) as varchar) as RecordTime,EmployeeID from [Record]--convert(varchar, max(RecordTime),108) as RecordTime
                                where EmployeeID=@ID and RecordTime between @YYYYMMDD+' 17:00' and @YYYYMMDD+' 23:59' 
                                group by EmployeeID 
								union all
								select cast( max(補登記錄時間) as varchar) as RecordTime, 員工編號 from [刷卡異常補登]
								where 補登狀態編號='9' and 員工編號=@ID and 補登記錄日期=@YYYYMMDD
								group by 員工編號 ";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入StoredProcedure
            cmd.Parameters.Add(new SqlParameter("@YYYYMMDD", SqlDbType.VarChar, 10)).Value = YYYYMMDD;//時間
            cmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.VarChar, 10)).Value = ID;//人員ID
            //開啟連線
            conn.Open();

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                if (dr[0].ToString().Trim() != "")
                {
                    Record = dr[0].ToString().Trim();
                }
                else
                {
                    Record = "沒有資料";
                }
            }
            else
            {
                Record = "沒有資料";
            }
            dr.Close();
        }
        catch (SqlException ex)
        {
            // handle error
            Record = "查詢刷退時間錯誤：" + overtime.replaceSingleQuote(ex.Message);
        }
        catch (Exception ex)
        {
            Record = "查詢刷退時間錯誤：" + overtime.replaceSingleQuote(ex.Message);            //num = "false" + overtime.replaceSingleQuote(ex.Message);
        }
        finally
        {
            conn.Close();
        }
        return Record;
    }
    /// <summary>
    /// 抓刷退時間及單位關資料
    /// </summary>
    /// <param name="time">時間</param>
    /// <param name="ID">人員</param>
    /// <returns></returns>
    public static DataSet funget_RecordTimeAll(string time, string ID)
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string query = @"   select cast( datepart(hour,max(RecordTime)) as varchar) +':'+ cast(datepart(minute,max(RecordTime)) as varchar) as RecordTime,EmployeeID ,DepartmentIndex
								from [Record]
                                where EmployeeID=@ID and RecordTime between @time+' 17:00' and @time+' 23:59' 
                                group by EmployeeID ,DepartmentIndex
								union all
								select cast( max(補登記錄時間) as varchar) as RecordTime, 員工編號,部門名稱 from [刷卡異常補登]
								where 補登狀態編號='9' and 員工編號=@ID and 補登記錄日期=@time
								group by 員工編號,部門名稱";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入queryString
            cmd.Parameters.Add(new SqlParameter("@time", SqlDbType.VarChar,10)).Value = time;//時間
            cmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.VarChar, 10)).Value = ID;//人員ID
            //開啟連線
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "Record";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData");
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }


    /// <summary>
    /// 抓類別
    /// </summary>
    /// <param name="BRNO">單位別</param>
    /// <returns></returns>
    public static DataSet funget_OvertimeRef(string Item)
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string query = @"   SELECT [Item]
                                      ,[RefNo]
                                      ,cast ([RefNo] as int)as RefNo_num
                                      ,[RefName]
                                  FROM [OvertimeRef]
                                  where Item= @Item ";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入queryString
            cmd.Parameters.Add(new SqlParameter("@Item", SqlDbType.VarChar, 30)).Value = Item;  //Item

            //開啟連線
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "OvertimeRef";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData");
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }

    /// <summary>
    /// 分行
    /// </summary>
    /// <param name="BRNO"></param>
    /// <returns></returns>
    public static DataSet fungetBRANCH()
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string query = @"   
                                SELECT [BRNO]
                                      ,BRNO + ' ' + [BRNAME] AS BRNAME
                                FROM [chb_pub].[dbo].[BRANCHTRANS]";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入StoredProcedure
            //cmd.Parameters.Add(new SqlParameter("@BRNO", SqlDbType.VarChar, 10)).Value = BRNO;//分行
            //開啟連線
            conn.Open();

            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "BRANCH";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData");
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }
    /// <summary>
    /// 人員
    /// </summary>
    /// <param name="BRNO"></param>
    public static DataSet fungetEMPLOYEE(string BRNO)
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string query = @"   select [STAFF] ,''+[STAFF]+'/'+[NAME] as NAME,[BRNO] from [chb_pub].[dbo].[EMPLOYEETRANS]
                                where BRNO=@BRNO and STATUS='1' order by STAFF";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入StoredProcedure
            cmd.Parameters.Add(new SqlParameter("@BRNO", SqlDbType.VarChar, 10)).Value = BRNO;//分行
            //開啟連線
            conn.Open();

            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "EMPLOYEE";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData");
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }
    /// <summary>
    /// 加入刷卡時間
    /// </summary>
    /// <param name="BRNO"></param>
    /// <param name="time"></param>
    /// <returns></returns>
    public static DataSet fungetEMPLOYEE(string BRNO,string time)
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string query = @"   select  DISTINCT * from(
                                select [STAFF] ,'員編:'+[STAFF]+' 姓名:'+[NAME] as NAME,[BRNO] from [chb_pub].[dbo].[EMPLOYEETRANS] 
                                where BRNO=@BRNO and STATUS='1' 
								UNION all

								SELECT 
								  [EmployeeID] as STAFF
								  ,'員編:'+[EmployeeID]+' 姓名:'+[EmployeeName]  as NAME 
								  ,[DepartmentIndex]
							    FROM [Record]
								where [DepartmentIndex]=@BRNO and [RecordTime] between @time+' 00:00'  and @time+' 23:59'
								) a
								order by STAFF
                                ";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入StoredProcedure
            cmd.Parameters.Add(new SqlParameter("@BRNO", SqlDbType.VarChar, 10)).Value = BRNO;//分行
            cmd.Parameters.Add(new SqlParameter("@time", SqlDbType.VarChar, 20)).Value = time;//時間
            //開啟連線
            conn.Open();

            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "EMPLOYEE";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData");
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }
    /// <summary>
    /// 補單明細
    /// </summary>
    /// <param name="ID">人員</param>
    /// <param name="time1">查詢開始時間</param>
    /// <param name="time2">查詢結束時間</param>
    /// <returns></returns>
    public static DataSet fungetExtraReport(string ID,string time1,string time2)
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string query = @"   --declare @time1 varchar(12)='2016/04/01'
								--declare @time2 varchar(12)='2016/06/20'
								--declare @ID varchar(8)='168574'
								declare @Brno varchar(6)--單位別
								declare @maxtime varchar(10)--最大月結時間
								IF OBJECT_ID('tempdb..#tt') IS NOT NULL 	DROP TABLE #tt--判斷暫存是否存在
								select CONVERT(VARCHAR(20), StartTime, 111)as StartTime into #tt  from OvertimeRequest 
									where YYMMDD between replace( @time1,'/','') and replace( @time2,'/','') and Staff =@ID 
										and DocNo in ( select max(DocNo)  from OvertimeRequest 
									where YYMMDD between replace( @time1,'/','') and replace( @time2,'/','') and Staff =@ID
									and flowstatus not in('0','4')group by YYMMDD)
									

								IF OBJECT_ID('tempdb..#tRecord') IS NOT NULL 	DROP TABLE #tRecord--判斷暫存是否存在
								create table #tRecord(Staff nvarchar(6),Brno varchar(10), RecordTime datetime)--當天加班申請的人
								insert into #tRecord
								select EmployeeID,DepartmentIndex,RecordTime from Record 
								where EmployeeID=@ID and ( datepart(hour,RecordTime)>17 
									  or( datepart(minute,RecordTime)>40 and datepart(hour,RecordTime) =17))
									  and RecordTime >'2016/04/01' and RecordTime between @time1 and @time2 + ' 23:59'

								delete #tRecord where CONVERT(VARCHAR(20), RecordTime, 111) in 
									(select CONVERT(VARCHAR(20), StartTime, 111)  from #tt 
									
									) 
								--insert into #tRecord
								select @Brno = (SELECT [BRNO] FROM [chb_pub].[dbo].[EMPLOYEETRANS] where [STAFF]=@ID)

								select @maxtime= max(SUBSTRING([DocNo],4,8)) from [OvertimeErrorFlow]
                                  where DocNo like '%'+@Brno and [FlowStatus]='15' 
								if @maxtime is null
								begin
									select @maxtime='2016/04/01'
								end
								  --select @maxtime
								select * from #tRecord where RecordTime > @maxtime+' 23:59'  order by RecordTime
                                ";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入StoredProcedure
            cmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.VarChar, 10)).Value = ID;//分行
            cmd.Parameters.Add(new SqlParameter("@time1", SqlDbType.VarChar, 20)).Value = time1;//時間
            cmd.Parameters.Add(new SqlParameter("@time2", SqlDbType.VarChar, 20)).Value = time2;//時間
            //開啟連線
            conn.Open();

            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "tRecord";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData");
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }
    /// <summary>
    /// 抓退件的補休申請單資料
    /// </summary>
    /// <param name="docno"></param>
    /// <param name="staff"></param>
    /// <returns></returns>
    public static DataSet fungetExtraRest(string docno, string staff)
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string query = @"  SELECT [DocNo]
                                    ,[Brno]
                                    ,[Staff]
                                    ,[YYMM]
                                    ,[Hour12]
                                    ,[Hour34]
                                    ,[FlowStatus]
                                    ,[UpdateTime]
                                FROM [OvertimeExtraRest]
                                where DocNo=@docno and Staff=@staff and FlowStatus='16' 
                                ";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入StoredProcedure
            cmd.Parameters.Add(new SqlParameter("@docno", SqlDbType.VarChar, 20)).Value = docno;//表單編號
            cmd.Parameters.Add(new SqlParameter("@staff", SqlDbType.VarChar, 10)).Value = staff;//人員ID
            //開啟連線
            conn.Open();

            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            ds = overtime.convertDataReaderToDataSet(dr);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables["table1"].TableName = "OvertimeExtraRest";
                outds = overtime.ReturnData(ds, "true", "有資料");
            }
            else
                outds = overtime.ReturnData("false", "NoData");
        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }
    /// <summary>
    /// 強制放行
    /// </summary>
    /// <param name="DocNo"></param>
    /// <param name="Brno"></param>
    /// <param name="Staff"></param>
    /// <param name="YYMM"></param>
    /// <param name="YYMMDD"></param>
    /// <param name="Week"></param>
    /// <param name="Reason"></param>
    /// <param name="StartTime"></param>
    /// <param name="ExtraRest"></param>
    /// <param name="FlowStatus"></param>
    /// <param name="ExtraRequest"></param>
    /// <param name="EndTime"></param>
    /// <param name="WorkTime"></param>
    /// <returns></returns>
    public static DataSet funSet_enforceOvertimeRequest(string DocNo, string Brno, string Staff, string YYMM, string YYMMDD, string Week, string Reason, string StartTime, int ExtraRest, string FlowStatus, string ExtraRequest, string EndTime, int WorkTime
        ,string NowDeal)
    {
        DataSet outds = new DataSet();
        SqlConnection conn = new SqlConnection(ATNS_AP_Test);
        try
        {
            string query = @" insert into [OvertimeRequest] (
                                           [DocNo]
                                          ,[Brno]
                                          ,[Staff]
                                          ,[YYMM]
                                          ,[YYMMDD]
                                          ,[Week]
                                          ,[Reason]
                                          ,[WorkTime]
                                          ,[StartTime]
                                          ,[EndTime]
                                          ,[ExtraRest]
                                          
                                          ,[FlowStatus]
                                          ,[ExtraRequest]
                                           ) VALUES(@DocNo 
                                          , @Brno 
                                          , @Staff 
                                          , @YYMM 
                                          , @YYMMDD 
                                          , @Week 
                                          , @Reason 
                                          , @WorkTime
                                          , @StartTime 
                                          , @EndTime
                                          , @ExtraRest 
                                          , @FlowStatus 
                                          , @ExtraRequest 
                                          )
                              insert into [OvertimeFlowLog] ([DocNo]
                                          ,[NowDeal]
                                          ,[Action]
                                          ,[UpdateTime]
                                          ,[FlowStatus]) VALUES(@DocNo 
                                          , @NowDeal 
                                          , @Action 
                                          , getdate() 
                                          , @FlowStatus1  )
                                            ";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.CommandType = CommandType.Text;
            //將參數帶入StoredProcedure
            cmd.Parameters.Add(new SqlParameter("@DocNo", SqlDbType.VarChar, 18)).Value = DocNo;//分公司
            cmd.Parameters.Add(new SqlParameter("@Brno", SqlDbType.VarChar, 6)).Value = Brno;//年度
            cmd.Parameters.Add(new SqlParameter("@Staff", SqlDbType.VarChar, 8)).Value = Staff;//代號
            cmd.Parameters.Add(new SqlParameter("@YYMM", SqlDbType.VarChar, 6)).Value = YYMM;//代號
            cmd.Parameters.Add(new SqlParameter("@YYMMDD", SqlDbType.VarChar, 8)).Value = YYMMDD;//代號
            cmd.Parameters.Add(new SqlParameter("@Week", SqlDbType.VarChar, 1)).Value = Week;//代號
            cmd.Parameters.Add(new SqlParameter("@Reason", SqlDbType.VarChar, 300)).Value = Reason;//代號
            cmd.Parameters.Add(new SqlParameter("@StartTime", SqlDbType.DateTime)).Value = StartTime;//代號
            cmd.Parameters.Add(new SqlParameter("@ExtraRest", SqlDbType.Bit, 1)).Value = ExtraRest;//代號
            cmd.Parameters.Add(new SqlParameter("@FlowStatus", SqlDbType.Int)).Value = FlowStatus;//代號
            cmd.Parameters.Add(new SqlParameter("@FlowStatus1", SqlDbType.Int)).Value = Convert.ToInt32(FlowStatus)-1;//代號
            cmd.Parameters.Add(new SqlParameter("@ExtraRequest", SqlDbType.VarChar, 1)).Value = ExtraRequest;//代號
            cmd.Parameters.Add(new SqlParameter("@NowDeal", SqlDbType.VarChar, 6)).Value = NowDeal;//代號
            cmd.Parameters.Add(new SqlParameter("@Action", SqlDbType.VarChar, 50)).Value = "負責人核可";//代號
            //cmd.Parameters.Add(new SqlParameter("@UpdateTime", SqlDbType.DateTime)).Value = DateTime.Now;//代號
            cmd.Parameters.Add(new SqlParameter("@EndTime", SqlDbType.DateTime)).Value = EndTime;//代號
            cmd.Parameters.Add(new SqlParameter("@WorkTime", SqlDbType.Int)).Value = WorkTime;//WorkTime
            //開啟連線
            conn.Open();
            DataSet ds = new DataSet();
            int i = cmd.ExecuteNonQuery();

            if (i > 0)
            {
                outds = overtime.ReturnData("true", "成功");
            }
            else
            {
                outds = overtime.ReturnData("false", "失敗");
            }

        }
        catch (SqlException ex)
        {
            // handle error
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        catch (Exception ex)
        {
            outds = overtime.ReturnData("false", overtime.replaceSingleQuote(ex.Message));
        }
        finally
        {
            conn.Close();
        }
        return outds;
    }
    #endregion
}