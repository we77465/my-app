﻿using System;
using System.Data;
using System.Configuration;
using System.Globalization;
using System.Data.SqlClient;
using System.Text;
using System.Threading;

/// <summary>
/// DateTimeUtility 的摘要描述
/// </summary>
public class DateTimeUtility
{
    public static string Time_Year_Month_Day = "yyyy/MM/dd";

    public DateTimeUtility()
	{
		//
		// TODO: 在此加入建構函式的程式碼
		//
    }
    #region 客制化時間
    /// <summary>
    /// 取得民國年月日.例:民國九十八年一月一日
    /// </summary>
    /// <param name="t1">The t1.</param>
    /// <returns></returns>
    public static string ShowTaiwanDate(DateTime t1)
    {
        //string SolarDate = t1.ToString("yyyyMMdd");
        string TaiwanMonth = ShowChiValue(t1.ToString("MM"));
        string TaiwanDay = ShowChiValue(t1.ToString("dd"));
        if (int.Parse(t1.ToString("MM")) >= 10 || int.Parse(t1.ToString("MM")) <= 12)
            TaiwanMonth = "十" + ShowChiValue(t1.AddMonths(-10).ToString("MM"));
        if (int.Parse(t1.ToString("MM")) == 10)
            TaiwanMonth = "十";        
        if (int.Parse(t1.ToString("dd")) >= 10 && int.Parse(t1.ToString("dd")) <= 19)
        {
            int Day = int.Parse(t1.ToString("dd"))%10;
            TaiwanDay = "十" + ShowChiValue(Day.ToString());
        }
        if (int.Parse(t1.ToString("dd")) == 10 )                    
            TaiwanDay = "十";        
        return "民國" + ShowChiValue(t1.AddYears(-1911).ToString("yyyy")) + "年" + TaiwanMonth + "月" 
               + TaiwanDay +"日";
    }

    /// <summary>
    /// 取得民國年月日.例:民國九十八年一月一日.
    /// </summary>
    /// <param name="SolarDate">The solar date.</param>
    /// <returns></returns>
    public static string ShowTaiwanDate(string SolarDate)
    {
        int YearValue = int.Parse(SolarDate.Substring(0,4))-1911;
        string TaiwanYear = ShowChiValue(YearValue.ToString());
        string TaiwanMonth = ShowChiValue(SolarDate.Substring(4, 2));
        string TaiwanDay = ShowChiValue(SolarDate.Substring(6, 2));
        if (int.Parse(SolarDate.Substring(4, 2)) >= 10 || int.Parse(SolarDate.Substring(4, 2)) <= 12)
        {
            int MonthValue = int.Parse(SolarDate.Substring(4, 2)) - 10;
            TaiwanMonth = "十" + ShowChiValue(MonthValue.ToString());
        }
        if (int.Parse(SolarDate.Substring(4, 2)) == 10)
            TaiwanMonth = "十";
        if (int.Parse(SolarDate.Substring(6, 2)) >= 10 && int.Parse(SolarDate.Substring(6, 2)) <= 19)
        {
            int Day = int.Parse(SolarDate.Substring(6, 2)) % 10;
            TaiwanDay = "十" + ShowChiValue(Day.ToString());
        }
        if (int.Parse(SolarDate.Substring(6, 2)) == 10)
            TaiwanDay = "十";
        return "民國" + TaiwanYear + "年" + TaiwanMonth + "月"
               + TaiwanDay + "日";
    }

    
    /// <summary>
    /// Shows the chi value.
    /// </summary>
    /// <param name="numValue">The num value.</param>
    /// <returns></returns>
    public static string ShowChiValue(object numValue)
    {
        string strMoney = Convert.ToInt32(numValue).ToString();
        int i;
        int intZeroCount;
        int intLength;
        bool boolStart = false;
        string[] strArrayNum = new string[10] { "零", "一", "二", "三", "四", "五", "六", "七", "八", "九" };
        string[] strArrayUnit = new string[13] { "", "十", "百", "千", "萬", "十", "百", "千", "億", "十", "百", "千", "兆" };
        string strAnswer = "";
        string strAnswreTemp = "";
        string strTemp = "";
        string strZero = "";
        intZeroCount = 0;
        int intTemp = 0;
        intLength = strMoney.Length - 1;
        for (i = 0; i <= intLength; i++)
        {
            strTemp = strMoney.Substring(intLength - i, 1);
            intTemp = int.Parse(strTemp);
            //boolStart True:補零 False:不補零
            if (intTemp > 0)
            {
                if ((i == 5) || (i == 9))
                    if (intZeroCount >= 1)
                    {
                        if (boolStart == true)
                            strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strArrayUnit[i - 1] + strArrayNum[0] + strAnswer;
                        else
                            strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strArrayUnit[i - 1] + strAnswer;
                        intZeroCount = 0;
                    }
                    else
                        strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strAnswer;
                else
                {
                    if (intZeroCount >= 1)
                    {
                        if (boolStart == true)
                            strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strArrayNum[0] + strAnswreTemp + strAnswer;
                        else
                            if (i >= 3)
                                strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strAnswreTemp + strArrayNum[0] + strAnswer;
                            else
                                strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strAnswreTemp + strAnswer;
                        intZeroCount = 0;
                        strAnswreTemp = "";

                    }
                    else
                        strAnswer = strArrayNum[intTemp] + strArrayUnit[i] + strAnswer;
                }
                strZero = "";
                boolStart = true;
            }
            else
            {
                if ((i == 5) || (i == 9))
                {
                    strAnswreTemp = strArrayUnit[i - 1];         //萬與億是單位,既使是零也要寫入
                    boolStart = false;                         //不能補零
                }
                intZeroCount = intZeroCount + 1;
                strZero = strArrayNum[0];
            }
        }
        //例外處理
        if (strAnswer.Length > 0)
        {
            if (strAnswer.Substring(strAnswer.Length - 1, 1) == "零")     //尾數為零時刪除靈
                strAnswer = strAnswer.Substring(0, strAnswer.Length - 1);
            if (strAnswer.Length > 2)
                if (strAnswer.Substring(strAnswer.Length - 2, 2) == "億萬")   //尾數為億萬時刪除萬
                    strAnswer = strAnswer.Substring(0, strAnswer.Length - 1);
            //尾數加"元整"
        }
        else
        {
            strAnswer = "零";
        }
       // strAnswer = strAnswer + "元整";
        return strAnswer;
    }    
    /// <summary>
    /// 輸出日期格式.格式為 yyyy/MM/dd HH:mm:ss
    /// </summary>
    /// <param name="Date">The date.</param>
    /// <returns></returns>
    public static string GetDateTimeFormat(string Date)
    {        
        return string.Format("{0:####/##/## ##:##:##}", Convert.ToInt64(Date.Substring(0, 14)));
    }

    /// <summary>
    /// 輸出日期格式.格式為 yyyy/MM/dd HH:mm:ss
    /// </summary>
    /// <param name="dt">The dt.</param>
    /// <returns></returns>
    public static string GetDateTimeFormat(DateTime dt)
    {
        string Input = dt.ToString("yyyyMMddHHmmss");
        return string.Format("{0:####/##/## ##:##:##}", Convert.ToInt64(Input));
    }
    /// <summary>
    /// Gets the zh tw date time format.
    /// </summary>
    /// <param name="Time">The time.</param>
    /// <param name="choice">1：民國yyy/MM/dd，2：西元yyyy/MM/dd</param>
    /// <returns></returns>
    public static string GetZhTwDateTimeFormat(DateTime Time, int choice)
    {
        if (choice >= 0 && choice <= 2)
        {
            System.Globalization.CultureInfo cuinfo = new System.Globalization.CultureInfo("zh-TW");
            cuinfo.DateTimeFormat.Calendar = cuinfo.OptionalCalendars[choice];
            return Time.ToString("yyyy/MM/dd", cuinfo);
        }
        else
        {
            return null;
        }
    }
    /// <summary>
    /// 輸出日期格式.格式為yyyy/MM/dd
    /// </summary>
    /// <param name="InputDate">The input date.</param>
    /// <returns></returns>
    public static string ShowDateTimeDay(DateTime InputDate)
    {
        return InputDate.ToString("yyyy/MM/dd");// 日期 ex. 2009/02/04         
    }
    /// <summary>
    /// 輸出時間格式.格式為HH:mm:ss
    /// </summary>
    /// <param name="InputDate">The input date.</param>
    /// <returns></returns>
    public static string ShowDateTimeDayNoDay(DateTime InputDate)
    {
        return InputDate.ToString("HH:mm:ss");  // 時間 ex. 17:10:10
    }
    /// <summary>
    /// 取得月底日.
    /// </summary>
    /// <param name="dt">The dt.</param>
    /// <returns></returns>
    public static DateTime GetLastMonthDay(DateTime dt)
    {
        System.DateTime ThisMonBeginDay = new System.DateTime(dt.Year, dt.Month, 1);
        return ThisMonBeginDay.AddMonths(1).AddDays(-1);
    }
    /// <summary>
    /// 取得月初日.
    /// </summary>
    /// <param name="dt">The dt.</param>
    /// <returns></returns>
    public static DateTime GetFirstMonthDay(DateTime dt)
    {
        System.DateTime ThisMonBeginDay = new System.DateTime(dt.Year, dt.Month, 1);
        return ThisMonBeginDay;
    }
    /// <summary>
    /// 取得目前日期的週第一天.
    /// </summary>
    /// <returns></returns>
    public static DateTime GetFirstDayOfWeek()
    {
        return DateTime.Today.AddDays(-1 * (((int)DateTime.Today.DayOfWeek) - 1));
    }
    /// <summary>
    /// 西曆轉農民曆.
    /// </summary>
    /// <param name="now">The now.</param>
    /// <returns></returns>
    public static string GetTaiwanLunaDay(DateTime now)
    {
        TaiwanLunisolarCalendar tlc = new TaiwanLunisolarCalendar();
        int luyear = tlc.GetYear(now);
        int lumonth = tlc.GetMonth(now);
        int ludaysOfMonth = tlc.GetDayOfMonth(now);
        int leapMonth = tlc.GetLeapMonth(luyear);

        if (leapMonth > 0 && lumonth <= leapMonth)
        {
            if (leapMonth == lumonth)
            {
                lumonth = (leapMonth - 1);
            }
            else
            {
                ;
            }
        }
        else if (leapMonth > 0 && lumonth > leapMonth)
        {
            lumonth = (lumonth - 1);
        }
        else
        {
            ;
        }
        return luyear + "-" + lumonth + "-" + ludaysOfMonth;
    }
    #endregion
    #region 下sql去db撈日期後調整輸出格式
    //編碼 sql指令 輸出格式
    //1  select convert(varchar, getdate(), 1)  12/30/06  
    //2  select convert(varchar, getdate(), 2)  06.12.30  
    //3  select convert(varchar, getdate(), 3)  30/12/06  
    //4  select convert(varchar, getdate(), 4)  30.12.06  
    //5  select convert(varchar, getdate(), 5)  30-12-06  
    //6  select convert(varchar, getdate(), 6)  30 Dec 06  
    //7  select convert(varchar, getdate(), 7)  Dec 30, 06  
    //10  select convert(varchar, getdate(), 10)  12-30-06  
    //11  select convert(varchar, getdate(), 11)  06/12/30  
    //101  select convert(varchar, getdate(), 101)  12/30/2006  
    //102  select convert(varchar, getdate(), 102)  2006.12.30  
    //103  select convert(varchar, getdate(), 103)  30/12/2006  
    //104  select convert(varchar, getdate(), 104)  30.12.2006  
    //105  select convert(varchar, getdate(), 105)  30-12-2006  
    //106  select convert(varchar, getdate(), 106)  30 Dec 2006  
    //107  select convert(varchar, getdate(), 107)  Dec 30, 2006  
    //110  select convert(varchar, getdate(), 110)  12-30-2006  
    //111  select convert(varchar, getdate(), 111)  2006/12/30  
    //8 or 108  select convert(varchar, getdate(), 8)  00:38:54  
    //9 or 109  select convert(varchar, getdate(), 9)  Dec 30 2006 12:38:54:840AM  
    //14 or 114  select convert(varchar, getdate(), 14)  00:38:54:840     
    /// <summary>
    /// 設定本日日期時間格式.
    /// </summary>
    /// <param name="type">The type.</param>
    /// <returns></returns>
    public static string GetTodayTimeFormatSql(int type)
    {
        DataTable dt = new DataTable();
        string SqlCmd = "select convert(varchar, getdate(), "+type.ToString()+" ) as expr1 ";
        using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["chb_pub"].ToString()))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    dt.Load(dr);
                }
            }
        }
        return dt.Rows[0][0].ToString();
    }

    /// <summary>
    /// 設定datetime欄位日期時間格式.
    /// </summary>
    /// <param name="type">The type.</param>
    /// <param name="ConnectString">The connect string.</param>
    /// <param name="TableName">Name of the table.</param>
    /// <param name="ColumnName">Name of the column.</param>
    /// <param name="Condition">The condition.</param>
    /// <returns></returns>
    public static DataTable GetTimeFormatFromSql(int type,string ConnectString, string TableName,string ColumnName,string Condition)
    {
        DataTable dt = new DataTable();
        string SqlCmd = " select convert(varchar, "+ColumnName+" , " + type.ToString() + " ) as expr1 ";
        SqlCmd += " from " + TableName;
        if (Condition != string.Empty)
            SqlCmd += " where " + Condition;
        using (SqlConnection cn = new SqlConnection(ConnectString))
        {
            cn.Open();
            using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    dt.Load(dr);
                }
            }
        }
        return dt;
    }
    #endregion
    #region 取得太陰曆日期
    public class LunaCalendar
    {
        public static ChineseLunisolarCalendar calendar = new ChineseLunisolarCalendar();        
        public static string GetYear(DateTime time)
        {
            StringBuilder sb = new StringBuilder();
            int year = calendar.GetYear(time);
            int d;
            do
            {
                d = year % 10;
                sb.Insert(0, ChineseNumber[d]);
                year = year / 10;
            } while (year > 0);
            return sb.ToString();
        }
        private static string ChineseNumber = "〇一二三四五六七八九";
        
        public static string GetMonth(DateTime time)
        {
            int month = calendar.GetMonth(time);
            int year = calendar.GetYear(time);
            int leap = 0;
            //正月不可能閏月
            for (int i = 3; i <= month; i++)
            {
                if (calendar.IsLeapMonth(year, i))
                {
                    leap = i;
                    break;  //一年中最多有一个閏月
                }
            }
            if (leap > 0) month--;
            return (leap == month + 1 ? "閏" : "") + ChineseMonthName[month - 1];
        }
        public static readonly string[] ChineseMonthName = new string[] { "正", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二" };        
        public static string GetDay(DateTime time)
        {            
            return ChineseDayName[calendar.GetDayOfMonth(time) - 1];
        }
        public static readonly string[] ChineseDayName = new string[] {
            "初一","初二","初三","初四","初五","初六","初七","初八","初九","初十",
            "十一","十二","十三","十四","十五","十六","十七","十八","十九","二十",
            "廿一","廿二","廿三","廿四","廿五","廿六","廿七","廿八","廿九","三十"};                
        public static string GetStemBranch(DateTime time)
        {
            int sexagenaryYear = calendar.GetSexagenaryYear(time);
            string stemBranch = CelestialStem.Substring(calendar.GetCelestialStem(sexagenaryYear) - 1, 1) + TerrestrialBranch.Substring(calendar.GetTerrestrialBranch(sexagenaryYear) - 1, 1);
            return stemBranch;

        }
        public const string CelestialStem = "甲乙丙丁戊己庚辛壬癸";
        public const string TerrestrialBranch = "子丑寅卯辰巳午未申酉戌亥";
        /// <summary>
        /// 取得生肖.
        /// </summary>
        /// <param name="time">The time.</param>
        /// <returns></returns>
        public static string GetLunaZodiacYear(DateTime time)
        {
            int sexagenaryYear = calendar.GetSexagenaryYear(time);
            string Tree = TreeYear.Substring(calendar.GetTerrestrialBranch(sexagenaryYear) - 1, 1);
            return Tree;
        }
        public const string TreeYear = "鼠牛虎兔龍蛇馬羊猴雞狗豬";
        /// <summary>
        /// 顯示太陰曆日期.
        /// </summary>
        /// <param name="Date">The date.</param>
        /// <returns></returns>
        public static string DisplayLunaDate(DateTime Date)
        {
            return String.Format("{0}年{1}月{2}", GetStemBranch(Date),
                       GetMonth(Date),
                       GetDay(Date));
        }
    }
    #endregion
    /// <summary>
    /// 取得民國年，例：2021-08-19 --> 110
    /// </summary>
    /// <param name="t1">時間</param>
    /// <returns>民國年YYY</returns>
    public static string GetTaiwanYear(DateTime t1)
    {
        return (int.Parse(t1.ToString("yyyy")) - 1911).ToString();
    }
    /// <summary>
    /// 取得民國年月，例：2021-08-19 --> 11008
    /// </summary>
    /// <param name="t1">時間</param>
    /// <returns>民國年月YYYMM</returns>
    public static string GetTaiwanYYMM(DateTime t1)
    {
        return (int.Parse(t1.ToString("yyyyMM")) - 191100).ToString();
    }
    /// <summary>
    /// 取得民國年月日，例：2021-08-19 --> 1100819
    /// </summary>
    /// <param name="t1">時間</param>
    /// <returns>民國年月YYYMMDD</returns>
    public static string GetTaiwanDate(DateTime t1)
    {
        return (int.Parse(t1.ToString("yyyyMMdd")) - 19110000).ToString();
    }
    public static void SetROCCal()
    {
        CultureInfo Cal = new CultureInfo("zh-TW");
        Cal.DateTimeFormat.Calendar = new TaiwanCalendar();
        Thread.CurrentThread.CurrentCulture = Cal;
    }

    public static bool chkDateType(string strDate, string dateType)
    {
        if (strDate.Length > 0)
        {
            DateTime dateTimeResult;
            return DateTime.TryParseExact(strDate, dateType, CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTimeResult);
        }

        return true;
    }
    /// <summary>
    /// 檢查民國年月日是否為合法的日期，例：1140229 --> False
    /// </summary>
    /// <param name="t1">民國年月日YYYMMDD</param>
    /// <returns>True:合法、False:不合法</returns>
    public static bool CheckTaiwanDate(string t1)
    {
        DateTime dtParse;
        string tt1;
        if (t1.Contains("/"))
            t1 = t1.Replace("/", "");
        else if (t1.Contains("-"))
            t1 = t1.Replace("-", "");

        try
        {
            tt1 = (int.Parse(t1) + 19110000).ToString();
            tt1 = tt1.Substring(0, 4) + "-" + tt1.Substring(4, 2) + "-" + tt1.Substring(6, 2);
        }
        catch (Exception)
        {
            return false;
        }
        return DateTime.TryParse(tt1, out dtParse);
    }
    /// <summary>
    /// 格式化民國年月日，例：1140228 --> 114-02-28
    /// </summary>
    /// <param name="t1">民國年月日yyyMMdd</param>
    /// <param name="Format">格式，目前只實做yyy-MM-dd</param>
    /// <returns>格式化後的民國年月日</returns>
    public static string FormatTaiwanDate(string t1, string Format)
    {
        if (t1.Contains("/"))
            t1 = t1.Replace("/", "");
        else if (t1.Contains("-"))
            t1 = t1.Replace("-", "");
        string tt1 = t1;
        try
        {
            if (Format == "yyy-MM-dd" && tt1.Length == 7)
                tt1 = tt1.Substring(0, 3) + "-" + tt1.Substring(3, 2) + "-" + tt1.Substring(5, 2);
            else
                tt1 = tt1.Substring(0, 3) + "-" + tt1.Substring(3, 2) + "-" + tt1.Substring(5, 2);
        }
        catch (Exception ex)
        {
            tt1 = "格式或長度錯誤：" + ex.Message;
        }
        return tt1;
    }
}
