﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// FDataSouce 的摘要描述
/// </summary>
public static class FDataSouce
{
    public static void BindGridView(GridView GV ,ParameterCollection Params ,string Sql ) 
    {
        SqlDataSource DS = new SqlDataSource();
        DS.ConnectionString = ConfigurationManager.ConnectionStrings["chb_eform"].ToString();
        //DS.SelectCommand = Sql;
        foreach(Parameter param in Params)
        {
            DS.SelectParameters.Add(param);        
        }
        DS.Select(new DataSourceSelectArguments());

        GV.DataSource = DS;
        GV.DataBind();    
    }
}
