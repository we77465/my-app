﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Data.Odbc;


/// <summary>
/// clsTeradata 的摘要描述
/// </summary>
public class ClsTeradata : clsIntraMaintainDBHandler
{
    public OdbcConnection conn_odbc;
    public OdbcDataReader dr_odbc;
    public OdbcCommand cmd_odbc;
    public DataTable dt_odbc;


    public ClsTeradata(string dsn, string uid, string pwd)
    {
        //Dsn=dw5400e;PageTimeout=6000;uid=intrauser;pwd=userintra;Connect Timeout=6000
        ConnectionStringWithNoDefaultDBName = "DSN=" + dsn +
                                        ";PageTimeout=6000;Connect Timeout=6000;" +
                                        ";uid=" + uid +
                                        ";pwd=" + pwd;
        ConnectionString = ConnectionStringWithNoDefaultDBName;
    }

    public override bool isConnected()
    {
        OdbcConnection conn = new OdbcConnection(ConnectionStringWithNoDefaultDBName);
        bool isOK;
        try
        {
            conn.Open();
            isOK = true;
            Message = "";
            conn.Close();
        }
        catch (Exception ex)
        {
            isOK = false;
            Message = ex.Message;
        }

        return isOK;


    }

    public override int ExecuteNonQuery(string sql)
    {
        int rtnValue;

        OdbcConnection conn = new OdbcConnection(ConnectionString);
        try
        {
            conn.Open();
            OdbcCommand cmd = new OdbcCommand(sql, conn);
            rtnValue = cmd.ExecuteNonQuery();

            if (rtnValue == -1)
            {
                rtnValue = 0;
            }
        }
        catch (Exception ex)
        {
            rtnValue = -1;
            Message = ex.Message;
        }
        finally
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }

        return rtnValue;
    }
    public int GetDataCountFromSQL()
    {
        int rowcount = 0;
        using (OdbcConnection connection = new OdbcConnection(ConnectionString))
        using (OdbcCommand command = connection.CreateCommand())
        {
            connection.Open();
            command.CommandText = "select * from intra_view.INTRA_YOUNG_ENTRE_LON where snapshot_month = '202305'";
            using (OdbcDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    ++rowcount;
                }
            }
        }
        return rowcount;
    }
    public override DataTable GetDataTableFromSQL(string sql, int MaxRowCount)
    {
        DataTable dt = null;
        DataTable dtSchema = null;
        DataRow dRow;
        int cnt = 0;

        OdbcConnection conn = new OdbcConnection(ConnectionString);
        OdbcCommand cmd = null;
        OdbcDataReader dr = null;

        try
        {
            conn.Open();
            cmd = new OdbcCommand(sql, conn);

            using (dr = cmd.ExecuteReader())
            {
                dt = new DataTable();

                dtSchema = dr.GetSchemaTable();
                //return dtSchema;
                if (dtSchema != null)
                {
                    foreach (DataRow drow in dtSchema.Rows)
                    {
                        string columnName = System.Convert.ToString(drow["ColumnName"]);
                        DataColumn column = new DataColumn(columnName, (Type)(drow["DataType"]));
                        //DataColumn column = new DataColumn(columnName);
                        dt.Columns.Add(column);
                    }
                }

                while (dr.Read())
                {
                    cnt += 1; //計算筆數

                    dRow = dt.NewRow();

                    for (int i = 0; i < dr.FieldCount; i++)
                    {
                        dRow[i] = dr[i];
                    }
                    dt.Rows.Add(dRow);

                    if (cnt >= MaxRowCount && MaxRowCount > 0) //超過自訂筆數就跳出
                        break;

                }
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
                cmd.Dispose();
                if (dr != null) { dr.Close(); }
                
            }


        }




        return dt;
    }

    public override DataTable GetTableList(string sType, string sCategory)
    {
        return GetDataTableFromSQL("SELECT  TableName FROM    DBC.TablesV WHERE   TableKind = 'T' and     DatabaseName = '" + sCategory + "' ORDER BY    TableName; ", -1);
    }


    public override void GenerateDataReader(string sql)
    {
        //設定好連線、CMD、Datatable及Datareader,以便函數ReadToDatatable使用

        conn_odbc = new OdbcConnection(ConnectionString);
        cmd_odbc = null;

        try
        {
            conn_odbc.Open();
            cmd_odbc = new OdbcCommand(sql, conn_odbc);

            dr_odbc = cmd_odbc.ExecuteReader();
            DataTable dtSchema = null;
            dtSchema = dr_odbc.GetSchemaTable();

            if (dtSchema != null)
            {
                dt_odbc = new DataTable();

                foreach (DataRow drow in dtSchema.Rows)
                {
                    string columnName = System.Convert.ToString(drow["ColumnName"]);
                    DataColumn column = new DataColumn(columnName, (Type)(drow["DataType"]));
                    dt_odbc.Columns.Add(column);
                }
            }
        }
        catch (Exception)
        {

            throw;
        }
        //finally
        //{
        //    if (conn_odbc.State == ConnectionState.Open)
        //        conn_odbc.Close();
        //}

    }
    public override DataTable ReadToDatatable()
    {
        DataRow dRow;
        int cnt = 0;

        dt_odbc.Clear();
        if (conn_odbc.State != ConnectionState.Open)
            return dt_odbc;


        try
        {

            while (dr_odbc.Read())
            {
                cnt += 1; //計算筆數

                dRow = dt_odbc.NewRow();

                for (int i = 0; i < dr_odbc.FieldCount; i++)
                {
                    dRow[i] = dr_odbc[i];
                }
                dt_odbc.Rows.Add(dRow);

                if (cnt >= 10000) //每次讀取上限一萬筆
                    break;

            }

        }
        catch
        {

        }

        //沒有資料了，將connection關閉
        if (dt_odbc.Rows.Count == 0)
            conn_odbc.Close();

        return dt_odbc;

    }

    public override string ExecuteScale(string sql)
    {
        string rtnValue;

        OdbcConnection conn = new OdbcConnection(ConnectionString);
        try
        {
            conn.Open();
            OdbcCommand cmd = new OdbcCommand(sql, conn);
            rtnValue = (string)cmd.ExecuteScalar();

        }
        catch (Exception ex)
        {
            rtnValue = "";
            Message = ex.Message;
        }
        finally
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }

        return rtnValue;
    }
}