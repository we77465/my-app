using System;
using System.Data.SqlClient;
using Microsoft.VisualBasic; // Install-Package Microsoft.VisualBasic

// 2023/11/22  176752 Modify�GVB TO C��

/// <summary>
/// �O�޽c�t�μg�J�޲z���M�Ͼާ@��x
/// </summary>
public partial class clsAdminSQL : DBAccess // �~��DBAccess(�B�z����SQL���O)
{

    public clsAdminSQL()
    {
    }

    #region Verlog

    /// <summary>
    /// ���o�g�J�޲z���M�Ͼާ@��x(AdminLlog)���O�X
    /// </summary>
    /// <param name="valDep_ID">���N��</param>
    /// <param name="valUser_ID">���u�s��</param>
    /// <param name="valUser_Name">���u�m�W</param>
    /// <param name="valTr_Date">���</param>
    /// <param name="valTr_Log">���e</param>
    /// <param name="valIP_Addr">IP</param>
    /// <returns></returns>
    public SqlCommand InsertAdminLog(string valDep_ID, string valUser_ID, string valUser_Name, string valTr_Date, string valTr_Log, string valIP_Addr)




    {
        var cmd = new SqlCommand();

        cmd.CommandText = "INSERT INTO [AdminLog]" + Constants.vbCrLf + " ([Dep_ID],[User_ID],[User_Name],[Tr_Date],[Tr_Log],[IP_Addr])" + Constants.vbCrLf + " VALUES" + Constants.vbCrLf + " (@Dep_ID,@User_ID,@User_Name,@Tr_Date,@Tr_Log,@IP_Addr)";

        // �Ѽ�
        cmd.Parameters.Add("@Dep_ID", System.Data.SqlDbType.NChar, 4);
        cmd.Parameters.Add("@User_ID", System.Data.SqlDbType.Decimal);
        cmd.Parameters.Add("@User_Name", System.Data.SqlDbType.NVarChar, 10);
        cmd.Parameters.Add("@Tr_Date", System.Data.SqlDbType.DateTime);
        cmd.Parameters.Add("@Tr_Log", System.Data.SqlDbType.NVarChar, 255);
        cmd.Parameters.Add("@IP_Addr", System.Data.SqlDbType.NChar, 15);

        // �w�]��
        cmd.Parameters["@Dep_ID"].Value = valDep_ID;
        cmd.Parameters["@User_ID"].Value = valUser_ID;
        cmd.Parameters["@User_Name"].Value = valUser_Name;
        cmd.Parameters["@Tr_Date"].Value = valTr_Date;
        cmd.Parameters["@Tr_Log"].Value = valTr_Log;

        if (string.IsNullOrEmpty(valIP_Addr))
        {
            cmd.Parameters["@IP_Addr"].Value = DBNull.Value;
        }
        else
        {
            cmd.Parameters["@IP_Addr"].Value = valIP_Addr;

        }
        return cmd;
    }


    /// <summary>
    /// �g�J�޲z���M�Ͼާ@��x(AdminLlog)
    /// </summary>
    /// <param name="valDep_ID">���N��</param>
    /// <param name="valUser_ID">���u�s��</param>
    /// <param name="valUser_Name">���u�m�W</param>
    /// <param name="valTr_Date">���</param>
    /// <param name="valTr_Log">���e</param>
    /// <param name="valIP_Addr">IP</param>

    public void InsAdmLog(string valDep_ID, string valUser_ID, string valUser_Name, string valTr_Date, string valTr_Log, string valIP_Addr)




    {

        try
        {
            ExecuteCommand(InsertAdminLog(valDep_ID, valUser_ID, valUser_Name, valTr_Date, valTr_Log, valIP_Addr));




        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }

    }



    #endregion




}