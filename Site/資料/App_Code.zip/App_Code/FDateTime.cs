﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// FDateTime 的摘要描述
/// </summary>
public static class FDateTime
{	

    public static string CHNYYMMDD(string Date)
    {
        int intYY = Convert.ToInt16(Convert.ToDateTime(Date).ToString("yyyy"))-1911;
        string strYY = (intYY.ToString().Length == 2) ? "0" + intYY.ToString() : intYY.ToString();
        return strYY + Convert.ToDateTime(Date).ToString("MMdd");
    }
}
