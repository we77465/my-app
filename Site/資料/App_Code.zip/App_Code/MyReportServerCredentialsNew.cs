﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Reporting.WebForms;
using System.Net;
using System.Security.Principal;

/// <summary>
/// MyReportServerCredentials 的摘要描述
/// </summary>
public class MyReportServerCredentialsNew : IReportServerCredentials
{
    private string sRptVer;
    public MyReportServerCredentialsNew(string rptVer)
    {
        //
        // TODO: 在此加入建構函式的程式碼
        sRptVer = rptVer;
        //
    }

    public WindowsIdentity ImpersonationUser
    {
        get
        {
            // Use the default Windows user.  Credentials will be
            // provided by the NetworkCredentials property.
            return null;
        }
    }

    public ICredentials NetworkCredentials
    {
        get
        {
            // Read the user information from the Web.config file.  
            // By reading the information on demand instead of 
            // storing it, the credentials will not be stored in 
            // session, reducing the vulnerable surface area to the
            // Web.config file, which can be secured with an ACL.

            string userName, password, domain;


            if (sRptVer == "0")
            {
                // User name
                userName = ConfigurationManager.AppSettings["ReportLoginID"];

                // Password
                password = ConfigurationManager.AppSettings["ReportPassword"];



                // Domain
                domain = ConfigurationManager.AppSettings["ReportServer"];


            }
            else
            {
                // User name
                userName = ConfigurationManager.AppSettings["ReportLoginIDNew"];

                // Password
                password = ConfigurationManager.AppSettings["ReportPasswordNew"];

                // Domain
                domain = ConfigurationManager.AppSettings["ReportServer2008"];
            }

            if (string.IsNullOrEmpty(userName))
                throw new Exception(
                    "Missing user name from web.config file");

            if (string.IsNullOrEmpty(password))
                throw new Exception(
                    "Missing password from web.config file");

            if (string.IsNullOrEmpty(domain))
                throw new Exception(
                    "Missing domain from web.config file");

            //// User name
            //string userName =
            //    ConfigurationManager.AppSettings
            //        ["ReportLoginID"];

            //if (string.IsNullOrEmpty(userName))
            //    throw new Exception(
            //        "Missing user name from web.config file");

            //// Password
            //string password =
            //    ConfigurationManager.AppSettings
            //        ["ReportPassword"];

            //if (string.IsNullOrEmpty(password))
            //    throw new Exception(
            //        "Missing password from web.config file");

            //// Domain
            //string domain =
            //    ConfigurationManager.AppSettings
            //        ["ReportServer"];

            //if (string.IsNullOrEmpty(domain))
            //    throw new Exception(
            //        "Missing domain from web.config file");

            return new NetworkCredential(userName, password, domain);
        }
    }

    public bool GetFormsCredentials(out Cookie authCookie,
                out string userName, out string password,
                out string authority)
    {
        authCookie = null;
        userName = null;
        password = null;
        authority = null;

        // Not using form credentials
        return false;
    }

}
