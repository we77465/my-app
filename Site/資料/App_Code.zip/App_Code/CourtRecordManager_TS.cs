﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using Unlocker.NET;

/// <summary>
/// CourtRecordManager 的摘要描述
/// </summary>
public class CourtRecordManager_TS
{
    [Flags]
    public enum FileTypeEnum
    {
        無對應資料 = -1,
        F1094 = 1,
        P0610 = 2,
        函文 = 3,
        其他資料 = 4,
        備註 = 5
    };
    [Flags]
    public enum FolderNameEnum
    {
        F1094 = 1,
        P0610 = 2,
        Correspondence = 3,
        Other = 4
    };
    [Flags]
    public enum DbActionEnum
    {
        查詢 = 0,
        新增 = 1,
        修改 = 2,
        刪除 = 3
    };


    //E:\CourtRecord\CourtRecordUpLoa
    private string sourceZipFilePath = "E:\\ZipField\\source\\";
    private string destZipFilePath = "E:\\ZipField\\dest\\" + DateTime.Now.ToString("yyyyMMddhhmmss") + "\\";
    private string destZipFilePathRoot = "E:\\ZipField\\dest\\";
    private string finalUnzipFilePath = "E:\\ZipField\\final\\";
    private string uploadFilePath = "E:\\CourtRecord\\CourtRecordUpload\\";

    public CourtRecordManager_TS()
    {
        DirectoryInfo zipsource = new DirectoryInfo(sourceZipFilePath);
        if (zipsource.Exists == false)
        {
            Directory.CreateDirectory(zipsource.FullName);
        }
        DirectoryInfo zipdest = new DirectoryInfo(destZipFilePathRoot);
        if (zipdest.Exists == false)
        {
            Directory.CreateDirectory(zipdest.FullName);
        }
    }
    public string GetFilePath(System.Web.UI.Page source, FileTypeEnum ftype, DateTime uploadtime)
    {
        int inputtype = (int)ftype;
        FolderNameEnum foldername = (FolderNameEnum)inputtype;
//        string path = source.Server.MapPath("~/../Upload/CourtRecordUpLoad/" + uploadtime.AddYears(-1911).ToString("yyy") + "/" + foldername.ToString() + "/");
        string path = uploadFilePath + uploadtime.AddYears(-1911).ToString("yyy") + "\\" + foldername.ToString() + "\\";
 
        DirectoryInfo DirInfo = new DirectoryInfo(path);
        if (DirInfo.Exists == false)
            Directory.CreateDirectory(path);
        return path;
    }
    public string GetFilePathInDb(System.Web.UI.Page source, FileTypeEnum ftype, DateTime uploadtime)
    {
        int inputtype = (int)ftype;
        FolderNameEnum foldername = (FolderNameEnum)inputtype;
        string path = uploadtime.AddYears(-1911).ToString("yyy") + "/" + foldername.ToString() + "/";
        return path;
    }
    public string UploadFile(System.Web.UI.Page source, FileUpload uploader, FileTypeEnum ftype, DbActionEnum action, string empno)
    {
        Boolean fileOK = false;
        if (uploader.HasFile)
        {
            String fileExtension =
                System.IO.Path.GetExtension(uploader.FileName).ToLower();
            String[] allowedExtensions = { ".pdf", ".txt", ".rar", ".zip" };
            for (int i = 0; i < allowedExtensions.Length; i++)
            {
                if (fileExtension == allowedExtensions[i])
                {
                    fileOK = true;
                }
            }
        }
        if (fileOK)
        {
            try
            {
                String fileExtension =
                System.IO.Path.GetExtension(uploader.FileName).ToLower();
                string[] sep = new string[] { "\\" };                
                //當上傳壓縮檔案
                if (fileExtension == ".rar" || fileExtension == ".zip")
                {                    
                    string destFileFullPath = sourceZipFilePath + uploader.FileName;
                    string destZipFilePathByFTYPE = destZipFilePath + ftype.ToString() + "\\";
                    Unlocker.NET.Unlocker.CloseFileHandle(destFileFullPath);
                    uploader.PostedFile.SaveAs(destFileFullPath);
                    ZipUtility.UnZipFile(destFileFullPath, destZipFilePathByFTYPE);
                    string result = string.Empty;
                    List<string> filelist = new List<string>();
                    foreach (string filename in GetAllFilesNameString(destZipFilePathByFTYPE).Split('\t'))
                    {
                        string[] shortname = filename.Split(sep, StringSplitOptions.None);                        
                        if (shortname[shortname.Length - 1].Trim().Length != 0 )
                        {
                            filelist.Add(filename);
                            List<string> upReceiveCode = GetRecieveCode(filename, ftype);                                                    
                            string destFileName = GetUploadFileName(filename, ftype);
                            string destFileFullPathCopy = GetFilePath(source, ftype, DateTime.Now)
                                + GetUploadFileName(filename, ftype);
                            string destFileFullPathInDb = GetFilePathInDb(source, ftype, DateTime.Now)
                                + GetUploadFileName(filename, ftype);
                            Unlocker.NET.Unlocker.CloseFileHandle(destFileFullPathCopy);
                            Unlocker.NET.Unlocker.CloseFileHandle(filename);
                            if (File.Exists(destFileFullPathCopy) == true)
                            {
                                File.Delete(destFileFullPathCopy);
                            }
                            
                            try
                            {
                                File.Copy(filename, destFileFullPathCopy); 
                            }catch(Exception e){
                                return e.Message.ToString();
                            }
                            foreach (string receiveCode in upReceiveCode)
                            {
                                NoneQueryResult(SqlCmdInsertUploadDataRecord(ftype, receiveCode, destFileName, destFileFullPathInDb, empno));
                                NoneQueryResult(SqlCmdUpdateUploadTime(ftype,receiveCode,destFileName));
                                NoneQueryResult(SqlCmdInsertUploadDataRecordLog(ftype, receiveCode, action, empno));
                                
                            }
                            if (ftype == FileTypeEnum.P0610)
                            {
                                P0602SplitItem p0602Obj = new P0602SplitItem();
                                p0602Obj.InsertToDB(destFileFullPathCopy);
                            }
                        }

                    }
                    //return "檔案zip上傳成功!";
                   // return destZipFilePath + ftype.ToString() + "\\";
                    //return result;
                    return string.Join("<br/>", filelist.ToArray());
                }
                else
                {

                    List<string> upReceiveCode = GetRecieveCode(uploader, ftype);                    
                    string destFileName = GetUploadFileName(uploader, ftype);
                    string destFileFullPath = GetFilePath(source, ftype, DateTime.Now)
                        + GetUploadFileName(uploader, ftype);
                    string destFileFullPathInDb = GetFilePathInDb(source, ftype, DateTime.Now)
                        + GetUploadFileName(uploader, ftype);
                    Unlocker.NET.Unlocker.CloseFileHandle(destFileFullPath);
                    uploader.PostedFile.SaveAs(destFileFullPath);
                    foreach (string receiveCode in upReceiveCode)
                    {
                        NoneQueryResult(SqlCmdInsertUploadDataRecord(ftype, receiveCode, destFileName, destFileFullPathInDb, empno));
                        NoneQueryResult(SqlCmdUpdateUploadTime(ftype, receiveCode, destFileName));
                        NoneQueryResult(SqlCmdInsertUploadDataRecordLog(ftype, receiveCode, action, empno));
                    }
                    if (ftype == FileTypeEnum.P0610)
                    {
                        P0602SplitItem p0602Obj = new P0602SplitItem();
                        p0602Obj.InsertToDB(destFileFullPath);
                    }
                    return "檔案upzip上傳成功!";
                }
            }
            catch (Exception ex)
            {
                //return "上傳失敗!請勿重覆上傳";
                return ex.ToString();
            }
        }
        else
        {
            return "請上傳pdf檔或文字檔!";
        }
    }
    public string GetUploadFileName(FileUpload uploader, FileTypeEnum ftype)
    {
        if (uploader.HasFile == false)
        {
            return string.Empty;
        }
        else
        {
            string filename = uploader.FileName.Replace(System.IO.Path.GetExtension(uploader.FileName).ToUpper(), string.Empty).Replace(System.IO.Path.GetExtension(uploader.FileName).ToLower(), string.Empty).Substring(0, 8);
            string fileExtension = System.IO.Path.GetExtension(uploader.FileName).ToLower();
            switch (ftype)
            {
                case FileTypeEnum.F1094:
                    return uploader.FileName;
                case FileTypeEnum.P0610:
                    return uploader.FileName;
                case FileTypeEnum.其他資料:
                    return filename + GetQueryResultFirstRecord(SqlCmdGetBatchNumber(FileTypeEnum.其他資料, filename)) + fileExtension;
                case FileTypeEnum.函文:
                    return filename + GetQueryResultFirstRecord(SqlCmdGetBatchNumber(FileTypeEnum.函文, filename)) + fileExtension;
                default:
                    return string.Empty;

            }
            return string.Empty;
        }
    }
    public string GetUploadFileName(string filefullname, FileTypeEnum ftype)
    {
        FileInfo fi = new FileInfo(filefullname);
        if (fi.Exists == false)
        {
            return string.Empty;
        }
        else
        {
            string filename = fi.Name.Replace(System.IO.Path.GetExtension(fi.Name).ToUpper(), string.Empty).Replace(System.IO.Path.GetExtension(fi.Name).ToLower(), string.Empty).Substring(0, 8);
            string fileExtension = System.IO.Path.GetExtension(fi.Name).ToLower();
            switch (ftype)
            {
                case FileTypeEnum.F1094:
                    return fi.Name;
                case FileTypeEnum.P0610:
                    return fi.Name;
                case FileTypeEnum.其他資料:
                    return filename + GetQueryResultFirstRecord(SqlCmdGetBatchNumber(FileTypeEnum.其他資料, filename)) + fileExtension;
                case FileTypeEnum.函文:
                    return filename + GetQueryResultFirstRecord(SqlCmdGetBatchNumber(FileTypeEnum.函文, filename)) + fileExtension;
                default:
                    return string.Empty;

            }
            return string.Empty;
        }
    }
    public void ResetLogState(DbActionEnum action, string empno)
    {
        NoneQueryResult(SqlCmdResetDataRecordLogState(action, empno));
    }
    public void InsertUploadDataRecordLog(FileTypeEnum ftype, string recievecode, DbActionEnum action, string empno)
    {
        NoneQueryResult(SqlCmdInsertUploadDataRecordLog(ftype, recievecode, action, empno));
    }
    #region sql指令區
    public static DataTable GetQueryResult(string SqlCmd)
    {
        DataTable dt = new DataTable();
        string connectString = ConfigurationManager.ConnectionStrings["chb_iom"].ToString();
        try
        {
            using (SqlConnection cn = new SqlConnection(connectString))
            {
                cn.Open();
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }
                }
            }
            return dt;
        }
        catch (Exception k)
        {
            return null;
        }
    }
    public static string GetQueryResultFirstRecord(string SqlCmd)
    {
        string connectString = ConfigurationManager.ConnectionStrings["chb_iom"].ToString();
        try
        {
            using (SqlConnection cn = new SqlConnection(connectString))
            {
                cn.Open();
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    return (cmd.ExecuteScalar() == null) ? string.Empty : (cmd.ExecuteScalar().ToString() == string.Empty) ? string.Empty : cmd.ExecuteScalar().ToString();
                }
            }
        }
        catch (Exception k)
        {
            return null;
        }
    }
    public static int NoneQueryResult(string SqlCmd)
    {
        string connectString = ConfigurationManager.ConnectionStrings["chb_iom"].ToString();
        try
        {
            using (SqlConnection cn = new SqlConnection(connectString))
            {
                cn.Open();
                using (SqlCommand cmd = new SqlCommand(SqlCmd, cn))
                {
                    return cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception k)
        {
            return 0;
        }
    }
    private string SqlCmdGetBatchNumber(FileTypeEnum ftype, string recievecode)
    {
        int typevalue = (int)ftype;
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(@"SELECT ");
        sb.AppendLine(@"case when len(cast(count(RecieveCode)+1 as varchar))<2 then '0'+cast(count(RecieveCode)+1 as varchar) else");
        sb.AppendLine(@"cast(count(RecieveCode)+1 as varchar) end as counter");
        sb.AppendLine(@"from tblCourtRecordUpMain_0804 ");
        sb.AppendLine(@"where SystemType='" + typevalue.ToString() + "' and RecieveCode= '" + recievecode + "'");
        return sb.ToString();
    }
    private string SqlCmdInsertUploadDataRecord(FileTypeEnum ftype, string recievecode, string note, string filepath, string empno)
    {
        int typevalue = (int)ftype;
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(@"INSERT INTO tblCourtRecordUpMain_0804 ");
        sb.AppendLine(@"           ([SystemType]");
        sb.AppendLine(@"           ,[RecieveCode]");
        sb.AppendLine(@"           ,[Note]");
        sb.AppendLine(@"           ,[FilePath]           ");
        sb.AppendLine(@"           ,[UpEmpNo])");
        sb.AppendLine(@"     VALUES");
        if (ftype != FileTypeEnum.備註)
        {
            sb.AppendLine(@"       ('" + typevalue.ToString() + "','" + recievecode + "','" + note + "','" + filepath + "','" + empno + "')");
        }
        else
        {
            sb.AppendLine(@"       ('" + typevalue.ToString() + "','" + recievecode + "','" + note + "',null,'" + empno + "')");
        }
        return sb.ToString();
    }
    private string SqlCmdInsertUploadDataRecordLog(FileTypeEnum ftype, string recievecode, DbActionEnum action, string empno)
    {
        int typevalue = (int)ftype;
        int actionvalue = (int)action;
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(@"INSERT INTO tblCourtRecordUpMainLog_0804");
        sb.AppendLine(@"           ([SystemType]");
        sb.AppendLine(@"           ,[RecieveCode]");
        sb.AppendLine(@"           ,[Action]");
        sb.AppendLine(@"           ,[UpEmpNo],[PreviousData])");
        sb.AppendLine(@"     VALUES");
        sb.AppendLine(@"       ('" + typevalue.ToString() + "','" + recievecode + "','" + actionvalue.ToString() + "','" + empno + "','Y')");
        return sb.ToString();
    }
    private string SqlCmdResetDataRecordLogState(DbActionEnum action, string empno)
    {
        int actionvalue = (int)action;
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(@"update tblCourtRecordUpMainLog_0804 ");
        sb.AppendLine(@"set PreviousData='N'");
        sb.AppendLine(@"where UpEmpNo='" + empno + "' and Action='" + actionvalue.ToString() + "'");
        return sb.ToString();
    }
    private string SqlCmdUpdateUploadTime(FileTypeEnum ftype, string recievecode, string note)
    {
        int typevalue = (int)ftype;
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(@"update tblCourtRecordUpMain_0804 ");
        sb.AppendLine(@"set RecordDate=getdate()");
        sb.AppendLine(@"where SystemType='" + typevalue.ToString() + "' and RecieveCode='" + recievecode + "' and Note='" + note + "'");
        return sb.ToString();
    }
    #endregion
    #region 分析上傳檔案取得文號
    public List<string> GetRecieveCode(FileUpload uploader, FileTypeEnum ftype)
    {
        List<string> result = new List<string>();
        if (uploader.HasFile == false)
        {
            return result;
        }
        else
        {
            switch (ftype)
            {
                case FileTypeEnum.F1094:
                    result.Add(uploader.FileName.Substring(0, 8));
                    break;
                case FileTypeEnum.P0610:
                    // return uploader.FileName;
                    result = GetP0610RecieveCode(uploader);
                    break;
                case FileTypeEnum.其他資料:
                    result.Add(uploader.FileName.Substring(0, 8));
                    break;
                case FileTypeEnum.函文:
                    result.Add(uploader.FileName.Substring(0, 8));
                    break;
                default:
                    break;

            }
            return result;
        }
    }
    public List<string> GetRecieveCode(string filefullname, FileTypeEnum ftype)
    {
        List<string> result = new List<string>();
        FileInfo fi = new FileInfo(filefullname);
        if (fi.Exists == false)
        {
            return result;
        }
        else
        {
            switch (ftype)
            {
                case FileTypeEnum.F1094:
                    result.Add(fi.Name.Substring(0, 8));
                    break;
                case FileTypeEnum.P0610:
                    result = GetP0610RecieveCode(filefullname);
                    break;
                case FileTypeEnum.其他資料:
                    result.Add(fi.Name.Substring(0, 8));
                    break;
                case FileTypeEnum.函文:
                    result.Add(fi.Name.Substring(0, 8));
                    break;
                default:
                    break;
            }
            return result;
        }
    }
    public List<string> GetP0610RecieveCode(FileUpload uploader)
    {

        List<string> result = new List<string>();
        if (uploader.HasFile == false)
        {
            return result;
        }
        StreamReader sr = new StreamReader(uploader.FileContent);
        bool isadd = true;
        while (sr.Peek() >= 0)
        {
            string temp = sr.ReadLine();
            if (temp.Length > 25)
            {
                isadd = true;
                foreach (string addeditem in result)
                {
                    if (string.Compare(temp.Substring(16, 8), addeditem) == 0)
                        isadd = false;
                }
                if (isadd == true)
                {
                    result.Add(temp.Substring(16, 8));
                }
            }
        }
        return result;
    }
    public List<string> GetP0610RecieveCode(string filefullname)
    {

        List<string> result = new List<string>();
        FileInfo fi = new FileInfo(filefullname);
        if (fi.Exists == false)
        {
            return result;
        }
        StreamReader sr = new StreamReader(filefullname);
        bool isadd = true;
        while (sr.Peek() >= 0)
        {
            string temp = sr.ReadLine();
            if (temp.Length > 25)
            {
                isadd = true;
                foreach (string addeditem in result)
                {
                    if (string.Compare(temp.Substring(16, 8), addeditem) == 0)
                        isadd = false;
                }
                if (isadd == true)
                {
                    result.Add(temp.Substring(16, 8));
                }
            }
        }
        return result;
    }
    #endregion
    #region 壓縮解壓縮檔案
    /// <summary>
    /// 遍歷某個目錄所有文件及子目錄下文件，并將文件名以字串方式拼接返回.
    /// </summary>
    /// <param name="dir">The dir.</param>
    /// <returns></returns>
    /// <summary>
    /// 遍歷某個目錄所有文件及子目錄下文件，并將文件名以字串方式拼接返回.
    /// </summary>
    /// <param name="dir">The dir.</param>
    /// <returns></returns>
    public static String GetAllFilesNameString(String dir)
    {
        String fileNameString = String.Empty;

        if (Directory.Exists(dir))
        {
            DirectoryInfo di = new DirectoryInfo(dir);
            foreach (FileInfo fi in di.GetFiles())
            {
                fileNameString += fi.FullName + "\t";
            }
            foreach (DirectoryInfo item in di.GetDirectories())
            {
                fileNameString += GetAllFilesNameString(item.FullName);
            }
        }

        return fileNameString;
    }

    #endregion
    #region 切割中文字串
    /// <summary>
    /// Splits the string.
    /// </summary>
    /// <param name="strData">The STR data.</param>
    /// <param name="Format">The format.</param>
    /// <returns></returns>
    public static List<string> SplitString(string strData, int[] Format)
    {
        string strResult = "";
        List<string> result = new List<string>();
        int IndexCount = 0;
        int intLoop;
        int intPos = 0;
        int intNext;
        byte[] byt = Encoding.Default.GetBytes(strData);
        try
        {
            for (intLoop = 0; intLoop <= byt.Length - 1; intLoop++)
            {
                if (byt[intLoop] >= 128)
                {
                    intNext = 2;
                }
                else
                {
                    intNext = 1;
                }
                strResult += Encoding.Default.GetString(byt, intLoop, intNext);
                if (intNext == 2)
                {
                    intLoop += 1;
                }
                intPos += intNext;
                if (intPos >= int.Parse(Format[IndexCount].ToString()))
                {
                    result.Add(strResult);
                    strResult = "";
                    intPos = 0;
                    IndexCount++;

                }
            }
            return result;
        }
        catch (IndexOutOfRangeException e)
        {
            //MessageBox.Show("格式錯誤請輸入正確格式!");
            return null;
        }
    }
    /// <summary>
    /// 取得從指定位置取長度的字串.
    /// </summary>
    /// <param name="strData">原始字串</param>
    /// <param name="From">開始位置(從0開始)</param>
    /// <param name="Length">長度</param>
    /// <returns></returns>
    public static string SubString(string strData, int From, int Length)
    {
        if (strData != string.Empty)
        {
            int ResultLength = Length;

            string PadBlank = "";
            byte[] byt = Encoding.Default.GetBytes(strData);
            int RestLength = byt.Length - ResultLength;
            if ((RestLength < 0))
            {
                return strData;
            }
            int[] Size;
            if (From != 0)
            {
                if (RestLength > 0)
                {
                    Size = new int[] { From, ResultLength, RestLength };
                }
                else
                {
                    Size = new int[] { From, ResultLength - From };
                }
            }
            else
            {
                if (RestLength > 0)
                {
                    Size = new int[] { ResultLength, RestLength };
                }
                else
                {
                    Size = new int[] { ResultLength };
                }
            }
            List<string> a = SplitString(strData, Size);
            if (From != 0)
            {
                return a[1].ToString();
            }

            else
            {
                return a[0].ToString();
            }
        }
        else
        {
            return string.Empty;
        }
    }
    #endregion
    #region 切割P0602物件
    public class P0602SplitItem
    {
        private int[] format = new int[] { 16, 8, 2, 80, 11, 13, 14, 8, 8, 8, 8, 8, 6, 6, 6, 6, 1 };
        private List<string> inputvalues;
        public P0602SplitItem(string text)
        {
            inputvalues = SplitString(text, format);
            //  NoneQueryResult();
        }
        private List<string> SplitFormatString(string text)
        {
            return SplitString(text, format);
        }
        public P0602SplitItem() { }
        public List<string> GetSplitValue()
        {
            return inputvalues;
        }
        public bool InsertToDB(string filename)
        {

            List<string> result = new List<string>();
            FileInfo fi = new FileInfo(filename);
            if (fi.Exists == false)
            {
                return false;
            }
            StreamReader sr = new StreamReader(filename, Encoding.Default);
            while (sr.Peek() >= 0)
            {
                string temp = sr.ReadLine();
                NoneQueryResult(SqlCmdInsertP0602Record(SplitFormatString(temp)));
            }
            return true;
        }
        public string GetInsertSql()
        {
            return SqlCmdInsertP0602Record(inputvalues);
        }

        //public string GetResultByCode(string sCode, string eCode)
        //{
        //    DataTable dtSource = GetQueryResult(SqlCmdGetP0602ByCode(sCode, eCode));
        //    if (dtSource == null || dtSource.Rows.Count == 0)
        //    {
        //        return SqlCmdGetP0602ByCode(sCode, eCode);
        //    }
        //    else
        //    {
        //        //StringBuilder sb = new StringBuilder();
        //        //sb.AppendLine("彰化銀行");
        //        //sb.AppendLine("[P0601]法院扣押案件查詢");
        //        return dtSource.Rows.Count.ToString();
        //    }
        //}

        private string SqlCmdInsertP0602Record(List<string> revalue)
        {
            string amount = revalue[5].Substring(0, revalue[5].Length - 2) + "." + revalue[5].Substring(revalue[5].Length - 2);
            string rate = revalue[6].Substring(0, revalue[6].Length - 8) + "." + revalue[5].Substring(revalue[6].Length - 8);
            //string logdate = revalue[8].Substring(0,4)+
            DateTime dtLogTime = new DateTime(int.Parse(revalue[8].Substring(0, 4)), int.Parse(revalue[8].Substring(4, 2)), int.Parse(revalue[8].Substring(6, 2)), int.Parse(revalue[9].Substring(2, 2))
                , int.Parse(revalue[9].Substring(4, 2)), int.Parse(revalue[9].Substring(6, 2)));
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(@"INSERT INTO [iom].[dbo].[tblCourtRecordP0602]");
            sb.AppendLine(@"           ([ACTNO]");
            sb.AppendLine(@"           ,[FILNO]");
            sb.AppendLine(@"           ,[CURCD]");
            sb.AppendLine(@"           ,[CNAME]");
            sb.AppendLine(@"           ,[UNINO]");
            sb.AppendLine(@"           ,[RGAMT]");
            sb.AppendLine(@"           ,[RRATE]");
            sb.AppendLine(@"           ,[ENDAY]");
            sb.AppendLine(@"           ,[RGDAY]");
            sb.AppendLine(@"           ,[RGTIME]");
            sb.AppendLine(@"           ,[CLSDAY]");
            sb.AppendLine(@"           ,[CLSTIME]");
            sb.AppendLine(@"           ,[EMPNOT]");
            sb.AppendLine(@"           ,[EMPNOS]");
            sb.AppendLine(@"           ,[CEMPNOT]");
            sb.AppendLine(@"           ,[CEMPNOS]");
            sb.AppendLine(@"           ,[CLSCD])");
            sb.AppendLine(@"     VALUES");
            sb.AppendLine(@"           ('" + revalue[0] + "'");
            sb.AppendLine(@"           ,'" + revalue[1] + "'");
            sb.AppendLine(@"           ,'" + revalue[2] + "'");
            sb.AppendLine(@"           ,'" + revalue[3] + "'");
            sb.AppendLine(@"           ,'" + revalue[4] + "'");
            sb.AppendLine(@"           ," + decimal.Parse(amount).ToString() + "");
            sb.AppendLine(@"           ," + decimal.Parse(rate).ToString() + "");
            sb.AppendLine(@"           ,'" + revalue[7] + "'");
            sb.AppendLine(@"           ,'" + revalue[8] + "'");
            sb.AppendLine(@"           ,'" + revalue[9] + "'");
            sb.AppendLine(@"           ,'" + revalue[10] + "'");
            sb.AppendLine(@"           ,'" + revalue[11] + "'");
            sb.AppendLine(@"           ,'" + revalue[12] + "'");
            sb.AppendLine(@"           ,'" + revalue[13] + "'");
            sb.AppendLine(@"           ,'" + revalue[14] + "'");
            sb.AppendLine(@"           ,'" + revalue[15] + "'");
            sb.AppendLine(@"           ,'" + revalue[16] + "')");
            return sb.ToString();
        }
        private string SqlCmdGetP0602ByDate(string sDate, string eDate)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(@"select * from dbo.tblCourtRecordP0602");
            sb.AppendLine(@"WHERE (CONVERT (varchar, RecordDate, 111) BETWEEN '" + sDate + "' AND '" + eDate + "')");
            sb.AppendLine(@"order by RecieveCode Desc");
            return sb.ToString();
        }
        private string SqlCmdGetP0602ByCode(string sCode, string eCode)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(@"select FILNO as 收文號碼 ,UNINO as 統一編號 , CurDesc as 幣別,");
            sb.AppendLine(@"substring(CNAME,2,80) as 戶名,RGAMT as 扣押金額,ENDAY as 應解繳日期,RGDAY as 受理日期 ,");
            sb.AppendLine(@"substring(RGTIME,3,2)+':'+substring(RGTIME,5,2)+':'+substring(RGTIME,3,2)  as 受理時間 ,");
            sb.AppendLine(@"case CLSCD when '0' then '未解除'");
            sb.AppendLine(@"when '1' then '已解除'");
            sb.AppendLine(@"when '2' then '已撤銷'");
            sb.AppendLine(@"end as 狀態,");
            sb.AppendLine(@"EMPNOT+'_'+EMPNOS as 登錄櫃員編號_登錄主管編號,");
            sb.AppendLine(@"CEMPNOT+'_'+CEMPNOS as 解除櫃員編號_解除主管編號");
            sb.AppendLine(@"");
            sb.AppendLine(@"");
            sb.AppendLine(@"from(");
            sb.AppendLine(@"select * from tblCourtRecordP0602 left outer join tblCourtRecordCurrency");
            sb.AppendLine(@"on tblCourtRecordP0602.CURCD = tblCourtRecordCurrency.CurCode) as c");
            sb.AppendLine(@"where FILNO between '" + sCode + "' and '" + eCode + "'");
            sb.AppendLine(@"order by FILNO Desc");

            return sb.ToString();
        }
    }


    #endregion
}