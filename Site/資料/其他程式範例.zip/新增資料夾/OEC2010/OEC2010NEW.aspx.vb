﻿Imports System.Data.SqlClient

Partial Class Program_OEC2010_OEC2010NEW
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not IsPostBack) Then
            '======================================================================================
            '前一頁傳來的值 IntraWeb\OACHB\Program\OAOvrd\OAOvrdList.asp
            Dim hDocNo As String = Request.Form("hDocNo")  '表單編號
            Dim hUsrId As String = Request.Form("hUsrId") '負責人ID

            'Response.Write("hDocNo:" & Request.Form("hDocNo") & "<br>")
            'Response.Write("hUsrId:" & Request.Form("hUsrId") & "<br>")
            '======================================================================================
            '取得表單資料
            lbl_DocNo.Text = hDocNo '表單號碼
            '登入人員
            lbl_Login.Text = hUsrId
            lbl_LoginName.Text = GetEmpID2Name(lbl_Login.Text)
            '從DB(tblLogDetail)取值
            GetDBLogDetail(lbl_DocNo.Text)
            '從DataInfo取值(資料內容)
            GetDataInfo(lbl_DocNo.Text)

        End If
    End Sub

    '決行
    Protected Sub BtnSign1OK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSign1OK.Click
        DS_tblLogDetail.UpdateParameters("Sign1").DefaultValue = lbl_Login.Text.Trim '登入人員ID
        DS_tblLogDetail.UpdateParameters("ACTION1").DefaultValue = "D"
        DS_tblLogDetail.UpdateParameters("SignDate1").DefaultValue = Now() ' 日期時間
        DS_tblLogDetail.UpdateParameters("DecManager").DefaultValue = lbl_Login.Text.Trim '登入人員ID
        DS_tblLogDetail.UpdateParameters("DecDate").DefaultValue = Now() '日期時間
        DS_tblLogDetail.UpdateParameters("FlowStatus").DefaultValue = "3" '流程狀態
        DS_tblLogDetail.UpdateParameters("SignComment1").DefaultValue = "" '批示
        DS_tblLogDetail.UpdateParameters("DocNo").DefaultValue = lbl_DocNo.Text.Trim '表單編號

        DS_tblLogDetail.Update()
        Response.Write("<script language=javascript>alert('決行成功!')</script>")
        Response.Write("<script language=javascript>window.location.href='/OACHB/Program/OAOvrd/OAOvrdQForm.asp?hOvrd=1'</script>")
    End Sub

    '退回
    Protected Sub BtnSign1Back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSign1Back.Click
        DS_tblLogDetail.UpdateParameters("Sign1").DefaultValue = lbl_Login.Text.Trim '登入人員ID
        DS_tblLogDetail.UpdateParameters("ACTION1").DefaultValue = "B"
        DS_tblLogDetail.UpdateParameters("SignDate1").DefaultValue = Now() ' 日期時間
        DS_tblLogDetail.UpdateParameters("DecManager").DefaultValue = "" ' 負責人ID
        DS_tblLogDetail.UpdateParameters("DecDate").DefaultValue = "" '日期時間
        DS_tblLogDetail.UpdateParameters("FlowStatus").DefaultValue = "0" '流程狀態        DS_tblLogDetail.UpdateParameters("DocNo").DefaultValue = lbl_DocNo.Text.Trim '表單編號

        DS_tblLogDetail.Update()
        Response.Write("<script language=javascript>alert('退回成功!')</script>")
        Response.Write("<script language=javascript>window.location.href='/OACHB/Program/OAOvrd/OAOvrdQForm.asp?hOvrd=1'</script>")
    End Sub

    '利用員編找名字
    Private Function GetEmpID2Name(ByVal gEmpId)
        'Response.Write("gEmpId:" & gEmpId & "<br>")
        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select NAME from chb_pub..EMPLOYEE where STAFF ='" & gEmpId & "'"
            ''Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function

    '利用分行代號找出分行名稱
    Private Function GetBrno2Name(ByVal gBrNo)
        Dim BrnoName As String = ""
        Using conn As New SqlConnection(DS_BRANCH.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select BRNAME from chb_pub..BRANCH where BRNO ='" & gBrNo & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                BrnoName = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using

        Return BrnoName
    End Function

    '從表單流程DB(tblLogDetail)取值
    Private Sub GetDBLogDetail(ByVal docno)
        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  FlowStatus,Ver,BrNo,EmpId,YYMM,RecordDate,Sign1,SignDate1,SignComment1 FROM tblLogDetail where DocNo = '" & docno & "' and DocType = 'EC'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read

                '表單狀態
                lbl_FlowStatus.Text = reader(0).ToString()
                DS_tblSysCode.SelectParameters("FlowStatus").DefaultValue = lbl_FlowStatus.Text
                ddl_FlowStatus.DataBind()
                '填報單位
                lbl_Brno.Text = reader(2).ToString()
                lbl_BrName.Text = GetBrno2Name(lbl_Brno.Text.Trim)
                '填報人員
                lbl_EmpId.Text = reader(3).ToString()
                lbl_EmpName.Text = GetEmpID2Name(lbl_EmpId.Text.Trim)
                '填報年月
                lbl_YYYMM.Text = reader(4).ToString()
                '填報日期
                lbl_RecordDate.Text = reader(5).ToString()
                'lbl_RecordDate.Text = format(reader(5), "yyyy/MM/dd HH:mm:ss")
                '核可負責人                lbl_Sign1.Text = reader(6).ToString()
                lbl_Sign1Name.Text = GetEmpID2Name(lbl_Sign1.Text.Trim)
                '簽核日
                lbl_SignDate1.Text = reader(7).ToString()

            End While
            reader.Close()
            cmd.Dispose()
        End Using
    End Sub

    '從DataInfo取值(資料內容)
    Private Sub GetDataInfo(ByVal docno)
        Using conn As New SqlConnection(DS_tblOverTrainingNew.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT OverM, OverT, Num FROM tblOverTrainingNew WHERE DOCNO = '" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read

                '當月份加班時數加總(分)
                lbl_OverM.Text = reader(0).ToString()
                '當月份自辦訓練時數加總(分)
                lbl_OverT.Text = reader(1).ToString()
                '當月份叫號機叫號數加總(分)
                lbl_Num.Text = reader(2).ToString()

            End While
            reader.Close()
            cmd.Dispose()
        End Using
    End Sub


End Class
