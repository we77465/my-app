﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="OEC2010NEW.aspx.vb" Inherits="Program_OEC2010_OEC2010NEW" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
    <style type="text/css">
    </style>
</head>
<body style="font-size: 10pt" bgcolor="White">
    <form id="form1" runat="server">
    <div>
        <table border="2" cellpadding="2" cellspacing="2" style="width: 800px">
            <tr>
                <td align="center" bgcolor="#FFFFCC" width = "150px" >
                    <asp:Label ID="Label10" runat="server" Font-Bold="True" Font-Size="Small" ForeColor="Black"
                        Text="OEC2010"></asp:Label></td>
                <td colspan="3">
                    <asp:Label ID="Label11" runat="server" Font-Bold="False" Font-Names="標楷體" Font-Size="Medium"
                        ForeColor="Red" Text="營業單位加班自辦訓練統計表-負責人核可" Width="343px" 
                        style="font-size: large; color: #000099"></asp:Label></td>
                <td bgcolor="#FFFFCC" width="88px" >
                    &nbsp;功 能：</td>
                <td align="center" colspan="3" >
                    <asp:Button ID="BtnSign1OK" runat="server" ForeColor="Red" Text="決 行" 
                        style="color: #000099; font-size: medium; font-weight: 700" />
                    &nbsp;
                    <asp:Button ID="BtnSign1Back" runat="server" ForeColor="Red" Text="退 回" 
                        style="color: #000099; font-size: medium; font-weight: 700" /></td>
            </tr>
            <tr>
                <td bgcolor="#FFFFCC">
                    &nbsp;表單號碼：</td>
                <td width="130px">
                    &nbsp;&nbsp;
                    <asp:Label ID="lbl_DocNo" runat="server" Font-Size="Medium" ForeColor="Black" Text="Label"></asp:Label>
                </td>
                <td bgcolor="#FFFFCC" style="color: #000000" width="88px">
                    &nbsp;填報年月：</td>
                <td width="130px" >
                    &nbsp;
                    <asp:Label ID="lbl_YYYMM" runat="server" Font-Size="Medium" Text="Label"></asp:Label>&nbsp;
                </td>
                <td bgcolor="#FFFFCC" width="88px" >
                    &nbsp;表單狀態：</td>
                <td align="center" >
                    <asp:Label ID="lbl_FlowStatus" runat="server" Font-Size="X-Small" Text="1"></asp:Label>
                    <asp:DropDownList ID="ddl_FlowStatus" runat="server" BackColor="#E0E0E0" DataSourceID="DS_tblSysCode"
                        DataTextField="TblDesc" DataValueField="TblId" Enabled="False">
                    </asp:DropDownList>&nbsp;</td>
            </tr>
            <tr>
                <td bgcolor="#FFFFCC" >
                    &nbsp;填報單位：</td>
                <td align="left" width="130px" >
                    &nbsp;
                    <asp:Label ID="lbl_Brno" runat="server" Font-Size="Medium" Text="Label"></asp:Label>&nbsp;
                    <asp:Label ID="lbl_BrName" runat="server" Font-Size="Medium" Text="Label"></asp:Label></td>
                <td bgcolor="#FFFFCC" width="88px">
                    &nbsp;填報人員：</td>
                <td width="130px" >
                    &nbsp;
                    <asp:Label ID="lbl_EmpId" runat="server" Font-Size="Medium" Text="Label"></asp:Label>&nbsp;
                    <asp:Label ID="lbl_EmpName" runat="server" Font-Size="Medium" Text="Label"></asp:Label></td>
                <td bgcolor="#FFFFCC" width="88px">
                    &nbsp;填報日期：</td>
                <td >
                    &nbsp;
                    <asp:Label ID="lbl_RecordDate" runat="server" Font-Size="Medium" Text="Label"></asp:Label>
                    &nbsp;&nbsp;</td>
            </tr>
            <tr> 
                <td bgcolor="#FFFFCC" >
                    &nbsp;登入人員：</td>
                <td width="130px" >
                    &nbsp;
                    <asp:Label ID="lbl_Login" runat="server" Font-Size="Medium" Text="Label"></asp:Label>&nbsp;
                    <asp:Label ID="lbl_LoginName" runat="server" Font-Size="Medium" Text="Label"></asp:Label></td>
                <td bgcolor="#FFFFCC" width="88px">
                    &nbsp;核可負責人：</td>
                <td width="130px" >
                    &nbsp;
                    <asp:Label ID="lbl_Sign1" runat="server" Font-Size="Medium" Text="Label"></asp:Label>&nbsp;
                    <asp:Label ID="lbl_Sign1Name" runat="server" Font-Size="Medium" Text="Label"></asp:Label></td>
                <td bgcolor="#FFFFCC" width="88px" >
                    &nbsp;核可時間：</td>
                <td >
                    &nbsp;
                    <asp:Label ID="lbl_SignDate1" runat="server" Font-Size="Medium" Text="Label"></asp:Label></td>
            </tr>
        </table>
    
    </div>
        <hr />
        <table border="2" cellpadding="5" cellspacing="2">
            <tr align="center">
                <td bgcolor="#FFFFCC">
                    當月份加班時數加總(分)</td>
                <td bgcolor="#FFFFCC">
                    當月份自辦訓練時數加總(分)</td>
                <td bgcolor="#FFFFCC">
                    當月份叫號機叫號數加總(分)</td>
            </tr>
            <tr align="center">
                <td>
                    <b>&nbsp;<asp:Label ID="lbl_OverM" runat="server" ForeColor="Black" Text="0" Font-Size="Medium"></asp:Label>
                    </b></td>
                <td>
                    <b>
                    <asp:Label ID="lbl_OverT" runat="server" ForeColor="Black" Text="0" Font-Size="Medium"></asp:Label>&nbsp;</b></td>
                <td>
                    <b>
                    <asp:Label ID="lbl_Num" runat="server" ForeColor="Black" Text="0" Font-Size="Medium"></asp:Label>
                    </b></td>
            </tr>
        </table><hr />
        <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblLogDetail WHERE (DocNo = @DocNo1) and (DocType = 'DR')"
            InsertCommand="INSERT INTO [tblLogDetail] ([DocType], [DocNo], [BrNo], [EmpId], [RecordDate], [DataFlag], [FormType], [YYMM], [Sign1], [Action1], [SignDate1], [SignComment1], [Sign2], [Action2], [SignDate2], [SignComment2], [DecManager], [DecDate], [FlowStatus], [Ver]) VALUES (@DocType, @DocNo, @BrNo, @EmpId, @RecordDate, @DataFlag, @FormType, @YYMM, @Sign1, @Action1, @SignDate1, @SignComment1, @Sign2, @Action2, @SignDate2, @SignComment2, @DecManager, @DecDate, @FlowStatus, @Ver)"
            SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
            UpdateCommand="UPDATE [tblLogDetail] SET [Sign1] = @Sign1, [Action1] = @Action1, [SignDate1] = @SignDate1, [SignComment1] = @SignComment1,  [DecManager] = @DecManager, [DecDate] = @DecDate, [FlowStatus] = @FlowStatus WHERE [DocNo] = @DocNo">
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <DeleteParameters>
                <asp:Parameter Name="DocNo1" />
            </DeleteParameters>
            <UpdateParameters>
                <asp:Parameter Name="Sign1" />
                <asp:Parameter Name="Action1" />
                <asp:Parameter Name="SignDate1" />
                <asp:Parameter Name="SignComment1" />
                <asp:Parameter Name="DecManager" />
                <asp:Parameter Name="DecDate" />
                <asp:Parameter Name="FlowStatus" />
                <asp:Parameter Name="DocNo" />
            </UpdateParameters>
            <InsertParameters>
                <asp:Parameter DefaultValue="" Name="DocType" Type="String" />
                <asp:Parameter DefaultValue="" Name="DocNo" Type="String" />
                <asp:Parameter Name="BrNo" Type="String" />
                <asp:Parameter Name="EmpId" Type="String" />
                <asp:Parameter DefaultValue="" Name="RecordDate" Type="DateTime" />
                <asp:Parameter DefaultValue="" Name="DataFlag" Type="String" />
                <asp:Parameter Name="FormType" Type="String" />
                <asp:Parameter Name="YYMM" Type="String" />
                <asp:Parameter Name="Sign1" Type="String" />
                <asp:Parameter Name="Action1" Type="String" />
                <asp:Parameter Name="SignDate1" Type="DateTime" />
                <asp:Parameter Name="SignComment1" Type="String" />
                <asp:Parameter Name="Sign2" Type="String" />
                <asp:Parameter Name="Action2" Type="String" />
                <asp:Parameter Name="SignDate2" Type="DateTime" />
                <asp:Parameter Name="SignComment2" Type="String" />
                <asp:Parameter Name="DecManager" Type="String" />
                <asp:Parameter Name="DecDate" Type="DateTime" />
                <asp:Parameter Name="FlowStatus" Type="String" />
                <asp:Parameter Name="Ver" Type="Int16" />
            </InsertParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblSysCode" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT     TblId, TblCd, TblDesc, TblSeq&#13;&#10;FROM         tblSysCode&#13;&#10;WHERE     (TblId = '11') AND (TblCd = @FlowStatus)">
            <SelectParameters>
                <asp:Parameter Name="FlowStatus" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblOverTrainingNew" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblOverTrainingNew WHERE DOCNO = @DOCNO" SelectCommand="SELECT [DOCNO], [BRNO], [OverM], [OverT], [Num] FROM [tblOverTrainingNew]&#13;&#10;WHERE DOCNO = @DocNo"
            UpdateCommand="UPDATE tblOverTrainingNew&#13;&#10;   SET BRNO = @BRNO&#13;&#10;      ,OverM = @OverM&#13;&#10;      ,OverT = @OverT&#13;&#10;      ,Num = @Num&#13;&#10; WHERE DOCNO = @DOCNO">
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <DeleteParameters>
                <asp:Parameter Name="DOCNO" />
            </DeleteParameters>
            <UpdateParameters>
                <asp:Parameter Name="BRNO" />
                <asp:Parameter Name="OverM" />
                <asp:Parameter Name="OverT" />
                <asp:Parameter Name="Num" />
                <asp:Parameter Name="DOCNO" />
            </UpdateParameters>
        </asp:SqlDataSource>
        <br />
        <asp:SqlDataSource ID="DS_EMPLOYEE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT STAFF, NAME FROM chb_pub.dbo.EMPLOYEE WHERE (STAFF = @gEmpId)">
            <SelectParameters>
                <asp:FormParameter FormField="gEmpId" Name="gEmpId" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_BRANCH" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT BRNO, BRNAME FROM chb_pub.dbo.BRANCH WHERE (BRNO = @gBrNo)">
            <SelectParameters>
                <asp:FormParameter FormField="gBrNo" Name="gBrNo" />
            </SelectParameters>
        </asp:SqlDataSource>
    </form>
</body>
</html>
