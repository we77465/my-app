﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="OEC3030.aspx.vb" Inherits="Program_OEC2010_OEC3030" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
    <style type="text/css">
        .style1
        {
            font-size: medium;
        }
        .style2
        {
            width: 195px;
        }
        .style3
        {
            height: 34px;
        }
        .style4
        {
            height: 36px;
        }
    </style>
</head>
<body style="font-size: 10pt" bgcolor="White">
    <form id="form1" runat="server">
    <div>
        <table border="2" cellpadding="2" cellspacing="2">
            <tr>
                <th align="center" bgcolor="White" colspan="2" class="style3">
                    <asp:Label ID="Label11" runat="server" Font-Bold="False" Font-Names="標楷體" Font-Size="Medium"
                        ForeColor="Red" Text="營業單位加班自辦訓練統計表-稽催表查詢" Width="346px" 
                        style="color: #000099; font-size: large; margin-bottom: 0px"></asp:Label>
                    &nbsp;&nbsp; &nbsp;
                </th>
            </tr>
            <tr >               
                <td bgcolor="#FFFFCC">
                    請輸入查詢年月：</td>
                <td align="center" class="style2">
                    <asp:DropDownList ID="ddl_YYY" runat="server" Height="20px" 
                        DataSourceID="sds_Year" DataTextField="YYY" DataValueField="YYY" Width="68px">
                    </asp:DropDownList>
                    年 &nbsp;<asp:DropDownList ID="ddl_MM" runat="server" Height="20px">
                        <asp:ListItem Enabled="False"></asp:ListItem>
                        <asp:ListItem>01</asp:ListItem>
                        <asp:ListItem>02</asp:ListItem>
                        <asp:ListItem>03</asp:ListItem>
                        <asp:ListItem>04</asp:ListItem>
                        <asp:ListItem>05</asp:ListItem>
                        <asp:ListItem>06</asp:ListItem>
                        <asp:ListItem>07</asp:ListItem>
                        <asp:ListItem>08</asp:ListItem>
                        <asp:ListItem>09</asp:ListItem>
                        <asp:ListItem>10</asp:ListItem>
                        <asp:ListItem>11</asp:ListItem>
                        <asp:ListItem>12</asp:ListItem>
                    </asp:DropDownList>月&nbsp;</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFCC" colspan="2" class="style4">
                    <asp:Button ID="Btn_Submit" runat="server" Text="送出查詢" Height="27px" />
                </td>
            </tr>
        </table>
    
    </div>
        <hr />
        <span class="style1">已填報：
        <asp:Label ID="lbl已填報" runat="server" Text="lbl已填報" ToolTip=" "></asp:Label>&nbsp;&nbsp;&nbsp; 
    未填報：<asp:Label ID="lbl未填報" runat="server" Text="lbl未填報"></asp:Label>
    </span><br />
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" BackColor="White"
            BorderColor="#CC9966" BorderStyle="None" BorderWidth="1px" CellPadding="4" DataKeyNames="BRNO"
            DataSourceID="SqlDataSource1">
            <RowStyle BackColor="White" ForeColor="#330099" />
            <Columns>
                <asp:BoundField DataField="BRNO" HeaderText="分行代號" ReadOnly="True" SortExpression="BRNO" />
                <asp:BoundField DataField="BRNAME" HeaderText="分行名稱" SortExpression="BRNAME" />
            </Columns>
            <FooterStyle BackColor="#FFFFCC" ForeColor="#330099" />
            <PagerStyle BackColor="#FFFFCC" ForeColor="#330099" HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="#FFCC66" Font-Bold="True" ForeColor="#663399" />
            <HeaderStyle BackColor="#990000" Font-Bold="True" ForeColor="#FFFFCC" />
        </asp:GridView>
        <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="select distinct BRNO,BRNO+' '+BRNAME as BRNAME
from [chb_pub].[dbo].[BRANCH]
where BRNO not in
(select BRNO from [chb_eform].[dbo].[tblOverTrainingNew] b
 inner join [chb_eform].[dbo].[tblLogDetail] c
 on b.[DOCNO]=c.[DocNo]
 where isnull(convert(int,c.FlowStatus),0)&gt;=3   --已決行不列
 and left(c.YYMM,3)=@YYY
 and right(c.YYMM,2)=@MM
)
and ([BRNAME] like '%分行%' or [BRNAME] like '%營業部%' )
and BRNO not in ('2120','2144','2151','2168','2175','2199','2026','2033') --OBU,海外分行不報

">
            <SelectParameters>
                <asp:ControlParameter ControlID="ddl_YYY" Name="YYY" 
                    PropertyName="SelectedValue" />
                <asp:ControlParameter ControlID="ddl_MM" Name="MM" 
                    PropertyName="SelectedValue" />
            </SelectParameters>
        </asp:SqlDataSource>
    <asp:SqlDataSource ID="sds_Year" runat="server" 
        ConnectionString="<%$ ConnectionStrings:chb_eform %>" SelectCommand="select distinct left(b.YYMM,3) as YYY from [tblOverTrainingNew] a
inner join [tblLogDetail] b
on a.[DOCNO]=b.[DocNo]
order by YYY desc"></asp:SqlDataSource>
    <asp:SqlDataSource ID="sds填報計數" runat="server" 
        ConnectionString="<%$ ConnectionStrings:chb_eform %>" SelectCommand="select *,全部-已填報 as 未填報
from (
select 
(select count(*) from [chb_pub].[dbo].[BRANCH]
  where ([BRNAME] like '%分行%' or [BRNAME] like '%營業部%')
  and BRNO not in ('2120','2144','2151','2168','2175','2199','2026','2033') --OBU,海外分行不報
 ) as 全部
,(select count(*) from [chb_eform].[dbo].[tblOverTrainingNew] a
  inner join [chb_eform].[dbo].[tblLogDetail] b
  on a.[DOCNO]=b.[DocNo]
 where left(YYMM,3)=@YYY and right(YYMM,2)=@MM
 and convert(int,FlowStatus)&gt;=3 and BrNo&lt;&gt;'0501' ) as 已填報
)x">
        <SelectParameters>
            <asp:ControlParameter ControlID="ddl_YYY" Name="YYY" 
                PropertyName="SelectedValue" />
            <asp:ControlParameter ControlID="ddl_MM" Name="MM" 
                PropertyName="SelectedValue" />
        </SelectParameters>
    </asp:SqlDataSource>
    </form>
</body>
</html>
