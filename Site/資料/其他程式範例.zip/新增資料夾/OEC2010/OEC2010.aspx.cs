﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.VisualBasic;
using System.IO;
using DataAccessLayer.DALC;

public partial class Program_OEC2010_OEC2010 : System.Web.UI.Page
{
    string strEmpId;
    string strBrNo;
    static string strSign1, strSignDate1, strFlowStatus;
    static string strDocNo, strHUsrId;
    static Int16 intOvrd;
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        Session.CodePage = 65001;
        Response.Charset = "UFT8";
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();

            Session.CodePage = 65001;
            Response.Charset = "UFT8";
            if (!IsPostBack)
            {
                string strSQL = "";
                intOvrd = System.Convert.ToInt16(Request.Form["hOvrd"]);
                strFlowStatus = Request.Form["hQFlowStatus"];
                strDocNo = Request.Form["hDocNo"];
                strHUsrId = Request.Form["hUsrId"];
                strSign1 = Request.Form["hUsrName"];
                strSignDate1 = DateTime.Now.ToString("yyyy/MM/dd");

                using (Bussiness buss = new Bussiness())
                {
                    ds = buss.select("SELECT a.NAME, b.BRNAME FROM  chb_pub..EMPLOYEE  AS a INNER JOIN " +
                        " chb_pub..BRANCH AS b ON a.BRNO = b.BRNO WHERE  (a.STAFF = '" + strHUsrId + "')", chb_eform.ConnectionString);
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtSign1.Text = ds.Tables[0].Rows[0]["NAME"].ToString();
                }

                string tSql = "SELECT t.*,e.NAME,b.BRNAME,e1.NAME as SignName1 " +
                   "FROM tblLogDetail t,chb_pub..EMPLOYEE e , chb_pub..BRANCH b ,chb_pub.dbo.EMPLOYEE e1 " +
                   "where t.EmpId = e.STAFF and t.EmpId *= e1.STAFF and t.BrNo=b.BRNO  and t.DocNo='" + strDocNo + "'";

                using (Bussiness buss = new Bussiness())
                {
                    ds = buss.select(tSql, chb_eform.ConnectionString);
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtSignDate1.Text = ds.Tables[0].Rows[0]["SignDate1"].ToString() == "" ? strSignDate1 : System.Convert.ToDateTime(ds.Tables[0].Rows[0]["SignDate1"]).ToString("yyyy/MM/dd");
                    txtSignComment1.Text = ds.Tables[0].Rows[0]["SignComment1"].ToString();
                    txtDocNo.Text = ds.Tables[0].Rows[0]["DocNo"].ToString();
                    txtVer.Text = "v " + ds.Tables[0].Rows[0]["Ver"].ToString() + ".0";
                    txtBrName.Text = ds.Tables[0].Rows[0]["BrName"].ToString();
                    txtName1.Text = ds.Tables[0].Rows[0]["Name"].ToString();
                    txtYYMM.Text = ds.Tables[0].Rows[0]["YYMM"].ToString();
                    txtRecordDate.Text = ds.Tables[0].Rows[0]["RecordDate"].ToString() == "" ? "" : System.Convert.ToDateTime(ds.Tables[0].Rows[0]["RecordDate"]).ToString("yyyy/MM/dd");
                    strBrNo = ds.Tables[0].Rows[0]["BrNo"].ToString();
                    strFlowStatus = ds.Tables[0].Rows[0]["FlowStatus"].ToString();
                    strEmpId = ds.Tables[0].Rows[0]["EmpId"].ToString();
                }
                if (strFlowStatus == "1" && intOvrd == 1)
                {
                    BtnOk.Visible = BtnBack.Visible = BtnClear.Visible = true;
                }

                //using (Bussiness buss = new Bussiness())
                //{
                //    strSQL = "select b.FlowStatus,b.RecordDate,b.SignDate1,b.DecDate,a.* from tblOverTraining" +
                //        " as a left join tblLogDetail as b on a.DOCNO=b.DocNo" +
                //        " where a.BRNO='" + strBrNo.ToString() + "' and a.DOCNO='" + strDocNo + "' ";
                //    ds = buss.select(strSQL, chb_eform.ConnectionString);
                //}
                if (ds.Tables[0].Rows.Count > 0)
                {
                    chb_eform.SelectParameters["DOCNO"].DefaultValue = strDocNo.ToString();
                    //GridView1.DataSource = ds;
                    GridView1.DataBind();
                }
            }
        }
    }
    protected void BtnOk_Click(object sender, EventArgs e)
    {
        chb_eform.UpdateParameters[0].DefaultValue = strHUsrId;
        chb_eform.UpdateParameters[1].DefaultValue = "D";
        chb_eform.UpdateParameters[2].DefaultValue = DateTime.Now.ToShortDateString();
        chb_eform.UpdateParameters[3].DefaultValue = strHUsrId;
        chb_eform.UpdateParameters[4].DefaultValue = DateTime.Now.ToShortDateString();
        chb_eform.UpdateParameters[5].DefaultValue = "3";
        chb_eform.UpdateParameters[6].DefaultValue = txtSignComment1.Text.ToString();
        chb_eform.UpdateParameters[7].DefaultValue = strDocNo;
        chb_eform.Update();
        Response.Redirect("/OACHB/Program/OAOvrd/OAOvrdQForm.asp?hOvrd=1");
    }
    protected void BtnBack_Click(object sender, EventArgs e)
    {
        chb_eform.UpdateParameters[0].DefaultValue = strHUsrId;
        chb_eform.UpdateParameters[1].DefaultValue = "B";
        chb_eform.UpdateParameters[2].DefaultValue = DateTime.Now.ToShortDateString();
        chb_eform.UpdateParameters[3].DefaultValue = "";
        chb_eform.UpdateParameters[4].DefaultValue = "";
        chb_eform.UpdateParameters[5].DefaultValue = "0";
        chb_eform.UpdateParameters[6].DefaultValue = txtSignComment1.Text.ToString();
        chb_eform.UpdateParameters[7].DefaultValue = strDocNo;
        chb_eform.Update();

        Response.Redirect("/OACHB/Program/OAOvrd/OAOvrdQForm.asp?hOvrd=1");
    }
    protected void BtnClear_Click(object sender, EventArgs e)
    {
        txtSignComment1.Text = "";
    }
}
