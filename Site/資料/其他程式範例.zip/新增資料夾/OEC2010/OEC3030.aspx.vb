﻿

Partial Class Program_OEC2010_OEC3030
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then ddl_MM.SelectedValue = DateAdd(DateInterval.Month, -1, Now()).ToString("MM")
        填報計數()


    End Sub

    Protected Sub Btn_Submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Submit.Click

        SqlDataSource1.SelectParameters("YYY").DefaultValue = ddl_YYY.SelectedValue
        SqlDataSource1.SelectParameters("MM").DefaultValue = ddl_MM.SelectedValue
        SqlDataSource1.Select(New DataSourceSelectArguments)
        GridView1.DataBind()
        填報計數()

    End Sub

    Sub 填報計數()
        Try

            lbl已填報.Text = "0"
            lbl未填報.Text = "0"
            Me.GridView1.Visible = False

            If ddl_YYY.SelectedIndex > -1 Then
                Dim dv As Data.DataView = sds填報計數.Select(DataSourceSelectArguments.Empty)
                If dv IsNot Nothing AndAlso dv.Count > 0 Then
                    lbl已填報.Text = dv(0)("已填報").ToString
                    lbl未填報.Text = dv(0)("未填報").ToString
                End If

                Me.GridView1.Visible = True

            End If

        Catch ex As Exception
        End Try
    End Sub


  
End Class
