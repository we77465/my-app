﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODK3010.aspx.vb" Inherits="Program_ODK3010_ODK3010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
    
    <script language="JavaScript" type="text/javascript" src="ODK3010.js"></script>
    <script language="JavaScript" type="text/javascript" src="..\Common\js\Numeric.js"></script>
    
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <table border="2" cellpadding="2" cellspacing="2" style="width: 700px">
            <tr>
                <td style="width: 78px; height: 30px">
                    <asp:Label ID="Label5" runat="server" Font-Size="Small" ForeColor="Red" Text="ODK3010"></asp:Label></td>
                <td style="font-size: 12pt; width: 180px; color: #000000; height: 30px">
                    <asp:Label ID="Label4" runat="server" Font-Size="Small" ForeColor="Red" Text="彰化銀行各營業單位銷售額申報明細表" Width="222px"></asp:Label></td>
                <td style="width: 70px; color: #000000; height: 30px">
                    功能：</td>
                <td colspan="3" style="width: 380px; height: 30px">
                    <asp:Button ID="Btn_OK" runat="server" Text="確 認" ValidationGroup="1" />&nbsp;
                    <asp:Button ID="Btn_Back" runat="server" Text="退 回" ValidationGroup="1" />&nbsp;</td>
            </tr>
            <tr>
                <td style="width: 78px; height: 15px">
                    表單號碼：</td>
                <td style="width: 180px; height: 15px">
                    <asp:Label ID="lblDOCNO" runat="server" Font-Size="Medium" ForeColor="Red" Text="Label"></asp:Label></td>
                <td style="width: 70px; color: #000000; height: 15px">
                    &nbsp;</td>
                <td align="center" style="width: 218px; height: 15px">
                    &nbsp;&nbsp;</td>
                <td style="width: 50px; height: 15px">
                    &nbsp;<span id="Label11" class="TBLHR" style="font-size: 9pt"></span></td>
                <td align="center" colspan="2" style="width: 102px; height: 15px">
                    &nbsp;&nbsp;</td>
            </tr>
            <tr>
                <td style="width: 78px; height: 39px">
                    分 行：</td>
                <td align="center" style="width: 180px; height: 39px">
                    &nbsp;<asp:TextBox ID="TXT_BRNO" runat="server" BackColor="White" ReadOnly="True" Width="62px"></asp:TextBox>
                    &nbsp;
                    <asp:TextBox ID="TXT_BRNO_NAME" runat="server" BackColor="White" ReadOnly="True"
                        Width="74px"></asp:TextBox></td>
                <td style="width: 70px; height: 39px">
                    經 辦：</td>
                <td align="center" style="width: 218px; height: 39px">
                    &nbsp;<asp:TextBox ID="TXT_EMPID" runat="server" BackColor="White" BorderColor="White"
                        ReadOnly="True" Width="66px"></asp:TextBox>&nbsp; <asp:TextBox ID="TXT_EMPNAME"
                            runat="server" BackColor="White" ReadOnly="True" Width="73px"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 50px; height: 39px">
                    分機：</td>
                <td colspan="2" style="width: 102px; height: 39px">
                    &nbsp;<asp:TextBox ID="TXT_EXT" runat="server" MaxLength="4" ValidationGroup="1"
                        Width="50px" ReadOnly="True"></asp:TextBox>&nbsp;</td>
            </tr>
            <tr>
                <td style="width: 78px; height: 15px">
                    年度：</td>
                <td style="width: 180px; height: 15px">
                    &nbsp;&nbsp;
                    <asp:TextBox ID="TXT_YEARLY" runat="server" BackColor="White" MaxLength="5" ReadOnly="True"
                        Width="50px"></asp:TextBox>年度</td>
                <td style="width: 70px; height: 15px">
                    承辦人：</td>
                <td align="center" style="width: 218px; height: 15px">
                    劉炳宏</td>
                <td style="width: 50px; height: 15px">
                    分機：</td>
                <td align="center" style="width: 110px; height: 14px">
                    2337</td>
            </tr>
        </table>
        <hr />
        <asp:Label ID="Label1" runat="server" ForeColor="Red" Text="負責人決行" Width="85px"></asp:Label><br />
        <table border="2" cellpadding="2" cellspacing="2" style="width: 698px">
            <tr>
                <td style="height: 25px; width: 56px;">
                    負責人:</td>
                <td colspan="2" style="height: 25px; ">
                    &nbsp;<asp:TextBox ID="txtSign1" runat="server" Width="60px" ReadOnly="True"></asp:TextBox>&nbsp;
                    <asp:TextBox ID="txtSign1Name" runat="server" Width="80px" ReadOnly="True"></asp:TextBox></td>
                         <td style="height: 25px;">
                             簽核日:</td>
                 <td style="height: 25px">
                     &nbsp;<asp:TextBox ID="txtSignDate1" runat="server" Width="90px" ReadOnly="True"></asp:TextBox></td>
               
            </tr>
            <tr>
                <td style="height: 25px; width: 56px;">
                    批 示:</td>
                <td colspan="4" style="height: 25px">
                    &nbsp;<asp:TextBox ID="txtSignComment1" runat="server" Height="50px" Width="612px" ReadOnly="True"></asp:TextBox></td>
               
            </tr>
          
        </table>
        <hr />
        <asp:Label ID="Label3" runat="server" ForeColor="Red" Text="單位: 新台幣元"></asp:Label><br />
        <table border="2" cellpadding="2" cellspacing="2" style="width: 700px">
            <tr>
                <td align="center" style="width: 295px; height: 20px">
                    月份</td>
                <td align="center" style="width: 130px; height: 20px">
                    專屬本業收入</td>
                <td align="center" style="width: 130px; height: 20px">
                    非專屬本業收入</td>
                <td align="center" style="width: 130px; height: 20px">
                    免稅收入</td>
                <td align="center" colspan="1" style="width: 130px; height: 20px">
                    合計</td>
            </tr>
            <tr>
                <td style="width: 295px; height: 25px">
                    &nbsp;1~2</td>
                <td style="width: 130px; height: 25px">
                    <asp:TextBox ID="TXT_SF1" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px; color: #000000; height: 25px">
                    <asp:TextBox ID="TXT_NOSF1" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px; color: #000000; height: 25px">
                    <asp:TextBox ID="TXT_NOTX1" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px; color: #000000; height: 25px">
                    <asp:TextBox ID="TXT_D1" runat="server" BackColor="White" ReadOnly="True" Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;</td>
            </tr>
            <tr>
                <td style="width: 295px">
                    &nbsp;3~4</td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_SF3" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px; color: #000000">
                    <asp:TextBox ID="TXT_NOSF3" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px; color: #000000">
                    <asp:TextBox ID="TXT_NOTX3" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px; color: #000000">
                    <asp:TextBox ID="TXT_D3" runat="server" BackColor="White" ReadOnly="True" Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;</td>
            </tr>
            <tr>
                <td style="width: 295px">
                    &nbsp;5~6</td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_SF5" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px; color: #000000">
                    <asp:TextBox ID="TXT_NOSF5" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_NOTX5" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_D5" runat="server" BackColor="White" ReadOnly="True" Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;</td>
            </tr>
            <tr>
                <td style="width: 295px">
                    &nbsp;7~8</td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_SF7" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_NOSF7" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_NOTX7" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_D7" runat="server" BackColor="White" ReadOnly="True" Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
            </tr>
            <tr>
                <td style="width: 295px">
                    &nbsp;9~10</td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_SF9" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_NOSF9" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_NOTX9" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_D9" runat="server" BackColor="White" ReadOnly="True" Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
            </tr>
            <tr>
                <td style="width: 295px">
                    11~12</td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_SF11" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_NOSF11" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_NOTX11" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px">
                    <asp:TextBox ID="TXT_D11" runat="server" BackColor="White" ReadOnly="True" Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
            </tr>
            <tr>
                <td style="width: 295px; height: 30px">
                    合計</td>
                <td style="width: 130px; height: 30px">
                    <asp:TextBox ID="TXT_SF_TOL" runat="server" BackColor="White" ReadOnly="True" Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px; height: 30px">
                    <asp:TextBox ID="TXT_NOSF_TOL" runat="server" BackColor="White" ReadOnly="True"
                        Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px; height: 30px">
                    <asp:TextBox ID="TXT_NOTX_TOL" runat="server" BackColor="White" ReadOnly="True"
                        Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
                <td style="width: 130px; height: 30px">
                    <asp:TextBox ID="TXT_D_TOL" runat="server" BackColor="White" ReadOnly="True" Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
            </tr>
            <tr>
                <td style="width: 295px; height: 25px">
                    應稅收入合計</td>
                <td align="center" colspan="2" style="width: 130px; height: 25px">
                    <asp:TextBox ID="TXT_TAX_TOL" runat="server" BackColor="White" ReadOnly="True"
                        Width="120px" Style="text-align:right"></asp:TextBox></td>
                <td colspan="2" style="width: 130px; height: 25px">
                </td>
            </tr>
            <tr>
                <td style="width: 295px">
                    應稅收入帳列數</td>
                <td colspan="4" style="width: 130px">
                    <asp:TextBox ID="TXT_TAXLST" runat="server" ValidationGroup="1" Width="120px" ReadOnly="True" Style="text-align:right"></asp:TextBox>&nbsp;&nbsp;
                </td>
            </tr>
            <tr>
                <td style="width: 295px">
                    差異數</td>
                <td colspan="4" style="width: 130px; height: 25px">
                    &nbsp;<asp:TextBox ID="TXT_DIFF" runat="server" BackColor="White" ReadOnly="True"
                        Width="120px" Style="text-align:right"></asp:TextBox>&nbsp;
                </td>
            </tr>
            <tr>
                <td style="width: 295px">
                    差異說明 (註2)</td>
                <td colspan="4" style="width: 130px">
                    <asp:TextBox ID="TXT_DIFMEMO" runat="server" Height="90px" MaxLength="1000" ValidationGroup="1"
                        Width="670px" ReadOnly="True"></asp:TextBox>
                </td>
            </tr>
        </table>
        <br />
        &nbsp;<br />
        <asp:SqlDataSource ID="DS_EMPLOYEE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT STAFF, NAME FROM chb_pub.dbo.EMPLOYEE WHERE (STAFF = @gEmpId)">
            <SelectParameters>
                <asp:Parameter Name="gEmpId" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblSell_Report" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT  SR_DOCNO,SR_BRNO, SR_BRNAME, SR_EMPID, SR_EMPNAME, SR_EXT, &#9;SR_YEARLY, SF1, SF3, SF5, SF7, SF9, SF11, SF_TOL, NOSF1, NOSF3, NOSF5, NOSF7, NOSF9, &#9;NOSF11, &#9;NOSF_TOL, NOTX1, NOTX3, NOTX5, &#9;NOTX7, &#9;NOTX9, &#9;NOTX11, NOTX_TOL, &#9;D_TOL, TAX_TOL, TAXLST, DIFF, DIFMEMO FROM [tblSell_Report] where SR_DOCNO = @hDocNo">
            <SelectParameters>
                <asp:Parameter Name="hDocNo" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
            UpdateCommand="Update tblLogDetail Set FlowStatus=4 where DocNo= @DocNo">
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <UpdateParameters>
                <asp:Parameter Name="DocNo" />
            </UpdateParameters>
        </asp:SqlDataSource>
        <br />
        <asp:HiddenField ID="hidn_hDocNo" runat="server" />
        <br />
        <br />
        <br />
        ODK3010.aspx<br />
    </div>
    </form>
</body>
</html>
