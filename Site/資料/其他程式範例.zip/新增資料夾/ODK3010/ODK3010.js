﻿// JScript 檔



    


 //金額格式轉換(value =數字,fixed = 小數點位數,currency = 貨幣代號NT)
       function money_format(value,fixed,currency)
        {
	        var fixed = fixed || 0;
	        var currency = currency || '';
	        isNaN(parseFloat(value))? value=0 : value=parseFloat(value);
	        v = value.toFixed(fixed).toString();
	        var ps = v.split('.');
	        var whole = ps[0];
	        var sub = ps[1] ? '.' + ps[1] : '';
	        var r = /(\d+)(\d{3})/;
	        while (r.test(whole)) 
	        {
		        whole = whole.replace(r, '$1' + ',' + '$2');
	        }
	        v = whole + sub;
	        if (v.charAt(0) == '-') 
	        {
		        return currency + '-' + '$' + v.substr(1);
	        }
	        return currency + '$' +v;
        }