﻿Imports System.Data.SqlClient
Partial Class Program_ODK3010_ODK3010
    Inherits System.Web.UI.Page
   
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not IsPostBack) Then
            '==============================================================================================
            '前一頁傳來的值  \IntraWeb\OACHB\Program\ODK3010\ODK3010List.asp
            Dim hDocNo As String = Request.Form("hDocNo")
            hidn_hDocNo.Value = hDocNo
            'Response.Write("hDocNo:" & Request.Form("hDocNo") & "<br>")
            '==============================================================================================
            '表單表頭區塊
            GetDBSellReport(hDocNo)   '從DS_tblSell_Report(DB)取值(資料內容)

            '==============================================================================================
            '負責人決行區塊
            GetDBLogDetail(hDocNo) '從DB(tblLogDetail)取值(負責人ID,簽核日,批示)

            Dim EmpId As Integer = Integer.Parse(txtSign1.Text.Trim()) '負責人ID
            'Response.Write("EmpId:" & EmpId & "<br>")
            txtSign1Name.Text = GetEmpID2Name(EmpId)  '利用員編找名字(負責人姓名)

            '==============================================================================================
            '資料區塊
            '從DS_tblSell_Report(DB)取值(資料內容)



        End If
    End Sub

    '利用員編找名字
    Private Function GetEmpID2Name(ByVal EmpId)

        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select NAME from chb_pub..EMPLOYEE where STAFF ='" & EmpId & "'"
            'Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function

    '從DB(tblLogDetail)取值(負責人ID,簽核日,批示)
    Private Sub GetDBLogDetail(ByVal docno)
        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  Sign1,SignDate1,SignComment1 FROM tblLogDetail where DocNo = '" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read
                txtSign1.Text = reader(0).ToString() '負責人ID
                txtSignDate1.Text = Format(DateValue(reader(1).ToString()), "yyyy/MM/dd") '簽核日
                txtSignComment1.Text = reader(2).ToString() '批示
            End While
            reader.Close()
            cmd.Dispose()
        End Using
    End Sub

    '從DS_tblSell_Report(DB)取值(資料內容)
    Private Sub GetDBSellReport(ByVal docno)

        '=================變 數 宣 告==================
        Dim DOCNO1, BRNO, BRNO_NAME, EMP_ID, EMPNAME, EXT, YEARLY, D_TOL, TAX_TOL, TAXLST, DIFF, DIFMEMO As String
        '專屬本業收入
        Dim SF1, SF3, SF5, SF7, SF9, SF11, SF_TOL As Decimal
        '非專屬本業收入
        Dim NOSF1, NOSF3, NOSF5, NOSF7, NOSF9, NOSF11, NOSF_TOL As Decimal
        '免稅收入
        Dim NOTX1, NOTX3, NOTX5, NOTX7, NOTX9, NOTX11, NOTX_TOL As Decimal

        '=================資 料 庫 撈 資 料==================
        Using conn As New SqlConnection(DS_tblSell_Report.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  SR_DOCNO,SR_BRNO,SR_BRNAME,SR_EMPID,SR_EMPNAME,SR_EXT,SR_YEARLY,SF1,SF3,SF5,SF7,SF9,SF11,SF_TOL,NOSF1,NOSF3,NOSF5,NOSF7,NOSF9,NOSF11,NOSF_TOL,NOTX1,NOTX3,NOTX5,NOTX7,NOTX9,NOTX11,NOTX_TOL,D_TOL,TAX_TOL,TAXLST,DIFF,DIFMEMO FROM tblSell_Report where SR_DOCNO = '" & docno & "'"
            'Response.Write(tmpsql)
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read

                DOCNO1 = reader(0).ToString() '表單編號
                BRNO = reader(1).ToString() '分行代號
                BRNO_NAME = reader(2).ToString() '分行名稱
                EMP_ID = reader(3).ToString() '員編
                EMPNAME = reader(4).ToString() '員工名稱
                EXT = reader(5).ToString() '分機號碼
                YEARLY = reader(6).ToString() '年度
                '專屬本業收入()
                SF1 = reader(7).ToString()
                SF3 = reader(8).ToString()
                SF5 = reader(9).ToString()
                SF7 = reader(10).ToString()
                SF9 = reader(11).ToString()
                SF11 = reader(12).ToString()
                SF_TOL = reader(13).ToString()
                '非專屬本業收入
                NOSF1 = reader(14).ToString()
                NOSF3 = reader(15).ToString()
                NOSF5 = reader(16).ToString()
                NOSF7 = reader(17).ToString()
                NOSF9 = reader(18).ToString()
                NOSF11 = reader(19).ToString()
                NOSF_TOL = reader(20).ToString()
                '免稅收入      
                NOTX1 = reader(21).ToString()
                NOTX3 = reader(22).ToString()
                NOTX5 = reader(23).ToString()
                NOTX7 = reader(24).ToString()
                NOTX9 = reader(25).ToString()
                NOTX11 = reader(26).ToString()
                NOTX_TOL = reader(27).ToString()
                '合計部分
                D_TOL = reader(28).ToString() '總合計
                TAX_TOL = reader(29).ToString() '應稅收入合計
                TAXLST = reader(30).ToString() '應稅收入帳列數
                DIFF = reader(31).ToString() '差異數
                DIFMEMO = reader(32).ToString() '差異說明

            End While
            reader.Close()
            cmd.Dispose()
        End Using

        '=================給 值==================
        lblDOCNO.Text = DOCNO1 '表單編號
        TXT_BRNO.Text = BRNO '分行代號
        TXT_BRNO_NAME.Text = BRNO_NAME '分行名稱
        TXT_EMPID.Text = EMP_ID '員編
        TXT_EMPNAME.Text = EMPNAME '員工名稱
        TXT_EXT.Text = EXT '分機號碼
        TXT_YEARLY.Text = YEARLY '年度
        '專屬本業收入()
        TXT_SF1.Text = FormatCurrency(SF1, 1)
        TXT_SF3.Text = FormatCurrency(SF3, 1)
        TXT_SF5.Text = FormatCurrency(SF5, 1)
        TXT_SF7.Text = FormatCurrency(SF7, 1)
        TXT_SF9.Text = FormatCurrency(SF9, 1)
        TXT_SF11.Text = FormatCurrency(SF11, 1)
        TXT_SF_TOL.Text = FormatCurrency(SF_TOL, 1)
        '非專屬本業收入
        TXT_NOSF1.Text = FormatCurrency(NOSF1, 1)
        TXT_NOSF3.Text = FormatCurrency(NOSF3, 1)
        TXT_NOSF5.Text = FormatCurrency(NOSF5, 1)
        TXT_NOSF7.Text = FormatCurrency(NOSF7, 1)
        TXT_NOSF9.Text = FormatCurrency(NOSF9, 1)
        TXT_NOSF11.Text = FormatCurrency(NOSF11, 1)
        TXT_NOSF_TOL.Text = FormatCurrency(NOSF_TOL, 1)
        '免稅收入  
        TXT_NOTX1.Text = FormatCurrency(NOTX1, 1)
        TXT_NOTX3.Text = FormatCurrency(NOTX3, 1)
        TXT_NOTX5.Text = FormatCurrency(NOTX5, 1)
        TXT_NOTX7.Text = FormatCurrency(NOTX7, 1)
        TXT_NOTX9.Text = FormatCurrency(NOTX9, 1)
        TXT_NOTX11.Text = FormatCurrency(NOTX11, 1)
        TXT_NOTX_TOL.Text = FormatCurrency(NOTX_TOL, 1)
        '合計部分
        TXT_D_TOL.Text = FormatCurrency(D_TOL, 1) '總合計
        TXT_TAX_TOL.Text = FormatCurrency(TAX_TOL, 1) '應稅收入合計
        TXT_TAXLST.Text = FormatCurrency(TAXLST, 1) '應稅收入帳列數
        TXT_DIFF.Text = FormatCurrency(DIFF, 1) '差異數
        TXT_DIFMEMO.Text = DIFMEMO '差異說明

        TXT_D1.Text = FormatCurrency((Decimal.Parse(SF1) + Decimal.Parse(NOSF1) + Decimal.Parse(NOTX1)), 1) '1~2月合計
        TXT_D3.Text = FormatCurrency((Decimal.Parse(SF3) + Decimal.Parse(NOSF3) + Decimal.Parse(NOTX3)), 1) '3~4月合計
        TXT_D5.Text = FormatCurrency((Decimal.Parse(SF5) + Decimal.Parse(NOSF5) + Decimal.Parse(NOTX5)), 1) '5~6月合計
        TXT_D7.Text = FormatCurrency((Decimal.Parse(SF7) + Decimal.Parse(NOSF7) + Decimal.Parse(NOTX7)), 1) '7~8月合計
        TXT_D9.Text = FormatCurrency((Decimal.Parse(SF9) + Decimal.Parse(NOSF9) + Decimal.Parse(NOTX9)), 1) '9~10月合計
        TXT_D11.Text = FormatCurrency((Decimal.Parse(SF11) + Decimal.Parse(NOSF11) + Decimal.Parse(NOTX11)), 1) '11~12月合計

    End Sub

    '確定 ,UPDATE 表單流程DB(tblLogDetail) 資料
    Protected Sub Btn_OK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_OK.Click

        Dim hDocNo As String = hidn_hDocNo.Value '表單編號
        DS_tblLogDetail.UpdateCommand = "Update tblLogDetail Set FlowStatus=4 where DocNo='" + hDocNo + "'"
        DS_tblLogDetail.Update()
        Response.Write("<script>alert('確認成功') ;</script>")
        Response.Redirect("/oachb/program/ODK3010/ODK3010QForm.asp")

    End Sub

    '退回 ,UPDATE 表單流程DB(tblLogDetail) 資料 
    Protected Sub Btn_Back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Back.Click
        Dim hDocNo As String = hidn_hDocNo.Value '表單編號
        DS_tblLogDetail.UpdateCommand = "Update tblLogDetail set FlowStatus='-1' where DocNo='" + hDocNo + "'"
        DS_tblLogDetail.Update()
        Response.Write("<script>alert('退回成功') ;</script>")
        Response.Redirect("/oachb/program/ODK3010/ODK3010QForm.asp")
    End Sub
End Class
