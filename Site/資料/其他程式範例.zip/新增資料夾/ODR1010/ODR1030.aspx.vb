﻿
Partial Class DotNet_Program_ODR1010_ODR1030
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim strLine(1) As String
            Dim TmpEmpId As String = Request.Cookies("CHB_IW_")("User_ID").ToString
            Dim drString As String = UserInfo.getUserInfo(TmpEmpId)
            strLine = drString.Split(Char.Parse(","))
            Me.hfBrNo.Value = strLine(0).ToString.Trim

            '篩選年範圍為現在日期往前推3年
            Dim s年 As Integer = Now.Year - 1911
            For i As Integer = 2 To 0 Step -1
                Me.ddl年.Items.Add(s年 - i)
            Next

            Me.ddl年.SelectedValue = Now.AddMonths(-1).Year - 1911
            Me.ddl月.SelectedValue = Now.AddMonths(-1).Month.ToString("0#")

            Me.btn_prt.Attributes.Add("onclick", "return PrintScreen()")
        End If
    End Sub
End Class
