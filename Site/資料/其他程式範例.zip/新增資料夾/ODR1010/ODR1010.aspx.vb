﻿Imports System.Data.SqlClient

Partial Class Program_ODR1010_ODR1010
    Inherits System.Web.UI.Page
    Const 格式轉換日 As String = "2012/1/31"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not IsPostBack) Then
            '===========================================================================================
            '0. 前一個網頁(ODR1010QForm.asp)得到的值
            Dim docno As String = ""
            Dim hDocNo As String = Request.Form("hDocNo").Replace(",", "") '表單編號
            Dim hYear As String = Request.Form("hYear").Replace(",", "") '年度
            Dim hMonth As String = ""
            hMonth = Request.Form("hMonth").Replace(",", "") '月
            Dim gBrNo As String = Request.Form("gBrNo") '分行代號
            Dim gEmpId As String = Request.Form("gEmpId") '員編

            hidn_EMPID.Value = gEmpId

            '組表單編號,如果表單不存在,則新增            If (hDocNo <> "") Then
                docno = hDocNo
            Else
                docno = "DR" & hYear & hMonth & gBrNo & "0"
            End If

            '組上半部欄位
            lblDOCNO.Text = docno '表單編號
            txt_Brno.Text = gBrNo '分行代號
            txt_Brno_Name.Text = GetBrno2Name(gBrNo) '分行名稱
            txt_EmpID.Text = gEmpId '經辦員編
            txt_EmpName.Text = GetEmpID2Name(gEmpId) '經辦名稱
            txt_YYYMM.Text = hYear & hMonth '所屬年月
            txt_RecordDate.Text = Format(Now(), "MM/dd/yyyy") '申報日期
            ''===========================================================================================
            '1. 查DS_tblLogDetail(DB)看表單編號是否已存在,如果沒有則新增,如果有的話則導到更新的頁面
            Dim tmpDocnoStatus As Array = CheckDocnoInDB(docno) '輸入表單編號,回傳(0表單編號是否存在,1流程代號,2流程日期,3版本)
            Dim tmpdocno As String = tmpDocnoStatus(0) '表單編號
            Dim tmpFlowID As String = tmpDocnoStatus(1) '流程狀態
            Dim tmpDate As String = tmpDocnoStatus(2) '流程日期
            Dim tmpVer As String = tmpDocnoStatus(3) '版本
            Dim tmpSign1 As String = tmpDocnoStatus(4) '負責人ID
            Dim tmpSignDate1 As String = tmpDocnoStatus(5) '負責人審核日期
            Dim tmpSignComment1 As String = tmpDocnoStatus(6) '負責人批示

            '===========================================================================================
            '2. 表單編號不存在,可新增            If (tmpdocno = "") Then '表單不存在,可新增                txt_status.Text = "分行新增中"
                '按鈕
                BtnAdd.Visible = True '新增按鈕顯示
                BtnMod.Visible = False '修改按鈕不顯示                BtnDel.Visible = False '刪除按鈕不顯示
            Else
                '===========================================================================================
                '3. 表單編號已存在,load DB(tblSell_Report)
                txt_status.Text = GetFlowStatus(tmpFlowID) '輸入流程狀態tmpFlowID代碼,回傳tmpFlowStatus中文
                txtDate.Text = tmpDate '流程狀態2(日期)
                txtVer.Text = tmpVer
                txtSign1.Text = tmpSign1 '負責人ID
                If (tmpSign1 <> "") Then
                    txtSign1Name.Text = GetEmpID2Name(tmpSign1) '負責人name
                End If
                txtSignDate1.Text = tmpSignDate1 '簽核日
                txtSignComment1.Text = tmpSignComment1 '批示

                '按鈕
                BtnAdd.Visible = False '新增按鈕不顯示                BtnNoCheck.Visible = False '無該當按鈕不顯示                BtnMod.Visible = True '修改按鈕顯示
                BtnDel.Visible = True '刪除按鈕顯示

                If (tmpFlowID = "3" Or tmpFlowID = "4") Then '已決行及已放行不能改
                    BtnMod.Visible = False '修改按鈕不顯示
                    BtnDel.Visible = False  '刪除按鈕不顯示
                    BtnNoCheck.Visible = False '無該當按鈕不顯示
                End If

                GettblMoneyInChinaDB()

            End If
            '===========================================================================================
            '3利用javascript 即時加總(ODK1010.js)
            javaAdd()
            BtnNoCheck.Attributes.Add("onclick", "return ChkDataFlag2()")

            '每月申報上個月資料, 101年3月起申報適用新格式(新增分行別)
            Dim tempD As DateTime = New Date(CInt(Me.txt_YYYMM.Text.Substring(0, 3)) + 1911, Right(Me.txt_YYYMM.Text, 2), 1)
            If tempD > CDate(格式轉換日) Then
                Me.pnlNew.Visible = True
                Me.hfNew.Value = 1
            Else
                Me.pnlNew.Visible = False
                Me.hfNew.Value = 0
            End If
            Me.pnlOld.Visible = Not Me.pnlNew.Visible

            If Me.hfNew.Value = 1 Then '套用新格式

                BtnAdd.Attributes.Add("onclick", "return ChkDataFlagNew()")
                BtnMod.Attributes.Add("onclick", "return ChkDataFlagNew()")
            Else
                BtnAdd.Attributes.Add("onclick", "return ChkDataFlag()")
                BtnMod.Attributes.Add("onclick", "return ChkDataFlag()")
            End If
        End If

    End Sub

    '行業別合計,放款申貸用途合計,分行別合計 
    Private Sub javaAdd()

        '行業別合計
        txt_A1.Attributes.Add("onblur", "return Add()")
        txt_A2.Attributes.Add("onblur", "return Add()")

        '放款申貸用途合計
        txt_B1.Attributes.Add("onblur", "return Add()")
        txt_B2.Attributes.Add("onblur", "return Add()")
        txt_B3.Attributes.Add("onblur", "return Add()")

        '分行別合計
        txt_C1.Attributes.Add("onblur", "return Add()")
        txt_C2.Attributes.Add("onblur", "return Add()")
        txt_C3.Attributes.Add("onblur", "return Add()")

        '2012/2/8 modify 新增分行別
        txtF_DBU.Attributes.Add("onblur", "return Add()")
        txtF_OBU.Attributes.Add("onblur", "return Add()")
        txtF_Over.Attributes.Add("onblur", "return Add()")
        txtG1_DBU.Attributes.Add("onblur", "return Add()")
        txtG1_OBU.Attributes.Add("onblur", "return Add()")
        txtG1_Over.Attributes.Add("onblur", "return Add()")
        txtG2_DBU.Attributes.Add("onblur", "return Add()")
        txtG2_OBU.Attributes.Add("onblur", "return Add()")
        txtG2_Over.Attributes.Add("onblur", "return Add()")
        txtG3_DBU.Attributes.Add("onblur", "return Add()")
        txtG3_OBU.Attributes.Add("onblur", "return Add()")
        txtG3_Over.Attributes.Add("onblur", "return Add()")

    End Sub

    '利用分行代號找出分行名稱
    Private Function GetBrno2Name(ByVal gBrNo As String) As String
        Dim BrnoName As String = ""
        Using conn As New SqlConnection(DS_BRANCH.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select BRNAME from chb_pub..BRANCH where BRNO ='" & gBrNo & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                BrnoName = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using

        Return BrnoName
    End Function

    '利用員編找名字
    Private Function GetEmpID2Name(ByVal gEmpId As String) As String
        'Response.Write("gEmpId:" & gEmpId & "<br>")
        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select NAME from chb_pub..EMPLOYEE where STAFF ='" & gEmpId & "'"

            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function

    '輸入流程狀態tmpFlowID代碼, 回傳tmpFlowStatus中文('0退回; 1待簽核; 2待決行; 3已決行; -1總行退件; 4已確認; 99已送至總行)
    Private Function GetFlowStatus(ByVal tmpFlowID As String) As String
        Dim tmpFlowStatus As String = ""
        Using conn As New SqlConnection(DS_tblSysCode.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT TblDesc FROM tblSysCode WHERE TblId = '11' AND TblCd =" & tmpFlowID
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                tmpFlowStatus = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using

        Return tmpFlowStatus
    End Function

    '輸入表單編號,回傳(0表單編號是否存在,1流程代號,2流程日期,3版本,4負責人id,5負責人審核日期,6負責人批示) db:tblLogDetail
    Private Function CheckDocnoInDB(ByVal docno As String) As Object
        Dim DocnoInDB(6) As String
        Dim tmpdocno As String = ""
        Dim tmpFlowStatus As String = ""
        Dim tmpRecordDate As String = ""
        Dim tmpSignDate1 As String = ""
        Dim tmpDecDate As String = ""
        Dim tmpDate As String = ""
        Dim tmpVer As String = ""
        Dim tmpSign1 As String = ""
        Dim tmpSignComment1 As String = ""

        '去DS_tblLogDetail(DB)查表單編號        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select DocType,DocNo, BrNo,EmpId,RecordDate,DataFlag,FormType,YYMM,Sign1,Action1,SignDate1,SignComment1,Sign2,Action2,SignDate2,SignComment2,DecManager,DecDate,FlowStatus,Ver from tblLogDetail where DocNo ='" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read
                tmpdocno = reader(1).ToString() '表單編號
                tmpRecordDate = reader(4).ToString() '分行日期
                tmpSign1 = reader(8).ToString() '負責人id
                tmpSignDate1 = reader(10).ToString() '負責人審核日期                tmpSignComment1 = reader(11).ToString() '負責人批示                tmpDecDate = reader(17).ToString() '日期
                tmpFlowStatus = reader(18).ToString() '表單流程
                tmpVer = reader(19).ToString() '版本

            End While
            reader.Close()
            cmd.Dispose()
        End Using

        '利用流程代號決定回傳日期
        Select Case tmpFlowStatus

            Case -1 '總行退回 
                tmpDate = FormatDateTime(tmpDecDate, DateFormat.ShortDate)
            Case 0 '退回                tmpDate = FormatDateTime(tmpSignDate1, DateFormat.ShortDate)
            Case 1 '待簽核                tmpDate = FormatDateTime(tmpRecordDate, DateFormat.ShortDate)
            Case 3 '已決行                tmpDate = FormatDateTime(tmpSignDate1, DateFormat.ShortDate)
            Case 4 '已確認                tmpDate = FormatDateTime(tmpDecDate, DateFormat.ShortDate)

        End Select

        DocnoInDB(0) = tmpdocno '表單編號
        DocnoInDB(1) = tmpFlowStatus '流程狀態        DocnoInDB(2) = tmpDate '流程狀態後面的日期
        DocnoInDB(3) = tmpVer '版本
        DocnoInDB(4) = tmpSign1 '負責人id
        DocnoInDB(5) = tmpSignDate1 '負責人審核日期        DocnoInDB(6) = tmpSignComment1 '負責人批示
        Return DocnoInDB
    End Function

    '新增按鈕
    Protected Sub BtnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd.Click

        Try

            '2012/2/8 modify 新增分行別
            If Me.hfNew.Value = "0" Then
                'E.保證款項資金運用於中國大陸餘額
                DS_tblMoneyInChina.InsertParameters("E1").DefaultValue = txt_E1.Text '商業本票保證
                DS_tblMoneyInChina.InsertParameters("E2").DefaultValue = txt_E2.Text '發行公司債
                DS_tblMoneyInChina.InsertParameters("E3").DefaultValue = txt_E3.Text '其他

                'F.應收帳款收買業務資金運用於中國大陸餘額
                DS_tblMoneyInChina.InsertParameters("F1").DefaultValue = txt_F1.Text

                'G.資金運用於中國大陸帳列金額逾期三個月以上
                DS_tblMoneyInChina.InsertParameters("G1").DefaultValue = txt_G1.Text '放款
                DS_tblMoneyInChina.InsertParameters("G2").DefaultValue = txt_G2.Text '保證墊款
                DS_tblMoneyInChina.InsertParameters("G3").DefaultValue = txt_G3.Text '應收帳款收買 
            Else

                'E.保證款項資金運用於中國大陸餘額()
                DS_tblMoneyInChina.InsertParameters("E1").DefaultValue = (CInt(txtE1_DBU.Text) + CInt(txtE1_OBU.Text) + CInt(txtE1_Over.Text)).ToString '商業本票保證
                DS_tblMoneyInChina.InsertParameters("E2").DefaultValue = (CInt(txtE2_DBU.Text) + CInt(txtE2_OBU.Text) + CInt(txtE2_Over.Text)).ToString '發行公司債
                DS_tblMoneyInChina.InsertParameters("E3").DefaultValue = (CInt(txtE3_DBU.Text) + CInt(txtE3_OBU.Text) + CInt(txtE3_Over.Text)).ToString '其他

                'F.應收帳款收買業務資金運用於中國大陸餘額
                DS_tblMoneyInChina.InsertParameters("F1").DefaultValue = (CInt(txtF_DBU.Text) + CInt(txtF_OBU.Text) + CInt(txtF_Over.Text)).ToString

                'G.資金運用於中國大陸帳列金額逾期三個月以上
                DS_tblMoneyInChina.InsertParameters("G1").DefaultValue = (CInt(txtG1_DBU.Text) + CInt(txtG1_OBU.Text) + CInt(txtG1_Over.Text)).ToString
                DS_tblMoneyInChina.InsertParameters("G2").DefaultValue = (CInt(txtG2_DBU.Text) + CInt(txtG2_OBU.Text) + CInt(txtG2_Over.Text)).ToString
                DS_tblMoneyInChina.InsertParameters("G3").DefaultValue = (CInt(txtG3_DBU.Text) + CInt(txtG3_OBU.Text) + CInt(txtG3_Over.Text)).ToString
            End If

            Dim AT As Integer = Integer.Parse(txt_A1.Text) + Integer.Parse(txt_A2.Text)
            Dim BT As Integer = Integer.Parse(txt_B1.Text) + Integer.Parse(txt_B2.Text) + Integer.Parse(txt_B3.Text)
            Dim CT As Integer = Integer.Parse(txt_C1.Text) + Integer.Parse(txt_C2.Text) + Integer.Parse(txt_C3.Text)

            '放款合計、行業別合計、放款申貸用途合計與分行別合計需相等
            If (AT = BT And BT = CT And CT = txt_D1.Text) Then
                DS_tblMoneyInChina.Insert()
                DS_tblLogDetail.Insert()
                Response.Write("<script language=javascript>alert('新增完畢!')</script>")
                Response.Write("<script language=javascript>window.location.href='/oachb/program/ODR1010/ODR1010QForm.asp'</script>")
            Else
                Response.Write("<script language=javascript>alert('放款合計,行業別合計,放款申貸用途合計,分行別合計 需相等!')</script>")
            End If
        Catch ex As Exception
            Response.Write("<script language=javascript>alert('每月金額欄位格式有誤！')</script>")
        End Try

    End Sub

    '無該當按鈕
    Protected Sub BtnNoCheck_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnNoCheck.Click

        Try
            DS_tblMoneyInChina.Insert()
            DS_tblLogDetail.Insert()
            Response.Write("<script language=javascript>alert('新增完畢(無該當)!')</script>")
            Response.Write("<script language=javascript>window.location.href='/oachb/program/ODR1010/ODR1010QForm.asp'</script>")
        Catch ex As Exception
        End Try

    End Sub

    '按下修改
    Protected Sub BtnMod_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnMod.Click

        Try
            Dim gEmpId As String = hidn_EMPID.Value
            txt_EmpID.Text = gEmpId '經辦員編
            txt_EmpName.Text = GetEmpID2Name(gEmpId) '找出經辦名稱

            '2012/2/8 modify 新增分行別
            If Me.hfNew.Value = "0" Then '舊格式
                'E.保證款項資金運用於中國大陸餘額
                DS_tblMoneyInChina.UpdateParameters("E1").DefaultValue = txt_E1.Text '商業本票保證
                DS_tblMoneyInChina.UpdateParameters("E2").DefaultValue = txt_E2.Text '發行公司債
                DS_tblMoneyInChina.UpdateParameters("E3").DefaultValue = txt_E3.Text '其他

                'F.應收帳款收買業務資金運用於中國大陸餘額
                DS_tblMoneyInChina.UpdateParameters("F1").DefaultValue = txt_F1.Text

                'G.資金運用於中國大陸帳列金額逾期三個月以上
                DS_tblMoneyInChina.UpdateParameters("G1").DefaultValue = txt_G1.Text '放款
                DS_tblMoneyInChina.UpdateParameters("G2").DefaultValue = txt_G2.Text '保證墊款
                DS_tblMoneyInChina.UpdateParameters("G3").DefaultValue = txt_G3.Text '應收帳款收買 
            Else
                '新格式
                'E.保證款項資金運用於中國大陸餘額
                DS_tblMoneyInChina.UpdateParameters("E1").DefaultValue = (CInt(txtE1_DBU.Text) + CInt(txtE1_OBU.Text) + CInt(txtE1_Over.Text)).ToString '商業本票保證
                DS_tblMoneyInChina.UpdateParameters("E2").DefaultValue = (CInt(txtE2_DBU.Text) + CInt(txtE2_OBU.Text) + CInt(txtE2_Over.Text)).ToString '發行公司債
                DS_tblMoneyInChina.UpdateParameters("E3").DefaultValue = (CInt(txtE3_DBU.Text) + CInt(txtE3_OBU.Text) + CInt(txtE3_Over.Text)).ToString '其他

                'F.應收帳款收買業務資金運用於中國大陸餘額
                DS_tblMoneyInChina.UpdateParameters("F1").DefaultValue = (CInt(txtF_DBU.Text) + CInt(txtF_OBU.Text) + CInt(txtF_Over.Text)).ToString

                'G.資金運用於中國大陸帳列金額逾期三個月以上
                DS_tblMoneyInChina.UpdateParameters("G1").DefaultValue = (CInt(txtG1_DBU.Text) + CInt(txtG1_OBU.Text) + CInt(txtG1_Over.Text)).ToString
                DS_tblMoneyInChina.UpdateParameters("G2").DefaultValue = (CInt(txtG2_DBU.Text) + CInt(txtG2_OBU.Text) + CInt(txtG2_Over.Text)).ToString
                DS_tblMoneyInChina.UpdateParameters("G3").DefaultValue = (CInt(txtG3_DBU.Text) + CInt(txtG3_OBU.Text) + CInt(txtG3_Over.Text)).ToString

            End If

            Dim AT As Integer = Integer.Parse(txt_A1.Text) + Integer.Parse(txt_A2.Text)
            Dim BT As Integer = Integer.Parse(txt_B1.Text) + Integer.Parse(txt_B2.Text) + Integer.Parse(txt_B3.Text)
            Dim CT As Integer = Integer.Parse(txt_C1.Text) + Integer.Parse(txt_C2.Text) + Integer.Parse(txt_C3.Text)

            '修改chb_eform 表單流程 (UPDATE [tblLogDetail] SET [EmpId] = @EmpId, [RecordDate] = @RecordDate, [DataFlag] = @DataFlag, [Sign1] = @Sign1, [Action1] = @Action1, [SignDate1] = @SignDate1, [SignComment1] = @SignComment1,  [DecManager] = @DecManager, [DecDate] = @DecDate, [FlowStatus] = @FlowStatus, [Ver] = @Ver WHERE [DocNo] = @DocNo)
            Dim docno As String = lblDOCNO.Text
            Dim tmpDocnoStatus As Array = CheckDocnoInDB(docno)
            Dim NewVer As String = Decimal.Parse(tmpDocnoStatus(3).ToString.Trim) + 1 '版本+1
            DS_tblLogDetail.UpdateParameters("Ver").DefaultValue = NewVer

            If (AT = BT And BT = CT And CT = txt_D1.Text) Then
                DS_tblMoneyInChina.Update()
                DS_tblLogDetail.Update()
                Response.Write("<script language=javascript>alert('修改完畢!')</script>")
                Response.Write("<script language=javascript>window.location.href='/oachb/program/ODR1010/ODR1010QForm.asp'</script>")
            Else
                Response.Write("<script language=javascript>alert('放款合計,行業別合計,放款申貸用途合計,分行別合計 需相等!')</script>")
            End If
        Catch ex As Exception
            Response.Write("<script language=javascript>alert('每月金額欄位格式有誤！')</script>")
        End Try

    End Sub

    '刪除按鈕
    Protected Sub BtnDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnDel.Click

        Try

            DS_tblLogDetail.Delete() '刪除 chb_eform 表單流程
            DS_tblMoneyInChina.Delete() '刪除 DS_tblMoneyInChina 表單流程

            Response.Write("<script language=javascript>alert('刪除完畢!')</script>")
            Response.Write("<script language=javascript>window.location.href='/oachb/program/ODR1010/ODR1010QForm.asp'</script>")
        Catch ex As Exception
        End Try

    End Sub

    '從DS_tblMoneyInChina(DB)取值(資料內容)
    Private Sub GettblMoneyInChinaDB()

        '=================變 數 宣 告==================
        Dim A1, A2, B1, B2, B3, C1, C2, C3, D1, E1, E2, E3, F1, G1, G2, G3 As Integer

        '2011/2/8 moidy 新增分行別
        Dim E1_DBU, E1_OBU, E1_Over, E2_DBU, E2_OBU, E2_Over, E3_DBU, E3_OBU, E3_Over, F_DBU, F_OBU, F_Over, G1_DBU, G1_OBU, G1_Over, G2_DBU, G2_OBU, G2_Over, G3_DBU, G3_OBU, G3_Over As Integer
        Dim docno As String
        docno = lblDOCNO.Text

        '=================資 料 庫 撈 資 料==================

        Using conn As New SqlConnection(DS_tblMoneyInChina.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            '2012/2/8 modify 新增分行別
            tmpsql = "SELECT DocNo, Brno, BRName, EmpID, EmpName, Ext, YYYMM, A1, A2" & _
                        ", B1, B2, B3, C1, C2, C3, D1, E1, E2, E3, F1, G1, G2, G3" & _
                        ", E1_DBU, E1_OBU, E1_Over, E2_DBU, E2_OBU, E2_Over, E3_DBU, E3_OBU, E3_Over" & _
                        ", F_DBU, F_OBU, F_Over, G1_DBU, G1_OBU, G1_Over " & _
                        ", G2_DBU, G2_OBU, G2_Over, G3_DBU, G3_OBU, G3_Over " & _
                        "FROM tblMoneyInChina where DocNo = '" & docno & "'"

            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read

                lblDOCNO.Text = reader(0).ToString() 'DocNo  
                txt_Brno.Text = reader(1).ToString() 'Brno   
                txt_Brno_Name.Text = reader(2).ToString() 'BRName 
                txt_EmpID.Text = reader(3).ToString()  'EmpID  
                txt_EmpName.Text = reader(4).ToString() 'EmpName
                txt_Ext.Text = reader(5).ToString() 'Ext    
                txt_YYYMM.Text = reader(6).ToString() 'YYYMM  
                A1 = reader(7).ToString()  'A1     
                A2 = reader(8).ToString()  'A2     
                B1 = reader(9).ToString()  'B1     
                B2 = reader(10).ToString() 'B2     
                B3 = reader(11).ToString() 'B3     
                C1 = reader(12).ToString() 'C1     
                C2 = reader(13).ToString() 'C2     
                C3 = reader(14).ToString() 'C3     
                D1 = reader(15).ToString() 'D1     
                E1 = reader(16).ToString() 'E1     
                E2 = reader(17).ToString() 'E2     
                E3 = reader(18).ToString() 'E3 
                F1 = reader(19).ToString 'F1     
                'F1 = iif(reader.IsDBNull(reader.GetOrdinal("F1")), "0", reader(19).ToString) 'F1     
                G1 = reader(20).ToString() 'G1     
                G2 = reader(21).ToString() 'G2     
                G3 = reader(22).ToString() 'G3 

                '2012/2/8 modify 新增分行別
                E1_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("E1_DBU")), "0", reader(23).ToString)
                E1_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("E1_OBU")), "0", reader(24).ToString)
                E1_Over = IIf(reader.IsDBNull(reader.GetOrdinal("E1_Over")), "0", reader(25).ToString)
                E2_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("E2_DBU")), "0", reader(26).ToString)
                E2_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("E2_OBU")), "0", reader(27).ToString)
                E2_Over = IIf(reader.IsDBNull(reader.GetOrdinal("E2_Over")), "0", reader(28).ToString)
                E3_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("E3_DBU")), "0", reader(29).ToString)
                E3_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("E3_OBU")), "0", reader(30).ToString)
                E3_Over = IIf(reader.IsDBNull(reader.GetOrdinal("E3_Over")), "0", reader(31).ToString)
                F_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("F_DBU")), "0", reader(32).ToString)
                F_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("F_OBU")), "0", reader(33).ToString)
                F_Over = IIf(reader.IsDBNull(reader.GetOrdinal("F_Over")), "0", reader(34).ToString)
                G1_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("G1_DBU")), "0", reader(35).ToString)
                G1_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("G1_OBU")), "0", reader(36).ToString)
                G1_Over = IIf(reader.IsDBNull(reader.GetOrdinal("G1_Over")), "0", reader(37).ToString)
                G2_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("G2_DBU")), "0", reader(38).ToString)
                G2_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("G2_OBU")), "0", reader(39).ToString)
                G2_Over = IIf(reader.IsDBNull(reader.GetOrdinal("G2_Over")), "0", reader(40).ToString)
                G3_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("G3_DBU")), "0", reader(41).ToString)
                G3_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("G3_OBU")), "0", reader(42).ToString)
                G3_Over = IIf(reader.IsDBNull(reader.GetOrdinal("G3_Over")), "0", reader(43).ToString)

            End While
            reader.Close()
            cmd.Dispose()
        End Using

        Try
            '=================給 值==================
            txt_A1.Text = A1.ToString()
            txt_A2.Text = A2.ToString()
            txt_AT.Text = (A1 + A2).ToString("N0")
            txt_B1.Text = B1.ToString()
            txt_B2.Text = B2.ToString()
            txt_B3.Text = B3.ToString()
            txt_BT.Text = (B1 + B2 + B3).ToString("N0")
            txt_C1.Text = C1.ToString()
            txt_C2.Text = C2.ToString()
            txt_C3.Text = C3.ToString()
            txt_CT.Text = (C1 + C2 + C3).ToString("N0")
            txt_D1.Text = D1.ToString()
            txt_E1.Text = E1.ToString()
            txt_E2.Text = E2.ToString()
            txt_E3.Text = E3.ToString()
            txt_F1.Text = F1.ToString()
            txt_G1.Text = G1.ToString()
            txt_G2.Text = G2.ToString()
            txt_G3.Text = G3.ToString()

            '2012/2/8 modify 新增分行別
            Me.txtE1_DBU.Text = E1_DBU.ToString
            Me.txtE1_OBU.Text = E1_OBU.ToString
            Me.txtE1_Over.Text = E1_Over.ToString
            Me.txtE2_DBU.Text = E2_DBU.ToString
            Me.txtE2_OBU.Text = E2_OBU.ToString
            Me.txtE2_Over.Text = E2_Over.ToString
            Me.txtE3_DBU.Text = E3_DBU.ToString
            Me.txtE3_OBU.Text = E3_OBU.ToString
            Me.txtE3_Over.Text = E3_Over.ToString
            Me.txtF_DBU.Text = F_DBU.ToString
            Me.txtF_OBU.Text = F_OBU.ToString
            Me.txtF_Over.Text = F_Over.ToString
            Me.txtFT_New.Text = F1.ToString
            Me.txtG1_DBU.Text = G1_DBU.ToString
            Me.txtG2_DBU.Text = G2_DBU.ToString
            Me.txtG3_DBU.Text = G3_DBU.ToString
            Me.txtGT_DBU.Text = (G1_DBU + G2_DBU + G3_DBU).ToString("N0")
            Me.txtG1_OBU.Text = G1_OBU.ToString
            Me.txtG2_OBU.Text = G2_OBU.ToString
            Me.txtG3_OBU.Text = G3_OBU.ToString
            Me.txtGT_OBU.Text = (G1_OBU + G2_OBU + G3_OBU).ToString("N0")
            Me.txtG1_Over.Text = G1_Over.ToString
            Me.txtG2_Over.Text = G2_Over.ToString
            Me.txtG3_Over.Text = G3_Over.ToString
            Me.txtGT_Over.Text = (G1_Over + G2_Over + G3_Over).ToString("N0")
        Catch ex As Exception
        End Try

    End Sub

End Class
