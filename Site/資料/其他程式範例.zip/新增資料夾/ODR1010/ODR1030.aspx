﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODR1030.aspx.vb" Inherits="DotNet_Program_ODR1010_ODR1030" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <style type="text/css">
        .style1
        {
            font-family: 標楷體;
            font-size: medium;
        }
        .style2
        {
            width: 100%;
            font-family: 新細明體;
            font-size: small;
        }
        .style3
        {
            font-family: 新細明體;
            font-size: small;
            text-align: right;
        }
        .style4
        {
            font-size: small;
            text-align: center;
        }
        .style5
        {
            font-family: 新細明體;
            font-size: small;
            text-align: center;
        }
        .style6
        {
            text-align: center;
        }
        .style7
        {
            text-align: right;
        }
        .style8
        {
            width: 100%;
        }
        .style9
        {
            font-family: 標楷體;
        }
        .style11
        {
            font-family: 標楷體;
            font-size: xx-small;
        }
    </style>

    <script type="text/javascript">
        //列印div包起來的部分並且列印完畢後自動關閉列印網頁
        function PrintScreen() {
            var value = prt.innerHTML;
            var printPage = window.open("", "printPage", "");
            printPage.document.open();
            printPage.document.write("<HTML><head></head><BODY onload='window.print();'><center>");
            printPage.document.write(value);
            printPage.document.close("</center></BODY></HTML>");
        }

    </script>

</head>
<body bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
    
        <span class="style9">查</span><span class="style1">詢年月：</span><asp:DropDownList ID="ddl年" 
            runat="server" AutoPostBack="True" CssClass="style1">
        </asp:DropDownList>
        <span class="style1">年</span><asp:DropDownList ID="ddl月" runat="server" AutoPostBack="True" CssClass="style1">
                                <asp:ListItem Value="01">01</asp:ListItem>
                                <asp:ListItem>02</asp:ListItem>
                                <asp:ListItem>03</asp:ListItem>
                                <asp:ListItem>04</asp:ListItem>
                                <asp:ListItem>05</asp:ListItem>
                                <asp:ListItem>06</asp:ListItem>
                                <asp:ListItem>07</asp:ListItem>
                                <asp:ListItem>08</asp:ListItem>
                                <asp:ListItem>09</asp:ListItem>
                                <asp:ListItem>10</asp:ListItem>
                                <asp:ListItem>11</asp:ListItem>
                                <asp:ListItem Value="12">12</asp:ListItem>
                    </asp:DropDownList>
        <span class="style1">月 </span>
        <asp:Button ID="btn_prt" runat="server" Text="列印" />
    </div>
    <div id="prt">
                <asp:FormView ID="fvData" runat="server" DataKeyNames="DocNo" 
                    DataSourceID="sdsData" EnableModelValidation="True" Width="92%" 
                    EmptyDataText="本月無填報資料！">
                    <EditItemTemplate>
                        DocNo:
                        <asp:Label ID="DocNoLabel1" runat="server" Text='<%# Eval("DocNo") %>' />
                        <br />
                        Brno:
                        <asp:TextBox ID="BrnoTextBox" runat="server" Text='<%# Bind("Brno") %>' />
                        <br />
                        BRName:
                        <asp:TextBox ID="BRNameTextBox" runat="server" Text='<%# Bind("BRName") %>' />
                        <br />
                        EmpID:
                        <asp:TextBox ID="EmpIDTextBox" runat="server" Text='<%# Bind("EmpID") %>' />
                        <br />
                        EmpName:
                        <asp:TextBox ID="EmpNameTextBox" runat="server" Text='<%# Bind("EmpName") %>' />
                        <br />
                        Ext:
                        <asp:TextBox ID="ExtTextBox" runat="server" Text='<%# Bind("Ext") %>' />
                        <br />
                        YYYMM:
                        <asp:TextBox ID="YYYMMTextBox" runat="server" Text='<%# Bind("YYYMM") %>' />
                        <br />
                        A1:
                        <asp:TextBox ID="A1TextBox" runat="server" Text='<%# Bind("A1") %>' />
                        <br />
                        A2:
                        <asp:TextBox ID="A2TextBox" runat="server" Text='<%# Bind("A2") %>' />
                        <br />
                        B1:
                        <asp:TextBox ID="B1TextBox" runat="server" Text='<%# Bind("B1") %>' />
                        <br />
                        B2:
                        <asp:TextBox ID="B2TextBox" runat="server" Text='<%# Bind("B2") %>' />
                        <br />
                        B3:
                        <asp:TextBox ID="B3TextBox" runat="server" Text='<%# Bind("B3") %>' />
                        <br />
                        C1:
                        <asp:TextBox ID="C1TextBox" runat="server" Text='<%# Bind("C1") %>' />
                        <br />
                        C2:
                        <asp:TextBox ID="C2TextBox" runat="server" Text='<%# Bind("C2") %>' />
                        <br />
                        C3:
                        <asp:TextBox ID="C3TextBox" runat="server" Text='<%# Bind("C3") %>' />
                        <br />
                        D1:
                        <asp:TextBox ID="D1TextBox" runat="server" Text='<%# Bind("D1") %>' />
                        <br />
                        E1:
                        <asp:TextBox ID="E1TextBox" runat="server" Text='<%# Bind("E1") %>' />
                        <br />
                        E2:
                        <asp:TextBox ID="E2TextBox" runat="server" Text='<%# Bind("E2") %>' />
                        <br />
                        E3:
                        <asp:TextBox ID="E3TextBox" runat="server" Text='<%# Bind("E3") %>' />
                        <br />
                        F1:
                        <asp:TextBox ID="F1TextBox" runat="server" Text='<%# Bind("F1") %>' />
                        <br />
                        G1:
                        <asp:TextBox ID="G1TextBox" runat="server" Text='<%# Bind("G1") %>' />
                        <br />
                        G2:
                        <asp:TextBox ID="G2TextBox" runat="server" Text='<%# Bind("G2") %>' />
                        <br />
                        G3:
                        <asp:TextBox ID="G3TextBox" runat="server" Text='<%# Bind("G3") %>' />
                        <br />
                        E1_DBU:
                        <asp:TextBox ID="E1_DBUTextBox" runat="server" Text='<%# Bind("E1_DBU") %>' />
                        <br />
                        E1_OBU:
                        <asp:TextBox ID="E1_OBUTextBox" runat="server" Text='<%# Bind("E1_OBU") %>' />
                        <br />
                        E1_Over:
                        <asp:TextBox ID="E1_OverTextBox" runat="server" Text='<%# Bind("E1_Over") %>' />
                        <br />
                        E2_DBU:
                        <asp:TextBox ID="E2_DBUTextBox" runat="server" Text='<%# Bind("E2_DBU") %>' />
                        <br />
                        E2_OBU:
                        <asp:TextBox ID="E2_OBUTextBox" runat="server" Text='<%# Bind("E2_OBU") %>' />
                        <br />
                        E2_Over:
                        <asp:TextBox ID="E2_OverTextBox" runat="server" Text='<%# Bind("E2_Over") %>' />
                        <br />
                        E3_DBU:
                        <asp:TextBox ID="E3_DBUTextBox" runat="server" Text='<%# Bind("E3_DBU") %>' />
                        <br />
                        E3_OBU:
                        <asp:TextBox ID="E3_OBUTextBox" runat="server" Text='<%# Bind("E3_OBU") %>' />
                        <br />
                        E3_Over:
                        <asp:TextBox ID="E3_OverTextBox" runat="server" Text='<%# Bind("E3_Over") %>' />
                        <br />
                        F_DBU:
                        <asp:TextBox ID="F_DBUTextBox" runat="server" Text='<%# Bind("F_DBU") %>' />
                        <br />
                        F_OBU:
                        <asp:TextBox ID="F_OBUTextBox" runat="server" Text='<%# Bind("F_OBU") %>' />
                        <br />
                        F_Over:
                        <asp:TextBox ID="F_OverTextBox" runat="server" Text='<%# Bind("F_Over") %>' />
                        <br />
                        G1_DBU:
                        <asp:TextBox ID="G1_DBUTextBox" runat="server" Text='<%# Bind("G1_DBU") %>' />
                        <br />
                        G1_OBU:
                        <asp:TextBox ID="G1_OBUTextBox" runat="server" Text='<%# Bind("G1_OBU") %>' />
                        <br />
                        G1_Over:
                        <asp:TextBox ID="G1_OverTextBox" runat="server" Text='<%# Bind("G1_Over") %>' />
                        <br />
                        G2_DBU:
                        <asp:TextBox ID="G2_DBUTextBox" runat="server" Text='<%# Bind("G2_DBU") %>' />
                        <br />
                        G2_OBU:
                        <asp:TextBox ID="G2_OBUTextBox" runat="server" Text='<%# Bind("G2_OBU") %>' />
                        <br />
                        G2_Over:
                        <asp:TextBox ID="G2_OverTextBox" runat="server" Text='<%# Bind("G2_Over") %>' />
                        <br />
                        G3_DBU:
                        <asp:TextBox ID="G3_DBUTextBox" runat="server" Text='<%# Bind("G3_DBU") %>' />
                        <br />
                        G3_OBU:
                        <asp:TextBox ID="G3_OBUTextBox" runat="server" Text='<%# Bind("G3_OBU") %>' />
                        <br />
                        G3_Over:
                        <asp:TextBox ID="G3_OverTextBox" runat="server" Text='<%# Bind("G3_Over") %>' />
                        <br />
                        <asp:LinkButton ID="UpdateButton" runat="server" CausesValidation="True" 
                            CommandName="Update" Text="更新" />
                        &nbsp;<asp:LinkButton ID="UpdateCancelButton" runat="server" 
                            CausesValidation="False" CommandName="Cancel" Text="取消" />
                    </EditItemTemplate>
                    <EmptyDataRowStyle Font-Names="標楷體" Font-Size="Large" ForeColor="Blue" 
                        HorizontalAlign="Center" />
                    <InsertItemTemplate>
                        DocNo:
                        <asp:TextBox ID="DocNoTextBox" runat="server" Text='<%# Bind("DocNo") %>' />
                        <br />
                        Brno:
                        <asp:TextBox ID="BrnoTextBox" runat="server" Text='<%# Bind("Brno") %>' />
                        <br />
                        BRName:
                        <asp:TextBox ID="BRNameTextBox" runat="server" Text='<%# Bind("BRName") %>' />
                        <br />
                        EmpID:
                        <asp:TextBox ID="EmpIDTextBox" runat="server" Text='<%# Bind("EmpID") %>' />
                        <br />
                        EmpName:
                        <asp:TextBox ID="EmpNameTextBox" runat="server" Text='<%# Bind("EmpName") %>' />
                        <br />
                        Ext:
                        <asp:TextBox ID="ExtTextBox" runat="server" Text='<%# Bind("Ext") %>' />
                        <br />
                        YYYMM:
                        <asp:TextBox ID="YYYMMTextBox" runat="server" Text='<%# Bind("YYYMM") %>' />
                        <br />
                        A1:
                        <asp:TextBox ID="A1TextBox" runat="server" Text='<%# Bind("A1") %>' />
                        <br />
                        A2:
                        <asp:TextBox ID="A2TextBox" runat="server" Text='<%# Bind("A2") %>' />
                        <br />
                        B1:
                        <asp:TextBox ID="B1TextBox" runat="server" Text='<%# Bind("B1") %>' />
                        <br />
                        B2:
                        <asp:TextBox ID="B2TextBox" runat="server" Text='<%# Bind("B2") %>' />
                        <br />
                        B3:
                        <asp:TextBox ID="B3TextBox" runat="server" Text='<%# Bind("B3") %>' />
                        <br />
                        C1:
                        <asp:TextBox ID="C1TextBox" runat="server" Text='<%# Bind("C1") %>' />
                        <br />
                        C2:
                        <asp:TextBox ID="C2TextBox" runat="server" Text='<%# Bind("C2") %>' />
                        <br />
                        C3:
                        <asp:TextBox ID="C3TextBox" runat="server" Text='<%# Bind("C3") %>' />
                        <br />
                        D1:
                        <asp:TextBox ID="D1TextBox" runat="server" Text='<%# Bind("D1") %>' />
                        <br />
                        E1:
                        <asp:TextBox ID="E1TextBox" runat="server" Text='<%# Bind("E1") %>' />
                        <br />
                        E2:
                        <asp:TextBox ID="E2TextBox" runat="server" Text='<%# Bind("E2") %>' />
                        <br />
                        E3:
                        <asp:TextBox ID="E3TextBox" runat="server" Text='<%# Bind("E3") %>' />
                        <br />
                        F1:
                        <asp:TextBox ID="F1TextBox" runat="server" Text='<%# Bind("F1") %>' />
                        <br />
                        G1:
                        <asp:TextBox ID="G1TextBox" runat="server" Text='<%# Bind("G1") %>' />
                        <br />
                        G2:
                        <asp:TextBox ID="G2TextBox" runat="server" Text='<%# Bind("G2") %>' />
                        <br />
                        G3:
                        <asp:TextBox ID="G3TextBox" runat="server" Text='<%# Bind("G3") %>' />
                        <br />
                        E1_DBU:
                        <asp:TextBox ID="E1_DBUTextBox" runat="server" Text='<%# Bind("E1_DBU") %>' />
                        <br />
                        E1_OBU:
                        <asp:TextBox ID="E1_OBUTextBox" runat="server" Text='<%# Bind("E1_OBU") %>' />
                        <br />
                        E1_Over:
                        <asp:TextBox ID="E1_OverTextBox" runat="server" Text='<%# Bind("E1_Over") %>' />
                        <br />
                        E2_DBU:
                        <asp:TextBox ID="E2_DBUTextBox" runat="server" Text='<%# Bind("E2_DBU") %>' />
                        <br />
                        E2_OBU:
                        <asp:TextBox ID="E2_OBUTextBox" runat="server" Text='<%# Bind("E2_OBU") %>' />
                        <br />
                        E2_Over:
                        <asp:TextBox ID="E2_OverTextBox" runat="server" Text='<%# Bind("E2_Over") %>' />
                        <br />
                        E3_DBU:
                        <asp:TextBox ID="E3_DBUTextBox" runat="server" Text='<%# Bind("E3_DBU") %>' />
                        <br />
                        E3_OBU:
                        <asp:TextBox ID="E3_OBUTextBox" runat="server" Text='<%# Bind("E3_OBU") %>' />
                        <br />
                        E3_Over:
                        <asp:TextBox ID="E3_OverTextBox" runat="server" Text='<%# Bind("E3_Over") %>' />
                        <br />
                        F_DBU:
                        <asp:TextBox ID="F_DBUTextBox" runat="server" Text='<%# Bind("F_DBU") %>' />
                        <br />
                        F_OBU:
                        <asp:TextBox ID="F_OBUTextBox" runat="server" Text='<%# Bind("F_OBU") %>' />
                        <br />
                        F_Over:
                        <asp:TextBox ID="F_OverTextBox" runat="server" Text='<%# Bind("F_Over") %>' />
                        <br />
                        G1_DBU:
                        <asp:TextBox ID="G1_DBUTextBox" runat="server" Text='<%# Bind("G1_DBU") %>' />
                        <br />
                        G1_OBU:
                        <asp:TextBox ID="G1_OBUTextBox" runat="server" Text='<%# Bind("G1_OBU") %>' />
                        <br />
                        G1_Over:
                        <asp:TextBox ID="G1_OverTextBox" runat="server" Text='<%# Bind("G1_Over") %>' />
                        <br />
                        G2_DBU:
                        <asp:TextBox ID="G2_DBUTextBox" runat="server" Text='<%# Bind("G2_DBU") %>' />
                        <br />
                        G2_OBU:
                        <asp:TextBox ID="G2_OBUTextBox" runat="server" Text='<%# Bind("G2_OBU") %>' />
                        <br />
                        G2_Over:
                        <asp:TextBox ID="G2_OverTextBox" runat="server" Text='<%# Bind("G2_Over") %>' />
                        <br />
                        G3_DBU:
                        <asp:TextBox ID="G3_DBUTextBox" runat="server" Text='<%# Bind("G3_DBU") %>' />
                        <br />
                        G3_OBU:
                        <asp:TextBox ID="G3_OBUTextBox" runat="server" Text='<%# Bind("G3_OBU") %>' />
                        <br />
                        G3_Over:
                        <asp:TextBox ID="G3_OverTextBox" runat="server" Text='<%# Bind("G3_Over") %>' />
                        <br />
                        <asp:LinkButton ID="InsertButton" runat="server" CausesValidation="True" 
                            CommandName="Insert" Text="插入" />
                        &nbsp;<asp:LinkButton ID="InsertCancelButton" runat="server" 
                            CausesValidation="False" CommandName="Cancel" Text="取消" />
                    </InsertItemTemplate>
                    <ItemTemplate>
                        <table class="style8" width="100%">
                            <tr>
                                <td style="text-align: center; font-size: medium; font-weight: 700" 
                                    class="style9">
                                    本國銀行資金運用於大陸彙總表</td>
                            </tr>
                            <tr>
                                <td style="text-align: left">
                                    <span class="style9">填報分行：</span><asp:Label ID="BrnoLabel" runat="server" 
                                        Text='<%# Bind("Brno") %>' CssClass="style9" />
                                    &nbsp;<asp:Label ID="BRNameLabel" runat="server" Text='<%# Bind("BRName") %>' 
                                        CssClass="style9" />
                                    <span class="style9">　填報年月：</span><asp:Label ID="YYYMMLabel" runat="server" 
                                        Text='<%# Bind("YYYMM") %>' CssClass="style9" />
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: left">
                                    <span class="style9">負責人：<asp:Label ID="SignName" runat="server" 
                                        Text='<%# Eval("NAME") %>'></asp:Label>
                                    　經辦：</span><asp:Label ID="EmpNameLabel" runat="server" 
                                        Text='<%# Bind("EmpName") %>' CssClass="style9" />
                                    <span class="style9">　分機：</span><asp:Label ID="ExtLabel" runat="server" 
                                        Text='<%# Bind("Ext") %>' CssClass="style9" />
                                </td>
                            </tr>
                        </table>
                        <table border="2" cellpadding="2" cellspacing="2" width="100%" 
                            style="border-color: #000000; border-style: solid;">
                            <tr>
                                <td bgcolor="Khaki" class="style4" colspan="8" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    <span class="style3">放款資金運用於中國大陸餘額 </span><span ID="Label1" class="style3" 
                                        style="COLOR: red; FONT-WEIGHT: normal">單位: 新台幣百萬元 以下欄位最多為5位正整數</span></td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style5" colspan="2" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    行 業 別(A)</td>
                                <td class="style5" colspan="3" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    放 款 申 貸 用 途(B)</td>
                                <td bgcolor="Khaki" class="style5" colspan="3" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    分行別(C)</td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="12%">
                                    傳統業(A1)</td>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="12%">
                                    科技業(A2)</td>
                                <td class="style5" style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="14%">
                                    企業投資(B1)</td>
                                <td class="style5" style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="13%">
                                    週轉金(B2)</td>
                                <td class="style5" style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="13%">
                                    其 他(B3)</td>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="12%">
                                    DBU(C1)</td>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="12%">
                                    OBU(C2)</td>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    海外分行(C3)</td>
                            </tr>
                            <tr>
                                <td style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="A1Label" runat="server" CssClass="style3" 
                                        Text='<%# Eval("A1", "{0:N0}") %>' />
                                </td>
                                <td style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="A2Label" runat="server" CssClass="style3" 
                                        Text='<%# Eval("A2", "{0:N0}") %>' />
                                </td>
                                <td style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="B1Label" runat="server" CssClass="style3" 
                                        Text='<%# Eval("B1", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="B2Label" runat="server" CssClass="style3" 
                                        Text='<%# Eval("B2", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="B3Label" runat="server" CssClass="style3" 
                                        Text='<%# Eval("B3", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="C1Label" runat="server" CssClass="style3" 
                                        Text='<%# Eval("C1", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="C2Label" runat="server" CssClass="style3" 
                                        Text='<%# Eval("C2", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="C3Label" runat="server" CssClass="style3" 
                                        Text='<%# Eval("C3", "{0:N0}") %>' />
                                </td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style3" colspan="2" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    行業別合計:&nbsp;
                                    <asp:Label ID="ATLabel" runat="server" Text='<%# Eval("AT", "{0:N0}") %>'></asp:Label>
                                </td>
                                <td class="style3" colspan="3" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    放款申貸用途合計:&nbsp;
                                    <asp:Label ID="BTLabel" runat="server" Text='<%# Eval("BT", "{0:N0}") %>'></asp:Label>
                                </td>
                                <td bgcolor="Khaki" class="style3" colspan="3" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    分行別合計:&nbsp;
                                    <asp:Label ID="CTLabel" runat="server" Text='<%# Eval("CT", "{0:N0}") %>'></asp:Label>
                                </td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style3" colspan="5" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    放款合計<span ID="Label2" style="FONT-FAMILY: 標楷體; COLOR: red">(放款合計,行業別合計,放款申貸用途合計,分行別合計 
                                    需相等)</span></td>
                                <td class="style3" colspan="3" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="D1Label" runat="server" Text='<%# Eval("D1", "{0:N0}") %>' />
                                </td>
                            </tr>
                        </table>
                        <table border="2" cellpadding="2" cellspacing="2" class="style2" 
                            style="border-style: solid; border-color: #000000" width="100%">
                            <tr>
                                <td bgcolor="Khaki" class="style5" colspan="4" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    保證款項資金運用於中國大陸餘額</td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="16%">
                                    &nbsp;</td>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="28%">
                                    商業本票保證</td>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="28%">
                                    發行公司債</td>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    其他</td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    DBU</td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="E1_DBULabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("E1_DBU", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="E2_DBULabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("E2_DBU", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="E3_DBULabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("E3_DBU", "{0:N0}") %>' />
                                </td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    OBU</td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="E1_OBULabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("E1_OBU", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="E2_OBULabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("E2_OBU", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="E3_OBULabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("E3_OBU", "{0:N0}") %>' />
                                </td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    海外</td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="E1_OverLabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("E1_Over", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="E2_OverLabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("E2_Over", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="E3_OverLabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("E3_Over", "{0:N0}") %>' />
                                </td>
                            </tr>
                        </table>
                        <table border="2" cellpadding="2" cellspacing="2" class="style2" 
                            style="border-style: solid; border-color: #000000" width="100%">
                            <tr>
                                <td bgcolor="Khaki" class="style5" colspan="8" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    應收帳款收買業務資金運用於中國大陸餘額(依分別行填報)</td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style5" colspan="6" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    分行別</td>
                                <td bgcolor="Khaki" class="style5" rowspan="2" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="14%">
                                    分行別合計</td>
                                <td rowspan="2" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="F1Label" runat="server" CssClass="style3" 
                                        Text='<%# Eval("F1", "{0:N0}") %>' />
                                </td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="12%">
                                    DBU</td>
                                <td style="border-style: solid; border-color: #000000; text-align: right;" 
                                    width="13%">
                                    <asp:Label ID="F_DBULabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("F_DBU", "{0:N0}") %>' />
                                </td>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="12%">
                                    OBU</td>
                                <td style="border-style: solid; border-color: #000000; text-align: right;" 
                                    width="13%">
                                    <asp:Label ID="F_OBULabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("F_OBU", "{0:N0}") %>' />
                                </td>
                                <td bgcolor="Khaki" class="style5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="12%">
                                    海外分行</td>
                                <td style="border-style: solid; border-color: #000000; text-align: right;" 
                                    width="13%">
                                    <asp:Label ID="F_OverLabel" runat="server" CssClass="style3" 
                                        Text='<%# Eval("F_Over", "{0:N0}") %>' />
                                </td>
                            </tr>
                        </table>
                        <table border="2" cellpadding="2" cellspacing="2" class="style2" 
                            style="border-style: solid; border-color: #000000" width="100%">
                            <tr>
                                <td bgcolor="Khaki" class="style6" colspan="5" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    資金運用於中國大陸帳列金額逾期三個月以上(依分別行填報)</td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style6" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="11%">
                                    &nbsp;</td>
                                <td bgcolor="Khaki" class="style6" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="22%">
                                    放款(D)</td>
                                <td bgcolor="Khaki" class="style6" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="22%">
                                    保證墊款(E)</td>
                                <td bgcolor="Khaki" class="style6" 
                                    style="border-style: solid; border-color: #000000; text-align: center;" 
                                    width="22%">
                                    應收帳款收買(E)</td>
                                <td bgcolor="Khaki" class="style6" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    合計(D+E+F)</td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style6" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    DBU</td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="G1_DBULabel" runat="server" 
                                        Text='<%# Eval("G1_DBU", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="G2_DBULabel" runat="server" 
                                        Text='<%# Eval("G2_DBU", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="G3_DBULabel" runat="server" 
                                        Text='<%# Eval("G3_DBU", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="GT_DBULabel" runat="server" 
                                        Text='<%# Eval("GT_DBU", "{0:N0}") %>'></asp:Label>
                                </td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style6" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    OBU</td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="G1_OBULabel" runat="server" 
                                        Text='<%# Eval("G1_OBU", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="G2_OBULabel" runat="server" 
                                        Text='<%# Eval("G2_OBU", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="G3_OBULabel" runat="server" 
                                        Text='<%# Eval("G3_OBU", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="GT_OBULabel" runat="server" 
                                        Text='<%# Eval("GT_OBU", "{0:N0}") %>'></asp:Label>
                                </td>
                            </tr>
                            <tr>
                                <td bgcolor="Khaki" class="style6" 
                                    style="border-style: solid; border-color: #000000; text-align: center;">
                                    海外</td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="G1_OverLabel" runat="server" 
                                        Text='<%# Eval("G1_Over", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="G2_OverLabel" runat="server" 
                                        Text='<%# Eval("G2_Over", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="G3_OverLabel" runat="server" 
                                        Text='<%# Eval("G3_Over", "{0:N0}") %>' />
                                </td>
                                <td class="style7" 
                                    style="border-style: solid; border-color: #000000; text-align: right;">
                                    <asp:Label ID="GT_OverLabel" runat="server" 
                                        Text='<%# Eval("GT_Over", "{0:N0}") %>'></asp:Label>
                                </td>
                            </tr>
                        </table>

                        <table class="style8" width="100%">
                            <tr>
                                <td class="style11" width="35%">
                                    &nbsp;</td>
                                <td class="style11" width="33%">
                                    &nbsp;</td>
                                <td class="style11">
                                    &nbsp;</td>
                            </tr>
                            <tr>
                                <td class="style9" width="35%">
                                    經理：</td>
                                <td class="style9" width="33%">
                                    負責人：</td>
                                <td class="style9">
                                    經辦：</td>
                            </tr>
                        </table>

                    </ItemTemplate>
                </asp:FormView>
            
                <br />
                    </div>
    <asp:SqlDataSource ID="sdsData" runat="server" 
        ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
        SelectCommand="select a.DocNo, a.Brno, a.BRName, a.EmpID, a.EmpName, Ext, a.YYYMM, b.Sign1, c.NAME
, A1, A2, A1 + A2 as AT
, B1, B2, B3, B1 + B2 + B3 AS BT 
, C1, C2, C3, C1 + C2 + C3 AS CT
, D1, E1, E2, E3, F1, G1, G2, G3
, E1_DBU, E1_OBU, E1_Over
, E2_DBU, E2_OBU, E2_Over
, E3_DBU, E3_OBU, E3_Over
, F_DBU, F_OBU, F_Over
, G1_DBU, G2_DBU, G3_DBU, G1_DBU + G2_DBU + G3_DBU as GT_DBU
, G1_OBU, G2_OBU, G3_OBU, G1_OBU + G2_OBU + G3_OBU as GT_OBU
, G1_Over, G2_Over, G3_Over, G1_Over + G2_Over + G3_Over as GT_Over
from tblMoneyInChina a
left join tblLogDetail b on a.DocNo = b.DocNo 
left join chb_pub..EMPLOYEE c on b.Sign1 = c.STAFF 
where YYYMM = cast(@YYY as nvarchar(3)) + cast(@MM as nvarchar(2)) and a.Brno = @BrNo">
        <SelectParameters>
            <asp:ControlParameter ControlID="ddl年" DefaultValue="" Name="YYY" 
                PropertyName="SelectedValue" />
            <asp:ControlParameter ControlID="ddl月" Name="MM" PropertyName="SelectedValue" />
            <asp:ControlParameter ControlID="hfBrNo" DefaultValue="" Name="BrNo" 
                PropertyName="Value" />
        </SelectParameters>
    </asp:SqlDataSource>
    <asp:HiddenField ID="hfBrNo" runat="server" />

    </form>

    
</body>
</html>
