﻿// JScript 檔
function ChkDataFlag()         
         { 
         
            var EXT=document.forms['form1'].txt_Ext.value;//分機          
            
            
            //放款資金運用於中國大陸餘額
            
            //A.行業別
            var A1=document.forms['form1'].txt_A1.value;//傳統業
            var A2=document.forms['form1'].txt_A2.value;//科技業
            
            //B.放款申貸用途
            var B1=document.forms['form1'].txt_B1.value;//企業投資
            var B2=document.forms['form1'].txt_B2.value;//週轉金
            var B3=document.forms['form1'].txt_B3.value;//其 他
            
            //C.分行別
            var C1=document.forms['form1'].txt_C1.value;//DBU
            var C2=document.forms['form1'].txt_C2.value;//OBU
            var C3=document.forms['form1'].txt_C3.value;//海外分行
            
            //D.放款合計(放款合計=行業別合計=放款申貸用途合計=分行別合計)
            var D1=document.forms['form1'].txt_D1.value;//放款合計
            
            //E.保證款項資金運用於中國大陸餘額
            var E1=document.forms['form1'].txt_E1.value;//商業本票保證
            var E2=document.forms['form1'].txt_E2.value;//發行公司債
            var E3=document.forms['form1'].txt_E3.value;//其他
            
            //F.應收帳款收買業務資金運用於中國大陸餘額
            var F1=document.forms['form1'].txt_F1.value;//
            
            //G.資金運用於中國大陸帳列金額逾期三個月以上
            var G1=document.forms['form1'].txt_G1.value;//放款
            var G2=document.forms['form1'].txt_G2.value;//保證墊款
            var G3=document.forms['form1'].txt_G3.value;//應收帳款收買        
            
           
      
             if (EXT=="")
            {
                alert("分機必填");
               return false;
            }
                      
             //非空值       
             if (A1=="" || A2=="" || B1=="" || B2==""|| B3==""|| C1=="" || C2=="" || C3=="" || D1==""|| E1=="" || E2==""|| E3==""||  F1=="" || G1=="" || G2=="" || G3=="")
             {
               alert("每月金額欄位為必填");
               return false;
             }   
             
             
             //非數值
             if (isNaN(A1)||isNaN(A2)||isNaN(B1)||isNaN(B2)||isNaN(B3)||isNaN(C1)||isNaN(C2)||isNaN(C3)||isNaN(D1)||isNaN(E1)||isNaN(E2)||isNaN(E3)||isNaN(F1)||isNaN(G1)||isNaN(G2)||isNaN(G3))
              {
               alert("每月金額欄位為數字");
               return false;
              }   
             
              var ATotal = parseInt(A1)+parseInt(A2); //行業別
              var BTotal = parseInt(B1)+parseInt(B2)+parseInt(B3);//放款申貸用途
              var CTotal = parseInt(C1)+parseInt(C2)+parseInt(C3);//分行別
              //放款合計(放款合計=行業別合計=放款申貸用途合計=分行別合計)
              //alert("ATotal:"+ ATotal);
              //alert("BTotal:"+ BTotal);
              //alert("CTotal:"+ CTotal);
              //alert("D1:"+ D1);
              
              
              if(ATotal == BTotal && BTotal == CTotal && CTotal== D1)
              {
                return true;                
               }
              else
              {
                 alert("放款合計,行業別合計,放款申貸用途合計,分行別合計 需相等");
                return false;
              }   
             
             
            
              alert("儲存完畢!");
              return true;
         }
         
         
         
         //無該當
         function ChkDataFlag2()
         { 
             var EXT=document.forms['form1'].txt_Ext.value;//分機
             
               if (EXT=="")
            {
                alert("分機必填");
               return false;
            }
                return true;
         }
         
         
         
         
         
         //小計
         function Add()         
         { 
            //行業別
            var A1=document.forms['form1'].txt_A1.value;//傳統業
            var A2=document.forms['form1'].txt_A2.value;//科技業
            
            //放款申貸用途
            var B1=document.forms['form1'].txt_B1.value;//企業投資
            var B2=document.forms['form1'].txt_B2.value;//週轉金
            var B3=document.forms['form1'].txt_B3.value;//其 他
            
            //分行別
            var C1=document.forms['form1'].txt_C1.value;//DBU
            var C2=document.forms['form1'].txt_C2.value;//OBU
            var C3=document.forms['form1'].txt_C3.value;//海外分行
            
            
            var AT = parseInt(A1)+parseInt(A2); //行業別
            document.forms['form1'].txt_AT.value = money_format(AT,0)
            
            var BT = parseInt(B1)+parseInt(B2)+parseInt(B3);//放款申貸用途
            document.forms['form1'].txt_BT.value =  money_format(BT,0)
            
            var CT = parseInt(C1)+parseInt(C2)+parseInt(C3);//分行別
            document.forms['form1'].txt_CT.value =  money_format(CT,0)
                      
           return  CT 
            
         }
         
        //金額格式轉換(value =數字,fixed = 小數點位數,currency = 貨幣代號NT)
       function money_format(value,fixed,currency)
        {
	        var fixed = fixed || 0;
	        var currency = currency || '';
	        isNaN(parseFloat(value))? value=0 : value=parseFloat(value);
	        v = value.toFixed(fixed).toString();
	        var ps = v.split('.');
	        var whole = ps[0];
	        var sub = ps[1] ? '.' + ps[1] : '';
	        var r = /(\d+)(\d{3})/;
	        while (r.test(whole)) 
	        {
		        whole = whole.replace(r, '$1' + ',' + '$2');
	        }
	        v = whole + sub;
	        if (v.charAt(0) == '-') 
	        {
		        return currency + '-'  + v.substr(1);
	        }
	        return currency + v;
        }