﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODR1010.aspx.vb" Inherits="Program_ODR1010_ODR1010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
    <%--<script language="JavaScript" type="text/javascript" src="ODR1010.js"></script>--%> 
    <script language="JavaScript" type="text/javascript">
    
        function ChkDataFlag() {

            var EXT = document.forms['form1'].txt_Ext.value; //分機          
            
            //放款資金運用於中國大陸餘額
            //A.行業別
            var A1 = document.forms['form1'].txt_A1.value; //傳統業
            var A2 = document.forms['form1'].txt_A2.value; //科技業

            //B.放款申貸用途
            var B1 = document.forms['form1'].txt_B1.value; //企業投資
            var B2 = document.forms['form1'].txt_B2.value; //週轉金
            var B3 = document.forms['form1'].txt_B3.value; //其 他

            //C.分行別
            var C1 = document.forms['form1'].txt_C1.value; //DBU
            var C2 = document.forms['form1'].txt_C2.value; //OBU
            var C3 = document.forms['form1'].txt_C3.value; //海外分行

            //D.放款合計(放款合計=行業別合計=放款申貸用途合計=分行別合計)
            var D1 = document.forms['form1'].txt_D1.value; //放款合計

            //E.保證款項資金運用於中國大陸餘額
            var E1 = document.forms['form1'].txt_E1.value; //商業本票保證
            var E2 = document.forms['form1'].txt_E2.value; //發行公司債
            var E3 = document.forms['form1'].txt_E3.value; //其他

            //F.應收帳款收買業務資金運用於中國大陸餘額
            var F1 = document.forms['form1'].txt_F1.value; 

            //G.資金運用於中國大陸帳列金額逾期三個月以上
            var G1 = document.forms['form1'].txt_G1.value; //放款
            var G2 = document.forms['form1'].txt_G2.value; //保證墊款
            var G3 = document.forms['form1'].txt_G3.value; //應收帳款收買        
      
            if (EXT == "") {
                alert("分機必填");
                return false;
            }

            //非空值       
            if (A1 == "" || A2 == "" || B1 == "" || B2 == "" || B3 == "" || C1 == "" || C2 == "" || C3 == "" || D1 == "" || E1 == "" || E2 == "" || E3 == "" || F1 == "" || G1 == "" || G2 == "" || G3 == "") {
                alert("每月金額欄位為必填");
                return false;
            }
            
            //非數值
            if (isNaN(A1) || isNaN(A2) || isNaN(B1) || isNaN(B2) || isNaN(B3) || isNaN(C1) || isNaN(C2) || isNaN(C3) || isNaN(D1) || isNaN(E1) || isNaN(E2) || isNaN(E3) || isNaN(F1) || isNaN(G1) || isNaN(G2) || isNaN(G3)) {
                alert("每月金額欄位為數字");
                return false;
            }

            var ATotal = parseInt(A1) + parseInt(A2); //行業別
            var BTotal = parseInt(B1) + parseInt(B2) + parseInt(B3); //放款申貸用途
            var CTotal = parseInt(C1) + parseInt(C2) + parseInt(C3); //分行別
            //放款合計(放款合計=行業別合計=放款申貸用途合計=分行別合計)
            //alert("ATotal:"+ ATotal);
            //alert("BTotal:"+ BTotal);
            //alert("CTotal:"+ CTotal);
            //alert("D1:"+ D1);
            
            if (ATotal == BTotal && BTotal == CTotal && CTotal == D1) {
                return true;
            }
            else {
                alert("放款合計,行業別合計,放款申貸用途合計,分行別合計 需相等");
                return false;
            }
            
            alert("儲存完畢!");
            return true;
        }

        function ChkDataFlagNew() {
                 
            var EXT = document.forms['form1'].txt_Ext.value; //分機          

            //放款資金運用於中國大陸餘額
            //A.行業別
            var A1 = document.forms['form1'].txt_A1.value; //傳統業
            var A2 = document.forms['form1'].txt_A2.value; //科技業

            //B.放款申貸用途
            var B1 = document.forms['form1'].txt_B1.value; //企業投資
            var B2 = document.forms['form1'].txt_B2.value; //週轉金
            var B3 = document.forms['form1'].txt_B3.value; //其 他

            //C.分行別
            var C1 = document.forms['form1'].txt_C1.value; //DBU
            var C2 = document.forms['form1'].txt_C2.value; //OBU
            var C3 = document.forms['form1'].txt_C3.value; //海外分行

            //D.放款合計(放款合計=行業別合計=放款申貸用途合計=分行別合計)
            var D1 = document.forms['form1'].txt_D1.value; //放款合計

            //E.保證款項資金運用於中國大陸餘額
            var E1_DBU = document.forms['form1'].txtE1_DBU.value; //商業本票保證(DBU)
            var E1_OBU = document.forms['form1'].txtE1_OBU.value; //OBU
            var E1_Over = document.forms['form1'].txtE1_Over.value; //Over
            var E2_DBU = document.forms['form1'].txtE2_DBU.value; //發行公司債(DBU)
            var E2_OBU = document.forms['form1'].txtE2_OBU.value; //OBU
            var E2_Over = document.forms['form1'].txtE2_Over.value; //Over
            var E3_DBU = document.forms['form1'].txtE3_DBU.value; //其他(DBU)
            var E3_OBU = document.forms['form1'].txtE3_OBU.value; //OBU
            var E3_Over = document.forms['form1'].txtE3_Over.value; //Over

            //F.應收帳款收買業務資金運用於中國大陸餘額
            var F_DBU = document.forms['form1'].txtF_DBU.value; //DBU
            var F_OBU = document.forms['form1'].txtF_OBU.value; //OBU
            var F_Over = document.forms['form1'].txtF_Over.value; //Over

            //G.資金運用於中國大陸帳列金額逾期三個月以上
            var G1_DBU = document.forms['form1'].txtG1_DBU.value; //放款(DBU)
            var G1_OBU = document.forms['form1'].txtG1_OBU.value;
            var G1_Over = document.forms['form1'].txtG1_Over.value;
            var G2_DBU = document.forms['form1'].txtG2_DBU.value; //保證墊款(DBU)
            var G2_OBU = document.forms['form1'].txtG2_OBU.value;
            var G2_Over = document.forms['form1'].txtG2_Over.value;  
            var G3_DBU = document.forms['form1'].txtG3_DBU.value; //應收帳款收買(DBU)
            var G3_OBU = document.forms['form1'].txtG3_OBU.value;
            var G3_Over = document.forms['form1'].txtG3_Over.value; 

            if (EXT == "") {
                alert("分機必填");
                return false;
            }

            //非空值       
            if (A1 == "" || A2 == "" || B1 == "" || B2 == "" || B3 == "" || C1 == "" || C2 == "" || C3 == "" || D1 == "" || E1_DBU == "" || E1_OBU == "" || E1_Over == "" || E2_DBU == "" || E2_OBU == "" || E2_Over == "" || E3_DBU == "" || E3_OBU == "" || E3_Over == "" || F_DBU == "" || F_OBU == "" || F_Over == "" || G1_DBU == "" || G1_OBU == "" || G1_Over == "" || G2_DBU == "" || G2_OBU == "" || G2_Over == "" || G3_DBU == "" || G3_OBU == "" || G3_Over == "") {
                alert("每月金額欄位為必填");
                return false;
            }

            //非數值
            if (isNaN(A1) || isNaN(A2) || isNaN(B1) || isNaN(B2) || isNaN(B3) || isNaN(C1) || isNaN(C2) || isNaN(C3) || isNaN(D1) || isNaN(E1_DBU) || isNaN(E1_OBU) || isNaN(E1_Over) || isNaN(E2_DBU) || isNaN(E2_OBU) || isNaN(E2_Over) || isNaN(E3_DBU) || isNaN(E3_OBU) || isNaN(E3_Over) || isNaN(F_DBU) || isNaN(F_OBU) || isNaN(F_Over) || isNaN(G1_DBU) || isNaN(G1_OBU) || isNaN(G1_Over) || isNaN(G2_DBU) || isNaN(G2_OBU) || isNaN(G2_Over) || isNaN(G3_DBU) || isNaN(G3_OBU) || isNaN(G3_Over)) {
                alert("每月金額欄位為數字");
                return false;
            }

            var ATotal = parseInt(A1) + parseInt(A2); //行業別
            var BTotal = parseInt(B1) + parseInt(B2) + parseInt(B3); //放款申貸用途
            var CTotal = parseInt(C1) + parseInt(C2) + parseInt(C3); //分行別

            if (ATotal == BTotal && BTotal == CTotal && CTotal == D1) {
                return true;
            }
            else {
                alert("放款合計,行業別合計,放款申貸用途合計,分行別合計 需相等");
                return false;
            }

            alert("儲存完畢!");
            return true;
        }

        
        //無該當
        function ChkDataFlag2() {
            var EXT = document.forms['form1'].txt_Ext.value; //分機

            if (EXT == "") {
                alert("分機必填");
                return false;
            }
            return true;
        }
        
        //小計
        function Add() {

            //行業別
            var A1 = document.forms['form1'].txt_A1.value; //傳統業
            var A2 = document.forms['form1'].txt_A2.value; //科技業

            //放款申貸用途
            var B1 = document.forms['form1'].txt_B1.value; //企業投資
            var B2 = document.forms['form1'].txt_B2.value; //週轉金
            var B3 = document.forms['form1'].txt_B3.value; //其 他

            //分行別
            var C1 = document.forms['form1'].txt_C1.value; //DBU
            var C2 = document.forms['form1'].txt_C2.value; //OBU
            var C3 = document.forms['form1'].txt_C3.value; //海外分行

            //2012.2.8 modify 新增分行別
            var fmt = document.forms['form1'].hfNew.value;
            if (fmt == 1) {
                //自101年3月起填報者適用新格式
                //應收帳款收買業務(分行別)
                var FDBU = document.forms['form1'].txtF_DBU.value;
                var FOBU = document.forms['form1'].txtF_OBU.value;
                var FOver = document.forms['form1'].txtF_Over.value;

                //資金運用於中國大陸帳列金額逾期三個月以上(DBU)
                var G1_DBU = document.forms['form1'].txtG1_DBU.value; //放款
                var G2_DBU = document.forms['form1'].txtG2_DBU.value; //保證墊款
                var G3_DBU = document.forms['form1'].txtG3_DBU.value; //應收帳款收買

                //資金運用於中國大陸帳列金額逾期三個月以上(OBU)
                var G1_OBU = document.forms['form1'].txtG1_OBU.value; //放款
                var G2_OBU = document.forms['form1'].txtG2_OBU.value; //保證墊款
                var G3_OBU = document.forms['form1'].txtG3_OBU.value; //應收帳款收買

                //資金運用於中國大陸帳列金額逾期三個月以上(海外)
                var G1_Over = document.forms['form1'].txtG1_Over.value; //放款
                var G2_Over = document.forms['form1'].txtG2_Over.value; //保證墊款
                var G3_Over = document.forms['form1'].txtG3_Over.value; //應收帳款收買

                var FT = parseInt(FDBU) + parseInt(FOBU) + parseInt(FOver); //應收帳款收買分行別合計
                document.forms['form1'].txtFT_New.value = money_format(FT, 0)

                var GT_DBU = parseInt(G1_DBU) + parseInt(G2_DBU) + parseInt(G3_DBU); //DBU合計
                document.forms['form1'].txtGT_DBU.value = money_format(GT_DBU, 0)

                var GT_OBU = parseInt(G1_OBU) + parseInt(G2_OBU) + parseInt(G3_OBU); //OBU合計
                document.forms['form1'].txtGT_OBU.value = money_format(GT_OBU, 0)

                var GT_Over = parseInt(G1_Over) + parseInt(G2_Over) + parseInt(G3_Over); //海外合計
                document.forms['form1'].txtGT_Over.value = money_format(GT_Over, 0)
            }
     
            var AT = parseInt(A1) + parseInt(A2); //行業別
            document.forms['form1'].txt_AT.value = money_format(AT, 0)

            var BT = parseInt(B1) + parseInt(B2) + parseInt(B3); //放款申貸用途
            document.forms['form1'].txt_BT.value = money_format(BT, 0)

            var CT = parseInt(C1) + parseInt(C2) + parseInt(C3); //分行別
            document.forms['form1'].txt_CT.value = money_format(CT, 0)
            
            return CT
           
        }

        //金額格式轉換(value =數字,fixed = 小數點位數,currency = 貨幣代號NT)
        function money_format(value, fixed, currency) {
            var fixed = fixed || 0;
            var currency = currency || '';
            isNaN(parseFloat(value)) ? value = 0 : value = parseFloat(value);
            v = value.toFixed(fixed).toString();
            var ps = v.split('.');
            var whole = ps[0];
            var sub = ps[1] ? '.' + ps[1] : '';
            var r = /(\d+)(\d{3})/;
            while (r.test(whole)) {
                whole = whole.replace(r, '$1' + ',' + '$2');
            }
            v = whole + sub;
            if (v.charAt(0) == '-') {
                return currency + '-' + v.substr(1);
            }
            return currency + v;
        }

    </script>
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <table border="2" cellpadding="2" cellspacing="2" style="width: 726px">
            <tr>
                <td bgcolor="khaki">
                    <asp:Label ID="Label5" runat="server" Font-Size="Small" ForeColor="Red" Text="ODR1010"></asp:Label></td>
                <td>
                    <asp:Label ID="Label4" runat="server" Font-Size="Medium" ForeColor="Red" Text="本國銀行資金運用於大陸彙總表" Width="241px" Font-Bold="True" Font-Names="標楷體"></asp:Label></td>
                <td bgcolor="khaki">
                    功 能：</td>
                <td colspan="3" align = "center">
                    &nbsp;&nbsp;
                    <asp:Button ID="BtnAdd" runat="server" Text="新  增" ValidationGroup="1" />
                    &nbsp; &nbsp;
                    <asp:Button ID="BtnMod" runat="server" Text="修  改" ValidationGroup="1" />
                    &nbsp;&nbsp;
                    <asp:Button ID="BtnDel" runat="server" Text="刪  除" />
                    &nbsp;&nbsp;
                    <asp:Button ID="BtnNoCheck" runat="server" ForeColor="Red" Text="無該當" /></td>
            </tr>
            <tr>
                <td bgcolor="khaki">
                    表單號碼：</td>
                <td >
                    <asp:Label ID="lblDOCNO" runat="server" Font-Size="Medium" ForeColor="Red" Text="Label"></asp:Label></td>
                <td bgcolor="khaki">
                    狀 態：</td>
                <td align = "center" style="height: 30px">
                    <asp:TextBox ID="txt_status" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                    &nbsp;<asp:TextBox ID="txtDate" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    &nbsp;版 本:<span id="Label11" class="TBLHR" style="font-size: 9pt"></span></td>
                <td align = "center" style="height: 30px">
                    <asp:TextBox ID="txtVer" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="50px"></asp:TextBox></td>
            </tr>
            <tr>
                <td bgcolor="khaki">
                    分 行：</td>
                <td align = "center">
                    &nbsp;
                    <asp:TextBox ID="txt_Brno" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;&nbsp;&nbsp;
                    <asp:TextBox ID="txt_Brno_Name" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="70px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    經 辦：</td>
                <td align = "center">
                    &nbsp;<asp:TextBox ID="txt_EmpID" runat="server" BackColor="#E0E0E0" BorderColor="White"
                        ReadOnly="True" Width="70px"></asp:TextBox>&nbsp; &nbsp;<asp:TextBox ID="txt_EmpName"
                            runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                </td>
                <td bgcolor="khaki">
                    分 機：</td>
                <td align = "center">
                    &nbsp;<asp:TextBox ID="txt_Ext" runat="server" MaxLength="4" ValidationGroup="1"
                        Width="50px"></asp:TextBox></td>
            </tr>
            <tr>
                <td bgcolor="khaki">
                    所屬年月：</td>
                <td align = "center">
                    &nbsp;
                    <asp:TextBox ID="txt_YYYMM" runat="server" BackColor="#E0E0E0" MaxLength="5" ReadOnly="True"
                        Width="70px"></asp:TextBox>
                    </td>
                <td bgcolor="khaki">
                    承 辦 人：</td>
                <td align = "center">
                    財管處#2339</td>
                <td bgcolor="khaki">
                    申報日期:</td>
                <td >
                    &nbsp;<asp:TextBox ID="txt_RecordDate" runat="server" BackColor="#E0E0E0" MaxLength="5"
                        ReadOnly="True" Width="70px"></asp:TextBox></td>
            </tr>
        </table>
    
    </div>
        <table border="2" cellpadding="2" cellspacing="2" style="width: 726px">
            <tr>
                <td  bgcolor="khaki">
                    負責人:</td>
                <td colspan="2"  align = "center">
                    &nbsp;<asp:TextBox ID="txtSign1" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="70px"></asp:TextBox>&nbsp; &nbsp;<asp:TextBox ID="txtSign1Name" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="70px"></asp:TextBox></td>
                <td  bgcolor="khaki">
                    簽 核 日:</td>
                <td align = "center">
                    &nbsp;<asp:TextBox ID="txtSignDate1" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="100px"></asp:TextBox></td>
                         <td  bgcolor="khaki">
                             簽 核:</td>
                         <td align = "center">
                             &nbsp;&nbsp;
                         </td>
                         
            </tr>
            <tr>
                <td  bgcolor="khaki" style="height: 64px" >
                    批 示:</td>
                <td colspan="6" style="height: 64px" >
                    &nbsp;<asp:TextBox ID="txtSignComment1" runat="server" BackColor="#E0E0E0" Height="50px"
                        ReadOnly="True" Width="650px"></asp:TextBox></td>
            </tr>
        </table>
        <br />
        <table style="width: 725px" border="2" cellpadding="2" cellspacing="2" >
            <tr align = "center">
                <td colspan="8" bgcolor="khaki">
                    放款資金運用於中國大陸餘額 &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
                    <asp:Label ID="Label1" runat="server" Font-Bold="False" Font-Names="標楷體" Font-Size="Medium"
                        ForeColor="Red" Text="單位: 新台幣百萬元 以下欄位最多為5位正整數"></asp:Label></td>
                
               
            </tr>
            <tr align = "center">
                <td  colspan="2" bgcolor="khaki" style="height: 22px">
                    行 業 別(A)</td>
                <td colspan="3" style="height: 22px" >
                    放 款 申 貸 用 途(B)</td>
                <td colspan="3" bgcolor="khaki" style="height: 22px">
                    分行別(C)</td>
            </tr>
            <tr align = "center">
                <td bgcolor="khaki">
                    傳統業(A1)</td>
                <td bgcolor="khaki">
                    科技業(A2)</td>
                <td >
                    企業投資(B1)</td>
                <td >
                    週轉金(B2)</td>
                <td  >
                    其 他(B3)</td>
                <td bgcolor="khaki">
                    DBU(C1)</td>
                <td bgcolor="khaki">
                    OBU(C2)</td>
                <td bgcolor="khaki">
                    海外分行(C3)</td>
               
            </tr>
             <tr align = "center">
                <td bgcolor="khaki">
                    <asp:TextBox ID="txt_A1" runat="server" Width="70px" MaxLength="5"></asp:TextBox></td>
                <td bgcolor="khaki">
                    <asp:TextBox ID="txt_A2" runat="server" Width="70px" MaxLength="5"></asp:TextBox></td>
                <td  >
                    <asp:TextBox ID="txt_B1" runat="server" Width="70px" MaxLength="5"></asp:TextBox></td>
                <td  >
                    <asp:TextBox ID="txt_B2" runat="server" Width="70px" MaxLength="5"></asp:TextBox></td>
                <td   style="width: 83px">
                    <asp:TextBox ID="txt_B3" runat="server" Width="70px" MaxLength="5"></asp:TextBox></td>
                <td  bgcolor="khaki">
                    <asp:TextBox ID="txt_C1" runat="server" Width="70px" MaxLength="5"></asp:TextBox></td>
                <td  bgcolor="khaki">
                    <asp:TextBox ID="txt_C2" runat="server" Width="70px" MaxLength="5"></asp:TextBox></td>
                <td  bgcolor="khaki">
                    <asp:TextBox ID="txt_C3" runat="server" Width="70px" MaxLength="5"></asp:TextBox></td>
               
            </tr>
             <tr align = "center">
                <td bgcolor="khaki" colspan="2">
                    行業別合計:<asp:TextBox ID="txt_AT" runat="server" Width="100px" ReadOnly="True" BackColor="#FFE0C0"></asp:TextBox></td>
               
                <td   colspan="3">
                    放款申貸用途合計:<asp:TextBox ID="txt_BT" runat="server" Width="100px" ReadOnly="True" BackColor="#FFE0C0"></asp:TextBox></td>
               
                <td  bgcolor="khaki" colspan="3">
                    分行別合計:<asp:TextBox ID="txt_CT" runat="server" Width="100px" ReadOnly="True" BackColor="#FFE0C0"></asp:TextBox></td>
              
               
            </tr>
             <tr align = "center">
                <td colspan="5" bgcolor="khaki">
                    放款合計<asp:Label ID="Label2" runat="server" Font-Names="標楷體" ForeColor="Red" Text="(放款合計,行業別合計,放款申貸用途合計,分行別合計 需相等)"></asp:Label></td>
                 <td colspan="3" bgcolor="khaki">
                     <asp:TextBox ID="txt_D1" runat="server" Width="240px" MaxLength="8"></asp:TextBox>&nbsp;</td>
               
            </tr>
        </table>

           <asp:Panel ID="pnlOld" runat="server">
               <table border="2" cellpadding="2" cellspacing="2" style="width: 725px">
                   <tr align="center">
                       <td bgcolor="khaki" colspan="3">
                           保證款項資金運用於中國大陸餘額</td>
                       <td rowspan="2">
                           應收帳款收買業務資金<br /> 運用於中國大陸餘額</td>
                       <td bgcolor="khaki" colspan="3" style="width: 279px">
                           資金運用於中國大陸帳列金額逾期三個月以上</td>
                   </tr>
                   <tr align="center">
                       <td bgcolor="khaki">
                           商業本票保證</td>
                       <td bgcolor="khaki">
                           發行公司債</td>
                       <td bgcolor="khaki">
                           其他</td>
                       <td bgcolor="khaki">
                           放款</td>
                       <td bgcolor="khaki">
                           保證墊款</td>
                       <td bgcolor="khaki" style="width: 98px">
                           應收帳款收買</td>
                   </tr>
                   <tr align="center">
                       <td bgcolor="khaki">
                           <asp:TextBox ID="txt_E1" runat="server" MaxLength="5" Width="70px"></asp:TextBox>
                       </td>
                       <td bgcolor="khaki">
                           <asp:TextBox ID="txt_E2" runat="server" MaxLength="5" Width="70px"></asp:TextBox>
                       </td>
                       <td bgcolor="khaki">
                           <asp:TextBox ID="txt_E3" runat="server" MaxLength="5" Width="70px"></asp:TextBox>
                       </td>
                       <td>
                           <asp:TextBox ID="txt_F1" runat="server" MaxLength="5" Width="70px"></asp:TextBox>
                       </td>
                       <td bgcolor="khaki">
                           <asp:TextBox ID="txt_G1" runat="server" MaxLength="5" Width="70px"></asp:TextBox>
                       </td>
                       <td bgcolor="khaki">
                           <asp:TextBox ID="txt_G2" runat="server" MaxLength="5" Width="70px"></asp:TextBox>
                       </td>
                       <td bgcolor="khaki" style="width: 98px">
                           <asp:TextBox ID="txt_G3" runat="server" MaxLength="5" Width="70px"></asp:TextBox>
                       </td>
                   </tr>
               </table>
    </asp:Panel>

                 
                <asp:Panel ID="pnlNew" runat="server">
                    <table border="2" cellpadding="2" cellspacing="2" style="width: 725px">
                        <tr align="center">
                            <td bgcolor="khaki" colspan="4">
                                保證款項資金運用於中國大陸餘額</td>
                        </tr>
                        <tr align="center">
                            <td bgcolor="khaki" width="16%">
                                &nbsp;</td>
                            <td bgcolor="khaki" width="28%">
                                商業本票保證</td>
                            <td bgcolor="khaki" width="28%">
                                發行公司債</td>
                            <td bgcolor="khaki" style="width: 45%">
                                其他</td>
                        </tr>
                        <tr align="center">
                            <td bgcolor="khaki">
                                DBU</td>
                            <td>
                                <asp:TextBox ID="txtE1_DBU" runat="server" MaxLength="5" Width="70%"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE2_DBU" runat="server" MaxLength="5" Width="70%"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE3_DBU" runat="server" MaxLength="5" Width="70%"></asp:TextBox>
                            </td>
                        </tr>
                        <tr align="center">
                            <td bgcolor="khaki">
                                OBU</td>
                            <td>
                                <asp:TextBox ID="txtE1_OBU" runat="server" MaxLength="5" Width="70%"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE2_OBU" runat="server" MaxLength="5" Width="70%"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE3_OBU" runat="server" MaxLength="5" Width="70%"></asp:TextBox>
                            </td>
                        </tr>
                        <tr align="center">
                            <td bgcolor="khaki">
                                海外</td>
                            <td>
                                <asp:TextBox ID="txtE1_Over" runat="server" MaxLength="5" Width="70%"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE2_Over" runat="server" MaxLength="5" Width="70%"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE3_Over" runat="server" MaxLength="5" Width="70%"></asp:TextBox>
                            </td>
                        </tr>
                    </table>

                    <table border="2" cellpadding="2" cellspacing="2" style="width: 725px">
                    <tr align="center">
                        <td bgcolor="khaki" colspan="8">
                            應收帳款收買業務資金運用於中國大陸餘額(依分別行填報)</td>
                    </tr>
                    <tr align="center">
                        <td bgcolor="khaki" colspan="6">
                            分行別</td>
                        <td bgcolor="khaki" rowspan="2">
                            分行別合計</td>
                        <td rowspan="2">
                            <asp:TextBox ID="txtFT_New" runat="server" BackColor="#FFE0C0" ReadOnly="True" 
                                Width="80px"></asp:TextBox>
                        </td>
                    </tr>
                     <tr align="center">
                         <td bgcolor="khaki">
                             DBU</td>
                         <td>
                             <asp:TextBox ID="txtF_DBU" runat="server" MaxLength="5" Width="70px"></asp:TextBox>
                         </td>
                         <td bgcolor="khaki">
                             OBU</td>
                         <td>
                             <asp:TextBox ID="txtF_OBU" runat="server" MaxLength="5" Width="70px"></asp:TextBox>
                         </td>
                         <td bgcolor="khaki">
                             海外分行</td>
                         <td>
                             <asp:TextBox ID="txtF_Over" runat="server" MaxLength="5" Width="70px"></asp:TextBox>
                         </td>
                     </tr>
                </table>

                <table border="2" cellpadding="2" cellspacing="2" style="width: 725px">
                    <tr align="center">
                        <td bgcolor="khaki" colspan="5">
                            資金運用於中國大陸帳列金額逾期三個月以上(依分別行填報)</td>
                    </tr>
                    <tr align="center">
                        <td bgcolor="khaki" width="11%">
                            &nbsp;</td>
                        <td bgcolor="khaki" width="22%">
                            放款(D)</td>
                        <td bgcolor="khaki" width="22%">
                            保證墊款(E)</td>
                        <td bgcolor="khaki" width="22%">
                            應收帳款收買(E)</td>
                        <td bgcolor="khaki" width="23%">
                            合計(D+E+F)</td>
                    </tr>
                    <tr align="center">
                        <td bgcolor="khaki">
                            DBU</td>
                        <td>
                            <asp:TextBox ID="txtG1_DBU" runat="server" MaxLength="5" Width="80%"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG2_DBU" runat="server" MaxLength="5" Width="80%"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG3_DBU" runat="server" MaxLength="5" Width="80%"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtGT_DBU" runat="server" BackColor="#FFE0C0" MaxLength="8" 
                                ReadOnly="True" Width="80%"></asp:TextBox>
                        </td>
                    </tr>
                    <tr align="center">
                        <td bgcolor="khaki">
                            OBU</td>
                        <td>
                            <asp:TextBox ID="txtG1_OBU" runat="server" MaxLength="5" Width="80%"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG2_OBU" runat="server" MaxLength="5" Width="80%"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG3_OBU" runat="server" MaxLength="5" Width="80%"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtGT_OBU" runat="server" BackColor="#FFE0C0" MaxLength="8" 
                                ReadOnly="True" Width="80%"></asp:TextBox>
                        </td>
                    </tr>
                    <tr align="center">
                        <td bgcolor="khaki">
                            海外</td>
                        <td>
                            <asp:TextBox ID="txtG1_Over" runat="server" MaxLength="5" Width="80%"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG2_Over" runat="server" MaxLength="5" Width="80%"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG3_Over" runat="server" MaxLength="5" Width="80%"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtGT_Over" runat="server" BackColor="#FFE0C0" MaxLength="8" 
                                ReadOnly="True" Width="80%"></asp:TextBox>
                        </td>
                    </tr>
                </table>
    </asp:Panel>
    <br />
                
        <br />
        <table>
            <tr>
                <td style="width: 814px; height: 78px">
                    註：1.本表填報單位包括本國銀行之國內各營業單位、國際金融業務分行及海外分行。。<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2.放款包括新台幣及外幣之短期貿易融資、貼現、擔保透支、短、中、長期擔保及無擔保放款及催收款項
                    (不包括保證、<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;承兌金額)； &nbsp;保證及應收帳款金額包括新台幣及外幣，外幣金額請按基準日中心匯率折算新台幣填報。<br />
                    &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;3.運用於大陸資金包括由經濟部投審會核准或報備之投資及未經核准但銀行依據與客戶往來研判可能用於大陸投資者。
                    <br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 4.「行業別」及「放款申貸用途」請填金額，「高科技產業」包括積體電路、通訊、精密機械、特用化學品與製藥、<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 資訊軟體、航太、生物科技等工業。
                    <br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5.國內總分支機構及國際金融業務分行依下列原則填報：
                    <br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (1)授信後資金匯至香港、澳門者全數填報，匯至其他地區者視情況填報；<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;(2)授信戶會計師簽證報告或聯合徵信中心查詢有資金運用於大陸者，按銀行授信餘額占全體銀行授信總額之比例，
                    <br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 乘以授信戶投資大陸金額填報。惟若銀行確知客戶授信資金非用於大陸者，可免填報。<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;(3)經實地查訪，授信客戶在台已無營運且已移往大陸投資者，全數填報。
                        <br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
                    海外分行請依上述（2）、（3）原則填報。
                    <br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 6.授信及應收帳款收買業務資金逾期三個月以上金額包括本金或利息延滯三個月以上<br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; （含列報逾期放款及尚未列報逾期放款）。<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7.行業別合計=放款申貸用途合計=分行別合計=放款合計&nbsp;<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 8.本報表請於次月5日前報送財管處會計業務科。</td>
            </tr>
        </table>
        <br />
        <br />
                    <asp:HiddenField ID="hidn_EMPID" runat="server" />
        <asp:HiddenField ID="hfNew" runat="server" />
        <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblLogDetail WHERE (DocNo = @DocNo1) and (DocType = 'DR')"
            InsertCommand="INSERT INTO tblLogDetail(DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, YYMM, FlowStatus, Ver) VALUES ('DR', @DocNo, @BrNo, @EmpId, GETDATE(), 'N', @YYMM, '1', 1)"
            SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
            
        
        UpdateCommand="UPDATE tblLogDetail SET EmpId = @EmpId, RecordDate = GETDATE(), Ver = @Ver, FlowStatus = '1' WHERE (DocNo = @DocNo)">
            <InsertParameters>
                <asp:ControlParameter ControlID="lblDOCNO" Name="DocNo" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_Brno" Name="BrNo" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_EmpID" Name="EmpId" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_YYYMM" Name="YYMM" PropertyName="Text" />
            </InsertParameters>
            <DeleteParameters>
                <asp:ControlParameter ControlID="lblDOCNO" Name="DocNo1" PropertyName="Text" />
            </DeleteParameters>
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <UpdateParameters>
                <asp:ControlParameter ControlID="txt_EmpID" Name="EmpId" PropertyName="Text" />
                <asp:Parameter Name="Ver" />
                <asp:ControlParameter ControlID="lblDOCNO" Name="DocNo" PropertyName="Text" />
            </UpdateParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblSysCode" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT TblId, TblCd, TblDesc, TblSeq FROM tblSysCode WHERE (TblId = '11') AND (TblCd =@TblCd  )">
            <SelectParameters>
                <asp:Parameter Name="TblCd" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_BRANCH" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT BRNO, BRNAME FROM chb_pub.dbo.BRANCH WHERE (BRNO = @gBrNo)">
            <SelectParameters>
                <asp:FormParameter FormField="gBrNo" Name="gBrNo" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_EMPLOYEE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT STAFF, NAME FROM chb_pub.dbo.EMPLOYEE WHERE (STAFF = @gEmpId)">
            <SelectParameters>
                <asp:FormParameter FormField="gEmpId" Name="gEmpId" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblMoneyInChina" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM [tblMoneyInChina] WHERE [DocNo] = @DocNo" InsertCommand="INSERT INTO tblMoneyInChina(DocNo, Brno, BRName, EmpID, EmpName, Ext, YYYMM, A1, A2, B1, B2, B3, C1, C2, C3, D1, E1, E2, E3, F1, G1, G2, G3, E1_DBU, E1_OBU, E1_Over, E2_DBU, E2_OBU, E2_Over, E3_DBU, E3_OBU, E3_Over, F_DBU, F_OBU, F_Over, G1_DBU, G1_OBU, G1_Over, G2_DBU, G2_OBU, G2_Over, G3_DBU, G3_OBU, G3_Over) VALUES (@DocNo, @Brno, @BRName, @EmpID, @EmpName, @Ext, @YYYMM, @A1, @A2, @B1, @B2, @B3, @C1, @C2, @C3, @D1, @E1, @E2, @E3, @F1, @G1, @G2, @G3, @E1_DBU, @E1_OBU, @E1_Over, @E2_DBU, @E2_OBU, @E2_Over, @E3_DBU, @E3_OBU, @E3_Over, @F_DBU, @F_OBU, @F_Over, @G1_DBU, @G1_OBU, @G1_Over, @G2_DBU, @G2_OBU, @G2_Over, @G3_DBU, @G3_OBU, @G3_Over)"
            SelectCommand="SELECT * FROM [tblMoneyInChina]" 
        
        
        
        
        UpdateCommand="UPDATE tblMoneyInChina SET Ext = @Ext, A1 = @A1, A2 = @A2, B1 = @B1, B2 = @B2, B3 = @B3, C1 = @C1, C2 = @C2, C3 = @C3, D1 = @D1, E1 = @E1, E2 = @E2, E3 = @E3, F1 = @F1, G1 = @G1, G2 = @G2, G3 = @G3, E1_DBU = @E1_DBU, E1_OBU = @E1_OBU, E1_Over = @E1_Over, E2_DBU = @E2_DBU, E2_OBU = @E2_OBU, E2_Over = @E2_Over, E3_DBU = @E3_DBU, E3_OBU = @E3_OBU, E3_Over = @E3_Over, F_DBU = @F_DBU, F_OBU = @F_OBU, F_Over = @F_Over, G1_DBU = @G1_DBU, G1_OBU = @G1_OBU, G1_Over = @G1_Over, G2_DBU = @G2_DBU, G2_OBU = @G2_OBU, G2_Over = @G2_Over, G3_DBU = @G3_DBU, G3_OBU = @G3_OBU, G3_Over = @G3_Over, EmpID = @EmpID, EmpName = @EmpName WHERE (DocNo = @DocNo)">
            <DeleteParameters>
                <asp:ControlParameter ControlID="lblDOCNO" Name="DocNo" PropertyName="Text" 
                    Type="String" />
            </DeleteParameters>
            <UpdateParameters>
                <asp:ControlParameter ControlID="txt_Ext" Name="Ext" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_A1" Name="A1" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_A2" Name="A2" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_B1" Name="B1" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_B2" Name="B2" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_B3" Name="B3" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_C1" Name="C1" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_C2" Name="C2" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_C3" Name="C3" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_D1" Name="D1" PropertyName="Text" />
                <asp:Parameter Name="E1" />
                <asp:Parameter Name="E2" />
                <asp:Parameter Name="E3" />
                <asp:Parameter Name="F1" />
                <asp:Parameter Name="G1" />
                <asp:Parameter Name="G2" />
                <asp:Parameter Name="G3" />
                <asp:ControlParameter ControlID="txtE1_DBU" Name="E1_DBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtE1_OBU" Name="E1_OBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtE1_Over" Name="E1_Over" 
                    PropertyName="Text" />
                <asp:ControlParameter ControlID="txtE2_DBU" Name="E2_DBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtE2_OBU" Name="E2_OBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtE2_Over" Name="E2_Over" 
                    PropertyName="Text" />
                <asp:ControlParameter ControlID="txtE3_DBU" Name="E3_DBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtE3_OBU" Name="E3_OBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtE3_Over" Name="E3_Over" 
                    PropertyName="Text" />
                <asp:ControlParameter ControlID="txtF_DBU" Name="F_DBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtF_OBU" Name="F_OBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtF_Over" Name="F_Over" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtG1_DBU" Name="G1_DBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtG1_OBU" Name="G1_OBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtG1_Over" Name="G1_Over" 
                    PropertyName="Text" />
                <asp:ControlParameter ControlID="txtG2_DBU" Name="G2_DBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtG2_OBU" Name="G2_OBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtG2_Over" Name="G2_Over" 
                    PropertyName="Text" />
                <asp:ControlParameter ControlID="txtG3_DBU" Name="G3_DBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtG3_OBU" Name="G3_OBU" PropertyName="Text" />
                <asp:ControlParameter ControlID="txtG3_Over" Name="G3_Over" 
                    PropertyName="Text" />
                <asp:ControlParameter ControlID="lblDOCNO" Name="DocNo" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_EmpID" Name="EmpID" PropertyName="Text" />
                <asp:ControlParameter ControlID="txt_EmpName" Name="EmpName" 
                    PropertyName="Text" />
            </UpdateParameters>
            <InsertParameters>
                <asp:ControlParameter ControlID="lblDOCNO" Name="DocNo" PropertyName="Text" 
                    Type="String" />
                <asp:ControlParameter ControlID="txt_Brno" Name="Brno" PropertyName="Text" 
                    Type="String" />
                <asp:ControlParameter ControlID="txt_Brno_Name" Name="BRName" 
                    PropertyName="Text" Type="String" />
                <asp:ControlParameter ControlID="txt_EmpID" Name="EmpID" PropertyName="Text" 
                    Type="String" />
                <asp:ControlParameter ControlID="txt_EmpName" Name="EmpName" 
                    PropertyName="Text" Type="String" />
                <asp:ControlParameter ControlID="txt_Ext" Name="Ext" PropertyName="Text" 
                    Type="String" />
                <asp:ControlParameter ControlID="txt_YYYMM" Name="YYYMM" PropertyName="Text" 
                    Type="String" />
                <asp:ControlParameter ControlID="txt_A1" Name="A1" PropertyName="Text" 
                    Type="Int32" DefaultValue="0" />
                <asp:ControlParameter ControlID="txt_A2" Name="A2" PropertyName="Text" 
                    Type="Int32" DefaultValue="0" />
                <asp:ControlParameter ControlID="txt_B1" Name="B1" PropertyName="Text" 
                    Type="Int32" DefaultValue="0" />
                <asp:ControlParameter ControlID="txt_B2" Name="B2" PropertyName="Text" 
                    Type="Int32" DefaultValue="0" />
                <asp:ControlParameter ControlID="txt_B3" Name="B3" PropertyName="Text" 
                    Type="Int32" DefaultValue="0" />
                <asp:ControlParameter ControlID="txt_C1" Name="C1" PropertyName="Text" 
                    Type="Int32" DefaultValue="0" />
                <asp:ControlParameter ControlID="txt_C2" Name="C2" PropertyName="Text" 
                    Type="Int32" DefaultValue="0" />
                <asp:ControlParameter ControlID="txt_C3" Name="C3" PropertyName="Text" 
                    Type="Int32" DefaultValue="0" />
                <asp:ControlParameter ControlID="txt_D1" Name="D1" PropertyName="Text" 
                    Type="Int32" DefaultValue="0" />
                <asp:Parameter Name="E1" Type="Int32" DefaultValue="0" />
                <asp:Parameter Name="E2" Type="Int32" DefaultValue="0" />
                <asp:Parameter Name="E3" Type="Int32" DefaultValue="0" />
                <asp:Parameter Name="F1" Type="Int32" DefaultValue="0" />
                <asp:Parameter Name="G1" Type="Int32" DefaultValue="0" />
                <asp:Parameter Name="G2" Type="Int32" DefaultValue="0" />
                <asp:Parameter Name="G3" Type="Int32" DefaultValue="0" />
                <asp:ControlParameter ControlID="txtE1_DBU" Name="E1_DBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtE1_OBU" Name="E1_OBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtE1_Over" Name="E1_Over" 
                    PropertyName="Text" DefaultValue="0" />
                <asp:ControlParameter ControlID="txtE2_DBU" Name="E2_DBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtE2_OBU" Name="E2_OBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtE2_Over" Name="E2_Over" 
                    PropertyName="Text" DefaultValue="0" />
                <asp:ControlParameter ControlID="txtE3_DBU" Name="E3_DBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtE3_OBU" Name="E3_OBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtE3_Over" Name="E3_Over" 
                    PropertyName="Text" DefaultValue="0" />
                <asp:ControlParameter ControlID="txtF_DBU" Name="F_DBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtF_OBU" Name="F_OBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtF_Over" Name="F_Over" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtG1_DBU" Name="G1_DBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtG1_OBU" Name="G1_OBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtG1_Over" Name="G1_Over" 
                    PropertyName="Text" DefaultValue="0" />
                <asp:ControlParameter ControlID="txtG2_DBU" Name="G2_DBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtG2_OBU" Name="G2_OBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtG2_Over" Name="G2_Over" 
                    PropertyName="Text" DefaultValue="0" />
                <asp:ControlParameter ControlID="txtG3_DBU" Name="G3_DBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtG3_OBU" Name="G3_OBU" PropertyName="Text" 
                    DefaultValue="0" />
                <asp:ControlParameter ControlID="txtG3_Over" Name="G3_Over" 
                    PropertyName="Text" DefaultValue="0" />
            </InsertParameters>
        </asp:SqlDataSource>
        <br />
        <br />
        <br />
    </form>
</body>
</html>
