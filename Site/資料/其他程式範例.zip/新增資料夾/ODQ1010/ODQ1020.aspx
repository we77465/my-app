﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODQ1020.aspx.vb" Inherits="Program_ODQ1010_ODQ1020" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <div>
            <table border="2" cellpadding="2" cellspacing="2" style="width: 726px">
                <tr>
                    <td bgcolor="khaki">
                        <asp:Label ID="Label5" runat="server" Font-Size="Small" ForeColor="Red" Text="ODQ1020"></asp:Label></td>
                    <td style="font-size: 12pt; color: #000000">
                        <asp:Label ID="Label4" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
                            ForeColor="Red" Text="台外幣放款餘額" Width="241px"></asp:Label></td>
                    <td bgcolor="khaki">
                        功 能：</td>
                    <td align="center" colspan="3">
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                    </td>
                </tr>
                <tr>
                    <td bgcolor="khaki">
                        表單號碼：</td>
                    <td>
                        <asp:Label ID="lblDOCNO" runat="server" Font-Size="Medium" ForeColor="Red" Text="Label"></asp:Label></td>
                    <td bgcolor="khaki" style="color: #000000">
                        狀 態：</td>
                    <td align="center" style="height: 30px">
                        <asp:TextBox ID="txt_status" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                        &nbsp;<asp:TextBox ID="txtDate" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki">
                        &nbsp;版 本:<span id="Label11" class="TBLHR" style="font-size: 9pt"></span></td>
                    <td align="center" style="height: 30px">
                        <asp:TextBox ID="txtVer" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="50px"></asp:TextBox></td>
                </tr>
                <tr>
                    <td bgcolor="khaki">
                        分 行：</td>
                    <td align="center">
                        &nbsp;
                        <asp:TextBox ID="txt_Brno" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>
                        &nbsp;&nbsp;
                        <asp:TextBox ID="txt_Brno_Name" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki">
                        經 辦：</td>
                    <td align="center">
                        &nbsp;<asp:TextBox ID="txt_EmpID" runat="server" BackColor="#E0E0E0" BorderColor="White"
                            ReadOnly="True" Width="70px"></asp:TextBox>&nbsp; &nbsp;<asp:TextBox ID="txt_EmpName"
                                runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                    </td>
                    <td bgcolor="khaki">
                        分 機：</td>
                    <td align="center">
                        &nbsp;<asp:TextBox ID="txt_Ext" runat="server" BackColor="#E0E0E0" MaxLength="4"
                            ValidationGroup="1" Width="50px"></asp:TextBox></td>
                </tr>
                <tr>
                    <td bgcolor="khaki">
                        所屬年月：</td>
                    <td align="center">
                        &nbsp;
                        <asp:TextBox ID="txt_YYYMM" runat="server" BackColor="#E0E0E0" MaxLength="5" ReadOnly="True"
                            Width="70px"></asp:TextBox>
                    </td>
                    <td bgcolor="khaki">
                        承 辦 人：</td>
                    <td align="center">
                        &nbsp;許 曉 萍&nbsp; #1852</td>
                    <td bgcolor="khaki">
                        申報日期:</td>
                    <td>
                        &nbsp;<asp:TextBox ID="txt_RecordDate" runat="server" BackColor="#E0E0E0" MaxLength="5"
                            ReadOnly="True" Width="70px"></asp:TextBox></td>
                </tr>
            </table>
        </div>
        <table border="2" cellpadding="2" cellspacing="2" style="width: 726px">
            <tr>
                <td bgcolor="khaki">
                    負責人:</td>
                <td align="center" colspan="2">
                    &nbsp;<asp:TextBox ID="txtSign1" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="70px"></asp:TextBox>&nbsp; &nbsp;<asp:TextBox ID="txtSign1Name" runat="server"
                            BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    簽 核 日:</td>
                <td align="center">
                    &nbsp;<asp:TextBox ID="txtSignDate1" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="100px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    簽 核:</td>
                <td align="center">
                    <asp:Button ID="BtnSign1OK" runat="server" ForeColor="Red" Text="決 行" />
                    &nbsp;
                    <asp:Button ID="BtnSign1Back" runat="server" ForeColor="Red" Text="退 回" /></td>
            </tr>
            <tr>
                <td bgcolor="khaki" style="height: 64px">
                    批 示:</td>
                <td colspan="6" style="height: 64px">
                    &nbsp;<asp:TextBox ID="txtSignComment1" runat="server" BackColor="White" Height="50px"
                        Width="650px"></asp:TextBox></td>
            </tr>
        </table>
        <br />
        <table border="2" cellpadding="2" cellspacing="2" style="width: 725px">
            <tr align="center">
                <td bgcolor="khaki" colspan="8">
                    台外幣放款餘額 &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
                    <asp:Label ID="Label1" runat="server" Font-Bold="False" Font-Names="標楷體" Font-Size="Medium"
                        ForeColor="Red" Text="單位: 新台幣千元"></asp:Label></td>
            </tr>
            <tr align="center" style="color: #000000; font-family: Times New Roman">
                <td bgcolor="khaki" colspan="2" style="height: 22px">
                    台幣放款餘額</td>
                <td colspan="3" style="height: 22px">
                    <asp:TextBox ID="txt_TWOVERAGE" runat="server"></asp:TextBox></td>
            </tr>
            <tr align="center" style="color: #000000; font-family: Times New Roman">
                <td bgcolor="khaki" colspan="2" style="height: 22px">
                    外幣放款餘額</td>
                <td colspan="3" style="height: 22px">
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                    <asp:TextBox ID="txt_OUTLETOVERAGE" runat="server"></asp:TextBox>&nbsp;
                    <asp:Label ID="Label2" runat="server" BackColor="Transparent" BorderColor="Transparent"
                        ForeColor="Red" Text="【限外指單位填報】"></asp:Label></td>
            </tr>
        </table>
        <br />
        <br />
        <asp:HiddenField ID="hidn_hUsrId" runat="server" />
        <br />
        <asp:HiddenField ID="hidn_EMPID" runat="server" />
        <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblLogDetail WHERE (DocNo = @DocNo1) and (DocType = 'DR')"
            InsertCommand="INSERT INTO [tblLogDetail] ([DocType], [DocNo], [BrNo], [EmpId], [RecordDate], [DataFlag], [FormType], [YYMM], [Sign1], [Action1], [SignDate1], [SignComment1], [Sign2], [Action2], [SignDate2], [SignComment2], [DecManager], [DecDate], [FlowStatus], [Ver]) VALUES (@DocType, @DocNo, @BrNo, @EmpId, @RecordDate, @DataFlag, @FormType, @YYMM, @Sign1, @Action1, @SignDate1, @SignComment1, @Sign2, @Action2, @SignDate2, @SignComment2, @DecManager, @DecDate, @FlowStatus, @Ver)"
            SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
            UpdateCommand="UPDATE [tblLogDetail] SET [Sign1] = @Sign1, [Action1] = @Action1, [SignDate1] = @SignDate1, [SignComment1] = @SignComment1,  [DecManager] = @DecManager, [DecDate] = @DecDate, [FlowStatus] = @FlowStatus WHERE [DocNo] = @DocNo">
            <InsertParameters>
                <asp:Parameter DefaultValue="" Name="DocType" Type="String" />
                <asp:Parameter DefaultValue="" Name="DocNo" Type="String" />
                <asp:Parameter Name="BrNo" Type="String" />
                <asp:Parameter Name="EmpId" Type="String" />
                <asp:Parameter DefaultValue="" Name="RecordDate" Type="DateTime" />
                <asp:Parameter DefaultValue="" Name="DataFlag" Type="String" />
                <asp:Parameter Name="FormType" Type="String" />
                <asp:Parameter Name="YYMM" Type="String" />
                <asp:Parameter Name="Sign1" Type="String" />
                <asp:Parameter Name="Action1" Type="String" />
                <asp:Parameter Name="SignDate1" Type="DateTime" />
                <asp:Parameter Name="SignComment1" Type="String" />
                <asp:Parameter Name="Sign2" Type="String" />
                <asp:Parameter Name="Action2" Type="String" />
                <asp:Parameter Name="SignDate2" Type="DateTime" />
                <asp:Parameter Name="SignComment2" Type="String" />
                <asp:Parameter Name="DecManager" Type="String" />
                <asp:Parameter Name="DecDate" Type="DateTime" />
                <asp:Parameter Name="FlowStatus" Type="String" />
                <asp:Parameter Name="Ver" Type="Int16" />
            </InsertParameters>
            <DeleteParameters>
                <asp:Parameter Name="DocNo1" />
            </DeleteParameters>
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <UpdateParameters>
                <asp:Parameter Name="Sign1" />
                <asp:Parameter Name="Action1" />
                <asp:Parameter Name="SignDate1" />
                <asp:Parameter Name="SignComment1" />
                <asp:Parameter Name="DecManager" />
                <asp:Parameter Name="DecDate" />
                <asp:Parameter Name="FlowStatus" />
                <asp:Parameter Name="DocNo" />
            </UpdateParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblSysCode" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT TblId, TblCd, TblDesc, TblSeq FROM tblSysCode WHERE (TblId = '11') AND (TblCd =@TblCd  )">
            <SelectParameters>
                <asp:Parameter Name="TblCd" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_BRANCH" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT BRNO, BRNAME FROM chb_pub.dbo.BRANCH WHERE (BRNO = @gBrNo)">
            <SelectParameters>
                <asp:FormParameter FormField="gBrNo" Name="gBrNo" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_EMPLOYEE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT STAFF, NAME FROM chb_pub.dbo.EMPLOYEE WHERE (STAFF = @gEmpId)">
            <SelectParameters>
                <asp:FormParameter FormField="gEmpId" Name="gEmpId" />
            </SelectParameters>
        </asp:SqlDataSource>
        <br />
        &nbsp;<br />
        <asp:SqlDataSource ID="DS_tblMoneyInChina" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM [tblLoanMonthDetail] WHERE [LOANS_DOCNO] = @LOANS_DOCNO" InsertCommand="INSERT INTO [tblLoanMonthDetail] ([LOANS_DOCNO], [LOANS_BRNO], [LOANS_BRNAME], [LOANS_EMPID], [LOANS_EMPNAME], [LOANS_EXT], [LOANS_YEARLY], [LOANS_MONTHLY], [LOANS_TW_OVERAGE], [LOANS_OUTLET_OVERAGE]) VALUES (@LOANS_DOCNO, @LOANS_BRNO, @LOANS_BRNAME, @LOANS_EMPID, @LOANS_EMPNAME, @LOANS_EXT, @LOANS_YEARLY, @LOANS_MONTHLY, @LOANS_TW_OVERAGE, @LOANS_OUTLET_OVERAGE)"
            SelectCommand="SELECT LOANS_DOCNO, LOANS_BRNO, LOANS_BRNAME, LOANS_EMPID, LOANS_EMPNAME, LOANS_EXT, LOANS_YEARLY, LOANS_MONTHLY, LOANS_TW_OVERAGE, LOANS_OUTLET_OVERAGE FROM tblLoanMonthDetail WHERE (LOANS_DOCNO = @LOANS_DOCNO)" UpdateCommand="UPDATE [tblLoanMonthDetail] SET [LOANS_BRNO] = @LOANS_BRNO, [LOANS_BRNAME] = @LOANS_BRNAME, [LOANS_EMPID] = @LOANS_EMPID, [LOANS_EMPNAME] = @LOANS_EMPNAME, [LOANS_EXT] = @LOANS_EXT, [LOANS_YEARLY] = @LOANS_YEARLY, [LOANS_MONTHLY] = @LOANS_MONTHLY, [LOANS_TW_OVERAGE] = @LOANS_TW_OVERAGE, [LOANS_OUTLET_OVERAGE] = @LOANS_OUTLET_OVERAGE WHERE [LOANS_DOCNO] = @LOANS_DOCNO">
            <DeleteParameters>
                <asp:Parameter Name="LOANS_DOCNO" Type="String" />
            </DeleteParameters>
            <UpdateParameters>
                <asp:Parameter Name="LOANS_BRNO" Type="String" />
                <asp:Parameter Name="LOANS_BRNAME" Type="String" />
                <asp:Parameter Name="LOANS_EMPID" Type="String" />
                <asp:Parameter Name="LOANS_EMPNAME" Type="String" />
                <asp:Parameter Name="LOANS_EXT" Type="String" />
                <asp:Parameter Name="LOANS_YEARLY" Type="String" />
                <asp:Parameter Name="LOANS_MONTHLY" Type="String" />
                <asp:Parameter Name="LOANS_TW_OVERAGE" Type="Decimal" />
                <asp:Parameter Name="LOANS_OUTLET_OVERAGE" Type="Decimal" />
                <asp:Parameter Name="LOANS_DOCNO" Type="String" />
            </UpdateParameters>
            <InsertParameters>
                <asp:Parameter Name="LOANS_DOCNO" Type="String" />
                <asp:Parameter Name="LOANS_BRNO" Type="String" />
                <asp:Parameter Name="LOANS_BRNAME" Type="String" />
                <asp:Parameter Name="LOANS_EMPID" Type="String" />
                <asp:Parameter Name="LOANS_EMPNAME" Type="String" />
                <asp:Parameter Name="LOANS_EXT" Type="String" />
                <asp:Parameter Name="LOANS_YEARLY" Type="String" />
                <asp:Parameter Name="LOANS_MONTHLY" Type="String" />
                <asp:Parameter Name="LOANS_TW_OVERAGE" Type="Decimal" />
                <asp:Parameter Name="LOANS_OUTLET_OVERAGE" Type="Decimal" />
            </InsertParameters>
            <SelectParameters>
                <asp:Parameter Name="LOANS_DOCNO" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:HiddenField ID="HiddenFlowStatus" runat="server" />
        <asp:HiddenField ID="HiddenVer" runat="server" />
        <asp:HiddenField ID="HiddenBrno" runat="server" />
        <asp:HiddenField ID="HiddenEmpId" runat="server" />
        <asp:HiddenField ID="HiddenYYMM" runat="server" />
        <asp:HiddenField ID="HiddenRecordDate" runat="server" />
        <asp:HiddenField ID="HiddenField2" runat="server" />
        <asp:HiddenField ID="HiddenSignComment1" runat="server" />
        <asp:HiddenField ID="HiddenExt" runat="server" />
        <asp:HiddenField ID="HiddenSign1" runat="server" />
        <asp:HiddenField ID="HiddenSignDate1" runat="server" />
        <br />
        <asp:SqlDataSource ID="DS_tblLogMonthDetailLog" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblLoanMonthDetailLog WHERE (LOANS_DOCNO = @LOANS_DOCNO) AND (LOANS_CAL_COUNT = @LOANS_CAL_COUNT)"
            InsertCommand="INSERT INTO tblLoanMonthDetailLog(LOANS_DOCNO, LOANS_IF_CAL, LOANS_CAL_COUNT, LOANS_TW_OVERAGE, LOANS_OUTLET_OVERAGE, LOANS_RecordDate) VALUES (@LOANS_DOCNO, @LOANS_IF_CAL, @LOANS_CAL_COUNT, @LOANS_TW_OVERAGE, @LOANS_OUTLET_OVERAGE, @LOANS_RecordDate)"
            SelectCommand="SELECT LOANS_DOCNO, LOANS_IF_CAL, LOANS_CAL_COUNT, LOANS_TW_OVERAGE, LOANS_OUTLET_OVERAGE, LOANS_RecordDate FROM tblLoanMonthDetailLog"
            UpdateCommand="UPDATE tblLoanMonthDetailLog SET LOANS_IF_CAL = @LOANS_IF_CAL, LOANS_CAL_COUNT = @LOANS_CAL_COUNT, LOANS_TW_OVERAGE = @LOANS_TW_OVERAGE, LOANS_OUTLET_OVERAGE = @LOANS_OUTLET_OVERAGE, LOANS_RecordDate = @LOANS_RecordDate WHERE (LOANS_DOCNO = @LOANS_DOCNO)">
            <DeleteParameters>
                <asp:Parameter Name="LOANS_DOCNO" />
                <asp:Parameter Name="LOANS_CAL_COUNT" />
            </DeleteParameters>
            <UpdateParameters>
                <asp:Parameter Name="LOANS_IF_CAL" />
                <asp:Parameter Name="LOANS_CAL_COUNT" />
                <asp:Parameter Name="LOANS_TW_OVERAGE" />
                <asp:Parameter Name="LOANS_OUTLET_OVERAGE" />
                <asp:Parameter Name="LOANS_RecordDate" />
                <asp:Parameter Name="LOANS_DOCNO" />
            </UpdateParameters>
            <InsertParameters>
                <asp:Parameter Name="LOANS_DOCNO" />
                <asp:Parameter Name="LOANS_IF_CAL" />
                <asp:Parameter Name="LOANS_CAL_COUNT" />
                <asp:Parameter Name="LOANS_TW_OVERAGE" />
                <asp:Parameter Name="LOANS_OUTLET_OVERAGE" />
                <asp:Parameter Name="LOANS_RecordDate" />
            </InsertParameters>
        </asp:SqlDataSource>
        <asp:HiddenField ID="hidn_IFCAL" runat="server" />
        <asp:HiddenField ID="hidn_CALCOUNT" runat="server" />
        <br />
        <br />
    
    </div>
    </form>
</body>
</html>
