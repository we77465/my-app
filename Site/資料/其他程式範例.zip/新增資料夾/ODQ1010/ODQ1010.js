﻿// JScript 檔
function ChkDataFlag()         
         { 
           
            var EXT=document.forms['form1'].txt_Ext.value;//分機          
            
            var A1=document.forms['form1'].txt_TWOVERAGE.value;//台幣
            var A2=document.forms['form1'].txt_OUTLETOVERAGE.value;//外幣        
            
            if (EXT=="")
            {
                alert("分機必填");
               return false;
            }
                      
             //非空值       
             if (A1=="" || A2=="")
             {
               alert("金額欄位為必填，無請填0");
               return false;
             }                
             
             //非數值
             if (isNaN(A1)||isNaN(A2))
              {
               alert("金額欄位為數字，無請填0");
               return false;
              }   
             
             
             
             
            
              alert("儲存完畢!");
              return true;
         }
         

