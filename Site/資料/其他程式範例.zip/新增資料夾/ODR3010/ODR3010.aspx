﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODR3010.aspx.vb" Inherits="Program_ODR3010_ODR3010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
        <div>
            <table border="2" cellpadding="2" cellspacing="2" style="width: 726px">
                <tr>
                    <td bgcolor="khaki">
                        <asp:Label ID="Label5" runat="server" Font-Size="Small" ForeColor="Red" Text="ODR1010"></asp:Label></td>
                    <td style="color: #000000">
                        <asp:Label ID="Label4" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
                            ForeColor="Red" Text="本國銀行資金運用於大陸彙總表" Width="241px"></asp:Label></td>
                    <td bgcolor="khaki">
                        功 能：</td>
                    <td align="center" colspan="3">
                        &nbsp;<asp:Button ID="BtnOK" runat="server" Text="總行確認" />
                        &nbsp;
                        <asp:Button ID="BtnBack" runat="server" Text="總行退回" /></td>
                </tr>
                <tr>
                    <td bgcolor="khaki">
                        表單號碼：</td>
                    <td>
                        <asp:Label ID="lblDOCNO" runat="server" Font-Size="Medium" ForeColor="Red" Text="Label"></asp:Label></td>
                    <td bgcolor="khaki" style="color: #000000">
                        狀 態：</td>
                    <td align="center" style="height: 30px">
                        <asp:TextBox ID="txt_status" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                        &nbsp;<asp:TextBox ID="txtDate" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki">
                        &nbsp;版 本:<span id="Label11" class="TBLHR" style="font-size: 9pt"></span></td>
                    <td align="center" style="height: 30px">
                        <asp:TextBox ID="txtVer" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="50px"></asp:TextBox></td>
                </tr>
                <tr>
                    <td bgcolor="khaki">
                        分 行：</td>
                    <td align="center">
                        &nbsp;
                        <asp:TextBox ID="txt_Brno" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>
                        &nbsp;&nbsp;
                        <asp:TextBox ID="txt_Brno_Name" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki">
                        經 辦：</td>
                    <td align="center">
                        &nbsp;<asp:TextBox ID="txt_EmpID" runat="server" BackColor="#E0E0E0" BorderColor="White"
                            ReadOnly="True" Width="70px"></asp:TextBox>&nbsp; &nbsp;<asp:TextBox ID="txt_EmpName"
                                runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                    </td>
                    <td bgcolor="khaki">
                        分 機：</td>
                    <td align="center">
                        &nbsp;<asp:TextBox ID="txt_Ext" runat="server" BackColor="#E0E0E0" MaxLength="4"
                            ValidationGroup="1" Width="50px"></asp:TextBox></td>
                </tr>
                <tr>
                    <td bgcolor="khaki">
                        所屬年月：</td>
                    <td align="center">
                        &nbsp;
                        <asp:TextBox ID="txt_YYYMM" runat="server" BackColor="#E0E0E0" MaxLength="5" ReadOnly="True"
                            Width="70px"></asp:TextBox>
                    </td>
                    <td bgcolor="khaki">
                        承 辦 人：</td>
                    <td align="center">
                        &nbsp;財管處#2339</td>
                    <td bgcolor="khaki">
                        申報日期:</td>
                    <td>
                        &nbsp;<asp:TextBox ID="txt_RecordDate" runat="server" BackColor="#E0E0E0" MaxLength="5"
                            ReadOnly="True" Width="70px"></asp:TextBox></td>
                </tr>
            </table>
        </div>
        <table border="2" cellpadding="2" cellspacing="2" style="width: 726px">
            <tr>
                <td bgcolor="khaki">
                    負責人:</td>
                <td align="center" colspan="2">
                    &nbsp;<asp:TextBox ID="txtSign1" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="70px"></asp:TextBox>&nbsp; &nbsp;<asp:TextBox ID="txtSign1Name" runat="server"
                            BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    簽 核 日:</td>
                <td align="center">
                    &nbsp;<asp:TextBox ID="txtSignDate1" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="100px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    簽 核:</td>
                <td align="center">
                    &nbsp;&nbsp;
                </td>
            </tr>
            <tr>
                <td bgcolor="khaki" style="height: 64px">
                    批 示:</td>
                <td colspan="6" style="height: 64px">
                    &nbsp;<asp:TextBox ID="txtSignComment1" runat="server" BackColor="Gainsboro" Height="50px"
                        Width="650px" ReadOnly="True"></asp:TextBox></td>
            </tr>
        </table>
        <br />
        <table border="2" cellpadding="2" cellspacing="2" style="width: 725px">
            <tr align="center">
                <td bgcolor="khaki" colspan="8">
                    放款資金運用於中國大陸餘額 &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
                    <asp:Label ID="Label1" runat="server" Font-Bold="False" Font-Names="標楷體" Font-Size="Medium"
                        ForeColor="Red" Text="單位: 新台幣百萬元 以下欄位最多為5位正整數"></asp:Label></td>
            </tr>
            <tr align="center" style="color: #000000; font-family: Times New Roman">
                <td bgcolor="khaki" colspan="2" style="height: 22px">
                    行 業 別(A)</td>
                <td colspan="3" style="height: 22px">
                    放 款 申 貸 用 途(B)</td>
                <td bgcolor="khaki" colspan="3" style="height: 22px">
                    分行別(C)</td>
            </tr>
            <tr align="center" style="font-family: Times New Roman">
                <td bgcolor="khaki">
                    傳統業(A1)</td>
                <td bgcolor="khaki">
                    科技業(A2)</td>
                <td>
                    企業投資(B1)</td>
                <td>
                    週轉金(B2)</td>
                <td>
                    其 他(B3)</td>
                <td bgcolor="khaki">
                    DBU(C1)</td>
                <td bgcolor="khaki">
                    OBU(C2)</td>
                <td bgcolor="khaki">
                    海外分行(C3)</td>
            </tr>
            <tr align="center" style="font-family: Times New Roman">
                <td bgcolor="khaki">
                    <asp:TextBox ID="txt_A1" runat="server" MaxLength="5" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    <asp:TextBox ID="txt_A2" runat="server" MaxLength="5" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td>
                    <asp:TextBox ID="txt_B1" runat="server" MaxLength="5" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td>
                    <asp:TextBox ID="txt_B2" runat="server" MaxLength="5" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td style="width: 83px">
                    <asp:TextBox ID="txt_B3" runat="server" MaxLength="5" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    <asp:TextBox ID="txt_C1" runat="server" MaxLength="5" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    <asp:TextBox ID="txt_C2" runat="server" MaxLength="5" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    <asp:TextBox ID="txt_C3" runat="server" MaxLength="5" ReadOnly="True" Width="70px"></asp:TextBox></td>
            </tr>
            <tr align="center" style="font-family: Times New Roman">
                <td bgcolor="khaki" colspan="2">
                    行業別合計:<asp:TextBox ID="txt_AT" runat="server" BackColor="#FFE0C0" ReadOnly="True"
                        Width="100px"></asp:TextBox></td>
                <td colspan="3">
                    放款申貸用途合計:<asp:TextBox ID="txt_BT" runat="server" BackColor="#FFE0C0" ReadOnly="True"
                        Width="100px"></asp:TextBox></td>
                <td bgcolor="khaki" colspan="3">
                    分行別合計:<asp:TextBox ID="txt_CT" runat="server" BackColor="#FFE0C0" ReadOnly="True"
                        Width="100px"></asp:TextBox></td>
            </tr>
            <tr align="center" style="font-family: Times New Roman">
                <td bgcolor="khaki" colspan="5">
                    放款合計<asp:Label ID="Label2" runat="server" Font-Names="標楷體" ForeColor="Red" Text="(放款合計,行業別合計,放款申貸用途合計,分行別合計 需相等)"></asp:Label></td>
                <td bgcolor="khaki" colspan="3" style="font-weight: bold; color: #000000; font-family: Times New Roman">
                    <asp:TextBox ID="txt_D1" runat="server" ReadOnly="True" Width="240px" 
                        MaxLength="8"></asp:TextBox>&nbsp;</td>
            </tr>
        </table>
        <asp:Panel ID="pnlOld" runat="server">
            <table border="2" cellpadding="2" cellspacing="2" style="width: 725px;
            font-family: Times New Roman">
                <tr align="center">
                    <td bgcolor="khaki" colspan="3">
                        保證款項資金運用於中國大陸餘額</td>
                    <td rowspan="2">
                        應收帳款收買業務資金<br /> 運用於中國大陸餘額</td>
                    <td bgcolor="khaki" colspan="3" style="width: 279px">
                        資金運用於中國大陸帳列金額逾期三個月以上</td>
                </tr>
                <tr align="center">
                    <td bgcolor="khaki">
                        商業本票保證</td>
                    <td bgcolor="khaki">
                        發行公司債</td>
                    <td bgcolor="khaki">
                        其他</td>
                    <td bgcolor="khaki">
                        放款</td>
                    <td bgcolor="khaki">
                        保證墊款</td>
                    <td bgcolor="khaki" style="width: 98px">
                        應收帳款收買</td>
                </tr>
                <tr align="center">
                    <td bgcolor="khaki">
                        <asp:TextBox ID="txt_E1" runat="server" MaxLength="5" ReadOnly="True" 
                        Width="70px"></asp:TextBox>
                    </td>
                    <td bgcolor="khaki">
                        <asp:TextBox ID="txt_E2" runat="server" MaxLength="5" ReadOnly="True" 
                        Width="70px"></asp:TextBox>
                    </td>
                    <td bgcolor="khaki">
                        <asp:TextBox ID="txt_E3" runat="server" MaxLength="5" ReadOnly="True" 
                        Width="70px"></asp:TextBox>
                    </td>
                    <td>
                        <asp:TextBox ID="txt_F1" runat="server" MaxLength="5" ReadOnly="True" 
                        Width="70px"></asp:TextBox>
                    </td>
                    <td bgcolor="khaki">
                        <asp:TextBox ID="txt_G1" runat="server" MaxLength="5" ReadOnly="True" 
                        Width="70px"></asp:TextBox>
                    </td>
                    <td bgcolor="khaki">
                        <asp:TextBox ID="txt_G2" runat="server" MaxLength="5" ReadOnly="True" 
                        Width="70px"></asp:TextBox>
                    </td>
                    <td bgcolor="khaki" style="width: 98px">
                        <asp:TextBox ID="txt_G3" runat="server" MaxLength="5" ReadOnly="True" 
                        Width="70px"></asp:TextBox>
                    </td>
                </tr>
            </table>
        </asp:Panel>

                 
                <asp:Panel ID="pnlNew" runat="server">
                    <table border="2" cellpadding="2" cellspacing="2" 
    style="width: 725px">
                        <tr align="center">
                            <td bgcolor="khaki" colspan="4">
                                保證款項資金運用於中國大陸餘額</td>
                        </tr>
                        <tr align="center">
                            <td bgcolor="khaki" width="16%">
                                &nbsp;</td>
                            <td bgcolor="khaki" width="28%">
                                商業本票保證</td>
                            <td bgcolor="khaki" width="28%">
                                發行公司債</td>
                            <td bgcolor="khaki" style="width: 45%">
                                其他</td>
                        </tr>
                        <tr align="center">
                            <td bgcolor="khaki">
                                DBU</td>
                            <td>
                                <asp:TextBox ID="txtE1_DBU" runat="server" MaxLength="5" Width="70%" 
                                    ReadOnly="True"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE2_DBU" runat="server" MaxLength="5" Width="70%" 
                                    ReadOnly="True"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE3_DBU" runat="server" MaxLength="5" Width="70%" 
                                    ReadOnly="True"></asp:TextBox>
                            </td>
                        </tr>
                        <tr align="center">
                            <td bgcolor="khaki">
                                OBU</td>
                            <td>
                                <asp:TextBox ID="txtE1_OBU" runat="server" MaxLength="5" ReadOnly="True" 
                                    Width="70%"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE2_OBU" runat="server" MaxLength="5" ReadOnly="True" 
                                    Width="70%"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE3_OBU" runat="server" MaxLength="5" ReadOnly="True" 
                                    Width="70%"></asp:TextBox>
                            </td>
                        </tr>
                        <tr align="center">
                            <td bgcolor="khaki">
                                海外</td>
                            <td>
                                <asp:TextBox ID="txtE1_Over" runat="server" MaxLength="5" ReadOnly="True" 
                                    Width="70%"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE2_Over" runat="server" MaxLength="5" ReadOnly="True" 
                                    Width="70%"></asp:TextBox>
                            </td>
                            <td>
                                <asp:TextBox ID="txtE3_Over" runat="server" MaxLength="5" ReadOnly="True" 
                                    Width="70%"></asp:TextBox>
                            </td>
                        </tr>
                    </table>

                    <table border="2" cellpadding="2" cellspacing="2" style="width: 725px">
                    <tr align="center">
                        <td bgcolor="khaki" colspan="8">
                            應收帳款收買業務資金運用於中國大陸餘額(依分別行填報)</td>
                    </tr>
                    <tr align="center">
                        <td bgcolor="khaki" colspan="6">
                            分行別</td>
                        <td bgcolor="khaki" rowspan="2">
                            分行別合計</td>
                        <td rowspan="2">
                            <asp:TextBox ID="txtFT_New" runat="server" BackColor="#FFE0C0" ReadOnly="True" 
                                Width="80px"></asp:TextBox>
                        </td>
                    </tr>
                     <tr align="center">
                         <td bgcolor="khaki">
                             DBU</td>
                         <td>
                             <asp:TextBox ID="txtF_DBU" runat="server" MaxLength="5" Width="70px" 
                                 ReadOnly="True"></asp:TextBox>
                         </td>
                         <td bgcolor="khaki">
                             OBU</td>
                         <td>
                             <asp:TextBox ID="txtF_OBU" runat="server" MaxLength="5" Width="70px" 
                                 ReadOnly="True"></asp:TextBox>
                         </td>
                         <td bgcolor="khaki">
                             海外分行</td>
                         <td>
                             <asp:TextBox ID="txtF_Over" runat="server" MaxLength="5" Width="70px" 
                                 ReadOnly="True"></asp:TextBox>
                         </td>
                     </tr>
                </table>

                <table border="2" cellpadding="2" cellspacing="2" style="width: 725px">
                    <tr align="center">
                        <td bgcolor="khaki" colspan="5">
                            資金運用於中國大陸帳列金額逾期三個月以上(依分別行填報)</td>
                    </tr>
                    <tr align="center">
                        <td bgcolor="khaki" width="11%">
                            &nbsp;</td>
                        <td bgcolor="khaki" width="22%">
                            放款(D)</td>
                        <td bgcolor="khaki" width="22%">
                            保證墊款(E)</td>
                        <td bgcolor="khaki" width="22%">
                            應收帳款收買(E)</td>
                        <td bgcolor="khaki" width="23%">
                            合計(D+E+F)</td>
                    </tr>
                    <tr align="center">
                        <td bgcolor="khaki">
                            DBU</td>
                        <td>
                            <asp:TextBox ID="txtG1_DBU" runat="server" MaxLength="5" Width="80%" 
                                ReadOnly="True"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG2_DBU" runat="server" MaxLength="5" Width="80%" 
                                ReadOnly="True"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG3_DBU" runat="server" MaxLength="5" Width="80%" 
                                ReadOnly="True"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtGT_DBU" runat="server" BackColor="#FFE0C0" MaxLength="8" 
                                ReadOnly="True" Width="80%"></asp:TextBox>
                        </td>
                    </tr>
                    <tr align="center">
                        <td bgcolor="khaki">
                            OBU</td>
                        <td>
                            <asp:TextBox ID="txtG1_OBU" runat="server" MaxLength="5" Width="80%" 
                                ReadOnly="True"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG2_OBU" runat="server" MaxLength="5" Width="80%" 
                                ReadOnly="True"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG3_OBU" runat="server" MaxLength="5" Width="80%" 
                                ReadOnly="True"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtGT_OBU" runat="server" BackColor="#FFE0C0" MaxLength="8" 
                                ReadOnly="True" Width="80%"></asp:TextBox>
                        </td>
                    </tr>
                    <tr align="center">
                        <td bgcolor="khaki">
                            海外</td>
                        <td>
                            <asp:TextBox ID="txtG1_Over" runat="server" MaxLength="5" Width="80%" 
                                ReadOnly="True"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG2_Over" runat="server" MaxLength="5" Width="80%" 
                                ReadOnly="True"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtG3_Over" runat="server" MaxLength="5" Width="80%" 
                                ReadOnly="True"></asp:TextBox>
                        </td>
                        <td>
                            <asp:TextBox ID="txtGT_Over" runat="server" BackColor="#FFE0C0" MaxLength="8" 
                                ReadOnly="True" Width="80%"></asp:TextBox>
                        </td>
                    </tr>
                </table>
    </asp:Panel>
        <br />
        <table>
            <tr>
                <td align="left" style="width: 814px; height: 78px">
                    註：1.本表填報單位包括本國銀行之國內各營業單位、國際金融業務分行及海外分行。<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2.放款包括新台幣及外幣之短期貿易融資、貼現、擔保透支、短、中、長期擔保及無擔保放款及催收款項
                    (不包括保證、<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;承兌金額)； &nbsp;保證及應收帳款金額包括新台幣及外幣，外幣金額請按基準日中心匯率折算新台幣填報。<br />
                    &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;3.運用於大陸資金包括由經濟部投審會核准或報備之投資及未經核准但銀行依據與客戶往來研判可能用於大陸投資者。
                    <br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 4.「行業別」及「放款申貸用途」請填金額，「高科技產業」包括積體電路、通訊、精密機械、特用化學品與製藥、<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 資訊軟體、航太、生物科技等工業。
                    <br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5.國內總分支機構及國際金融業務分行依下列原則填報：
                    <br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (1)授信後資金匯至香港、澳門者全數填報，匯至其他地區者視情況填報；<br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;(2)授信戶會計師簽證報告或聯合徵信中心查詢有資金運用於大陸者，按銀行授信餘額占全體銀行授信總額之比例，
                    <br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 乘以授信戶投資大陸金額填報。惟若銀行確知客戶授信資金非用於大陸者，可免填報。<br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;(3)經實地查訪，授信客戶在台已無營運且已移往大陸投資者，全數填報。
                    <br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 海外分行請依上述（2）、（3）原則填報。
                    <br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 6.授信及應收帳款收買業務資金逾期三個月以上金額包括本金或利息延滯三個月以上<br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; （含列報逾期放款及尚未列報逾期放款）。<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7.行業別合計=放款申貸用途合計=分行別合計=放款合計&nbsp;<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 8.本報表請於次月5日前報送財管處會計業務科。</td>
            </tr>
        </table>
        <br />
        <asp:HiddenField ID="hfNew" runat="server" />
        <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblLogDetail WHERE (DocNo = @DocNo1) and (DocType = 'DR')"
            InsertCommand="INSERT INTO [tblLogDetail] ([DocType], [DocNo], [BrNo], [EmpId], [RecordDate], [DataFlag], [FormType], [YYMM], [Sign1], [Action1], [SignDate1], [SignComment1], [Sign2], [Action2], [SignDate2], [SignComment2], [DecManager], [DecDate], [FlowStatus], [Ver]) VALUES (@DocType, @DocNo, @BrNo, @EmpId, @RecordDate, @DataFlag, @FormType, @YYMM, @Sign1, @Action1, @SignDate1, @SignComment1, @Sign2, @Action2, @SignDate2, @SignComment2, @DecManager, @DecDate, @FlowStatus, @Ver)"
            SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
            UpdateCommand="UPDATE [tblLogDetail] SET [FlowStatus] = @FlowStatus WHERE [DocNo] = @DocNo">
            <InsertParameters>
                <asp:Parameter DefaultValue="" Name="DocType" Type="String" />
                <asp:Parameter DefaultValue="" Name="DocNo" Type="String" />
                <asp:Parameter Name="BrNo" Type="String" />
                <asp:Parameter Name="EmpId" Type="String" />
                <asp:Parameter DefaultValue="" Name="RecordDate" Type="DateTime" />
                <asp:Parameter DefaultValue="" Name="DataFlag" Type="String" />
                <asp:Parameter Name="FormType" Type="String" />
                <asp:Parameter Name="YYMM" Type="String" />
                <asp:Parameter Name="Sign1" Type="String" />
                <asp:Parameter Name="Action1" Type="String" />
                <asp:Parameter Name="SignDate1" Type="DateTime" />
                <asp:Parameter Name="SignComment1" Type="String" />
                <asp:Parameter Name="Sign2" Type="String" />
                <asp:Parameter Name="Action2" Type="String" />
                <asp:Parameter Name="SignDate2" Type="DateTime" />
                <asp:Parameter Name="SignComment2" Type="String" />
                <asp:Parameter Name="DecManager" Type="String" />
                <asp:Parameter Name="DecDate" Type="DateTime" />
                <asp:Parameter Name="FlowStatus" Type="String" />
                <asp:Parameter Name="Ver" Type="Int16" />
            </InsertParameters>
            <DeleteParameters>
                <asp:Parameter Name="DocNo1" />
            </DeleteParameters>
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <UpdateParameters>
                <asp:Parameter Name="FlowStatus" />
                <asp:ControlParameter ControlID="hidn_hDocNo" Name="DocNo" 
                    PropertyName="Value" />
            </UpdateParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblSysCode" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT TblId, TblCd, TblDesc, TblSeq FROM tblSysCode WHERE (TblId = '11') AND (TblCd =@TblCd  )">
            <SelectParameters>
                <asp:Parameter Name="TblCd" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_EMPLOYEE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT STAFF, NAME FROM chb_pub.dbo.EMPLOYEE WHERE (STAFF = @gEmpId)">
            <SelectParameters>
                <asp:FormParameter FormField="gEmpId" Name="gEmpId" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:HiddenField ID="hidn_hDocNo" runat="server" />
        <asp:SqlDataSource ID="DS_tblMoneyInChina" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM [tblMoneyInChina] WHERE [DocNo] = @DocNo" InsertCommand="INSERT INTO [tblMoneyInChina] ([DocNo], [Brno], [BRName], [EmpID], [EmpName], [Ext], [YYYMM], [A1], [A2], [B1], [B2], [B3], [C1], [C2], [C3], [D1], [E1], [E2], [E3], [F1], [G1], [G2], [G3]) VALUES (@DocNo, @Brno, @BRName, @EmpID, @EmpName, @Ext, @YYYMM, @A1, @A2, @B1, @B2, @B3, @C1, @C2, @C3, @D1, @E1, @E2, @E3, @F1, @G1, @G2, @G3)"
            SelectCommand="SELECT * FROM [tblMoneyInChina]" UpdateCommand="UPDATE [tblMoneyInChina] SET [Brno] = @Brno, [BRName] = @BRName, [EmpID] = @EmpID, [EmpName] = @EmpName, [Ext] = @Ext, [YYYMM] = @YYYMM, [A1] = @A1, [A2] = @A2, [B1] = @B1, [B2] = @B2, [B3] = @B3, [C1] = @C1, [C2] = @C2, [C3] = @C3, [D1] = @D1, [E1] = @E1, [E2] = @E2, [E3] = @E3, [F1] = @F1, [G1] = @G1, [G2] = @G2, [G3] = @G3 WHERE [DocNo] = @DocNo">
            <DeleteParameters>
                <asp:Parameter Name="DocNo" Type="String" />
            </DeleteParameters>
            <UpdateParameters>
                <asp:Parameter Name="Brno" Type="String" />
                <asp:Parameter Name="BRName" Type="String" />
                <asp:Parameter Name="EmpID" Type="String" />
                <asp:Parameter Name="EmpName" Type="String" />
                <asp:Parameter Name="Ext" Type="String" />
                <asp:Parameter Name="YYYMM" Type="String" />
                <asp:Parameter Name="A1" Type="Int32" />
                <asp:Parameter Name="A2" Type="Int32" />
                <asp:Parameter Name="B1" Type="Int32" />
                <asp:Parameter Name="B2" Type="Int32" />
                <asp:Parameter Name="B3" Type="Int32" />
                <asp:Parameter Name="C1" Type="Int32" />
                <asp:Parameter Name="C2" Type="Int32" />
                <asp:Parameter Name="C3" Type="Int32" />
                <asp:Parameter Name="D1" Type="Int32" />
                <asp:Parameter Name="E1" Type="Int32" />
                <asp:Parameter Name="E2" Type="Int32" />
                <asp:Parameter Name="E3" Type="Int32" />
                <asp:Parameter Name="F1" Type="Int32" />
                <asp:Parameter Name="G1" Type="Int32" />
                <asp:Parameter Name="G2" Type="Int32" />
                <asp:Parameter Name="G3" Type="Int32" />
                <asp:Parameter Name="DocNo" Type="String" />
            </UpdateParameters>
            <InsertParameters>
                <asp:Parameter Name="DocNo" Type="String" />
                <asp:Parameter Name="Brno" Type="String" />
                <asp:Parameter Name="BRName" Type="String" />
                <asp:Parameter Name="EmpID" Type="String" />
                <asp:Parameter Name="EmpName" Type="String" />
                <asp:Parameter Name="Ext" Type="String" />
                <asp:Parameter Name="YYYMM" Type="String" />
                <asp:Parameter Name="A1" Type="Int32" />
                <asp:Parameter Name="A2" Type="Int32" />
                <asp:Parameter Name="B1" Type="Int32" />
                <asp:Parameter Name="B2" Type="Int32" />
                <asp:Parameter Name="B3" Type="Int32" />
                <asp:Parameter Name="C1" Type="Int32" />
                <asp:Parameter Name="C2" Type="Int32" />
                <asp:Parameter Name="C3" Type="Int32" />
                <asp:Parameter Name="D1" Type="Int32" />
                <asp:Parameter Name="E1" Type="Int32" />
                <asp:Parameter Name="E2" Type="Int32" />
                <asp:Parameter Name="E3" Type="Int32" />
                <asp:Parameter Name="F1" Type="Int32" />
                <asp:Parameter Name="G1" Type="Int32" />
                <asp:Parameter Name="G2" Type="Int32" />
                <asp:Parameter Name="G3" Type="Int32" />
            </InsertParameters>
        </asp:SqlDataSource>
        <br />
        <br />
        <br />
    </form>
</body>
</html>
