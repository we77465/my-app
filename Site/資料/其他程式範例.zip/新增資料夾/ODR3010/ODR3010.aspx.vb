﻿Imports System.Data.SqlClient

Partial Class Program_ODR3010_ODR3010
    Inherits System.Web.UI.Page
    Const 格式轉換日 As String = "2012/1/31"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not IsPostBack) Then
            '==============================================================================================
            '前一頁傳來的值  \IntraWeb\OACHB\Program\ODR3010\ODR3010List.asp
            Dim hDocNo As String = Request.Form("hDocNo")
            hidn_hDocNo.Value = hDocNo

            '==============================================================================================
            '表單表頭區塊
            GettblMoneyInChinaDB(hDocNo) '從DS_tblMoneyInChina(DB)取值(資料內容)

            '==============================================================================================
            '負責人決行區塊
            GetDBLogDetail(hDocNo) '從DB(tblLogDetail)取值(負責人ID,簽核日,批示)

            Dim EmpId As String = txtSign1.Text.Trim '負責人ID
            txtSign1Name.Text = GetEmpID2Name(EmpId)  '利用員編找名字(負責人姓名)

            '每月申報上個月資料, 101年3月起申報適用新格式(新增分行別)
            Dim tempD As DateTime = New Date(CInt(Me.txt_YYYMM.Text.Substring(0, 3)) + 1911, Right(Me.txt_YYYMM.Text, 2), 1)
            If tempD > CDate(格式轉換日) Then
                Me.pnlNew.Visible = True
                Me.hfNew.Value = 1
            Else
                Me.pnlNew.Visible = False
                Me.hfNew.Value = 0
            End If

            Me.pnlOld.Visible = Not Me.pnlNew.Visible

        End If
    End Sub

    '利用員編找名字
    Private Function GetEmpID2Name(ByVal EmpId As String) As String

        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select NAME from chb_pub..EMPLOYEE where STAFF ='" & EmpId & "'"

            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function

    '從DB(tblLogDetail)取值(負責人ID,簽核日,批示)
    Private Sub GetDBLogDetail(ByVal docno As String)
        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            Dim FlowStatus As String = ""
            tmpsql = "SELECT Sign1,SignDate1,SignComment1,FlowStatus FROM tblLogDetail where DocNo = '" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read
                txtSign1.Text = reader(0).ToString() '負責人ID
                txtSignDate1.Text = Format(DateValue(reader(1).ToString()), "yyyy/MM/dd") '簽核日
                txtSignComment1.Text = reader(2).ToString() '批示
                FlowStatus = reader(3).ToString()
            End While
            txt_status.Text = FlowStatus & "-" & GetFlowStatus(FlowStatus)
            reader.Close()
            cmd.Dispose()
        End Using
    End Sub

    '從DS_tblMoneyInChina(DB)取值(資料內容)
    Private Sub GettblMoneyInChinaDB(ByVal docno As String)

        '=================變 數 宣 告==================
        Dim A1, A2, B1, B2, B3, C1, C2, C3, D1, E1, E2, E3, F1, G1, G2, G3 As Integer
        Dim E1_DBU, E1_OBU, E1_Over, E2_DBU, E2_OBU, E2_Over, E3_DBU, E3_OBU, E3_Over, F_DBU, F_OBU, F_Over, G1_DBU, G1_OBU, G1_Over, G2_DBU, G2_OBU, G2_Over, G3_DBU, G3_OBU, G3_Over As Integer

        '=================資 料 庫 撈 資 料==================
        Using conn As New SqlConnection(DS_tblMoneyInChina.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            '2012/2/8 modify 新增分行別
            tmpsql = "SELECT DocNo, Brno, BRName, EmpID, EmpName, Ext, YYYMM, A1, A2" & _
                        ", B1, B2, B3, C1, C2, C3, D1, E1, E2, E3, F1, G1, G2, G3" & _
                        ", E1_DBU, E1_OBU, E1_Over, E2_DBU, E2_OBU, E2_Over, E3_DBU, E3_OBU, E3_Over" & _
                        ", F_DBU, F_OBU, F_Over, G1_DBU, G1_OBU, G1_Over " & _
                        ", G2_DBU, G2_OBU, G2_Over, G3_DBU, G3_OBU, G3_Over " & _
                        "FROM tblMoneyInChina where DocNo = '" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read

                lblDOCNO.Text = reader(0).ToString() 'DocNo  
                txt_Brno.Text = reader(1).ToString() 'Brno   
                txt_Brno_Name.Text = reader(2).ToString() 'BRName 
                txt_EmpID.Text = reader(3).ToString() 'EmpID  
                txt_EmpName.Text = reader(4).ToString() 'EmpName
                txt_Ext.Text = reader(5).ToString() 'Ext    
                txt_YYYMM.Text = reader(6).ToString() 'YYYMM  
                A1 = reader(7).ToString() 'A1     
                A2 = reader(8).ToString() 'A2     
                B1 = reader(9).ToString() 'B1     
                B2 = reader(10).ToString() 'B2     
                B3 = reader(11).ToString() 'B3     
                C1 = reader(12).ToString() 'C1     
                C2 = reader(13).ToString() 'C2     
                C3 = reader(14).ToString() 'C3     
                D1 = reader(15).ToString() 'D1     
                E1 = reader(16).ToString() 'E1     
                E2 = reader(17).ToString() 'E2     
                E3 = reader(18).ToString() 'E3     
                F1 = reader(19).ToString() 'F1     
                G1 = reader(20).ToString() 'G1     
                G2 = reader(21).ToString() 'G2     
                G3 = reader(22).ToString() 'G3  

                '2012/2/8 modify 新增分行別
                E1_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("E1_DBU")), "0", reader(23).ToString)
                E1_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("E1_OBU")), "0", reader(24).ToString)
                E1_Over = IIf(reader.IsDBNull(reader.GetOrdinal("E1_Over")), "0", reader(25).ToString)
                E2_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("E2_DBU")), "0", reader(26).ToString)
                E2_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("E2_OBU")), "0", reader(27).ToString)
                E2_Over = IIf(reader.IsDBNull(reader.GetOrdinal("E2_Over")), "0", reader(28).ToString)
                E3_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("E3_DBU")), "0", reader(29).ToString)
                E3_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("E3_OBU")), "0", reader(30).ToString)
                E3_Over = IIf(reader.IsDBNull(reader.GetOrdinal("E3_Over")), "0", reader(31).ToString)
                F_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("F_DBU")), "0", reader(32).ToString)
                F_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("F_OBU")), "0", reader(33).ToString)
                F_Over = IIf(reader.IsDBNull(reader.GetOrdinal("F_Over")), "0", reader(34).ToString)
                G1_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("G1_DBU")), "0", reader(35).ToString)
                G1_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("G1_OBU")), "0", reader(36).ToString)
                G1_Over = IIf(reader.IsDBNull(reader.GetOrdinal("G1_Over")), "0", reader(37).ToString)
                G2_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("G2_DBU")), "0", reader(38).ToString)
                G2_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("G2_OBU")), "0", reader(39).ToString)
                G2_Over = IIf(reader.IsDBNull(reader.GetOrdinal("G2_Over")), "0", reader(40).ToString)
                G3_DBU = IIf(reader.IsDBNull(reader.GetOrdinal("G3_DBU")), "0", reader(41).ToString)
                G3_OBU = IIf(reader.IsDBNull(reader.GetOrdinal("G3_OBU")), "0", reader(42).ToString)
                G3_Over = IIf(reader.IsDBNull(reader.GetOrdinal("G3_Over")), "0", reader(43).ToString)
            End While
            reader.Close()
            cmd.Dispose()
        End Using

        Try
            '=================給 值==================
            txt_A1.Text = A1.ToString("N0")
            txt_A2.Text = A2.ToString("N0")
            txt_AT.Text = (A1 + A2).ToString("N0")
            txt_B1.Text = B1.ToString("N0")
            txt_B2.Text = B2.ToString("N0")
            txt_B3.Text = B3.ToString("N0")
            txt_BT.Text = (B1 + B2 + B3).ToString("N0")
            txt_C1.Text = C1.ToString("N0")
            txt_C2.Text = C2.ToString("N0")
            txt_C3.Text = C3.ToString("N0")
            txt_CT.Text = (C1 + C2 + C3).ToString("N0")
            txt_D1.Text = D1.ToString("N0")
            txt_E1.Text = E1.ToString("N0")
            txt_E2.Text = E2.ToString("N0")
            txt_E3.Text = E3.ToString("N0")
            txt_F1.Text = F1.ToString("N0")
            txt_G1.Text = G1.ToString("N0")
            txt_G2.Text = G2.ToString("N0")
            txt_G3.Text = G3.ToString("N0")

            '2012/2/8 modify 新增分行別
            Me.txtE1_DBU.Text = E1_DBU.ToString("N0")
            Me.txtE1_OBU.Text = E1_OBU.ToString("N0")
            Me.txtE1_Over.Text = E1_Over.ToString("N0")
            Me.txtE2_DBU.Text = E2_DBU.ToString("N0")
            Me.txtE2_OBU.Text = E2_OBU.ToString("N0")
            Me.txtE2_Over.Text = E2_Over.ToString("N0")
            Me.txtE3_DBU.Text = E3_DBU.ToString("N0")
            Me.txtE3_OBU.Text = E3_OBU.ToString("N0")
            Me.txtE3_Over.Text = E3_Over.ToString("N0")
            Me.txtF_DBU.Text = F_DBU.ToString("N0")
            Me.txtF_OBU.Text = F_OBU.ToString("N0")
            Me.txtF_Over.Text = F_Over.ToString("N0")
            Me.txtFT_New.Text = F1.ToString("N0")
            Me.txtG1_DBU.Text = G1_DBU.ToString("N0")
            Me.txtG2_DBU.Text = G2_DBU.ToString("N0")
            Me.txtG3_DBU.Text = G3_DBU.ToString("N0")
            Me.txtGT_DBU.Text = (G1_DBU + G2_DBU + G3_DBU).ToString("N0")
            Me.txtG1_OBU.Text = G1_OBU.ToString("N0")
            Me.txtG2_OBU.Text = G2_OBU.ToString("N0")
            Me.txtG3_OBU.Text = G3_OBU.ToString("N0")
            Me.txtGT_OBU.Text = (G1_OBU + G2_OBU + G3_OBU).ToString("N0")
            Me.txtG1_Over.Text = G1_Over.ToString("N0")
            Me.txtG2_Over.Text = G2_Over.ToString("N0")
            Me.txtG3_Over.Text = G3_Over.ToString("N0")
            Me.txtGT_Over.Text = (G1_Over + G2_Over + G3_Over).ToString("N0")
        Catch ex As Exception
        End Try

    End Sub

    '總行確認, UPDATE表單流程DB(tblLogDetail)資料
    Protected Sub BtnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnOK.Click

        Try

            DS_tblLogDetail.UpdateParameters("FlowStatus").DefaultValue = "4"
            DS_tblLogDetail.Update()

            Response.Write("<script language=javascript>alert('確認成功!')</script>")
            Response.Write("<script language=javascript>window.location.href='/oachb/program/ODR3010/ODR3010QForm.asp'</script>")
        Catch ex As Exception
        End Try

    End Sub

    '總行退回, UPDATE表單流程DB(tblLogDetail)資料 
    Protected Sub BtnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnBack.Click

        Try

            DS_tblLogDetail.UpdateParameters("FlowStatus").DefaultValue = "-1"
            DS_tblLogDetail.Update()

            Response.Write("<script language=javascript>alert('退回成功!')</script>")
            Response.Write("<script language=javascript>window.location.href='/oachb/program/ODR3010/ODR3010QForm.asp'</script>")
        Catch ex As Exception
        End Try

    End Sub

    '輸入流程狀態tmpFlowID代碼,回傳tmpFlowStatus中文('0退回;1待簽核;2待決行;3已決行;-1總行退件;4已確認;99已送至總行)
    Private Function GetFlowStatus(ByVal tmpFlowID As String) As String
        Dim tmpFlowStatus As String = ""
        Using conn As New SqlConnection(DS_tblSysCode.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT TblDesc FROM tblSysCode WHERE TblId = '11' AND TblCd =" & tmpFlowID
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                tmpFlowStatus = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using

        Return tmpFlowStatus
    End Function

End Class
