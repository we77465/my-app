﻿Imports System.Data.SqlClient

Partial Class Program_ODS3010_ODS3010
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Not IsPostBack) Then
            '==============================================================================================
            '前一頁傳來的值  \IntraWeb\OACHB\Program\ODS3010\ODS3010List.asp
            Dim hDocNo As String = Request.Form("hDocNo")
            hidn_hDocNo.Value = hDocNo
            'Response.Write("hDocNo:" & Request.Form("hDocNo") & "<br>")
            '==============================================================================================
            '表單表頭區塊
            GettblIntraMgrRpt(hDocNo)   '從DS_tblIntraMgrRpt(DB)取值(資料內容)

            '==============================================================================================
            '單位主管決行區塊
            GetDBLogDetail(hDocNo) '從DB(tblLogDetail)取值(負責人ID,簽核日,批示)

            Dim EmpId As Integer = Integer.Parse(txtSign1.Text.Trim()) '負責人ID
            'Response.Write("EmpId:" & EmpId & "<br>")
            txtSign1Name.Text = GetEmpID2Name(EmpId)  '利用員編找名字(負責人姓名)

            '==============================================================================================
            '資料區塊


        End If


    End Sub

    '總行確認
    Protected Sub BtnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnOK.Click

        Dim hDocNo As String = hidn_hDocNo.Value '表單編號
        DS_tblLogDetail.UpdateCommand = "Update tblLogDetail Set FlowStatus=4 where DocNo='" + hDocNo + "'"
        DS_tblLogDetail.Update()
        '新增總行意見

       


        DS_tblIntraMgrRpt.UpdateParameters("Content2").DefaultValue = txtContent2.Text '總行意見
        DS_tblIntraMgrRpt.Update()
        Response.Write("<script language=javascript>alert('確定成功!')</script>")
        Response.Write("<script language=javascript>window.location.href='/oachb/program/ODS3010/ODS3010QForm.asp'</script>")

    End Sub
    

    '總行退回
    Protected Sub BtnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnBack.Click
        Dim hDocNo As String = hidn_hDocNo.Value '表單編號
        DS_tblLogDetail.UpdateCommand = "Update tblLogDetail set FlowStatus='-1' where DocNo='" + hDocNo + "'"
        DS_tblLogDetail.Update()

        Response.Write("<script language=javascript>alert('退回成功!')</script>")
        Response.Write("<script language=javascript>window.location.href='/oachb/program/ODS3010/ODS3010QForm.asp'</script>")

    End Sub

    '匯出列印
    Protected Sub BtnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnExport.Click
        '匯出成HTML檔
        Response.AddHeader("content-disposition", "attachment; filename=saveExcel.htm")
        Response.Charset = "utf-8"
        Response.ContentType = "Content-Language;content=zh-tw"
        Response.ContentType = "application/vnd.ms-excel"
    End Sub


    '輸入流程狀態tmpFlowID代碼,回傳tmpFlowStatus中文('0退回;1待簽核;2待決行;3已決行;-1總行退件;4已確認;99已送至總行)
    Private Function GetFlowStatus(ByVal tmpFlowID)
        Dim tmpFlowStatus As String = ""
        Using conn As New SqlConnection(DS_tblSysCode.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  TblDesc FROM tblSysCode WHERE TblId = '11' AND TblCd =" & tmpFlowID
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                tmpFlowStatus = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using
        '0		退回
        '1		待簽核
        '2		待決行
        '3		已決行
        '-1		總行退件
        '4		已確認
        '99		已送至總行
        Return tmpFlowStatus
    End Function

    '利用員編找名字
    Private Function GetEmpID2Name(ByVal EmpId)

        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select NAME from chb_pub..EMPLOYEE where STAFF ='" & EmpId & "'"
            'Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function

    '從DB(tblLogDetail)取值(單位主管ID,簽核日,批示)
    Private Sub GetDBLogDetail(ByVal docno)
        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            Dim FlowStatus As String = ""
            tmpsql = "SELECT  Sign1,SignDate1,SignComment1,FlowStatus,Ver,RecordDate FROM tblLogDetail where DocNo = '" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read
                txtSign1.Text = reader(0).ToString() '負責人ID
                txtSignDate1.Text = Format(DateValue(reader(1).ToString()), "yyyy/MM/dd") '簽核日
                txtSignComment1.Text = reader(2).ToString() '批示
                FlowStatus = reader(3).ToString()
                txtVer.Text = reader(4).ToString() '版本
                txt_RecordDate.Text = reader(5).ToString() '申報日期
            End While
            txt_status.Text = FlowStatus & "-" & GetFlowStatus(FlowStatus)
            reader.Close()
            cmd.Dispose()
        End Using
    End Sub

    '從DS_tblIntraMgrRpt(DB)取值(資料內容)
    Private Sub GettblIntraMgrRpt(ByVal docno)

        '=================變 數 宣 告==================



        '=================資 料 庫 撈 資 料==================
        Try

            Using conn As New SqlConnection(DS_tblIntraMgrRpt.ConnectionString)
                conn.Open()
                Dim tmpsql As String
                tmpsql = "SELECT DocNo, Brno, BRName, EmpId, EmpName, Ext, YYYMM,SN,Brno_2,Brno_Name_2,Sign1Name_2,EmpName_2, Content1, Improve, Item, Content2 FROM   tblIntraMgrRpt where DocNo = '" & docno & "'"
                'Response.Write(tmpsql)
                Dim cmd As New SqlCommand(tmpsql, conn)
                Dim reader As SqlDataReader = cmd.ExecuteReader()
                While reader.Read

                    lblDOCNO.Text = reader(0).ToString() 'DocNo  
                    txt_Brno.Text = reader(1).ToString()  'Brno   
                    txt_Brno_Name.Text = reader(2).ToString()  'BRName 
                    txt_EmpID.Text = reader(3).ToString()  'EmpID  
                    txt_EmpName.Text = reader(4).ToString()  'EmpName
                    txt_Ext.Text = reader(5).ToString()  'Ext    
                    txt_YYYMM.Text = reader(6).ToString()  'YYYMM 

                    txt_GoouNum.Text = reader(7).ToString() '固有號碼:
                    txt_Brno_2.Text = reader(8).ToString() '單位:
                    txt_Brno_Name_2.Text = reader(9).ToString() '單位:
                    txtSign1Name_2.Text = reader(10).ToString() '主管:
                    txt_EmpName_2.Text = reader(11).ToString() '報告人:
                    txtContent1.Text = reader(12).ToString()  '該當人員及具體內容
                    txtImprove.Text = reader(13).ToString()  '建議或改進意見    
                    txtContent2.Text = reader(15).ToString() '總行確認

                    Dim i As Integer                                       '0981104
                    For i = 1 To (Len(reader(14).ToString())) Step 1
                        If Mid(reader(14).ToString(), i, 1) = "1" Then
                            CheckBoxList1.Items(i - 1).Selected = True
                        End If
                    Next                                                   '1104

                End While
                reader.Close()
                cmd.Dispose()
            End Using

        Catch ex As Exception

            Response.Write("<script language=javascript>alert('讀取資料庫失敗,原因:" & ex.Message & "')</script>")

        End Try

    End Sub


    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        txtContent2.Text = "呈閱後存查"
    End Sub
End Class
