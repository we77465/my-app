﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODS2010.aspx.vb" Inherits="Program_ODS3010_ODS2010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
     <script language="JavaScript">
        if (navigator.appName.indexOf('Internet Explorer') != -1)
        {
	        document.onmousedown = noSourceExplorer;
        }

            function noSourceExplorer()
            {
	            if (event.button == 2 | event.button == 3)
	            {
	                if (confirm('是否列印?')) 
	                {
	                    window.print();
                    }
	            }
            }
    </script>
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <table style="width: 725px" border="2" cellpadding="2" cellspacing="2">
            <tr>
                <td bgcolor="khaki" style="height: 32px">
                    &nbsp;
        <asp:Label ID="Label5" runat="server" Font-Size="Small" ForeColor="Red" Text="ODS2010"></asp:Label></td>
                <td style="height: 32px">
                    &nbsp;<asp:Label ID="Label4" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
            ForeColor="Red" Text="內部管理綜合報告表" Width="164px"></asp:Label></td>
                <td bgcolor="khaki" style="height: 32px">
                    &nbsp; 所 屬 年 月</td>
                <td style="height: 32px" >
                    &nbsp; &nbsp; 
                    <asp:DropDownList ID="ddlYYY" runat="server">
                        <asp:ListItem>098</asp:ListItem>
                        <asp:ListItem>099</asp:ListItem>
                        <asp:ListItem>100</asp:ListItem>
                        <asp:ListItem>101</asp:ListItem>
                        <asp:ListItem>102</asp:ListItem>
                        <asp:ListItem>103</asp:ListItem>
                        <asp:ListItem>104</asp:ListItem>
                    </asp:DropDownList>
                    &nbsp;年
                    <asp:DropDownList ID="ddlMM" runat="server">
                        <asp:ListItem>01</asp:ListItem>
                        <asp:ListItem>02</asp:ListItem>
                        <asp:ListItem>03</asp:ListItem>
                        <asp:ListItem>04</asp:ListItem>
                        <asp:ListItem>05</asp:ListItem>
                        <asp:ListItem>06</asp:ListItem>
                        <asp:ListItem>07</asp:ListItem>
                        <asp:ListItem>08</asp:ListItem>
                        <asp:ListItem>09</asp:ListItem>
                        <asp:ListItem>10</asp:ListItem>
                        <asp:ListItem>11</asp:ListItem>
                        <asp:ListItem>12</asp:ListItem>
                    </asp:DropDownList>&nbsp;
                    月</td>
                    
                    <td  bgcolor="khaki" style="height: 32px">
                        &nbsp; &nbsp; &nbsp;
                        功&nbsp; 能 :</td><td style="height: 32px">
                            &nbsp;<asp:Button ID="Button1" runat="server" Text="查詢" />&nbsp;
                    <asp:Button ID="BtnExport" runat="server" Text="匯出列印" /></td>
                    
            </tr>
              
        </table>
        <hr />
        <asp:Label ID="Label1" runat="server" Text="有填列通報事項單位"></asp:Label><br />
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" DataKeyNames="DocNo"
            DataSourceID="DS_tblIntraMgrRpt" AllowSorting="True" BackColor="#DEBA84" BorderColor="#DEBA84" BorderWidth="1px" CellPadding="3" BorderStyle="None" CellSpacing="2" EmptyDataText="無相關資料">
            <Columns>
                <asp:BoundField DataField="DocNo" HeaderText="表單編號" ReadOnly="True" SortExpression="DocNo" />
                <asp:BoundField DataField="Brno" SortExpression="Brno" Visible="False" />
                <asp:BoundField DataField="BRName" SortExpression="BRName" Visible="False" />
                <asp:BoundField DataField="EmpId" HeaderText="EmpId" SortExpression="EmpId" Visible="False" />
                <asp:BoundField DataField="EmpName" HeaderText="EmpName" SortExpression="EmpName" Visible="False" />
                <asp:BoundField DataField="YYYMM" HeaderText="年月" SortExpression="YYYMM" Visible="False" />
                <asp:BoundField DataField="SN" HeaderText="固有號碼" SortExpression="SN" />
                <asp:BoundField DataField="Brno_2" HeaderText="單位" SortExpression="Brno_2" />
                <asp:BoundField DataField="Brno_Name_2" HeaderText="單位名稱" SortExpression="Brno_Name_2" />
                <asp:BoundField DataField="Sign1Name_2" HeaderText="主管" SortExpression="Sign1Name_2" />
                <asp:BoundField DataField="EmpName_2" HeaderText="報告人" SortExpression="EmpName_2" />
                <asp:BoundField DataField="Ext" HeaderText="分機" SortExpression="Ext" />
                <asp:BoundField SortExpression="Item" DataField="item" ShowHeader="False" HeaderText="項目"  />
                
            </Columns>
            <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" Font-Size="Small" />
            <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" Font-Size="Small" />
            <SelectedRowStyle BackColor="#738A9C" ForeColor="White" Font-Bold="True" Font-Size="Smaller" />
            <HeaderStyle BackColor="#A55129" Font-Bold="True" ForeColor="White" Font-Size="Smaller" />
            <RowStyle BackColor="#FFF7E7" ForeColor="#8C4510" Font-Size="Smaller" />
            <EmptyDataRowStyle Font-Size="Small" />
            <EditRowStyle Font-Size="Small" />
            <AlternatingRowStyle Font-Size="Smaller" />
        </asp:GridView>
        <br />
        <asp:Label ID="Label2" runat="server" Text="填報無該當單位"></asp:Label><br />
        <asp:GridView ID="GridView2" runat="server" AutoGenerateColumns="False" DataKeyNames="DocNo"
            DataSourceID="DS_tblIntraMgrRpt2" AllowSorting="True" BackColor="#DEBA84" BorderColor="#DEBA84" BorderWidth="1px" CellPadding="3" BorderStyle="None" CellSpacing="2" EmptyDataText="無相關資料">
            <RowStyle BackColor="#FFF7E7" ForeColor="#8C4510" Font-Size="Smaller" />
            <EmptyDataRowStyle Font-Size="Small" />
            <Columns>
                <asp:BoundField DataField="DocNo" HeaderText="表單編號" ReadOnly="True" SortExpression="DocNo" />
                <asp:BoundField DataField="Brno" SortExpression="Brno" Visible="False" />
                <asp:BoundField DataField="BRName" SortExpression="BRName" Visible="False" />
                <asp:BoundField DataField="EmpId" HeaderText="EmpId" SortExpression="EmpId" Visible="False" />
                <asp:BoundField DataField="EmpName" HeaderText="EmpName" SortExpression="EmpName" Visible="False" />
                <asp:BoundField DataField="YYYMM" HeaderText="年月" SortExpression="YYYMM" Visible="False" />
                <asp:BoundField DataField="SN" HeaderText="固有號碼" SortExpression="SN" />
                <asp:BoundField DataField="Brno_2" HeaderText="單位" SortExpression="Brno_2" />
                <asp:BoundField DataField="Brno_Name_2" HeaderText="單位名稱" SortExpression="Brno_Name_2" />
                <asp:BoundField DataField="Sign1Name_2" HeaderText="主管" SortExpression="Sign1Name_2" />
                <asp:BoundField DataField="EmpName_2" HeaderText="報告人" SortExpression="EmpName_2" />
                <asp:BoundField DataField="Ext" HeaderText="分機" SortExpression="Ext" />
                <asp:BoundField DataField="Content1" HeaderText="具體內容" SortExpression="Content1" />
                <asp:BoundField DataField="Improve" HeaderText="改進意見" SortExpression="Improve" />
                
            </Columns>
            <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" Font-Size="Small" />
            <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" Font-Size="Small" />
            <SelectedRowStyle BackColor="#738A9C" ForeColor="White" Font-Bold="True" Font-Size="Smaller" />
            <HeaderStyle BackColor="#A55129" Font-Bold="True" ForeColor="White" Font-Size="Smaller" />
            <EditRowStyle Font-Size="Small" />
            <AlternatingRowStyle Font-Size="Smaller" />
        </asp:GridView>
        &nbsp;
        <br />
        <br />
    </div>
        <asp:SqlDataSource ID="DS_tblIntraMgrRpt" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT     I.DocNo,I.Brno,I.BRName,I.EmpId,I.EmpName,I.Ext,I.YYYMM,I.SN,I.Brno_2,I.Brno_Name_2,I.Sign1Name_2,I.EmpName_2,I.Content1,I.Improve,I.Content2,I.Item&#13;&#10;from &#13;&#10;(SELECT     DocNo, Brno, BRName, EmpId, EmpName, Ext, YYYMM, SN, Brno_2, Brno_Name_2, Sign1Name_2, EmpName_2, Content1, Improve, Content2,Item&#13;&#10;FROM         tblIntraMgrRpt&#13;&#10;WHERE     (YYYMM = @YYYMM) AND (Content1 <> '無該當' or Improve <> '無該當' )) as I&#13;&#10;JOIN &#13;&#10;(select DocNo,FlowStatus from tblLogDetail&#13;&#10;where DocType = 'DS' AND FlowStatus >= '3') as L&#13;&#10;on I.DocNo = L.DocNo">
            <SelectParameters>
                <asp:Parameter Name="YYYMM" />
            </SelectParameters>
        </asp:SqlDataSource>
        <br />
        <asp:SqlDataSource ID="DS_tblIntraMgrRpt2" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT     I.DocNo,I.Brno,I.BRName,I.EmpId,I.EmpName,I.Ext,I.YYYMM,I.SN,I.Brno_2,I.Brno_Name_2,I.Sign1Name_2,I.EmpName_2,I.Content1,I.Improve,I.Content2,I.Item&#13;&#10;from &#13;&#10;(SELECT   DocNo, Brno, BRName, EmpId, EmpName, Ext, YYYMM, SN, Brno_2, Brno_Name_2, Sign1Name_2, EmpName_2, Content1, Improve, Content2,Item&#13;&#10;FROM [tblIntraMgrRpt] where YYYMM= @YYYMM and Content1 = '無該當' &#13;&#10;or  Content1 = '' ) as I&#13;&#10;JOIN &#13;&#10;(select DocNo,FlowStatus from tblLogDetail&#13;&#10;where DocType = 'DS' AND FlowStatus >= '3') as L&#13;&#10;on I.DocNo = L.DocNo">
            <SelectParameters>
                <asp:Parameter Name="YYYMM" />
            </SelectParameters>
        </asp:SqlDataSource>
    </form>
</body>
</html>
