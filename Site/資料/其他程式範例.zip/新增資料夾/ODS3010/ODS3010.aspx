﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODS3010.aspx.vb" Inherits="Program_ODS3010_ODS3010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
     <script language="JavaScript">
        if (navigator.appName.indexOf('Internet Explorer') != -1)
        {
	        document.onmousedown = noSourceExplorer;
        }

            function noSourceExplorer()
            {
	            if (event.button == 2 | event.button == 3)
	            {
	                if (confirm('是否列印?')) 
	                {
	                    window.print();
                    }
	            }
            }
    </script>
</head>
<body style="font-size: 8pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
        <div>
            &nbsp;<asp:Label ID="Label17" runat="server" Font-Bold="True" ForeColor="Black" Text="流 程 狀 態"></asp:Label><br />
            <table id="tblflow" border="2" cellpadding="2" cellspacing="2" style="width: 720px; height: 112px;">
                <tr>
                    <td bgcolor="khaki">
                        <asp:Label ID="Label5" runat="server" Font-Size="Small" ForeColor="Red" Text="ODS3010"></asp:Label></td>
                    <td style="font-size: 12pt; color: #000000">
                        <asp:Label ID="Label4" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
                            ForeColor="Red" Text="內部管理綜合報告表" Width="164px"></asp:Label></td>
                    <td bgcolor="khaki" style="width: 61px">
                        功 能：</td>
                    <td align="center" colspan="3">
                        &nbsp; &nbsp;&nbsp;
                    </td>
                </tr>
                <tr>
                    <td bgcolor="khaki" style="height: 22px">
                        表單號碼：</td>
                    <td style="height: 22px">
                        <asp:Label ID="lblDOCNO" runat="server" Font-Size="Medium" ForeColor="Red" Text="Label"></asp:Label></td>
                    <td bgcolor="khaki" style="color: #000000; width: 61px; height: 22px;">
                        狀 態：</td>
                    <td align="center" style="height: 22px">
                        <asp:TextBox ID="txt_status" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                        &nbsp;<asp:TextBox ID="txtDate" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki" style="height: 22px">
                        &nbsp;版 本:<span id="Label11" class="TBLHR" style="font-size: 9pt"></span></td>
                    <td align="center" style="height: 22px; width: 101px;">
                        <asp:TextBox ID="txtVer" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="50px"></asp:TextBox></td>
                </tr>
                <tr>
                    <td bgcolor="khaki" style="height: 19px">
                        <span style="font-size: 9pt; font-family: 新細明體">單位</span>：</td>
                    <td align="center" style="height: 19px">
                        &nbsp;
                        <asp:TextBox ID="txt_Brno" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>
                        &nbsp;&nbsp;
                        <asp:TextBox ID="txt_Brno_Name" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki" style="width: 61px; height: 19px;">
                        填 報 人：</td>
                    <td align="center" style="height: 19px">
                        &nbsp;<asp:TextBox ID="txt_EmpID" runat="server" BackColor="#E0E0E0" BorderColor="White"
                            ReadOnly="True" Width="70px"></asp:TextBox>&nbsp; &nbsp;<asp:TextBox ID="txt_EmpName"
                                runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                    </td>
                    <td bgcolor="khaki" style="height: 19px">
                        分 機：</td>
                    <td align="center" style="height: 19px; width: 101px;">
                        &nbsp;<asp:TextBox ID="txt_Ext" runat="server" MaxLength="4" ValidationGroup="1"
                            Width="50px" BackColor="#E0E0E0" ReadOnly="True"></asp:TextBox></td>
                </tr>
                <tr>
                    <td bgcolor="khaki" style="height: 2px">
                        所屬年月：</td>
                    <td align="center" style="height: 2px">
                        &nbsp;
                        <asp:TextBox ID="txt_YYYMM" runat="server" BackColor="White" MaxLength="5"
                            Width="70px"></asp:TextBox>
                    </td>
                    <td bgcolor="khaki" style="width: 61px; height: 2px;">
                        &nbsp;</td>
                    <td align="center" style="height: 2px">
                        <br />
                        </td>
                    <td bgcolor="khaki" style="height: 2px">
                        <span style="font-size: 9pt; font-family: 新細明體">填報日期</span>:</td>
                    <td style="height: 2px; width: 101px;">
                        &nbsp;<asp:TextBox ID="txt_RecordDate" runat="server" BackColor="#E0E0E0" MaxLength="5"
                            ReadOnly="True" Width="70px"></asp:TextBox></td>
                </tr>
            </table>
            <asp:Label ID="Label18" runat="server" Font-Bold="True" Text="主 管 (負責人) 核 示"></asp:Label></div>
        <table id="tbls" border="2" cellpadding="2" cellspacing="2" style="width: 726px">
            <tr>
                <td bgcolor="khaki">
                    單位主管:</td>
                <td align="center" colspan="2">
                    &nbsp;<asp:TextBox ID="txtSign1" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="70px"></asp:TextBox>&nbsp; &nbsp;<asp:TextBox ID="txtSign1Name" runat="server"
                            BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    簽 核 日:</td>
                <td align="center">
                    &nbsp;<asp:TextBox ID="txtSignDate1" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="100px"></asp:TextBox></td>
                <td bgcolor="khaki">
                    簽 核:</td>
                <td align="center" style="width: 114px">
                    &nbsp;&nbsp;</td>
            </tr>
            <tr>
                <td bgcolor="khaki" style="height: 64px">
                    批 示:</td>
                <td colspan="6" style="height: 64px">
                    &nbsp;<asp:TextBox ID="txtSignComment1" runat="server" BackColor="#E0E0E0" Height="50px"
                        ReadOnly="True" Width="620px"></asp:TextBox></td>
            </tr>
        </table>
        <asp:Label ID="Label2" runat="server" Font-Bold="True" Text="總 行 簽 辦"></asp:Label><br />
        <table id="Table1" border="2" cellpadding="2" cellspacing="2" style="width: 726px">
            <tr>
                <td bgcolor="khaki" style="height: 26px">
                    簽 辦:
                </td>
                <td colspan="2" style="height: 26px">
                    &nbsp;<asp:Button ID="BtnOK" runat="server" Text="總行確認" />&nbsp;&nbsp;
                        <asp:Button ID="BtnBack" runat="server" Text="總行退回" />&nbsp;&nbsp;
                        <asp:Button ID="BtnExport" runat="server" Text="匯出列印" />&nbsp;<asp:Button ID="Button1"
                            runat="server" Text="呈閱後存查" /></td>
                             
            </tr>
            <tr>
                <td bgcolor="khaki" style="height: 48px">
                    簽辦意見:</td>
                <td colspan="6" style="height: 48px">
                    &nbsp;<asp:TextBox ID="txtContent2" runat="server" BackColor="White" Height="103px" Width="620px" TextMode="MultiLine"></asp:TextBox></td>
            </tr>
        </table>
        <table style="width: 720px">
            <tr>
                <td style="height: 20px; width: 241px;">
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                    &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; 處長:
                </td>
                <td style="height: 20px; width: 158px;">
                    副處長:</td>
                <td style="height: 20px; width: 223px;">
                    &nbsp;科長:
                </td>
                 <td style="width: 114px; height: 20px">
                     經辦:</td>
            </tr>
           
        </table>
        <!---  here --->
        <table id="ODS1010table" border="2" cellpadding="2" cellspacing="2" style="width: 670px">
            <tr>
                <td align="center" colspan="3">
                    <asp:Label ID="Label12" runat="server" BorderStyle="None" Font-Bold="True" Font-Size="Large"
                        Text="內部管理綜合報告表"></asp:Label>
                    &nbsp;
                </td>
            </tr>
            <tr>
                <td style="width: 166px">
                    &nbsp;<asp:Label ID="Label13" runat="server" Text="人力資源處   台照"></asp:Label></td>
                <td style="width: 234px">
                    &nbsp;</td>
                <td style="width: 170px">
                    <asp:Label ID="Label14" runat="server" Text="固有號碼:"></asp:Label>&nbsp;
                    <asp:TextBox ID="txt_GoouNum" runat="server" ReadOnly="True" Width="90px"></asp:TextBox></td>
            </tr>
            <tr>
                <td style="width: 166px">
                    <asp:Label ID="Label1" runat="server" Text="單位:"></asp:Label>
                    <asp:TextBox ID="txt_Brno_2" runat="server" BackColor="White" ReadOnly="True" Width="32px"></asp:TextBox>
                    <asp:TextBox ID="txt_Brno_Name_2" runat="server" BackColor="White" ReadOnly="True"
                        Width="88px"></asp:TextBox></td>
                <td style="width: 234px">
                    <asp:Label ID="Label3" runat="server" Text="主管:"></asp:Label>
                    &nbsp;
                    <asp:TextBox ID="txtSign1Name_2" runat="server" BackColor="White" Width="100px" ReadOnly="True"></asp:TextBox></td>
                <td style="width: 170px">
                    <asp:Label ID="Label7" runat="server" Text="報告人:"></asp:Label>
                    &nbsp;
                    <asp:TextBox ID="txt_EmpName_2" runat="server" BackColor="White" ReadOnly="True"
                        Width="100px"></asp:TextBox></td>
            </tr>
            <tr align="center">
                <td bgcolor="khaki" style="width: 166px">
                    項&nbsp; 目</td>
                <td bgcolor="khaki" style="width: 234px">
                    該 當 人 員 及 具 體 內 容</td>
                <td bgcolor="khaki" style="width: 170px">
                    建 議 或 改 進 意 見</td>
            </tr>
            <tr>
                <td bgcolor="khaki" valign=top rowspan="17" style="height: 72px; width: 166px;">
                    <asp:CheckBoxList ID="CheckBoxList1" runat="server" Height="1px" Width="224px">
                        <asp:ListItem Value="1.對員工之領導及輔導 ">1.對員工之領導及輔導 </asp:ListItem>
                        <asp:ListItem Value="2.對本行各方面之反應意見 ">2.對本行各方面之反應意見 </asp:ListItem>
                        <asp:ListItem Value="3.對人事管理之意見 ">3.對人事管理之意見</asp:ListItem>
                        <asp:ListItem Value="4.日常工作協調及執行情形 ">4.日常工作協調及執行情形</asp:ListItem>
                        <asp:ListItem Value="5.員工在職訓練辦理情形 ">5.員工在職訓練辦理情形</asp:ListItem>
                        <asp:ListItem>6.職務指派之執行情形</asp:ListItem>
                        <asp:ListItem>7.平常考核辦理情形 </asp:ListItem>
                        <asp:ListItem>8.員工服務態度之輔導 </asp:ListItem>
                        <asp:ListItem>9.員工勤惰之管理 </asp:ListItem>
                        <asp:ListItem>10.單位紀律之維護 </asp:ListItem>
                        <asp:ListItem>11.員工品德操守生活之考核輔導 </asp:ListItem>
                        <asp:ListItem>12.與客戶、朋友之交往情形 </asp:ListItem>
                        <asp:ListItem>13.金錢往來情形 </asp:ListItem>
                        <asp:ListItem>14.員工士氣 </asp:ListItem>
                        <asp:ListItem>15.行內風氣 </asp:ListItem>
                        <asp:ListItem>16.行舍周圍及內部環境衛生安全防護 </asp:ListItem>
                        <asp:ListItem>17.其他內部管理綜合意見 </asp:ListItem>
                    </asp:CheckBoxList></td>
                <td rowspan="17" style="height: 72px; width: 234px;">
                    <asp:TextBox ID="txtContent1" runat="server" Height="430px" TextMode="MultiLine"
                        Width="234px" ReadOnly="True" MaxLength="1500"></asp:TextBox></td>
                <td rowspan="17" style="height: 72px; width: 170px;">
                    <asp:TextBox ID="txtImprove" runat="server" Height="430px" TextMode="MultiLine" Width="232px" ReadOnly="True" MaxLength="1500"></asp:TextBox></td>
            
        </table>
        <asp:HiddenField ID="hidn_hUsrId" runat="server" />
        <asp:HiddenField ID="hidn_EMPID" runat="server" />
        <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblLogDetail WHERE (DocNo = @DocNo1) and (DocType = 'DS')"
            InsertCommand="INSERT INTO [tblLogDetail] ([DocType], [DocNo], [BrNo], [EmpId], [RecordDate], [DataFlag], [FormType], [YYMM], [Sign1], [Action1], [SignDate1], [SignComment1], [Sign2], [Action2], [SignDate2], [SignComment2], [DecManager], [DecDate], [FlowStatus], [Ver]) VALUES (@DocType, @DocNo, @BrNo, @EmpId, @RecordDate, @DataFlag, @FormType, @YYMM, @Sign1, @Action1, @SignDate1, @SignComment1, @Sign2, @Action2, @SignDate2, @SignComment2, @DecManager, @DecDate, @FlowStatus, @Ver)"
            SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
            UpdateCommand="UPDATE [tblLogDetail] 
SET [FlowStatus] = @FlowStatus
     , [YYMM]=@YYMM
     , [DocNo] ='DS' + @YYMM + right(DocNo,5)
WHERE [DocNo] = @DocNo">
            <InsertParameters>
                <asp:Parameter DefaultValue="" Name="DocType" Type="String" />
                <asp:Parameter DefaultValue="" Name="DocNo" Type="String" />
                <asp:Parameter Name="BrNo" Type="String" />
                <asp:Parameter Name="EmpId" Type="String" />
                <asp:Parameter DefaultValue="" Name="RecordDate" Type="DateTime" />
                <asp:Parameter DefaultValue="" Name="DataFlag" Type="String" />
                <asp:Parameter Name="FormType" Type="String" />
                <asp:Parameter Name="YYMM" Type="String" />
                <asp:Parameter Name="Sign1" Type="String" />
                <asp:Parameter Name="Action1" Type="String" />
                <asp:Parameter Name="SignDate1" Type="DateTime" />
                <asp:Parameter Name="SignComment1" Type="String" />
                <asp:Parameter Name="Sign2" Type="String" />
                <asp:Parameter Name="Action2" Type="String" />
                <asp:Parameter Name="SignDate2" Type="DateTime" />
                <asp:Parameter Name="SignComment2" Type="String" />
                <asp:Parameter Name="DecManager" Type="String" />
                <asp:Parameter Name="DecDate" Type="DateTime" />
                <asp:Parameter Name="FlowStatus" Type="String" />
                <asp:Parameter Name="Ver" Type="Int16" />
            </InsertParameters>
            <DeleteParameters>
                <asp:Parameter Name="DocNo1" />
            </DeleteParameters>
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <UpdateParameters>
                <asp:Parameter Name="FlowStatus" DefaultValue="" />
                <asp:ControlParameter ControlID="hidn_hDocNo" DefaultValue="" Name="DocNo" 
                    PropertyName="Value" />
                <asp:ControlParameter ControlID="txt_YYYMM" Name="YYMM" PropertyName="Text" />
            </UpdateParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblSysCode" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT TblId, TblCd, TblDesc, TblSeq FROM tblSysCode WHERE (TblId = '11') AND (TblCd =@TblCd  )">
            <SelectParameters>
                <asp:Parameter Name="TblCd" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_BRANCH" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT BRNO, BRNAME FROM chb_pub.dbo.BRANCH WHERE (BRNO = @gBrNo)">
            <SelectParameters>
                <asp:FormParameter FormField="gBrNo" Name="gBrNo" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_EMPLOYEE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT STAFF, NAME FROM chb_pub.dbo.EMPLOYEE WHERE (STAFF = @gEmpId)">
            <SelectParameters>
                <asp:FormParameter FormField="gEmpId" Name="gEmpId" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblIntraMgrRpt" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM [tblIntraMgrRpt] WHERE [DocNo] = @DocNo" InsertCommand="INSERT INTO [tblIntraMgrRpt] ([DocNo], [Brno], [BRName], [EmpId], [EmpName], [Ext], [YYYMM], [SN], [Brno_2], [Brno_Name_2], [Sign1Name_2], [EmpName_2], [Content1], [Improve]) VALUES (@DocNo, @Brno, @BRName, @EmpId, @EmpName, @Ext, @YYYMM, @SN, @Brno_2, @Brno_Name_2, @Sign1Name_2, @EmpName_2, @Content1, @Improve)"
            SelectCommand="SELECT * FROM [tblIntraMgrRpt]" UpdateCommand="UPDATE tblIntraMgrRpt 
SET  Content2 = @Content2
      , YYYMM = @YYYMM
     ,  DocNo ='DS' + @YYYMM + right(DocNo,5)
WHERE (DocNo = @DocNo)">
            <DeleteParameters>
                <asp:Parameter Name="DocNo" Type="String" />
            </DeleteParameters>
            <UpdateParameters>
                <asp:ControlParameter ControlID="hidn_hDocNo" Name="DocNo" PropertyName="Value" Type="String" />
                <asp:ControlParameter ControlID="txtContent2" Name="Content2" 
                    PropertyName="Text" Type="String" />
                <asp:ControlParameter ControlID="txt_YYYMM" Name="YYYMM" PropertyName="Text" />
            </UpdateParameters>
            <InsertParameters>
                <asp:Parameter Name="DocNo" Type="String" />
                <asp:Parameter Name="Brno" Type="String" />
                <asp:Parameter Name="BRName" Type="String" />
                <asp:Parameter Name="EmpId" Type="String" />
                <asp:Parameter Name="EmpName" Type="String" />
                <asp:Parameter Name="Ext" Type="String" />
                <asp:Parameter Name="YYYMM" Type="String" />
                <asp:Parameter Name="SN" Type="String" />
                <asp:Parameter Name="Brno_2" Type="String" />
                <asp:Parameter Name="Brno_Name_2" Type="String" />
                <asp:Parameter Name="Sign1Name_2" Type="String" />
                <asp:Parameter Name="EmpName_2" Type="String" />
                <asp:Parameter Name="Content1" Type="String" />
                <asp:Parameter Name="Improve" Type="String" />
                <asp:Parameter Name="Content2" Type="String" />
            </InsertParameters>
        </asp:SqlDataSource>
        <asp:HiddenField ID="hidn_hDocNo" runat="server" />
    </form>
</body>
</html>
