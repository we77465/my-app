﻿Imports System.Data.SqlClient
Partial Class Program_ODS3010_ODS2010
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''===== 從前一個網頁得到的值 IntraWeb/OACHB/Program/ODR2010/ODR2010QForm.asp ==========
        'Dim YYY As String = Request.QueryString("YYY") '年
        'Dim MM As String = Request.QueryString("MM") '月
        'Dim check1 As String = Request.QueryString("check1") '有無填報分行 yes = 有填報分行 no = 無該當分行

        ''Response.Write("YYY:" & YYY & "<br>")
        ''Response.Write("MM:" & MM & "<br>")
        ''Response.Write("check1:" & check1 & "<br>")

        'lblYYY.Text = YYY
        'lblMM.Text = MM

        'DS_tblIntraMgrRpt.SelectParameters("YYYMM").DefaultValue = YYY & MM '有填報 GridView1
        'DS_tblIntraMgrRpt2.SelectParameters("YYYMM").DefaultValue = YYY & MM '無該當  GridView2

    End Sub

    '匯出列印
    Protected Sub BtnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnExport.Click

        '匯出成HTML檔
        Response.AddHeader("content-disposition", "attachment; filename=ODS2010.htm")
        Response.Charset = "utf-8"
        Response.ContentType = "Content-Language;content=zh-tw"
        Response.ContentType = "application/vnd.ms-excel"

    End Sub

    '查詢
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim aaa As Array
        Dim bbb As String = "1:對員工之領導及輔導, 2:對本行各方面之反應意見, 3:對人事管理之意見, 4:日常工作協調及執行情形,5:員工在職訓練辦理情形, 6:職務指派之執行情形, 7:平常考核辦理情形, 8:員工服務態度之輔導,9:員工勤惰之管理, 10:單位記律之維護, 11:員工品德操守生活之考核輔導, 12:與客戶.朋友之交往情形,13:金錢往來情形, 14:員工士氣, 15:行內風氣, 16:行舍周圍及內部環境衛生安全防護, 17:其他內部管理綜合意見"
        aaa = bbb.Split(",")
        Dim i As Integer



        'For  r As GridViewRow In GridView1.Rows
        '    'MoneyCheck(r)
        '    '將(評估可回收金額的原幣合計)加總跟(列帳金額的原幣合計)做比較,如果一樣就寫資料庫,不一樣就離開迴圈

        '    If IsRowModified(r) Then GridView1.UpdateRow(r.RowIndex, False) '有異動才更新
        'Next
        


        'Response.Write(aaa(0) + "<br>")
        'Response.Write(aaa(1) + "<br>")
        'Response.Write(aaa(2) + "<br>")
        'Response.Write(aaa(3) + "<br>")
        'Response.Write(aaa(4) + "<br>")
        'Response.Write(aaa(15) + "<br>")
        'Response.Write(aaa(16) + "<br>")
        'GridView1.Rows(0).Cells(12).Text
        '"100101000101000"
        '        GridView1.Rows(0).Cells(12).Text





        '        Dim item1() As String
        '        item1 = Array("1:對員工之領導及輔導", "2:對本行各方面之反應意見", "3:對人事管理之意見", "4:日常工作協調及執行情形", _
        '         "5:員工在職訓練辦理情形", "6:事務分擔之執行情形", "7:平常考核辦理情形", "8:員工服務態度之輔導", _
        '"9:員工勤惰之管理", "10:單位記律之維護", "11:員工品德操守生活之考核輔導", "12:與客戶.朋友之交往情形", _
        '"13:金錢往來情形", "14:員工士氣", "15:行內風氣", "16:行舍周圍及內部環境衛生安全防護", "17:其他內部管理綜合意見")

        DS_tblIntraMgrRpt.SelectParameters("YYYMM").DefaultValue = ddlYYY.Text & ddlMM.Text '有填報 GridView1
        DS_tblIntraMgrRpt2.SelectParameters("YYYMM").DefaultValue = ddlYYY.Text & ddlMM.Text '無該當 GridView2

        GridView1.DataBind()
        GridView2.DataBind()
        Dim stemp As String
        stemp = ""
        Dim ii As Integer
        For ii = 0 To GridView1.Rows.Count - 1
            stemp = ""    '0981231增加(清除TEMP))
            For i = 1 To 17
                If Mid(GridView1.Rows(ii).Cells(12).Text, i, 1) = "1" Then
                    stemp = stemp & aaa(i - 1) + "<br>"
                End If
            Next

            '  Me.Response.Write(stemp)
            GridView1.Rows(ii).Cells(12).Text = stemp
        Next
    End Sub
End Class
