﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.VisualBasic;
using System.IO;
using DataAccessLayer.DALC;

public partial class Program_OEC1010_OEC1010 : System.Web.UI.Page
{
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        String strDOCNO="";
        
        if (!IsPostBack)
        {
            string strYYMM="";
            int intYear;
            txtBRNO.Text = (Request.Form["gBrNo"] == null) ? "" : Request.Form["gBrNo"].ToString().Replace("/", "").Trim();
            txtEmpid.Text = (Request.Form["gEmpId"] == null) ? "" : Request.Form["gEmpId"].ToString().Replace("/", "").Trim();
            
            using (Bussiness applc = new Bussiness())
            {
                ds = applc.select("select BRNAME from chb_pub..BRANCH where BRNO='" + txtBRNO.Text + "'", chb_eform.ConnectionString);
            }
            if (ds.Tables[0].Rows.Count != 0)
            {
                txtBRNAME.Text = ds.Tables[0].Rows[0]["BRNAME"].ToString();
            }
            using (Bussiness applc = new Bussiness())
            {
                ds = applc.select("select NAME from chb_pub..EMPLOYEE where STAFF='" + txtEmpid.Text + "'", chb_eform.ConnectionString);
            }
            if (ds.Tables[0].Rows.Count != 0)
            {
                txtEmpName.Text = ds.Tables[0].Rows[0]["NAME"].ToString();
            }

            if (Request.QueryString["DOCNO"] != null)
            {
                strDOCNO = Request.QueryString["DOCNO"].ToString();
                switch (strDOCNO.ToString().Substring(11,1))
                {
                    case "1":
                        DropDownList1.SelectedIndex = 1;
                        break;
                    case "2":
                        DropDownList1.SelectedIndex = 2;
                        break;
                    case "3":
                        DropDownList1.SelectedIndex = 3;
                        break;
                }
            }
            else
            {
                intYear = int.Parse(DateTime.Now.AddYears(-1911).Year.ToString());
                strYYMM = intYear.ToString().PadLeft(3, '0') + DateTime.Now.Month.ToString().PadLeft(2, '0');
                strDOCNO = "EC" + strYYMM + txtBRNO.Text + DropDownList1.SelectedValue;
            }

            lblDOCNO.Text = strDOCNO.ToString();
            chb_eform.SelectParameters["DOCNO"].DefaultValue = lblDOCNO.Text;
            
            using (Bussiness buss = new Bussiness())
            {
                string strSQL = "select b.FlowStatus,b.RecordDate,b.SignDate1,b.DecDate,a.* from tblOverTraining" +
                    " as a left join tblLogDetail as b on a.DOCNO=b.DocNo" +
                    " where a.BRNO='" + txtBRNO.Text.Trim() + "' and a.DOCNO='" + strDOCNO + "' order by a.DocDate ";
                ds = buss.select(strSQL, chb_eform.ConnectionString);
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblVer.Text = ShowFlowStatus(ds.Tables[0].Rows[0]["FlowStatus"].ToString(), ds.Tables[0].Rows[0]["RecordDate"].ToString(),
                    ds.Tables[0].Rows[0]["SignDate1"].ToString(), ds.Tables[0].Rows[0]["DecDate"].ToString());
                txtEnter.Text = ds.Tables[0].Rows[0]["EnterDate"].ToString();

                if (ds.Tables[0].Rows[0]["FlowStatus"].ToString() == "3" || ds.Tables[0].Rows[0]["FlowStatus"].ToString() == "4")
                    DropDownList1.Enabled = btnSave.Enabled = btnDel.Enabled = false;
            }
            //else
            //{
            //    txtEnter.Text = strYYMM + DateTime.Now.Day.ToString().PadLeft(2, '0');
            //}
            txtYYMM.Text = lblDOCNO.Text.Substring(2, 5);
        }
        chb_eform.SelectParameters["DOCNO"].DefaultValue = lblDOCNO.Text;
    }
    protected void OnPreRender(object sender, System.EventArgs e)
    {
        int j = 1;
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            j = j + 1;
            GridViewRow row = GridView1.Rows[i];
            Label DocDate = (Label)row.FindControl("txtDocDate");
            TextBox OverM = (TextBox)row.FindControl("txtOverM");
            TextBox OverT = (TextBox)row.FindControl("txtOverT");
            TextBox Num = (TextBox)row.FindControl("txtNum");

            OverM.Attributes.Add(("onblur"), "Numeric_OnBlur('GridView1$ctl0" + j + "$txtOverM')");
            OverT.Attributes.Add(("onblur"), "Numeric_OnBlur('GridView1$ctl0" + j + "$txtOverT')");
            Num.Attributes.Add(("onblur"), "Numeric_OnBlur('GridView1$ctl0" + j + "$txtNum');");
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string tSQL="";
        chb_eform.DeleteParameters["DOCNO"].DefaultValue = lblDOCNO.Text.Trim();
        chb_eform.Delete();

        if (txtYYMM.Text.Trim().Length != 5)
        {
            msg.Text = "年月輸入錯誤";
            return;
        }

        using (Bussiness applc = new Bussiness())
        {
            ds = applc.select("select * from tblLogDetail where DocNo='" + lblDOCNO.Text.Trim() + "'", chb_eform.ConnectionString);
        }
        if (ds.Tables[0].Rows.Count == 0)
        {
            tSQL = "insert into tblLogDetail (DocType,DocNo,BrNo,EmpId,RecordDate,DataFlag,YYMM,FlowStatus,Ver)" +
                " values('EC','" + lblDOCNO.Text + "','" + txtBRNO.Text + "','" + txtEmpid.Text + "',getdate(),'N','" + txtYYMM.Text + "','1','1')";
        }
        else
        {
            tSQL = "update tblLogDetail set EmpId='" + txtEmpid.Text + "', DataFlag = 'N'," +
               " FlowStatus = '1', Ver = Ver where DocNo='" + lblDOCNO.Text + "'";
        }
        using (Bussiness applc = new Bussiness())
        {
            applc.execute(tSQL, chb_eform.ConnectionString);
        }

        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow row = GridView1.Rows[i];
            Label DocDate = (Label)row.FindControl("txtDocDate");
            TextBox OverM = (TextBox)row.FindControl("txtOverM");
            TextBox OverT = (TextBox)row.FindControl("txtOverT");
            TextBox Num = (TextBox)row.FindControl("txtNum");
            int intYear = (DateTime.Now.Year-1911);
            chb_eform.InsertParameters["DOCNO"].DefaultValue = lblDOCNO.Text.Trim();
            chb_eform.InsertParameters["BRNO"].DefaultValue = txtBRNO.Text.Trim();
            chb_eform.InsertParameters["Empid"].DefaultValue = txtEmpid.Text.Trim();
            chb_eform.InsertParameters["EnterDate"].DefaultValue = DateTime.Now.Date.ToString("yyyyMMdd");//intYear.ToString().PadLeft(3, '0') + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
            chb_eform.InsertParameters["DocDate"].DefaultValue = DocDate.Text.Trim();
            chb_eform.InsertParameters["OverM"].DefaultValue = OverM.Text.Trim();
            chb_eform.InsertParameters["OverT"].DefaultValue = OverT.Text.Trim();
            chb_eform.InsertParameters["Num"].DefaultValue = Num.Text.Trim();
                        
            chb_eform.Insert();
            msg.Text = "儲存成功";
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string date1, date2;
        msg.Text = "";
        //lblDOCNO.Text = lblDOCNO.Text.Substring(0, 11) + DropDownList1.SelectedValue;
        lblDOCNO.Text = "EC" + txtYYMM.Text.Trim() + txtBRNO.Text.Trim() + DropDownList1.SelectedValue;
        switch (DropDownList1.SelectedValue.ToString())
        {
            case "1":
                date1 = "01";
                date2 = "10"; break;
            case "2":
                date1 = "11";
                date2 = "20"; break;
            case "3":
                date1 = "21";
                date2 = "31"; break;
            default:
                date1 = "01";
                date2 = "10"; break;
        }
        int YYYY = int.Parse(txtYYMM.Text.Substring(0, 3)) + 1911;
        string dateS = YYYY.ToString() + txtYYMM.Text.Substring(3, 2) + date1;
        string dateE = YYYY.ToString() + txtYYMM.Text.Substring(3, 2) + date2;
        string strSQL1 = "select b.*,a.FlowStatus from tblLogDetail as a inner join tblOverTraining as b on a.DocNo=b.DOCNO where a.DocNo='" + lblDOCNO.Text.Trim() + "' and b.BRNO='"+txtBRNO.Text+"'";
        string strSQL2 = "select a.DocDate,b.EnterDate,b.OverM,b.OverT,b.Num from (select distinct(NBSDY) as DocDate from DCHK_DATE "+
            " where NBSDY>='" + dateS + "' and NBSDY<='" + dateE + "')as a left join"+
            " (select DocDate,EnterDate,OverM,OverT,Num from tblOverTraining where DocDate>='" + dateS + "'"+
            " and DocDate<='" + dateE + "' and BRNO='"+txtBRNO.Text+"') as b on a.DocDate=b.DocDate";

        //DateTime.Now.AddMonths(1).Month.ToString().PadLeft(2,'0');
        using (Bussiness applc = new Bussiness())
        {
            ds = applc.select(strSQL1, chb_eform.ConnectionString);
        }
        if (ds.Tables[0].Rows.Count != 0)
        {
            chb_eform.SelectCommand = strSQL1;
            txtEnter.Text = ds.Tables[0].Rows[0]["EnterDate"].ToString();
            GridView1.DataBind();                

            if (ds.Tables[0].Rows[0]["FlowStatus"].ToString() == "3" || ds.Tables[0].Rows[0]["FlowStatus"].ToString() == "4")
                btnSave.Enabled = btnDel.Enabled = false;
            else
                btnSave.Enabled = btnDel.Enabled = true;
        }
        else
        {
            using (Bussiness applc = new Bussiness())
            {
                ds = applc.select(strSQL2, chb_eform.ConnectionString);
            }
            chb_eform.SelectCommand = strSQL2;
            GridView1.DataBind();
            btnSave.Enabled = btnDel.Enabled = true;
            //if (ds.Tables[0].Rows[0]["EnterDate"].ToString() == "")
                txtEnter.Text = DateTime.Now.Date.ToString("yyyyMMdd");

        }
    }


    private string ShowFlowStatus(string Ver, string RecordDate, string SignDate1, string DecDate)
    {
        string strRecordDate, strSignDate1, strDecDate;
        strRecordDate = (RecordDate == "") ? "" : FDateTime.CHNYYMMDD(RecordDate);
        strSignDate1 = (SignDate1 == "") ? "" : FDateTime.CHNYYMMDD(SignDate1);
        strDecDate = (DecDate == "") ? "" : FDateTime.CHNYYMMDD(DecDate);

        switch (Ver)
        {
            case "-1":
                return "總行退回 " + strDecDate;
            case "0":
                return "退回 " + strSignDate1;
            case "1":
                return "待簽核 " + strRecordDate;
            case "3":
                return "已決行 " + strSignDate1;
            case "4":
                return "已確認 " + strDecDate;
            default:
                return "";
        }
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        chb_eform.DeleteParameters["DOCNO"].DefaultValue = lblDOCNO.Text.Trim();
        chb_eform.Delete();

        using (Bussiness buss = new Bussiness())
        {
            buss.execute("delete from tblLogDetail where DocNo='"+lblDOCNO.Text.Trim()+"'",chb_eform.ConnectionString);
        }
        Response.Redirect("/oachb/program/OEC1010/QForm.asp");
    }
}
