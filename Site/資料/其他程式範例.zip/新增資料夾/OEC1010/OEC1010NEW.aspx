﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="OEC1010NEW.aspx.vb" Inherits="Program_OEC1010_OEC1010NEW" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
     <script language="JavaScript" type="text/javascript" src="OEC1010NEW.js"></script> 
</head>
  
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <table border="2" cellpadding="2" cellspacing="2" style="width: 750px">
            <tr>
                <td align="center" bgcolor="khaki">
                    <asp:Label ID="Label10" runat="server" Font-Bold="True" Font-Size="Small" ForeColor="Black"
                        Text="OEC1010"></asp:Label></td>
                <td colspan="3">
                    <asp:Label ID="Label11" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
                        ForeColor="Red" Text="營業單位加班自辦訓練統計表-單位填報" Width="300px"></asp:Label></td>
                <td bgcolor="khaki" style="width: 70px">
                    &nbsp;功 能：</td>
                <td align="center" colspan="3">
                    &nbsp;<asp:Button ID="Btn_Save" runat="server" Text="儲 存" />&nbsp;
                    <asp:Button ID="Btn_Del" runat="server"  Text="刪  除" OnClientClick="return confirm('確定刪除資料列？')" /></td>
            </tr>
            <tr>
                <td bgcolor="khaki">
                    &nbsp;表單號碼：</td>
                <td>
                    &nbsp;&nbsp;
                    <asp:Label ID="lbl_DocNo" runat="server" Font-Size="Medium" ForeColor="Black" Text="Label"></asp:Label>
                    </td>
                <td bgcolor="khaki" style="color: #000000">
                    &nbsp;填報年月：</td>
                <td align="center">
                    <asp:Label ID="lbl_YYYMM" runat="server" Font-Size="Medium" Text="Label"></asp:Label>&nbsp;
                </td>
                <td bgcolor="khaki">
                    &nbsp;表單狀態：</td>
                <td align="center">
                    <asp:Label ID="lbl_FlowStatus" runat="server" Font-Size="X-Small" Text="1"></asp:Label>
                    <asp:DropDownList ID="ddl_FlowStatus" runat="server" BackColor="#E0E0E0" DataSourceID="DS_tblSysCode" DataTextField="TblDesc" DataValueField="TblId" Enabled="False">
                    </asp:DropDownList>&nbsp;</td>
            </tr>
            <tr>
                <td bgcolor="khaki">
                    &nbsp;填報單位：</td>
                <td align="left">
                    &nbsp;
                    <asp:DropDownList ID="ddl_Brno" runat="server" BackColor="#E0E0E0" DataSourceID="DS_SC_USER"
                        DataTextField="OU_NAME" DataValueField="OU_ID" Enabled="False">
                    </asp:DropDownList></td>
                <td bgcolor="khaki">
                    &nbsp;填報人員：</td>
                <td align="center">
                    &nbsp;<asp:DropDownList ID="ddl_Name" runat="server" BackColor="#E0E0E0" DataSourceID="DS_SC_USER"
                        DataTextField="USR_NAM" DataValueField="USR_ID" Enabled="False">
                    </asp:DropDownList></td>
                <td bgcolor="khaki">
                    &nbsp;填報日期：</td>
                <td align="center">
                    <asp:Label ID="lbl_RecordDate" runat="server" Text="Label" Font-Size="Medium"></asp:Label>
                    &nbsp;&nbsp;</td>
            </tr>
        </table>
    </div>
        <hr />
        <table border="2" cellpadding="5" cellspacing="2">
            <tr align="center">
                <td bgcolor="khaki">
                    當月份加班時數加總(分)</td>
                <td bgcolor="khaki">
                    當月份自辦訓練時數加總(分)</td>
                <td bgcolor="khaki">
                    當月份叫號機叫號數加總(分)</td>
            </tr>
            <tr align="center">
                                <td>
                    <asp:TextBox ID="txt_OverM" runat="server" MaxLength="5" Style="text-align:right">0</asp:TextBox><br />
                    <asp:Label ID="Label2" runat="server" ForeColor="Red" Text="* 必填!請輸入正整數(最多5位數)"></asp:Label></td>
                <td>
                    <asp:TextBox ID="txt_OverT" runat="server" MaxLength="5" Style="text-align:right">0</asp:TextBox><br />
                    <asp:Label ID="Label1" runat="server" ForeColor="Red" Text="* 必填!請輸入正整數(最多5位數)"></asp:Label>&nbsp;</td>
                <td>
                    <asp:TextBox ID="txt_Num" runat="server" MaxLength="5" Style="text-align:right">0</asp:TextBox><br />
                    <asp:Label ID="Label3" runat="server" ForeColor="Red" Text="* 必填!請輸入正整數(最多5位數)"></asp:Label></td>
            </tr>
        </table>
        <br />
        <br />
        <asp:SqlDataSource ID="DS_SC_USER" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT     a.USR_ID, a.USR_ID + '-' + a.USR_NAME AS USR_NAM, a.OU_ID, a.OU_ID + '-' + b.OU_NAME AS OU_NAME, a.ID_ENABLE&#13;&#10;FROM         SC_USER AS a LEFT OUTER JOIN&#13;&#10;                      SC_ORG_UNIT AS b ON a.OU_ID = b.OU_ID&#13;&#10;WHERE     (a.ID_ENABLE = 'Y') AND (a.USR_ID = @USR_ID)">
            <SelectParameters>
                <asp:Parameter Name="USR_ID" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblLogDetail WHERE (DocNo = @DocNo) and (DocType = 'EC')"
            InsertCommand="INSERT INTO [tblLogDetail] ([DocType], [DocNo], [BrNo], [EmpId], [RecordDate], [DataFlag], [FormType], [YYMM], [Sign1], [Action1], [SignDate1], [SignComment1], [Sign2], [Action2], [SignDate2], [SignComment2], [DecManager], [DecDate], [FlowStatus], [Ver]) VALUES (@DocType, @DocNo, @BrNo, @EmpId, @RecordDate, @DataFlag, @FormType, @YYMM, @Sign1, @Action1, @SignDate1, @SignComment1, @Sign2, @Action2, @SignDate2, @SignComment2, @DecManager, @DecDate, @FlowStatus, @Ver)"
            SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
            UpdateCommand="UPDATE [tblLogDetail] SET [EmpId] = @EmpId, [RecordDate] = @RecordDate, [DataFlag] = @DataFlag, [Sign1] = @Sign1, [Action1] = @Action1, [SignDate1] = @SignDate1, [SignComment1] = @SignComment1,  [DecManager] = @DecManager, [DecDate] = @DecDate, [FlowStatus] = @FlowStatus, [Ver] = @Ver WHERE [DocNo] = @DocNo">
            <InsertParameters>
                <asp:Parameter DefaultValue="" Name="DocType" Type="String" />
                <asp:Parameter DefaultValue="" Name="DocNo" Type="String" />
                <asp:Parameter Name="BrNo" Type="String" />
                <asp:Parameter Name="EmpId" Type="String" />
                <asp:Parameter DefaultValue="" Name="RecordDate" Type="DateTime" />
                <asp:Parameter DefaultValue="" Name="DataFlag" Type="String" />
                <asp:Parameter Name="FormType" Type="String" />
                <asp:Parameter Name="YYMM" Type="String" />
                <asp:Parameter Name="Sign1" Type="String" />
                <asp:Parameter Name="Action1" Type="String" />
                <asp:Parameter Name="SignDate1" Type="DateTime" />
                <asp:Parameter Name="SignComment1" Type="String" />
                <asp:Parameter Name="Sign2" Type="String" />
                <asp:Parameter Name="Action2" Type="String" />
                <asp:Parameter Name="SignDate2" Type="DateTime" />
                <asp:Parameter Name="SignComment2" Type="String" />
                <asp:Parameter Name="DecManager" Type="String" />
                <asp:Parameter Name="DecDate" Type="DateTime" />
                <asp:Parameter Name="FlowStatus" Type="String" />
                <asp:Parameter Name="Ver" Type="Int16" />
            </InsertParameters>
            <DeleteParameters>
                <asp:Parameter Name="DocNo" />
            </DeleteParameters>
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <UpdateParameters>
                <asp:Parameter Name="EmpId" />
                <asp:Parameter Name="RecordDate" />
                <asp:Parameter Name="DataFlag" />
                <asp:Parameter Name="Sign1" />
                <asp:Parameter Name="Action1" />
                <asp:Parameter Name="SignDate1" />
                <asp:Parameter Name="SignComment1" />
                <asp:Parameter Name="DecManager" />
                <asp:Parameter Name="DecDate" />
                <asp:Parameter Name="FlowStatus" />
                <asp:Parameter Name="Ver" />
                <asp:Parameter Name="DocNo" />
            </UpdateParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblSysCode" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT     TblId, TblCd, TblDesc, TblSeq&#13;&#10;FROM         tblSysCode&#13;&#10;WHERE     (TblId = '11') AND (TblCd = @FlowStatus)">
            <SelectParameters>
                <asp:Parameter Name="FlowStatus" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblOverTrainingNew" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblOverTrainingNew WHERE DOCNO = @DOCNO" SelectCommand="SELECT [DOCNO], [BRNO], [OverM], [OverT], [Num] FROM [tblOverTrainingNew]&#13;&#10;WHERE DOCNO = @DocNo"
            UpdateCommand="UPDATE tblOverTrainingNew&#13;&#10;   SET BRNO = @BRNO&#13;&#10;      ,OverM = @OverM&#13;&#10;      ,OverT = @OverT&#13;&#10;      ,Num = @Num&#13;&#10; WHERE DOCNO = @DOCNO">
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <DeleteParameters>
                <asp:Parameter Name="DOCNO" />
            </DeleteParameters>
            <UpdateParameters>
                <asp:Parameter Name="BRNO" />
                <asp:Parameter Name="OverM" />
                <asp:Parameter Name="OverT" />
                <asp:Parameter Name="Num" />
                <asp:Parameter Name="DOCNO" />
            </UpdateParameters>
        </asp:SqlDataSource>
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        &nbsp;&nbsp;
    </form>
</body>
</html>
