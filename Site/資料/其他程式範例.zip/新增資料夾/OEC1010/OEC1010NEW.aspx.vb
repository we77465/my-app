﻿Imports System.Data.SqlClient

Partial Class Program_OEC1010_OEC1010NEW
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Not IsPostBack) Then

            '===========================================================================================
            '0. 前一個網頁(OEC1010QNEWForm.asp)得到的值

            Dim Tmpdocno As String = "" '表單編號
            Dim hDocNo As String = Request.Form("hDocNo").Replace(",", "") '表單編號            
            Dim gBrNo As String = Request.Form("gBrNo") '分行代號
            Dim gEmpId As String = Request.Form("gEmpId") '員編
            Dim hYear As String = Request.Form("hYear") '年月
            hYear = hYear.Replace(",", "").Replace("/", "")

            'Response.Write("hDocNo:(" & hDocNo & ")")
            'Response.Write("hYear:(" & hYear & ")")
            'Response.Write("gBrNo:(" & gBrNo & ")")
            'Response.Write("gEmpId:(" & gEmpId & ")")

            '表單編號判斷 ================================================================
            If (hDocNo = "") Then
                '表單不存在,組表單編號                Tmpdocno = "EC" & hYear & gBrNo & "1"            Else
                Tmpdocno = hDocNo '表單已存在
            End If
            'Response.Write("Tmpdocno:" & Tmpdocno & "<br>")

            '給值 =================================================================

            lbl_DocNo.Text = Tmpdocno.Trim '表單號碼
            lbl_YYYMM.Text = hYear.Trim '填報年月
            DS_SC_USER.SelectParameters("USR_ID").DefaultValue = gEmpId.Trim '填報單位 & 人員
            lbl_RecordDate.Text = Now().ToString("yyyy/MM/dd") '填報日期

            '查詢表單流程狀態
            GetDocNoInfo(lbl_DocNo.Text)
            '查詢表單內容
            GetDocNoFlw(lbl_DocNo.Text)

            '如果已核可不給變更
            If (Integer.Parse(lbl_FlowStatus.Text) >= 3) Then
                Btn_Save.Visible = False
                Btn_Del.Visible = False
                txt_OverM.ReadOnly = True
                txt_OverT.ReadOnly = True
                txt_Num.ReadOnly = True
            Else
                Btn_Save.Visible = True
                Btn_Del.Visible = True
                txt_OverM.ReadOnly = False
                txt_OverT.ReadOnly = False
                txt_Num.ReadOnly = False
            End If

            Btn_Save.Attributes.Add("onclick", "return ChkALL()") '檢查

        End If
    End Sub

    '儲存
    Protected Sub Btn_Save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        UpdateDB()
    End Sub

    '刪除
    Protected Sub Btn_Del_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Del.Click
        DS_tblLogDetail.DeleteParameters("DocNo").DefaultValue = lbl_DocNo.Text.Trim
        DS_tblOverTrainingNew.DeleteParameters("DOCNO").DefaultValue = lbl_DocNo.Text.Trim
        DS_tblLogDetail.Delete()
        DS_tblOverTrainingNew.Delete()

        Response.Write("<script language=javascript>alert('刪除成功！')</script>")
        Response.Write("<script language=javascript>window.location.href='/OACHB/Program/OEC1010/OEC1010NEWQForm.asp?hOvrd=1'</script>")
    End Sub

    '查詢表單流程狀態
    Private Sub GetDocNoFlw(ByVal DocNo)
        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT FlowStatus,RecordDate,EmpId FROM tblLogDetail WHERE DocNo = '" & DocNo & "' and DocType = 'EC'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                lbl_FlowStatus.Text = reader1(0).ToString()
                lbl_RecordDate.Text = reader1(1).ToString()
                DS_SC_USER.SelectParameters("USR_ID").DefaultValue = reader1(2).ToString().Trim '填報單位 & 人員
                ddl_Name.DataBind()
                ddl_Brno.DataBind()

            End While
            reader1.Close()
            cmd.Dispose()
        End Using

        DS_tblSysCode.SelectParameters("FlowStatus").DefaultValue = lbl_FlowStatus.Text
        ddl_FlowStatus.DataBind()
    End Sub

    '查詢表單內容
    Private Sub GetDocNoInfo(ByVal DocNo)
        Using conn As New SqlConnection(DS_tblOverTrainingNew.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT OverM, OverT, Num FROM tblOverTrainingNew WHERE DOCNO = '" & DocNo & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                txt_OverM.Text = reader1(0).ToString()
                txt_OverT.Text = reader1(1).ToString()
                txt_Num.Text = reader1(2).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using
    End Sub

    '更新資料庫
    Private Sub UpdateDB()


        If (txt_OverM.Text.Trim = "" Or txt_OverT.Text.Trim = "" Or txt_Num.Text.Trim = "") Then
            Page.RegisterStartupScript("checkAlert", "<script>alert('錯誤！時數加總必填！');</script>")

        ElseIf (Not IsNumeric(txt_OverM.Text.Trim) Or Not IsNumeric(txt_OverT.Text.Trim) Or Not IsNumeric(txt_Num.Text.Trim)) Then
            Page.RegisterStartupScript("checkAlert", "<script>alert('錯誤！時數加總為數字！');</script>")

        Else
            Dim ErrMesg As String = ""
            Dim RollBackMesg As String = ""
            Dim TmpSqlCommand_Del As String = ""
            Dim TmpSqlCommand_Insert As String = ""
            Dim TmpLogDetail_Del As String = ""
            Dim TmpLogDetail_Insert As String = ""

            TmpSqlCommand_Del = "DELETE FROM tblOverTrainingNew WHERE DOCNO = '" & lbl_DocNo.Text & "'"
            TmpSqlCommand_Insert = "INSERT INTO tblOverTrainingNew (DOCNO,BRNO,OverM,OverT,Num) VALUES ('" & lbl_DocNo.Text & "','" & ddl_Brno.SelectedValue & "','" & txt_OverM.Text.Trim & "','" & txt_OverT.Text.Trim & "','" & txt_Num.Text.Trim & "')"
            TmpLogDetail_Del = "delete from tblLogDetail where DocType = 'EC' and DocNo = '" & lbl_DocNo.Text & "'"
            TmpLogDetail_Insert = "INSERT INTO tblLogDetail (DocType,DocNo,BrNo,EmpId,RecordDate,DataFlag,YYMM,FlowStatus,Ver) " & _
                                  "VALUES ('EC','" & lbl_DocNo.Text & "','" & ddl_Brno.SelectedValue.Trim & "','" & ddl_Name.SelectedValue & "','" & Now() & "','N','" & lbl_YYYMM.Text.Trim & "','1','1')"

            Using conn As New SqlConnection(DS_tblOverTrainingNew.ConnectionString)
                conn.Open()
                Dim tran As SqlTransaction
                tran = conn.BeginTransaction()

                Dim cmd As New SqlCommand(TmpSqlCommand_Del, conn)
                Dim cmd2 As New SqlCommand(TmpSqlCommand_Insert, conn)
                Dim cmd3 As New SqlCommand(TmpLogDetail_Del, conn)
                Dim cmd4 As New SqlCommand(TmpLogDetail_Insert, conn)

                cmd.Transaction = tran
                cmd2.Transaction = tran
                cmd3.Transaction = tran
                cmd4.Transaction = tran

                Try
                    cmd.ExecuteNonQuery()
                    cmd2.ExecuteNonQuery()
                    cmd3.ExecuteNonQuery()
                    cmd4.ExecuteNonQuery()

                    tran.Commit()
                    Response.Write("<script language=javascript>alert('儲存成功，請通知負責人簽核！')</script>")
                    Response.Write("<script language=javascript>window.location.href='/OACHB/Program/OEC1010/OEC1010NEWQForm.asp?hOvrd=1'</script>")
                Catch ex As Exception
                    Response.Write("儲存失敗,請連絡資訊處,原因: (" & ex.Message & ")")
                    tran.Rollback()
                Finally
                    cmd.Dispose()
                    cmd2.Dispose()
                End Try

            End Using




        End If



   
    End Sub




End Class
