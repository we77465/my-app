﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="OEC1020NEW.aspx.vb" Inherits="Program_OEC1010_OEC1020NEW" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
    <style type="text/css">
        .style1
        {
            height: 32px;
        }
        .style2
        {
            height: 33px;
        }
    </style>
</head>
<script type="text/javascript" language="JavaScript">
        if (navigator.appName.indexOf('Internet Explorer') != -1)
        {
	        document.onmousedown = noSourceExplorer;
        }

            function noSourceExplorer()
            {
	            if (event.button == 2 | event.button == 3)
	            {
	                if (confirm('是否列印?')) 
	                {
                       	PrintScreen();                       	
                       	//window.print();
                    }
	            }
            }
            
            //列印div包起來的部分並且列印完畢後自動關閉列印網頁

            function PrintScreen()
            {
                var value = prt.innerHTML;
                var printPage = window.open("","printPage","");
                printPage.document.open();
                printPage.document.write("<HTML><head></head><BODY onload='window.print();'><center>");
                printPage.document.write(value);
                printPage.document.close("</center></BODY></HTML>");
            }

            
    </script>   
<body style="font-size: 10pt; background-color: #FFFFFF;" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    
        <table border="2" cellpadding="2" cellspacing="2" style="width: 750px">
            <tr>
                <th align="center" bgcolor="White" colspan="6" class="style1">
                    <asp:Label ID="Label10" runat="server" Font-Bold="True" Font-Size="Small" ForeColor="Black"
                        Text="OEC1020"></asp:Label>&nbsp;
                    <asp:Label ID="Label11" runat="server" Font-Bold="False" Font-Names="標楷體" Font-Size="Medium"
                        ForeColor="Red" Text="營業單位加班自辦訓練統計表-報表查詢" Width="323px" 
                        style="font-family: 標楷體; color: #000099; font-size: large"></asp:Label>
                    &nbsp;&nbsp;
                    <asp:Label ID="lbl_Brno" runat="server" Font-Size="Small" Text="Label"></asp:Label>
                    <asp:Label ID="lbl_Login" runat="server" Font-Size="Small" Text="Label"></asp:Label></th>
            </tr>
            <tr>
                <td bgcolor="#FFFFCC">
                    請輸入查詢單位：</td>
                <td align="center">
                    <asp:DropDownList ID="DDL_BRNO" runat="server" AppendDataBoundItems="True" DataSourceID="DB_BRNO"
                        DataTextField="BRNAME" DataValueField="BRNO">
                        <asp:ListItem Value="%" Selected="True">查詢全部</asp:ListItem>
                    </asp:DropDownList>&nbsp;</td>
                <td bgcolor="#FFFFCC">
                    請輸入查詢年月：</td>
                <td align="center">
                    <asp:DropDownList ID="ddl_YYY" runat="server" DataSourceID="sds_Year" 
                        DataTextField="YYY" DataValueField="YYY">
                    </asp:DropDownList>
                    年 &nbsp;<asp:DropDownList ID="ddl_MM" runat="server">
                        <asp:ListItem Enabled="False"></asp:ListItem>
                        <asp:ListItem>01</asp:ListItem>
                        <asp:ListItem>02</asp:ListItem>
                        <asp:ListItem>03</asp:ListItem>
                        <asp:ListItem>04</asp:ListItem>
                        <asp:ListItem>05</asp:ListItem>
                        <asp:ListItem>06</asp:ListItem>
                        <asp:ListItem>07</asp:ListItem>
                        <asp:ListItem>08</asp:ListItem>
                        <asp:ListItem>09</asp:ListItem>
                        <asp:ListItem>10</asp:ListItem>
                        <asp:ListItem>11</asp:ListItem>
                        <asp:ListItem>12</asp:ListItem>
                    </asp:DropDownList>月&nbsp;</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFCC" colspan="4" class="style2">
                    <asp:Button ID="btn_Submit" runat="server" Height="27px" Text="送出查詢" />
                </td>
            </tr>
        </table>
        <hr />
        <asp:Button ID="btn_excel" runat="server" Text="匯至EXCEL" />
        &nbsp;
        <asp:Button ID="Btn_Prt" runat="server" Text="列 印" /><br />
        <div id="prt">
        <asp:Label ID="Label3" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
            ForeColor="Red" Text="營業單位加班自辦訓練統計表-報表查詢"></asp:Label>
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
        <asp:Label ID="Label2" runat="server" Text="查詢單位："></asp:Label><asp:Label ID="lbl_BrnoInq" runat="server" ForeColor="Red" Text="請輸入"></asp:Label>
            &nbsp;&nbsp;
            <asp:Label ID="Label1" runat="server" Text="查詢年月："></asp:Label><asp:Label ID="lbl_YYYMMInq" runat="server" ForeColor="Red" Text="請輸入"></asp:Label><br />        
        <asp:GridView ID="GridView1" runat="server" BackColor="White" BorderColor="#996633"
            BorderStyle="None" BorderWidth="1px" CellPadding="4" DataSourceID="DS_tblOverTrainingNew"
            EmptyDataText="無相關資料" AutoGenerateColumns="False" ShowFooter="True">
            <RowStyle BackColor="White" ForeColor="#330099" />
            <FooterStyle BackColor="#990000" ForeColor="White" Font-Bold="True" />
            <PagerStyle BackColor="#FFFFCC" ForeColor="#330099" HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="#FFCC66" Font-Bold="True" ForeColor="#663399" />
            <HeaderStyle BackColor="#990000" Font-Bold="True" ForeColor="#FFFFCC" />
            <Columns>
                <asp:BoundField DataField="DOCNO" HeaderText="表單編號" SortExpression="DOCNO" />
                <asp:BoundField DataField="YYMM" HeaderText="所屬年月" SortExpression="YYMM" />
                <asp:BoundField DataField="BRNO" HeaderText="分行代號" SortExpression="BRNO" />
                <asp:BoundField DataField="BRNAME" HeaderText="分行名稱" SortExpression="BRNAME" />
                <asp:BoundField DataField="OverM" HeaderText="加班時數加總(分)" SortExpression="OverM">
                    <ItemStyle HorizontalAlign="Right" />
                </asp:BoundField>
                <asp:BoundField DataField="OverT" HeaderText="自辦訓練時數加總(分)" SortExpression="OverT">
                    <ItemStyle HorizontalAlign="Right" />
                </asp:BoundField>
                <asp:BoundField DataField="Num" HeaderText="叫號機叫號數加總(分)" SortExpression="Num">
                    <ItemStyle HorizontalAlign="Right" />
                </asp:BoundField>
            </Columns>
        </asp:GridView>
            <br />
            <br />
        <hr />
        </div>
        <asp:SqlDataSource ID="DB_BRNO" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
            SelectCommand="SELECT     BRNO, BRNO + '-' + BRNAME AS BRNAME
FROM         BRANCH
WHERE BRNO not in ('0000') 
and ([BRNAME] like '%分行%' or [BRNAME] like '%營業部%' )
and BRNO not in ('2120','2144','2151','2168','2175','2199','2026','2033') --OBU,海外分行不報
ORDER BY BRNO

--select distinct a.BRNO,a.BRNO+' '+a.BRNAME as BRNAME
--from [chb_pub].[dbo].[BRANCH] a
--inner join (select DOCNO,BRNO from [chb_eform].[dbo].[tblOverTrainingNew])b
--on a.BRNO=b.BRNO
--inner join [chb_eform].[dbo].[tblLogDetail] c
--on b.[DOCNO]=c.[DocNo]
--and c.FlowStatus='3'  --已決行才列
--and left(c.YYMM,3)=@YYY
--and right(c.YYMM,2)=@MM">
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_SC_USER" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT     OU_ID&#13;&#10;FROM         SC_USER&#13;&#10;WHERE     (USR_ID = @USR_ID) AND (ID_ENABLE = 'Y')">
            <SelectParameters>
                <asp:Parameter Name="USR_ID" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblOverTrainingNew" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT a.YYMM, a.DocNo, b.BRNO, c.BRNAME, b.OverM, b.OverT, b.Num FROM (SELECT DocNo, YYMM FROM tblLogDetail WHERE (DocType = 'EC') AND (BrNo LIKE @BrNo) AND (YYMM = @YYMM) AND (FlowStatus >= 3)) AS a LEFT OUTER JOIN tblOverTrainingNew AS b ON a.DocNo = b.DOCNO LEFT OUTER JOIN chb_pub.dbo.BRANCH AS c ON b.BRNO = c.BRNO ORDER BY b.BRNO">
            <SelectParameters>
                <asp:Parameter Name="YYMM" />
                <asp:Parameter Name="BrNo" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="sds_Year" runat="server" 
            ConnectionString="<%$ ConnectionStrings:chb_eform %>" SelectCommand="select * from
(select distinct left(b.YYMM,3) as YYY from [tblOverTrainingNew] a
inner join [tblLogDetail] b
on a.[DOCNO]=b.[DocNo])x
order by YYY desc"></asp:SqlDataSource>
    </form>
</body>
</html>
