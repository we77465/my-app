﻿// JScript 檔


  //列印div包起來的部分並且列印完畢後自動關閉列印網頁
            function PrintScreen(prt)
            {
                alert("111");
                //window.print();
                var value = prt.innerHTML;
                var printPage = window.open("","printPage","");
                printPage.document.open();
                printPage.document.write("<HTML><head></head><BODY onload='window.print();window.close()'><center>");
                printPage.document.write("<PRE>");
                printPage.document.write(value);
                printPage.document.write("</PRE>");
                printPage.document.close("</center></BODY></HTML>");
                return true;
            }
