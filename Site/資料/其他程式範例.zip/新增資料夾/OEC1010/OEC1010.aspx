﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="OEC1010.aspx.cs" Inherits="Program_OEC1010_OEC1010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head id="Head1" runat="server">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <script language="JavaScript" type="text/javascript" src="..\Common\js\Numeric.js"></script>
    <script language="JavaScript" type="text/javascript" src="..\Common\js\Other.js"></script>
    <link rel="stylesheet" type="text/css" href="../Common/css/Common.css"  /> 
    <title>未命名頁面</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <table border="1" class="APPID">
            <tr>
                <td>
                    <span class="t4">OEC1010：</span> <span style="color: #ff0066; font-family: 細明體; font-size: 10pt;">營業單位加班自辦訓練統計表</span>
                </td>
            </tr>
        </table>
    
    </div>
        <table style="width: 670px; height: 74px">
            <tr>
                <td style="width: 253px; height: 24px;">
                    <span style="font-size: 10pt">
                    表單編號：</span><asp:Label ID="lblDOCNO" runat="server" Text="" Width="165px"></asp:Label></td>
                <td style="width: 248px; height: 24px;">
                </td>
                <td style="height: 24px">
                    <asp:Button ID="btnSave" runat="server" Text="儲  存" OnClick="btnSave_Click" />
                    &nbsp;&nbsp;<asp:Button ID="btnDel" runat="server" Text="刪  除" OnClick="btnDel_Click" /></td>
            </tr>
            <tr>
                <td style="width: 253px">
                    <span style="font-size: 10pt">分行：</span>
                   <asp:TextBox ID="txtBRNO" runat="server" Width="60px" ReadOnly="true"></asp:TextBox>
                   <asp:TextBox ID="txtBRNAME" runat="server" Width="116px" ReadOnly="true"></asp:TextBox></td>
                <td style="width: 248px">
                    <span style="font-size: 10pt">經辦：</span>
                   <asp:TextBox ID="txtEmpid" runat="server" Width="70px" ReadOnly="true"></asp:TextBox>
                   <asp:TextBox ID="txtEmpName" runat="server" Width="100px" ReadOnly="true"></asp:TextBox></td>
                <td>
                    <span style="font-size: 10pt">
                    狀態：</span><asp:Label ID="lblVer" runat="server" Enabled="false" Font-Size="Smaller" Width="100px"></asp:Label></td>
            </tr>
            <tr>
                <td>
                    <span style="font-size: 10pt">
                    年月：</span>
                    <asp:TextBox ID="txtYYMM" runat="server" Width="60px"></asp:TextBox>
                    <asp:DropDownList ID="DropDownList1" runat="server" AutoPostBack="True" OnSelectedIndexChanged="DropDownList1_SelectedIndexChanged" >
                        <asp:ListItem Selected="True" Value="0">請選擇上中下旬..</asp:ListItem>
                        <asp:ListItem Value="1">1-上旬</asp:ListItem>
                        <asp:ListItem Value="2">2-中旬</asp:ListItem>
                        <asp:ListItem Value="3">3-下旬</asp:ListItem>
                    </asp:DropDownList></td>

                <td><span style="font-size: 10pt">
                    填報日期：<asp:TextBox ID="txtEnter" runat="server" ReadOnly="true" Width="105px"></asp:TextBox></span><%--<asp:Button ID="btnStart" runat="server" Text="開始填報" OnClick="btnStart_Click" /></td>--%><td>
                    <asp:Label ID="msg" runat="server" ForeColor="Red" Font-Bold="True"></asp:Label>
                    </td>
            </tr>
        </table>
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" CellPadding="4" DataSourceID="chb_eform" ForeColor="#333333" GridLines="None" OnPreRender="OnPreRender">
            <FooterStyle BackColor="#990000" Font-Bold="True" ForeColor="White" />
            <RowStyle BackColor="#FFFBD6" ForeColor="#333333"  />
            <Columns>
                <asp:TemplateField HeaderText="資料日期" SortExpression="DocDate">
                    <ItemTemplate>
                        <asp:Label ID="txtDocDate" runat="server" Text='<%# Bind("DocDate") %>' Width="110px"></asp:Label>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="本日加班時數(分)" SortExpression="OverM">
                    <ItemTemplate>
                        <asp:TextBox ID="txtOverM" runat="server" CssClass="numericINPUT" Text='<%# Bind("OverM") %>' ></asp:TextBox>
                    </ItemTemplate>
                    <HeaderStyle Wrap="False" />
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="本日自辦訓練時數(分)" SortExpression="OverT">
                    <ItemTemplate>
                        <asp:TextBox ID="txtOverT" runat="server" CssClass="numericINPUT" Text='<%# Bind("OverT") %>'></asp:TextBox>
                    </ItemTemplate>
                    <HeaderStyle Wrap="False" />
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="本日叫號機叫號數" SortExpression="Num">
                    <ItemTemplate>
                        <asp:TextBox ID="txtNum" runat="server" CssClass="numericINPUT" Text='<%# Bind("Num") %>'></asp:TextBox>
                    </ItemTemplate>
                    <HeaderStyle Wrap="False" />
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>
            </Columns>
            <PagerStyle BackColor="#FFCC66" ForeColor="#333333" HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="#FFCC66" Font-Bold="True" ForeColor="Navy" />
            <HeaderStyle BackColor="#990000" Font-Bold="True" ForeColor="White" />
            <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        <asp:SqlDataSource ID="chb_eform" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
        SelectCommand="select * from tblOverTraining as a left join tblLogDetail as b on a.DOCNO=b.DocNo where a.DOCNO=@DOCNO order by a.DocDate" 
        DeleteCommand="delete from tblOverTraining where DOCNO=@DOCNO" 
        InsertCommand="insert into tblOverTraining values(@DOCNO,@BRNO,@Empid,@EnterDate,@DocDate,@OverM,@OverT,@Num)">
            <SelectParameters>
                <asp:Parameter Name="DOCNO" />
            </SelectParameters>
            <DeleteParameters>
                <asp:Parameter Name="DOCNO" />
            </DeleteParameters>
            <InsertParameters>
                <asp:Parameter Name="DOCNO" />
                <asp:Parameter Name="BRNO" />
                <asp:Parameter Name="Empid" />
                <asp:Parameter Name="EnterDate" />
                <asp:Parameter Name="DocDate" />
                <asp:Parameter Name="OverM" />
                <asp:Parameter Name="OverT" />
                <asp:Parameter Name="Num" />
            </InsertParameters>
        </asp:SqlDataSource>
    </form>
</body>
</html>
