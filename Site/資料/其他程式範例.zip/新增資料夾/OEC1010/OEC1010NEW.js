﻿// JScript 檔

function ChkALL()         
         { 
            var TmpOverM = document.forms['form1'].txt_OverM.value;//當月份加班時數加總(分)
            var TmpOverT = document.forms['form1'].txt_OverT.value;//當月份自辦訓練時數加總(分)
            var TmpNum = document.forms['form1'].txt_Num.value;    //當月份叫號機叫號數加總(分)  
            
            ////當月份加班時數加總(分)
            if (trim(TmpOverM) == "")
            {
                alert("當月份加班時數加總(分)必填");
                document.forms['form1'].txt_OverM.value = 0;
                document.getElementById("txt_OverM").focus();  
                return false;
            }
            
              if (isNaN(TmpOverM) || TmpOverM.indexOf('.')>0)
            {
                alert("當月份加班時數加總(分)為正整數");
                document.forms['form1'].txt_OverM.value = 0;
                document.getElementById("txt_OverM").focus();  
                return false;
            }
            
            //當月份自辦訓練時數加總(分)
            if (trim(TmpOverT) == "")
            {
                alert("當月份加班時數加總(分)必填");
                document.forms['form1'].txt_OverT.value = 0;
                document.getElementById("txt_OverT").focus();  
                return false;
            }
            
              if (isNaN(TmpOverT) || TmpOverT.indexOf('.')>0)
            {
                alert("當月份加班時數加總(分)為正整數");
                document.forms['form1'].txt_OverT.value = 0;
                document.getElementById("txt_OverT").focus();  
                return false;
            }
            
            //當月份叫號機叫號數加總(分) 
             if (trim(TmpNum) == "")
            {
                alert("當月份加班時數加總(分)必填");
                document.forms['form1'].txt_Num.value = 0;
                document.getElementById("txt_Num").focus();  
                return false;
            }
            
              if (isNaN(TmpNum) || TmpNum.indexOf('.')>0)
            {
                alert("當月份加班時數加總(分)為正整數");
                document.forms['form1'].txt_Num.value = 0;
                document.getElementById("txt_Num").focus();  
                return false;
            }
            
        
 
             //alert("儲存完畢!");
             return true;
         }
         
//去除字串左邊的空白虛格
function ltrim(instr)
        {
            return instr.replace(/^[\s]*/gi,"");
        }

//去除字串右邊的空白虛格
function rtrim(instr)
        {
            return instr.replace(/[\s]*$/gi,"");
        }

//去除字串前後的空白虛格
function trim(instr)
        {
            instr = ltrim(instr);
            instr = rtrim(instr);
            return instr;
        }