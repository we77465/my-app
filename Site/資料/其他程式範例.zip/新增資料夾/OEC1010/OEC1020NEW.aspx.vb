﻿Imports System.Data.SqlClient
Imports System.IO.StringWriter
Imports System.Web.UI.HtmlTextWriter


Partial Class Program_OEC1010_OEC1020NEW
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Not IsPostBack) Then
            Dim TmpEmpId As String = Request.Cookies("CHB_IW_")("User_ID").ToString()
            lbl_Login.Text = TmpEmpId.Trim '填報人員

            Dim TmpBrno As String = GetEmpID2Name(lbl_Login.Text)            'OBU,海外分行不報            If TmpBrno = "2120" OrElse TmpBrno = "2144" OrElse TmpBrno = "2151" OrElse _                TmpBrno = "2168" OrElse TmpBrno = "2175" OrElse TmpBrno = "2199" OrElse _                TmpBrno = "2026" OrElse TmpBrno = "2033" Then                Me.Controls.Clear()                Me.Response.Write("您無此頁面的查詢權限！")            Else
                lbl_Brno.Text = TmpBrno '所屬分行
                DDL_BRNO.SelectedValue = lbl_Brno.Text.Trim '分行選單
                ddl_MM.SelectedValue = DateAdd(DateInterval.Month, -1, Now()).ToString("MM")

                '國內營運處＆資訊處可查全行
                If (lbl_Brno.Text.Trim = "0501" Or lbl_Brno.Text.Trim = "0201") Then
                    DDL_BRNO.Enabled = True
                    DDL_BRNO.SelectedValue = "%"
                Else
                    DDL_BRNO.Enabled = False
                End If

                '列印
                Btn_Prt.Attributes.Add("onclick", "return PrintScreen()")
                btn_excel.Visible = False
                Btn_Prt.Visible = False
            End If
        End If
    End Sub

    '利用員編找所屬分行
    Private Function GetEmpID2Name(ByVal gEmpId)
        'Response.Write("gEmpId:" & gEmpId & "<br>")
        Dim TmpBrno As String = ""
        Using conn As New SqlConnection(DS_SC_USER.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT OU_ID FROM SC_USER WHERE (USR_ID = '" & gEmpId & "') AND (ID_ENABLE = 'Y')"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                TmpBrno = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using
        Return TmpBrno
    End Function

    '送出查詢
    Protected Sub Btn_Submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Submit.Click
        lbl_BrnoInq.Text = DDL_BRNO.SelectedValue
        lbl_YYYMMInq.Text = ddl_YYY.SelectedValue & "/" & ddl_MM.SelectedValue

        DS_tblOverTrainingNew.SelectParameters("BrNo").DefaultValue = DDL_BRNO.SelectedValue
        DS_tblOverTrainingNew.SelectParameters("YYMM").DefaultValue = ddl_YYY.SelectedValue & ddl_MM.SelectedValue
        DS_tblOverTrainingNew.Select(New DataSourceSelectArguments)
        GridView1.DataBind()

        btn_excel.Visible = True
        Btn_Prt.Visible = True

        'Response.Write("DDL_BRNO:(" & DDL_BRNO.SelectedValue & ")")
        'Response.Write("ddl_YYY:(" & ddl_YYY.SelectedValue & ")")
        'Response.Write("ddl_MM:(" & ddl_MM.SelectedValue & ")")
        'Response.Write("<br>")
    End Sub

    '增加Gridview1表尾欄位(記得Gridview的ShowFooter要設為True)
    Protected Sub GridView1_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowCreated

        '===========增加表尾=========================================
        If Not (e.Row.RowType = DataControlRowType.Footer) Then
            Exit Sub
        End If

        Dim footer As TableCellCollection = e.Row.Cells
        footer.Clear() '清除原本的表尾

        '增加表尾,共7個Cell
        '表單編號
        Dim gv1 As New TableCell()
        gv1.HorizontalAlign = HorizontalAlign.Right
        gv1.Text = "合計"
        footer.Add(gv1)

        '所屬年月
        Dim gv2 As New TableCell()
        gv2.HorizontalAlign = HorizontalAlign.Center
        gv2.Text = ""
        footer.Add(gv2)

        '分行代號
        Dim gv3 As New TableCell()
        gv3.HorizontalAlign = HorizontalAlign.Right
        gv3.Text = ""
        footer.Add(gv3)

        '分行名稱
        Dim gv4 As New TableCell()
        gv4.HorizontalAlign = HorizontalAlign.Right
        gv4.Text = ""
        footer.Add(gv4)

        '加班時數加總(分)
        Dim gv5 As New TableCell()
        gv5.HorizontalAlign = HorizontalAlign.Right
        gv5.Text = "NULL"
        footer.Add(gv5)

        '自辦訓練時數加總(分)
        Dim gv6 As New TableCell()
        gv6.HorizontalAlign = HorizontalAlign.Right
        gv6.Text = "NULL"
        footer.Add(gv6)

        '叫號機叫號數加總(分)
        Dim gv7 As New TableCell()
        gv7.HorizontalAlign = HorizontalAlign.Right
        gv7.Text = "NULL"
        footer.Add(gv7)

    End Sub

    'Gridview1表尾加總計算
    Protected Sub GridView1_DataBound(ByVal sender As Object, ByVal e As EventArgs) Handles GridView1.DataBound

        If GridView1.Rows.Count = 0 Then
            Exit Sub
        End If

	Dim i as Integer

        Dim gv4, gv5, gv6 As Decimal
        '各欄位加總計算
        For Each row As GridViewRow In GridView1.Rows

            GridView1.FooterRow.Cells(0).Text = "合計"

            'Response.Write("r4:(" & row.Cells(4).Text & ")")
            'Response.Write("r5:(" & row.Cells(5).Text & ")")
            'Response.Write("r6:(" & row.Cells(6).Text & ")")

            '加班時數加總(分)
	    If (Integer.TryParse(row.Cells(4).Text,i)) Then
               gv4 += Decimal.Parse(row.Cells(4).Text.Replace("$", "").Replace(",", ""))
                GridView1.FooterRow.Cells(4).Text = gv4.ToString("N0") '貨幣符號
            End If

	    '自辦訓練時數加總(分)
            If (Integer.TryParse(row.Cells(5).Text,i)) Then
                gv5 += Decimal.Parse(row.Cells(5).Text.Replace("$", "").Replace(",", ""))
                GridView1.FooterRow.Cells(5).Text = gv5.ToString("N0") '貨幣符號
            End If

            '叫號機叫號數加總(分)
            If (Integer.TryParse(row.Cells(6).Text,i)) Then
                gv6 += Decimal.Parse(row.Cells(6).Text.Replace("$", "").Replace(",", ""))
                GridView1.FooterRow.Cells(6).Text = gv6.ToString("N0") '貨幣符號
            End If
        Next
    End Sub

    '匯至EXCEL
    Protected Sub btn_excel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_excel.Click
        '欄位為文字的 CSS設定
        Dim style As String = "<style> .text { mso-number-format:""\@""; } </style> "
        '以下為 GridView 轉 Excel 的程式
        Response.Clear()
        Response.AddHeader("content-disposition", "attachment;filename=OverTraining" & lbl_YYYMMInq.Text & ".xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excels"
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Dim stringWrite As New System.IO.StringWriter()
        Dim htmlWrite As New HtmlTextWriter(stringWrite)

        If GridView1.Visible = True Then
            GridView1.RenderControl(htmlWrite) '顯示分行 
        End If

        Response.Write(style)
        Response.Write(stringWrite.ToString())
        Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>") '內容亂碼使用
        Response.End()
    End Sub
    '將Gridview轉成excel檔(加此 sub 就不會出現「run at server」錯誤)
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' 加此 sub 就不會出現「run at server」錯誤
    End Sub
    '將Gridview轉成excel檔(將每個欄位格式都設成「文字」)
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        '將每個欄位格式都設成「文字」
        Dim i As Integer
        For i = 0 To 6
            If e.Row.RowType = DataControlRowType.DataRow Then
                e.Row.Cells(i).Attributes.Add("class", "text")
            End If
        Next
    End Sub

End Class
