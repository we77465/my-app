﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="OEA1010.aspx.cs" Inherits="Program_OEA1010_OEA1010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head id="Head1" runat="server">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <script language="JavaScript" type="text/javascript" src="..\Common\js\Numeric.js"></script>
    <script language="JavaScript" type="text/javascript" src="..\Common\js\Other.js"></script>
    <link rel="stylesheet" type="text/css" href="../Common/css/Common.css"  /> 
    <title>未命名頁面</title>
</head>
<body style="font-size: 12pt">
    <form id="form1" runat="server">
    <div>
        <br />
        表單編號：<asp:Label ID="lblDOCNO" runat="server" Height="19px" Width="150px"></asp:Label>分行：<asp:TextBox ID="txtBRNO" runat="server" Width="60px" ReadOnly="true"></asp:TextBox>
        <asp:TextBox ID="txtBRNAME" runat="server" ReadOnly="true"></asp:TextBox>
        &nbsp;&nbsp; &nbsp;&nbsp;
        狀態：<asp:Label ID="lblVer" runat="server" Height="19px" Width="150px" ForeColor="Gray" Font-Size="Medium"></asp:Label><br />
        <span style="font-family: 標楷體"><span style="color: #0000cc">*註：表列資料為97年1～6月平均動用率低於50％之企金授信戶，請填報至少20戶<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;列印請按滑鼠右鍵</span><br />
        </span>
        <asp:Button ID="btnSave" runat="server" Height="29px" Text="儲  存" Width="110px" Font-Size="Large" OnClick="btnSave_Click"/>
        &nbsp; &nbsp;
        <asp:Button ID="btnPrint" runat="server" Height="29px" Text="列  印" Width="110px" Font-Size="Large" OnClick="btnPrint_Click"/>

        <%--<asp:Button ID="btnDel" runat="server" Height="29px" Text="全部刪除" Width="110px" Font-Size="Large" OnClick="btnDel_Click"/>--%>
        &nbsp; &nbsp;<asp:Label ID="msg" runat="server" Text="" Height="22px" Width="235px" Font-Bold="true" Font-Size="Large" ForeColor="Red"></asp:Label><br />
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" CellPadding="4"
            Font-Size="Smaller" ForeColor="#333333" GridLines="None" 
            Width="1250px" OnPreRender="OnPreRender" OnSelectedIndexChanged="btnLink_Click">
            <HeaderStyle BackColor="#990000" CssClass="TBLHC" Font-Bold="True" ForeColor="White" />
            <RowStyle BackColor="#FFFBD6" ForeColor="#333333" />
            <AlternatingRowStyle BackColor="White" />
            <Columns>
                <asp:TemplateField HeaderText="勾選">
                    <ItemTemplate>
                        <asp:CheckBox ID="ChkSel" runat="server" CssClass="TBLHL" ></asp:CheckBox>
                    </ItemTemplate>
                    <ItemStyle HorizontalAlign="Center" Width="2%" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="客戶名稱">
                    <ItemTemplate>
                        <asp:TextBox ID="txtCmpName" runat="server" CssClass="TBLHL" Width="140px" ReadOnly="true" Text='<%# Eval("CmpName") %>'></asp:TextBox>
                    </ItemTemplate>
                    <ItemStyle HorizontalAlign="Center" Width="10%" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="客戶統編">
                    <ItemTemplate>
                        <asp:TextBox ID="txtCmpid" runat="server" CssClass="TBLHL" Width="90px" ReadOnly="true" Text='<%# Eval("Cmpid") %>' ></asp:TextBox>
                    </ItemTemplate>
                    <ItemStyle HorizontalAlign="Center" Width="8%" />
                </asp:TemplateField>
                <%--<asp:CommandField  ShowSelectButton="True" HeaderText="編輯" SelectText="更改AO" >
                    <ItemStyle Width="5%" />
                </asp:CommandField>--%>
                <asp:TemplateField HeaderText="AO">
                    <ItemTemplate>
                       <%--<asp:DropDownList ID="drop" runat="server" CssClass="TBLHL" Width="50px"></asp:DropDownList>--%>
                        <%--<asp:DropDownList ID="DropDownList1" runat="server" AutoPostBack="true"   >
                            <asp:ListItem Selected="True" Value="0">是否更改AO</asp:ListItem>
                            <asp:ListItem Value="1">是</asp:ListItem>
                            <asp:ListItem Value="2">否</asp:ListItem>
                        </asp:DropDownList>--%>
                        <%--<asp:TextBox ID="txtList" runat="server" Height="165px" Width="169px" TextMode="MultiLine" ReadOnly="true"></asp:TextBox>--%>
                        
                        <asp:TextBox ID="txtEmpid" runat="server" CssClass="TBLHL" Width="90px"  Text='<%# Eval("Empid") %>'></asp:TextBox>
                        <asp:TextBox ID="txtEmpName" runat="server" CssClass="TBLHL" Width="90px" Text='<%# Eval("EmpName") %>'></asp:TextBox>
                        <asp:Label ID="lblChange" runat="server" CssClass="TBLHL" Width="90px"  Visible="false"></asp:Label>
                        <br />
                        <asp:TextBox ID="txtEmpid2" runat="server" CssClass="TBLHL" Width="90px" Visible="false"></asp:TextBox>
                        <asp:TextBox ID="txtEmpName2" runat="server" CssClass="TBLHL" Width="90px" Visible="false"></asp:TextBox>
                    </ItemTemplate>
                    <ItemStyle HorizontalAlign="Center" Width="8%" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="97年6月平均動用率(%)">
                    <ItemTemplate>
                        <asp:TextBox ID="txtRate6" runat="server" CssClass="TBLHL" Width="140px" ReadOnly="true"></asp:TextBox><%--Text='<%# Eval("Rate6") %>'--%>
                    </ItemTemplate>
                    <ItemStyle Width="2%" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="未動用原因(可複選)">
                    <ItemTemplate>
                        <%--<asp:CheckBoxList  ID="chkA" runat="server" RepeatLayout="Flow" RepeatColumns="3" RepeatDirection="Horizontal" Font-Size="10pt">
                          <asp:ListItem Value="1" Text="1-額度">1-額度</asp:ListItem>
                          <asp:ListItem Value="2" Text="2-利率">2-利率</asp:ListItem>
                          <asp:ListItem Value="3" Text="3-費率、手續費">3-費率、手續費</asp:ListItem>
                          <asp:ListItem Value="4" Text="4-匯率">4-匯率</asp:ListItem>
                          <asp:ListItem Value="5" Text="5-鑑價">5-鑑價</asp:ListItem>
                          <asp:ListItem Value="6" Text="6-徵提擔保品內容">6-徵提擔保品內容</asp:ListItem>
                          <asp:ListItem Value="7" Text="7-距離較遠">7-距離較遠</asp:ListItem>
                          <asp:ListItem Value="8" Text="8-台新合併影響遭同業中傷">8-台新合併影響遭同業中傷<br/></asp:ListItem>
                          <asp:ListItem Value="9" Text="9-其他商品無法滿足客戶需求">9-其他商品無法滿足客戶需求</asp:ListItem>
                          <asp:ListItem Value="10" Text="10-作業程序繁瑣">10-作業程序繁瑣</asp:ListItem>                        
                        </asp:CheckBoxList>--%>
                        <asp:CheckBoxList  ID="chkA" runat="server" RepeatLayout="Flow" RepeatColumns="2" RepeatDirection="Horizontal" Font-Size="10pt">
                        </asp:CheckBoxList>
                    </ItemTemplate>
                    <ItemStyle Width="20%" Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="平均動用率(月份/%)">
                    <ItemTemplate>
                        <asp:Label ID="lblMonth7" runat="server" Width="20px" Font-Size="Medium" Text="7"></asp:Label>
                        <asp:TextBox ID="txtRate7" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                        <asp:Label ID="lblMonth8" runat="server" Width="20px" Font-Size="Medium" Text="8"></asp:Label>
                        <asp:TextBox ID="txtRate8" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                        <asp:Label ID="lblMonth9" runat="server" Width="20px" Font-Size="Medium" Text="9"></asp:Label>
                        <asp:TextBox ID="txtRate9" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                        <asp:Label ID="lblMonth10" runat="server" Width="20px" Font-Size="Medium" Text="10"></asp:Label>
                        <asp:TextBox ID="txtRate10" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                        <asp:Label ID="lblMonth11" runat="server" Width="20px" Font-Size="Medium" Text="11"></asp:Label>
                        <asp:TextBox ID="txtRate11" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                        <asp:Label ID="lblMonth12" runat="server" Width="20px" Font-Size="Medium" Text="12"></asp:Label>
                        <asp:TextBox ID="txtRate12" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                    </ItemTemplate>
                    <ItemStyle Width="15%" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="處理情形及執行瓶頸">
                    <ItemTemplate>
                        <asp:TextBox ID="txtPro7" runat="server" CssClass="TBLHL" Width="140px" ></asp:TextBox><br />
                        <asp:TextBox ID="txtPro8" runat="server" CssClass="TBLHL" Width="140px" ></asp:TextBox><br />
                        <asp:TextBox ID="txtPro9" runat="server" CssClass="TBLHL" Width="140px" ></asp:TextBox><br />
                        <asp:TextBox ID="txtPro10" runat="server" CssClass="TBLHL" Width="140px" ></asp:TextBox><br />
                        <asp:TextBox ID="txtPro11" runat="server" CssClass="TBLHL" Width="140px" ></asp:TextBox><br />
                        <asp:TextBox ID="txtPro12" runat="server" CssClass="TBLHL" Width="140px" ></asp:TextBox><br />
                    </ItemTemplate>
                    <ItemStyle HorizontalAlign="Center" Width="10%" />
                </asp:TemplateField>
            </Columns>
            <PagerStyle Font-Size="Large" />
        </asp:GridView>
        &nbsp;&nbsp;<asp:SqlDataSource ID="chb_eform" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
        SelectCommand="select * from tblLoanRate" 
        DeleteCommand="delete from tblLoanRate where  DocNo=@DocNo" 
        InsertCommand="insert into tblLoanRate(DocNo,Lindex,BRNO,CmpName,Cmpid,Empid,EmpName,ChkSel,C1,C2,C3,C4,C5,C6,C7,C8,C9,C10,C11,Rate,P7,P8,P9,P10,P11,P12) values  
        (@DocNo , @Lindex , @BRNO , @CmpName , @Cmpid ,@Empid ,@EmpName,@ChkSel,@C1 , @C2 , @C3 , @C4 , @C5 , @C6 , @C7 , @C8 , @C9 , @C10 ,@C11, @Rate , @P7 , @P8 , @P9 , @P10 , @P11 , @P12)" 
        UpdateCommand="update  tblLoanRate  set Empid=@Empid,EmpName=@EmpName,P7=@P7,P8=@P8,P9=@P9,P10=@P10,P11=@P11,P12=@P12 where DOCNO=@DOCNO and Cmpid=@Cmpid">
            <DeleteParameters>
                <asp:Parameter Name="DocNo" />
            </DeleteParameters>
            <InsertParameters>
                <asp:Parameter Name="DocNo" />
                <asp:Parameter Name="Lindex" />
                <asp:Parameter Name="BRNO" />
                <asp:Parameter Name="CmpName" />
                <asp:Parameter Name="Cmpid" />
                <asp:Parameter Name="Empid" />
                <asp:Parameter Name="EmpName" />
                <%--<asp:Parameter Name="ChangeDate" />
                <asp:Parameter Name="Empid2" />
                <asp:Parameter Name="EmpName2" />--%>
                <asp:Parameter Name="ChkSel" />
                <asp:Parameter Name="C1" />
                <asp:Parameter Name="C2" />
                <asp:Parameter Name="C3" />
                <asp:Parameter Name="C4" />
                <asp:Parameter Name="C5" />
                <asp:Parameter Name="C6" />
                <asp:Parameter Name="C7" />
                <asp:Parameter Name="C8" />
                <asp:Parameter Name="C9" />
                <asp:Parameter Name="C10" />
                <asp:Parameter Name="C11" />
                <asp:Parameter Name="Rate" />
                <asp:Parameter Name="P7" />
                <asp:Parameter Name="P8" />
                <asp:Parameter Name="P9" />
                <asp:Parameter Name="P10" />
                <asp:Parameter Name="P11" />
                <asp:Parameter Name="P12" />
            </InsertParameters>
            <UpdateParameters>
                <%--<asp:Parameter Name="ChangeDate" />--%>
                <asp:Parameter Name="Empid" />
                <asp:Parameter Name="EmpName" />
                <asp:Parameter Name="P7" />
                <asp:Parameter Name="P8" />
                <asp:Parameter Name="P9" />
                <asp:Parameter Name="P10" />
                <asp:Parameter Name="P11" />
                <asp:Parameter Name="P12" />
                <asp:Parameter Name="DOCNO" />
                <asp:Parameter Name="Cmpid" />
            </UpdateParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="AOSource" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
        InsertCommand="insert  into  tblLoanRateAO values (@DOCNO,@Cmpid,@ChangeDate,@AO,@AOName)" 
        SelectCommand="select * from  tblLoanRateAO"
        UpdateCommand="update tblLoanRateAO set ChangeDate=@ChangeDate where DOCNO=@DOCNO and Cmpid=@Cmpid and ChangeDate is NULL">
            <InsertParameters>
                <asp:Parameter Name="DOCNO" />
                <asp:Parameter Name="Cmpid" />
                <asp:Parameter Name="ChangeDate" />
                <asp:Parameter Name="AO" />
                <asp:Parameter Name="AOName" />
                <%--<asp:Parameter Name="Number" />--%>
            </InsertParameters>
            <UpdateParameters>
                <asp:Parameter Name="ChangeDate" />
                <asp:Parameter Name="DOCNO" />
                <asp:Parameter Name="Cmpid" />
            </UpdateParameters>
        </asp:SqlDataSource>
    </div>
    </form>
</body>
</html>
