﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.VisualBasic;
using System.IO;
using DataAccessLayer.DALC;

public partial class Program_OEA1010_OEA1010 : System.Web.UI.Page
{
    DataTable dt;
    String strUsrId = "", rFlowStatus = "";
    DataSet ds = new DataSet();
    string strSQL = "", strDOCNO = "";
    int index = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        ViewState["index"] = "";
        strUsrId = Request.Cookies["CHB_IW_"]["User_ID"];
        //strUsrId = "150066";
        using (Bussiness applc = new Bussiness())
        {
            ds = applc.select("select a.*,b.OU_NAME from CHBSC..SC_USER as a inner join CHBSC..SC_ORG_UNIT as b on a.OU_ID=b.OU_ID where USR_ID='" + strUsrId.ToString() + "'", chb_eform.ConnectionString);
        }
        if (ds.Tables[0].Rows.Count != 0)
        {
            txtBRNO.Text = ds.Tables[0].Rows[0]["OU_ID"].ToString();
            txtBRNAME.Text = ds.Tables[0].Rows[0]["OU_NAME"].ToString();
        }
        //txtBRNO.Text = "6006";
        //txtBRNAME.Text = "彰化分行";
        //strLine = UserInfo.getUserAdminInfo(Request.QueryString["SID"].ToString().Trim(), Request);
        //txtBRNO.Text = strLine[3].ToString();
        //txtBRNAME.Text = strLine[4].ToString();
        msg.Text = "";
        if (!IsPostBack)
        {
            int year = int.Parse(DateTime.Now.Year.ToString()) - 1911;
            string strYear = "097";//year.ToString().PadLeft(3, '0');
            string strMon = "07";//DateTime.Now.AddMonths(-2).Month.ToString().PadLeft(2, '0');
            ViewState["YYMM"] = DateTime.Now.Year.ToString() + strMon.ToString();
            strDOCNO = "EA" + strYear + strMon + txtBRNO.Text.Trim() + "1";

            using (Bussiness buss = new Bussiness())
            {
                strSQL = "select b.FlowStatus,b.RecordDate,b.SignDate1,b.DecDate,a.* from tblLoanRate" +
                    " as a left join tblLogDetail as b on a.DocNo=b.DocNo" +
                    " where a.BRNO='" + txtBRNO.Text.Trim() + "' and a.DocNo='" + strDOCNO + "' order by a.Empid desc ";
                ds = buss.select(strSQL, chb_eform.ConnectionString);
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                
                GridView1.DataSource = ds;
                GridView1.DataBind();
                lblDOCNO.Text = strDOCNO.ToString();
                rFlowStatus = ds.Tables[0].Rows[0]["FlowStatus"].ToString();
                lblVer.Text = ShowFlowStatus(rFlowStatus, ds.Tables[0].Rows[0]["RecordDate"].ToString(),
                    ds.Tables[0].Rows[0]["SignDate1"].ToString(), ds.Tables[0].Rows[0]["DecDate"].ToString());
                //if (rFlowStatus == "3" || rFlowStatus == "4")
                //    btnSave.Enabled = false;
                //else
                //    btnSave.Enabled = true;
            }
            else
            {
                lblDOCNO.Text = "EA" + strYear + strMon + txtBRNO.Text.Trim() + "1";

                using (Bussiness buss = new Bussiness())
                {
                    //strSQL = "select a.* from (SELECT BRNO,BRNAME,Cmpid,CmpName,Empid,EmpName," +
                    //    "SUM(CASE YYMM WHEN 200806 THEN Rate6*100 ELSE NULL END) AS Rate6, " +
                    //    "SUM(CASE YYMM WHEN 200807 THEN Rate6*100 ELSE NULL END) AS Rate7, " +
                    //    "SUM(CASE YYMM WHEN 200808 THEN Rate6*100 ELSE NULL END) AS Rate8, " +
                    //    "SUM(CASE YYMM WHEN 200809 THEN Rate6*100 ELSE NULL END) AS Rate9, " +
                    //    "SUM(CASE YYMM WHEN 200810 THEN Rate6*100 ELSE NULL END) AS Rate10, " +
                    //    "SUM(CASE YYMM WHEN 200811 THEN Rate6*100 ELSE NULL END) AS Rate11, " +
                    //    "SUM(CASE YYMM WHEN 200812 THEN Rate6*100 ELSE NULL END) AS Rate12 " +
                    //    "FROM tblLoanRate02 where BRNO='" + txtBRNO.Text.Trim() + "' " +
                    //    "GROUP BY BRNO,BRNAME,Cmpid,CmpName,Empid,EmpName) as a " +
                    //    "where a.Rate6 is not NULL and a.Rate6<=50 ";
                    strSQL = "select a.*,b.Empid,b.EmpName,b.ChkSel,b.C1,b.C2,b.C3,b.C4,b.C5,b.C6,b.C7,b.C8,b.C9,b.C10,C11,b.P7," +
                        " b.P8,b.P9,b.P10,b.P11,b.P12 from " +
                        "(SELECT RTRIM(BRNO) as BRNO,RTRIM(BRNAME) as BRNAME,RTRIM(Cmpid) as Cmpid,RTRIM(CmpName) as CmpName," +
                        " SUM(CASE YYMM WHEN 200806 THEN Rate6*100 ELSE NULL END) AS Rate6, " +
                        " SUM(CASE YYMM WHEN 200807 THEN Rate6*100 ELSE NULL END) AS Rate7, " +
                        " SUM(CASE YYMM WHEN 200808 THEN Rate6*100 ELSE NULL END) AS Rate8, " +
                        " SUM(CASE YYMM WHEN 200809 THEN Rate6*100 ELSE NULL END) AS Rate9, " +
                        " SUM(CASE YYMM WHEN 200810 THEN Rate6*100 ELSE NULL END) AS Rate10, " +
                        " SUM(CASE YYMM WHEN 200811 THEN Rate6*100 ELSE NULL END) AS Rate11, " +
                        " SUM(CASE YYMM WHEN 200812 THEN Rate6*100 ELSE NULL END) AS Rate12 " +
                        " FROM tblLoanRate02 where BRNO='" + txtBRNO.Text.Trim() + "' " +
                        " GROUP BY BRNO,BRNAME,Cmpid,CmpName) as a right join " +
                        " (select * from tblLoanRate) as b on a.BRNO=b.BRNO and a.Cmpid=b.Cmpid " +
                        " where a.Rate6 is not NULL and (a.Rate6<=50) order by b.Empid ";

                    ds = buss.select(strSQL, chb_eform.ConnectionString);
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                }
            }
            //ViewState["DOCNO"] = lblDOCNO.Text;
            //ViewState["BRNO"] = txtBRNO.Text;
        }
    }

    protected void OnPreRender(object sender, System.EventArgs e)
    {
        int i = 0;
        DataSet ds1 = new DataSet();
        DataSet ds2 = new DataSet();

        using (Bussiness buss = new Bussiness())
        {
            strSQL = "select a.*,b.Empid,b.EmpName,b.ChkSel,b.C1,b.C2,b.C3,b.C4,b.C5,b.C6,b.C7,b.C8,b.C9,b.C10,C11,b.P7," +
                    " b.P8,b.P9,b.P10,b.P11,b.P12 from " +
                    "(SELECT RTRIM(BRNO) as BRNO,RTRIM(BRNAME) as BRNAME,RTRIM(Cmpid) as Cmpid,RTRIM(CmpName) as CmpName," +
                    " SUM(CASE YYMM WHEN 200806 THEN Rate6*100 ELSE NULL END) AS Rate6, " +
                    " SUM(CASE YYMM WHEN 200807 THEN Rate6*100 ELSE NULL END) AS Rate7, " +
                    " SUM(CASE YYMM WHEN 200808 THEN Rate6*100 ELSE NULL END) AS Rate8, " +
                    " SUM(CASE YYMM WHEN 200809 THEN Rate6*100 ELSE NULL END) AS Rate9, " +
                    " SUM(CASE YYMM WHEN 200810 THEN Rate6*100 ELSE NULL END) AS Rate10, " +
                    " SUM(CASE YYMM WHEN 200811 THEN Rate6*100 ELSE NULL END) AS Rate11, " +
                    " SUM(CASE YYMM WHEN 200812 THEN Rate6*100 ELSE NULL END) AS Rate12 " +
                    " FROM tblLoanRate02 where BRNO='" + txtBRNO.Text.Trim() + "' " +
                    " GROUP BY BRNO,BRNAME,Cmpid,CmpName) as a right join " +
                    " (select * from tblLoanRate) as b on a.BRNO=b.BRNO and a.Cmpid=b.Cmpid " +
                    " where a.Rate6 is not NULL and (a.Rate6<=50) order by b.Empid "; 
            ds1 = buss.select(strSQL, chb_eform.ConnectionString);
        }

        if (ds1.Tables[0].Rows.Count == 0)
        {
            msg.Text = "無資料";
            btnSave.Enabled = false;
        }
        else
        {
            GridView1.DataSource = ds1;
            GridView1.DataBind();
        }

        //}
            for (i = 0; i < GridView1.Rows.Count; i++)
            {
                GridViewRow GVR = GridView1.Rows[i];
                TextBox CmpName = (TextBox)GVR.FindControl("txtCmpName");
                TextBox Cmpid = (TextBox)GVR.FindControl("txtCmpid");
                TextBox Empid = (TextBox)GVR.FindControl("txtEmpid");
                TextBox EmpName = (TextBox)GVR.FindControl("txtEmpName");

                TextBox Rate6 = (TextBox)GVR.FindControl("txtRate6");
                TextBox Rate7 = (TextBox)GVR.FindControl("txtRate7");
                TextBox Rate8 = (TextBox)GVR.FindControl("txtRate8");
                TextBox Rate9 = (TextBox)GVR.FindControl("txtRate9");
                TextBox Rate10 = (TextBox)GVR.FindControl("txtRate10");
                TextBox Rate11 = (TextBox)GVR.FindControl("txtRate11");
                TextBox Rate12 = (TextBox)GVR.FindControl("txtRate12");
                //if (txtBRNO.Text.Trim() != "9554")
                //{
                TextBox P7 = (TextBox)GVR.FindControl("txtPro7");
                TextBox P8 = (TextBox)GVR.FindControl("txtPro8");
                TextBox P9 = (TextBox)GVR.FindControl("txtPro9");
                TextBox P10 = (TextBox)GVR.FindControl("txtPro10");
                TextBox P11 = (TextBox)GVR.FindControl("txtPro11");
                TextBox P12 = (TextBox)GVR.FindControl("txtPro12");
                //}
                CheckBoxList chkA = (CheckBoxList)GVR.FindControl("chkA");
                CheckBox ChkSel = (CheckBox)GVR.FindControl("ChkSel");
                ChkSel.Enabled = false;
                chkA.Items.Clear();

                if (ds1.Tables[0].Rows.Count > 0)
                {
                    if (i < ds1.Tables[0].Rows.Count)
                    {
                        CmpName.Text = ds1.Tables[0].Rows[i]["CmpName"].ToString();
                        Cmpid.Text = ds1.Tables[0].Rows[i]["Cmpid"].ToString();
                        using (Bussiness buss = new Bussiness())
                        {
                            ds = buss.select("SELECT * FROM tblLoanRateAO AS a INNER JOIN tblLoanRate AS b " +
                                " ON a.DOCNO = b.DocNo AND a.Cmpid = b.Cmpid  WHERE a.DOCNO='" + lblDOCNO.Text.Trim() + "' and a.Cmpid='" + Cmpid.Text + "' and a.ChangeDate is NULL ", chb_eform.ConnectionString);
                        }
                        if (ds.Tables[0].Rows.Count != 0)
                        {
                            Empid.Text = ds.Tables[0].Rows[0]["AO"].ToString();
                            EmpName.Text = ds.Tables[0].Rows[0]["AOName"].ToString();
                        }
                        Rate6.Text = ds1.Tables[0].Rows[i]["Rate6"].ToString();
                        if (ds1.Tables[0].Rows[i]["Rate7"].ToString() != "")
                            Rate7.Text = ds1.Tables[0].Rows[i]["Rate7"].ToString();
                        else
                            Rate7.Text = "已結清或沒有餘額";
                            
                        if (ds1.Tables[0].Rows[i]["Rate8"].ToString() != "")
                            Rate8.Text = ds1.Tables[0].Rows[i]["Rate8"].ToString();
                        else
                            Rate8.Text = "已結清或沒有餘額";

                        if (ds1.Tables[0].Rows[i]["Rate9"].ToString() != "")
                            Rate9.Text = ds1.Tables[0].Rows[i]["Rate9"].ToString();
                        else
                            Rate9.Text = "已結清或沒有餘額";
                            
                        if (ds1.Tables[0].Rows[i]["Rate10"].ToString() != "")
                            Rate10.Text = ds1.Tables[0].Rows[i]["Rate10"].ToString();
                        else
                            Rate10.Text = "已結清或沒有餘額";  
                        
                        if (ds1.Tables[0].Rows[i]["Rate11"].ToString() != "")
                            Rate11.Text = ds1.Tables[0].Rows[i]["Rate11"].ToString();
                        else
                            Rate11.Text = "已結清或沒有餘額";

                        if (ds1.Tables[0].Rows[i]["Rate12"].ToString() != "")
                            Rate12.Text = ds1.Tables[0].Rows[i]["Rate12"].ToString();
                        else
                            Rate12.Text = "已結清或沒有餘額";

                        //Rate12.Text = ds1.Tables[0].Rows[i]["Rate12"].ToString();

                        P7.Text = ds1.Tables[0].Rows[i]["P7"].ToString();
                        P8.Text = ds1.Tables[0].Rows[i]["P8"].ToString();
                        P9.Text = ds1.Tables[0].Rows[i]["P9"].ToString();
                        P10.Text = ds1.Tables[0].Rows[i]["P10"].ToString();
                        P11.Text = ds1.Tables[0].Rows[i]["P11"].ToString();
                        P12.Text = ds1.Tables[0].Rows[i]["P12"].ToString();


                        using (Bussiness buss = new Bussiness())
                        {
                            ds = buss.select("SELECT * FROM tblLoanRateAO WHERE DOCNO='" + lblDOCNO.Text.Trim() + "' and Cmpid='" + Cmpid.Text + "' and ChangeDate is not NULL ", chb_eform.ConnectionString);
                        }

                        //chkA.RepeatColumns = 1;
                        for (int j = 1; j <= 11; j++)
                        {
                            string col = "C" + j.ToString();
                            ListItem item = new ListItem();

                            item.Text = addItem(j);
                            if (ds1.Tables[0].Rows[i][col].ToString() == "Y")
                            {
                                item.Selected = true;
                                //item.Enabled = false;
                            }
                            chkA.Items.Add(item);

                        }

                        if (ds1.Tables[0].Rows[i]["ChkSel"].ToString() == "Y")
                        {
                            ChkSel.Checked = true;
                            //ChkSel.Enabled = false;
                        }
                    }
                }
            }
    }

    private string addItem(int a)
    {
        string ItemText = "";
        switch (a)
        {
            case 1:
                ItemText = "1-額度"; break;
            case 2:
                ItemText = "2-利率"; break;
            case 3:
                ItemText = "3-費率、手續費"; break;
            case 4:
                ItemText = "4-匯率"; break;
            case 5:
                ItemText = "5-鑑價"; break;
            case 6:
                ItemText = "6-徵提擔保品內容"; break;
            case 7:
                ItemText = "7-距離較遠"; break;
            case 8:
                ItemText = "8-台新合併影響遭同業中傷"; break;
            case 9:
                ItemText = "9-其他商品無法滿足客戶需求"; break;
            case 10:
                ItemText = "10-作業程序繁瑣"; break;
            case 11:
                ItemText = "11-其他"; break;
            default:
                ItemText = ""; break;
        }
        return ItemText.ToString();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        int indexNo = 0, SelectSum = 0;
        ViewState["hasData"] = "";

        chb_eform.DeleteParameters["DocNo"].DefaultValue = lblDOCNO.Text.Trim();
        chb_eform.Delete();

        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            GridViewRow row = GridView1.Rows[i];
            CheckBox ChkSel = (CheckBox)row.FindControl("ChkSel");
            TextBox CmpName = (TextBox)row.FindControl("txtCmpName");
            TextBox Cmpid = (TextBox)row.FindControl("txtCmpid");
            TextBox Empid = (TextBox)row.FindControl("txtEmpid");
            TextBox EmpName = (TextBox)row.FindControl("txtEmpName");
            TextBox Rate6 = (TextBox)row.FindControl("txtRate6");
            TextBox Rate7 = (TextBox)row.FindControl("txtRate7");
            TextBox Rate8 = (TextBox)row.FindControl("txtRate8");
            TextBox Rate9 = (TextBox)row.FindControl("txtRate9");
            TextBox Rate10 = (TextBox)row.FindControl("txtRate10");
            TextBox Rate11 = (TextBox)row.FindControl("txtRate11");
            TextBox Rate12 = (TextBox)row.FindControl("txtRate12");
            TextBox P7 = (TextBox)row.FindControl("txtPro7");
            TextBox P8 = (TextBox)row.FindControl("txtPro8");
            TextBox P9 = (TextBox)row.FindControl("txtPro9");
            TextBox P10 = (TextBox)row.FindControl("txtPro10");
            TextBox P11 = (TextBox)row.FindControl("txtPro11");
            TextBox P12 = (TextBox)row.FindControl("txtPro12");
            CheckBoxList chkA = (CheckBoxList)row.FindControl("chkA");
            indexNo = i + 1;
            chb_eform.InsertParameters["DocNo"].DefaultValue = lblDOCNO.Text;
            chb_eform.InsertParameters["Lindex"].DefaultValue = indexNo.ToString();
            chb_eform.InsertParameters["BRNO"].DefaultValue = txtBRNO.Text;
            chb_eform.InsertParameters["CmpName"].DefaultValue = CmpName.Text.Trim();
            chb_eform.InsertParameters["Cmpid"].DefaultValue = Cmpid.Text.Trim();
            chb_eform.InsertParameters["Empid"].DefaultValue = Empid.Text.Trim();
            chb_eform.InsertParameters["EmpName"].DefaultValue = EmpName.Text.Trim();

            chb_eform.InsertParameters["Rate"].DefaultValue = Rate6.Text.Trim();
            chb_eform.InsertParameters["P7"].DefaultValue = P7.Text.Trim();
            chb_eform.InsertParameters["P8"].DefaultValue = P8.Text.Trim();
            chb_eform.InsertParameters["P9"].DefaultValue = P9.Text.Trim();
            chb_eform.InsertParameters["P10"].DefaultValue = P10.Text.Trim();
            chb_eform.InsertParameters["P11"].DefaultValue = P11.Text.Trim();
            chb_eform.InsertParameters["P12"].DefaultValue = P12.Text.Trim();
            chb_eform.InsertParameters["C1"].DefaultValue = " ";
            chb_eform.InsertParameters["C2"].DefaultValue = " ";
            chb_eform.InsertParameters["C3"].DefaultValue = " ";
            chb_eform.InsertParameters["C4"].DefaultValue = " ";
            chb_eform.InsertParameters["C5"].DefaultValue = " ";
            chb_eform.InsertParameters["C6"].DefaultValue = " ";
            chb_eform.InsertParameters["C7"].DefaultValue = " ";
            chb_eform.InsertParameters["C8"].DefaultValue = " ";
            chb_eform.InsertParameters["C9"].DefaultValue = " ";
            chb_eform.InsertParameters["C10"].DefaultValue = " ";
            chb_eform.InsertParameters["C11"].DefaultValue = " ";

            if (ChkSel.Checked == true)
                chb_eform.InsertParameters["ChkSel"].DefaultValue = "Y";
            else
                chb_eform.InsertParameters["ChkSel"].DefaultValue = "";

            for (int j = 1; j <= chkA.Items.Count; j++)
            {
                ListItem item = new ListItem();
                if (chkA.Items[j - 1].Selected.ToString() == "True")
                {
                    string col;
                    if (chkA.Items[j - 1].Text.Substring(0, 2) == "10")
                        col = "C10";
                    else if (chkA.Items[j - 1].Text.Substring(0, 2) == "11")
                        col = "C11";
                    else
                        col = "C" + chkA.Items[j - 1].Text.Substring(0, 1);
                    chb_eform.InsertParameters[col].DefaultValue = "Y";
                }
            }

            //using (Bussiness buss = new Bussiness())
            //{
            //    buss.execute("delete tblLoanRateAO where DOCNO='" + lblDOCNO.Text.Trim() + "' and Cmpid='" + Cmpid.Text.Trim() + "' and AO='" + Empid.Text.Trim() + "'", AOSource.ConnectionString);
            //}

            if (ChkSel.Checked)
            {
                SelectSum = SelectSum + 1;
                chb_eform.Insert();
                ViewState["hasData"] = "Y";
                using (Bussiness buss = new Bussiness())
                {
                    ds = buss.select("SELECT * FROM tblLoanRateAO WHERE DOCNO='" + lblDOCNO.Text.Trim() + "' and Cmpid='" + Cmpid.Text.Trim() + "' ", AOSource.ConnectionString);
                }
                if (ds.Tables[0].Rows.Count == 0)
                {
                    AOSource.InsertParameters["DOCNO"].DefaultValue = lblDOCNO.Text;
                    AOSource.InsertParameters["Cmpid"].DefaultValue = Cmpid.Text.Trim();
                    AOSource.InsertParameters["AO"].DefaultValue = Empid.Text.Trim();
                    AOSource.InsertParameters["AOName"].DefaultValue = EmpName.Text.Trim();
                    AOSource.InsertParameters["ChangeDate"].DefaultValue = "";
                    AOSource.Insert();
                }
                else
                {

                    using (Bussiness buss = new Bussiness())
                    {
                        ds = buss.select("SELECT * FROM tblLoanRateAO WHERE DOCNO='" + lblDOCNO.Text.Trim() + "' and Cmpid='" + Cmpid.Text.Trim() + "' and AO='" + Empid.Text.Trim() + "' and AOName='" + EmpName.Text.Trim() + "'", AOSource.ConnectionString);
                    }
                    if (ds.Tables[0].Rows.Count == 0 && Empid.Text.Trim().Length!=0)
                    {
                        AOSource.UpdateParameters["ChangeDate"].DefaultValue = lblDOCNO.Text.Substring(2, 3) + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
                        AOSource.UpdateParameters["DOCNO"].DefaultValue = lblDOCNO.Text.Trim();
                        AOSource.UpdateParameters["Cmpid"].DefaultValue = Cmpid.Text.Trim();
                        AOSource.Update();
                        AOSource.InsertParameters["DOCNO"].DefaultValue = lblDOCNO.Text;
                        AOSource.InsertParameters["Cmpid"].DefaultValue = Cmpid.Text.Trim();
                        AOSource.InsertParameters["AO"].DefaultValue = Empid.Text.Trim();
                        AOSource.InsertParameters["AOName"].DefaultValue = EmpName.Text.Trim();
                        AOSource.InsertParameters["ChangeDate"].DefaultValue = "";
                        AOSource.Insert();

                    }

                }

                msg.Text = "儲存成功";
            }
        }
        if (ViewState["hasData"] == "Y")
        {
            using (Bussiness buss = new Bussiness())
            {
                ds = buss.select("SELECT count(*) as Count FROM tblLogDetail WHERE DocNo='" + lblDOCNO.Text.Trim() + "' ", chb_eform.ConnectionString);
            }

            if (ds.Tables[0].Rows[0]["Count"].ToString() == "0")
            {
                string strSQL = "insert into tblLogDetail values('EA','" + lblDOCNO.Text + "'," +
                    "'" + txtBRNO.Text + "','" + strUsrId.ToString() + "','" + DateTime.Now.ToShortDateString() + "','N'" +
                    ",null,'" + lblDOCNO.Text.Trim().Substring(2, 5) + "',null,null,null,null,null,null,null,null,null,null,'1','1')";
                using (Bussiness buss = new Bussiness())
                {
                    buss.execute(strSQL, chb_eform.ConnectionString);
                }
            }
            else
            {
                using (Bussiness buss = new Bussiness())
                {
                    buss.execute("update tblLogDetail set FlowStatus=1,Ver=Ver where DocNo='" + lblDOCNO.Text + "'", chb_eform.ConnectionString);
                }
            }
        }
        //if (SelectSum != 20)
        //{
        //    Response.Write("<script>window.alert('請勾選20筆')</script>");

        //    chb_eform.DeleteParameters["DocNo"].DefaultValue = lblDOCNO.Text.Trim();
        //    chb_eform.Delete();

        //    using (Bussiness buss = new Bussiness())
        //    {
        //        buss.execute("delete from tblLogDetail where DocNo='" + lblDOCNO.Text + "'", chb_eform.ConnectionString);
        //    }
        //    return;
        //}
    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        chb_eform.DeleteParameters["DocNo"].DefaultValue = lblDOCNO.Text.Trim();
        chb_eform.Delete();
        bool bl;
        using (Bussiness buss = new Bussiness())
        {
            bl = buss.execute("delete tblLogDetail where DocNo='" + lblDOCNO.Text.Trim() + "'", chb_eform.ConnectionString);
        }
        if (bl)
            msg.Text = "刪除成功";
    }

    private string ShowFlowStatus(string Ver, string RecordDate, string SignDate1, string DecDate)
    {
        string strRecordDate, strSignDate1, strDecDate;
        strRecordDate = (RecordDate == "") ? "" : FDateTime.CHNYYMMDD(RecordDate);
        strSignDate1 = (SignDate1 == "") ? "" : FDateTime.CHNYYMMDD(SignDate1);
        strDecDate = (DecDate == "") ? "" : FDateTime.CHNYYMMDD(DecDate);

        switch (Ver)
        {
            case "-1":
                return "總行退回 " + strDecDate;
            case "0":
                return "退回 " + strSignDate1;
            case "1":
                return "待簽核 " + strRecordDate;
            case "3":
                return "已決行 " + strSignDate1;
            case "4":
                return "已確認 " + strDecDate;
            default:
                return "";
        }
    }

    protected void btnLink_Click(object sender, EventArgs e)
    {
        ViewState["Change"] = "Y";
        ViewState["index"] = GridView1.SelectedIndex;
        //GridView1.Rows[index].FindControl("lblChange").Visible = true;
        //GridView1.Rows[index].FindControl("txtEmpid2").Visible = true;
        //GridView1.Rows[index].FindControl("txtEmpName2").Visible = true;

    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        Response.Redirect(System.Web.Configuration.WebConfigurationManager.AppSettings["ReportServerUrl"].ToString()+"/DotNetReports/OEA1010&rs:Command=Render&BRNO=" + txtBRNO.Text.Trim());
    }
}
