﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODQ2010.aspx.vb" Inherits="Program_ODQ2010_ODQ2010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <center>
            
                <div>
                    <asp:Label ID="Label1" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
                        Text="台外幣放款餘額彙總表"></asp:Label>
                    <br />
                    <asp:Label ID="Label2" runat="server" Font-Names="標楷體" Text="查詢時間"></asp:Label>
                    <asp:Label ID="lblYYY" runat="server" ForeColor="Red" Text="Label"></asp:Label>
                    <asp:Label ID="Label4" runat="server" Font-Names="標楷體" Text="年"></asp:Label><strong>
                    </strong>
                    <asp:Label ID="lblMM" runat="server" ForeColor="Red" Text="Label"></asp:Label><strong>
                    </strong>
                    <asp:Label ID="Label6" runat="server" Font-Names="標楷體" Text="月"></asp:Label><strong>&nbsp;</strong><strong>
                    </strong>
                    <strong>
                        &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; </strong>
                    <asp:Label ID="Label9" runat="server" Font-Names="標楷體" Text="單位:新台幣千元"></asp:Label>
                    <asp:Button ID="btn_excel" runat="server" Height="25px" Text="匯出成EXCEL檔" Width="120px" /><br />
                    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" BackColor="#DEBA84"
                        BorderColor="#DEBA84" BorderWidth="1px" CellPadding="3" DataSourceID="DS_tblMoneyInChina"
                        EmptyDataText="無相關資料可提供" ShowFooter="True" BorderStyle="None" CellSpacing="2">
                        <Columns>
                            <asp:BoundField DataField="LOANS_BRNO" HeaderText="分行代號" SortExpression="LOANS_BRNO" />
                            <asp:BoundField DataField="LOANS_BRNAME" HeaderText="分行名稱" SortExpression="LOANS_BRNAME" />
                            <asp:BoundField DataField="LOANS_TW_OVERAGE" HeaderText="台幣放款餘額" SortExpression="LOANS_TW_OVERAGE" DataFormatString="{0:N0}" HtmlEncode="False" />
                            <asp:BoundField DataField="LOANS_OUTLET_OVERAGE" HeaderText="外幣放款餘額【限外指單位填報】"
                                SortExpression="LOANS_OUTLET_OVERAGE" DataFormatString="{0:N0}" HtmlEncode="False" >
                                <HeaderStyle Width="150px" />
                            </asp:BoundField>
                        </Columns>
                        <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" />
                        <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" />
                        <SelectedRowStyle BackColor="#738A9C" ForeColor="White" Font-Bold="True" />
                        <HeaderStyle BackColor="#A55129" Font-Bold="True" ForeColor="White" />
                        <RowStyle HorizontalAlign="Right" BackColor="#FFF7E7" ForeColor="#8C4510" />
                    </asp:GridView>
                    &nbsp;<br />
                    &nbsp;<br />
                    &nbsp;<br />
                    <br />
                    <br />
                    <br />
                    <asp:SqlDataSource ID="DS_tblLoanMonthDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>" DeleteCommand="DELETE FROM [tblLoanMonthDetail] WHERE [LOANS_DOCNO] = @LOANS_DOCNO" InsertCommand="INSERT INTO [tblLoanMonthDetail] ([LOANS_DOCNO], [LOANS_BRNO], [LOANS_BRNAME], [LOANS_EMPID], [LOANS_EMPNAME], [LOANS_EXT], [LOANS_YEARLY], [LOANS_MONTHLY], [LOANS_TW_OVERAGE], [LOANS_OUTLET_OVERAGE]) VALUES (@LOANS_DOCNO, @LOANS_BRNO, @LOANS_BRNAME, @LOANS_EMPID, @LOANS_EMPNAME, @LOANS_EXT, @LOANS_YEARLY, @LOANS_MONTHLY, @LOANS_TW_OVERAGE, @LOANS_OUTLET_OVERAGE)" SelectCommand="SELECT LOANS_BRNO, LOANS_BRNAME, LOANS_TW_OVERAGE, LOANS_OUTLET_OVERAGE FROM tblLoanMonthDetail WHERE (LOANS_BRNO = @LOANS_BRNO) AND (LOANS_YEARLY = @LOANS_YEARLY) AND (LOANS_MONTHLY = @LOANS_MONTHLY) AND (LOANS_DOCNO IN (SELECT DocNo FROM tblLogDetail WHERE (DocType = 'DQ') AND (FlowStatus >= 3)))" UpdateCommand="UPDATE [tblLoanMonthDetail] SET [LOANS_BRNO] = @LOANS_BRNO, [LOANS_BRNAME] = @LOANS_BRNAME, [LOANS_EMPID] = @LOANS_EMPID, [LOANS_EMPNAME] = @LOANS_EMPNAME, [LOANS_EXT] = @LOANS_EXT, [LOANS_YEARLY] = @LOANS_YEARLY, [LOANS_MONTHLY] = @LOANS_MONTHLY, [LOANS_TW_OVERAGE] = @LOANS_TW_OVERAGE, [LOANS_OUTLET_OVERAGE] = @LOANS_OUTLET_OVERAGE WHERE [LOANS_DOCNO] = @LOANS_DOCNO">
                        <SelectParameters>
                            <asp:Parameter Name="LOANS_BRNO" />
                            <asp:Parameter Name="LOANS_YEARLY" />
                            <asp:Parameter Name="LOANS_MONTHLY" />
                        </SelectParameters>
                        <DeleteParameters>
                            <asp:Parameter Name="LOANS_DOCNO" Type="String" />
                        </DeleteParameters>
                        <UpdateParameters>
                            <asp:Parameter Name="LOANS_BRNO" Type="String" />
                            <asp:Parameter Name="LOANS_BRNAME" Type="String" />
                            <asp:Parameter Name="LOANS_EMPID" Type="String" />
                            <asp:Parameter Name="LOANS_EMPNAME" Type="String" />
                            <asp:Parameter Name="LOANS_EXT" Type="String" />
                            <asp:Parameter Name="LOANS_YEARLY" Type="String" />
                            <asp:Parameter Name="LOANS_MONTHLY" Type="String" />
                            <asp:Parameter Name="LOANS_TW_OVERAGE" Type="Decimal" />
                            <asp:Parameter Name="LOANS_OUTLET_OVERAGE" Type="Decimal" />
                            <asp:Parameter Name="LOANS_DOCNO" Type="String" />
                        </UpdateParameters>
                        <InsertParameters>
                            <asp:Parameter Name="LOANS_DOCNO" Type="String" />
                            <asp:Parameter Name="LOANS_BRNO" Type="String" />
                            <asp:Parameter Name="LOANS_BRNAME" Type="String" />
                            <asp:Parameter Name="LOANS_EMPID" Type="String" />
                            <asp:Parameter Name="LOANS_EMPNAME" Type="String" />
                            <asp:Parameter Name="LOANS_EXT" Type="String" />
                            <asp:Parameter Name="LOANS_YEARLY" Type="String" />
                            <asp:Parameter Name="LOANS_MONTHLY" Type="String" />
                            <asp:Parameter Name="LOANS_TW_OVERAGE" Type="Decimal" />
                            <asp:Parameter Name="LOANS_OUTLET_OVERAGE" Type="Decimal" />
                        </InsertParameters>
                    </asp:SqlDataSource>
                    <br />
                    <asp:SqlDataSource ID="DS_tblMoneyInChina" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
                        SelectCommand="SELECT LOANS_BRNO, LOANS_BRNAME, LOANS_TW_OVERAGE, LOANS_OUTLET_OVERAGE FROM tblLoanMonthDetail WHERE (LOANS_YEARLY = @LOANS_YEARLY) AND (LOANS_MONTHLY = @LOANS_MONTHLY) AND (LOANS_DOCNO IN (SELECT DocNo FROM tblLogDetail WHERE (DocType = 'DQ') AND (FlowStatus >= 3)))">
                        <SelectParameters>
                            <asp:Parameter Name="LOANS_YEARLY" />
                            <asp:Parameter Name="LOANS_MONTHLY" />
                        </SelectParameters>
                    </asp:SqlDataSource>
                    <asp:HiddenField ID="HiddenYYYMM" runat="server" />
                </div>
           
        </center>
    
    </div>
    </form>
</body>
</html>
