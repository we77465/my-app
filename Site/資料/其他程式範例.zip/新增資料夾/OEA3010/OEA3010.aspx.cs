﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.VisualBasic;
using System.IO;
using DataAccessLayer.DALC;

public partial class Program_OEA3010_OEA3010 : System.Web.UI.Page
{
    string strEmpId;
    string strBrNo;
    static string strSign1, strSignDate1, strFlowStatus;
    static string strDocNo, strHUsrId;
    static Int16 intOvrd;
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {        
        Session.CodePage = 65001;
        Response.Charset = "UFT8";
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();

            Session.CodePage = 65001;
            Response.Charset = "UFT8";
            if (!IsPostBack)
            {
                string strSQL="";
                intOvrd = System.Convert.ToInt16(Request.Form["hOvrd"]);
                strFlowStatus = Request.Form["hQFlowStatus"];

                strDocNo = Request.Form["hDocNo"];
                strHUsrId = Request.Form["hUsrId"];
                strSign1 = Request.Form["hUsrName"];
                strSignDate1 = DateTime.Now.ToString("yyyy/MM/dd");

                using (Bussiness buss = new Bussiness())
                {
                    ds = buss.select("SELECT a.NAME, b.BRNAME FROM  chb_pub..EMPLOYEE  AS a INNER JOIN " +
                        " chb_pub..BRANCH AS b ON a.BRNO = b.BRNO WHERE  (a.STAFF = '" + strHUsrId + "')", chb_eform.ConnectionString);
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtSign1.Text = ds.Tables[0].Rows[0]["NAME"].ToString();
                }

                string tSql = "SELECT t.*,e.NAME,b.BRNAME,e1.NAME as SignName1 " +
                   "FROM tblLogDetail t,chb_pub..EMPLOYEE e , chb_pub..BRANCH b ,chb_pub.dbo.EMPLOYEE e1 " +
                   "where t.EmpId = e.STAFF and t.EmpId *= e1.STAFF and t.BrNo=b.BRNO  and t.DocNo='" + strDocNo + "'";

                using (Bussiness buss = new Bussiness())
                {
                    ds = buss.select(tSql, chb_eform.ConnectionString);
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtSignDate1.Text = ds.Tables[0].Rows[0]["SignDate1"].ToString() == "" ? strSignDate1 : System.Convert.ToDateTime(ds.Tables[0].Rows[0]["SignDate1"]).ToString("yyyy/MM/dd");
                    txtSignComment1.Text = ds.Tables[0].Rows[0]["SignComment1"].ToString();
                    txtDocNo.Text = ds.Tables[0].Rows[0]["DocNo"].ToString();
                    txtVer.Text = "v " + ds.Tables[0].Rows[0]["Ver"].ToString() + ".0";
                    txtBrName.Text = ds.Tables[0].Rows[0]["BrName"].ToString();
                    txtName1.Text = ds.Tables[0].Rows[0]["Name"].ToString();
                    txtYYMM.Text = ds.Tables[0].Rows[0]["YYMM"].ToString();
                    txtRecordDate.Text = ds.Tables[0].Rows[0]["RecordDate"].ToString() == "" ? "" : System.Convert.ToDateTime(ds.Tables[0].Rows[0]["RecordDate"]).ToString("yyyy/MM/dd");
                    strBrNo = ds.Tables[0].Rows[0]["BrNo"].ToString();
                    strFlowStatus = ds.Tables[0].Rows[0]["FlowStatus"].ToString();
                    strEmpId = ds.Tables[0].Rows[0]["EmpId"].ToString();
                }
                if (strFlowStatus == "1" && intOvrd == 1)
                {
                    BtnOk.Visible = BtnBack.Visible = BtnClear.Visible = true;
                }

                using (Bussiness buss = new Bussiness())
                {
                    strSQL = "select b.FlowStatus,b.RecordDate,b.SignDate1,b.DecDate,a.* from tblLoanRate" +
                        " as a left join tblLogDetail as b on a.DocNo=b.DocNo" +
                        " where a.BRNO='" + strBrNo.ToString() + "' and a.DocNo='" + strDocNo + "'order by a.Cmpid ";
                    
                    ds = buss.select(strSQL, chb_eform.ConnectionString);
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                }
            }
        }
    }
    protected void OnPreRender(object sender, System.EventArgs e)
    {
        string strSQL = "";
        int i = 0;

        using (Bussiness buss = new Bussiness())
        {

            //strSQL = "SELECT a.DocNo,a.BRNO,a.CmpName,a.Cmpid,a.Empid,a.EmpName,a.ChangeDate,a.Empid2,a.EmpName2,b.Rate6,b.Rate7, b.Rate8, b.Rate9," +
            //    " b.Rate10, b.Rate11, b.Rate12,a.ChkSel,a.C1,a.C2,a.C3,a.C4,a.C5, a.C6, a.C7, a.C8, a.C9, a.C10,a.C11, a.P7," +
            //    " a.P8,a.P9,a.P10,a.P11,a.P12 FROM tblLoanRate AS a left JOIN" +
            //    "(SELECT RTRIM(BRNO) as BRNO,RTRIM(BRNAME) as BRNAME,RTRIM(Cmpid) as Cmpid,RTRIM(CmpName) as CmpName,RTRIM(Empid) as Empid,RTRIM(EmpName) as EmpName, " +
            //    " SUM(CASE YYMM WHEN 200806 THEN Rate6*100 ELSE NULL END) AS Rate6," +
            //    " SUM(CASE YYMM WHEN 200807 THEN Rate6*100 ELSE NULL END) AS Rate7," +
            //    " SUM(CASE YYMM WHEN 200808 THEN Rate6*100 ELSE NULL END) AS Rate8," +
            //    " SUM(CASE YYMM WHEN 200809 THEN Rate6*100 ELSE NULL END) AS Rate9," +
            //    " SUM(CASE YYMM WHEN 200810 THEN Rate6*100 ELSE NULL END) AS Rate10," +
            //    " SUM(CASE YYMM WHEN 200811 THEN Rate6*100 ELSE NULL END) AS Rate11," +
            //    " SUM(CASE YYMM WHEN 200812 THEN Rate6*100 ELSE NULL END) AS Rate12 " +
            //    " FROM tblLoanRate02 WHERE (BRNO = '" + strBrNo.ToString() + "')  GROUP BY BRNO, BRNAME, Cmpid, CmpName, Empid, EmpName) AS b " +
            //    " ON a.BRNO = b.BRNO AND a.Cmpid = b.Cmpid WHERE  a.DocNo='" + strDocNo.ToString() + "' order by a.Cmpid";

            //ds = buss.select(strSQL, chb_eform.ConnectionString);


            strSQL = "select a.BRNO,a.BRNAME,a.Cmpid,a.CmpName,b.Empid,b.EmpName," +
                    " a.Rate6,a.Rate7,a.Rate8,a.Rate9,a.Rate10,a.Rate11,a.Rate12," +
                    "b.ChkSel,b.C1,b.C2,b.C3,b.C4,b.C5,b.C6,b.C7,b.C8,b.C9,b.C10,C11,b.P7," +
                    " b.P8,b.P9,b.P10,b.P11,b.P12,b.ChangeDate from " +
                    "(SELECT RTRIM(BRNO) as BRNO,RTRIM(BRNAME) as BRNAME,RTRIM(Cmpid) as Cmpid," +
                    "RTRIM(CmpName) as CmpName,RTRIM(Empid) as Empid,RTRIM(EmpName) as EmpName," +
                    "SUM(CASE YYMM WHEN 200806 THEN Rate6*100 ELSE NULL  END) AS Rate6, " +
                    "SUM(CASE YYMM WHEN 200807 THEN Rate6*100 ELSE NULL   END) AS Rate7, " +
                    "SUM(CASE YYMM WHEN 200808 THEN Rate6*100 ELSE NULL  END) AS Rate8, " +
                    "SUM(CASE YYMM WHEN 200809 THEN Rate6*100 ELSE NULL  END) AS Rate9, " +
                    "SUM(CASE YYMM WHEN 200810 THEN Rate6*100 ELSE NULL  END) AS Rate10, " +
                    "SUM(CASE YYMM WHEN 200811 THEN Rate6*100 ELSE NULL  END) AS Rate11, " +
                    "SUM(CASE YYMM WHEN 200812 THEN Rate6*100 ELSE NULL  END) AS Rate12 " +
                    " FROM tblLoanRate02 where BRNO='" + strBrNo.ToString() + "' " +
                    " GROUP BY BRNO,BRNAME,Cmpid,CmpName,Empid,EmpName) as a right join " +
                    "(select * from tblLoanRate) as b on a.BRNO=b.BRNO and a.Cmpid=b.Cmpid " +
                    " where a.Rate6 is not NULL and (a.Rate6<=50) order by a.Empid ";
            ds = buss.select(strSQL, chb_eform.ConnectionString);
        }
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Response.Write(GridView1.Rows.Count);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            for (i = 0; i < GridView1.Rows.Count; i++)
            {
                GridViewRow GVR = GridView1.Rows[i];
                Label CmpName = (Label)GVR.FindControl("txtCmpName");
                Label Cmpid = (Label)GVR.FindControl("txtCmpid");
                Label Empid = (Label)GVR.FindControl("txtEmpid");
                Label EmpName = (Label)GVR.FindControl("txtEmpName");
                Label ChangeDate = (Label)GVR.FindControl("lblChange");
                Label Empid2 = (Label)GVR.FindControl("txtEmpid2");
                Label EmpName2 = (Label)GVR.FindControl("txtEmpName2");
                Label Rate6 = (Label)GVR.FindControl("txtRate6");
                TextBox Rate7 = (TextBox)GVR.FindControl("txtRate7");
                TextBox Rate8 = (TextBox)GVR.FindControl("txtRate8");
                TextBox Rate9 = (TextBox)GVR.FindControl("txtRate9");
                TextBox Rate10 = (TextBox)GVR.FindControl("txtRate10");
                TextBox Rate11 = (TextBox)GVR.FindControl("txtRate11");
                TextBox Rate12 = (TextBox)GVR.FindControl("txtRate12");
                TextBox P7 = (TextBox)GVR.FindControl("txtPro7");
                TextBox P8 = (TextBox)GVR.FindControl("txtPro8");
                TextBox P9 = (TextBox)GVR.FindControl("txtPro9");
                TextBox P10 = (TextBox)GVR.FindControl("txtPro10");
                TextBox P11 = (TextBox)GVR.FindControl("txtPro11");
                TextBox P12 = (TextBox)GVR.FindControl("txtPro12");
                CheckBoxList chkA = (CheckBoxList)GVR.FindControl("chkA");
                //if (i < ds.Tables[0].Rows.Count)
                //{
                    if (ds.Tables[0].Rows[i]["ChangeDate"].ToString() != "")
                        ChangeDate.Text = "(" + ds.Tables[0].Rows[i]["ChangeDate"].ToString() + ")";
                    else
                        ChangeDate.Text = "";

                    Rate6.Text = ds.Tables[0].Rows[i]["Rate6"].ToString();
                    if (ds.Tables[0].Rows[i]["Rate7"].ToString() != "")
                        Rate7.Text = ds.Tables[0].Rows[i]["Rate7"].ToString();
                    else
                        Rate7.Text = "已結清或沒有餘額";

                    if (ds.Tables[0].Rows[i]["Rate8"].ToString() != "")
                        Rate8.Text = ds.Tables[0].Rows[i]["Rate8"].ToString();
                    else
                        Rate8.Text = "已結清或沒有餘額";
                    //Rate8.Text = ds.Tables[0].Rows[i]["Rate8"].ToString();
                    Rate9.Text = ds.Tables[0].Rows[i]["Rate9"].ToString();
                    Rate10.Text = ds.Tables[0].Rows[i]["Rate10"].ToString();
                    Rate11.Text = ds.Tables[0].Rows[i]["Rate11"].ToString();
                    Rate12.Text = ds.Tables[0].Rows[i]["Rate12"].ToString();
                    P7.Text = ds.Tables[0].Rows[i]["P7"].ToString();
                    P8.Text = ds.Tables[0].Rows[i]["P8"].ToString();
                    P9.Text = ds.Tables[0].Rows[i]["P9"].ToString();
                    P10.Text = ds.Tables[0].Rows[i]["P10"].ToString();
                    P11.Text = ds.Tables[0].Rows[i]["P11"].ToString();
                    P12.Text = ds.Tables[0].Rows[i]["P12"].ToString();

                    chkA.RepeatColumns = 1;
                    for (int j = 1; j <= 11; j++)
                    {
                        string col = "C" + j.ToString();
                        ListItem item = new ListItem();

                        if (ds.Tables[0].Rows[i][col].ToString() == "Y")
                        {
                            item.Text = addItem(j);
                            item.Selected = true;
                            item.Enabled = false;
                            chkA.Items.Add(item);
                        }
                    }
                //}
                //i++;
            }
        }
    }
    private string addItem(int a)
    {
        string ItemText = "";
        switch (a)
        {
            case 1:
                ItemText = "1-額度"; break;
            case 2:
                ItemText = "2-利率"; break;
            case 3:
                ItemText = "3-費率、手續費"; break;
            case 4:
                ItemText = "4-匯率"; break;
            case 5:
                ItemText = "5-鑑價"; break;
            case 6:
                ItemText = "6-徵提擔保品內容"; break;
            case 7:
                ItemText = "7-距離較遠"; break;
            case 8:
                ItemText = "8-台新合併影響遭同業中傷"; break;
            case 9:
                ItemText = "9-其他商品無法滿足客戶需求"; break;
            case 10:
                ItemText = "10-作業程序繁瑣"; break;
            case 11:
                ItemText = "11-其他"; break;
            default:
                ItemText = ""; break;
        }
        return ItemText.ToString();
    }
    protected void BtnOk_Click(object sender, EventArgs e)
    {
        chb_eform.UpdateParameters[0].DefaultValue = strHUsrId;
        chb_eform.UpdateParameters[1].DefaultValue = "D";
        chb_eform.UpdateParameters[2].DefaultValue = DateTime.Now.ToShortDateString();
        chb_eform.UpdateParameters[3].DefaultValue = strHUsrId;
        chb_eform.UpdateParameters[4].DefaultValue = DateTime.Now.ToShortDateString();
        chb_eform.UpdateParameters[5].DefaultValue = "3";
        chb_eform.UpdateParameters[6].DefaultValue = txtSignComment1.Text.ToString();
        chb_eform.UpdateParameters[7].DefaultValue = strDocNo;
        chb_eform.Update();
        Response.Redirect("/OACHB/Program/OAOvrd/OAOvrdQForm.asp?hOvrd=1");
    }
    protected void BtnBack_Click(object sender, EventArgs e)
    {
        chb_eform.UpdateParameters[0].DefaultValue = strHUsrId;
        chb_eform.UpdateParameters[1].DefaultValue = "B";
        chb_eform.UpdateParameters[2].DefaultValue = DateTime.Now.ToShortDateString();
        chb_eform.UpdateParameters[3].DefaultValue = "";
        chb_eform.UpdateParameters[4].DefaultValue = "";
        chb_eform.UpdateParameters[5].DefaultValue = "0";
        chb_eform.UpdateParameters[6].DefaultValue = txtSignComment1.Text.ToString();
        chb_eform.UpdateParameters[7].DefaultValue = strDocNo;
        chb_eform.Update();

        Response.Redirect("/OACHB/Program/OAOvrd/OAOvrdQForm.asp?hOvrd=1");
    }
    protected void BtnClear_Click(object sender, EventArgs e)
    {
        txtSignComment1.Text = "";
    }
}
