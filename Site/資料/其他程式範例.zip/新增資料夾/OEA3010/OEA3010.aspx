﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="OEA3010.aspx.cs" Inherits="Program_OEA3010_OEA3010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head id="Head1" runat="server">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="../Common/css/Common.css"  /> 
    <title>未命名頁面</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <table border="0" width="880">
            <tr>
                <td colspan="2">
                    <table border="1" class="APPID">
                        <tr>
                            <td>
                                <span class="t4">OEA3010：</span> <span style="font-family: 新細明體"><span style="font-size: 12px;
                                    color: #ff0000">授信動用率</span><span><span style="font-size: 12px; color: #ff0000"></span><span><span
                                        style="color: #ff0000"><span style="font-size: 12px"></span><span class="t5"><span
                                            style="font-size: 12pt">(</span>負責人)</span></span></span></span></span>
                            </td>
                        </tr>
                    </table>
                    &nbsp; &nbsp;&nbsp;
                </td>
                <td align="center">
                    &nbsp;&nbsp;
                </td>
            </tr>
            <tr>
                <td style="width: 215px">
                </td>
                <td align="center" style="width: 417px">
                </td>
                <td align="center">
                    <asp:Button ID="BtnOk" runat="server" CssClass="BUTTON" OnClick="BtnOk_Click" Text="決    行"
                        Visible="False" />
                    <asp:Button ID="BtnBack" runat="server" CssClass="BUTTON" OnClick="BtnBack_Click"
                        Text="退    回" Visible="False" />
                    <asp:Button ID="BtnClear" runat="server" OnClick="BtnClear_Click" Text="清    除" Visible="False" /></td>
            </tr>
            <tr>
                <td style="width: 215px">
                </td>
                <td align="left" style="width: 417px">
                    &nbsp; &nbsp; &nbsp;<asp:Label ID="Label3" runat="server" CssClass="TBLHR" Text="負責人:"></asp:Label>
                    <asp:TextBox ID="txtSign1" runat="server" BackColor="Info" BorderStyle="None" ReadOnly="true"
                        Width="70"></asp:TextBox>
                    &nbsp; &nbsp; &nbsp;<asp:Label ID="Label4" runat="server" CssClass="TBLHR" Text="簽核日:"></asp:Label>
                    <asp:TextBox ID="txtSignDate1" runat="server" BackColor="Info" BorderStyle="None"
                        ReadOnly="true" Width="70"></asp:TextBox></td>
                <td align="right">
                </td>
            </tr>
            <tr>
                <td style="width: 215px; height: 33px">
                </td>
                <td align="center" style="width: 417px; height: 33px">
                    <asp:Label ID="Label5" runat="server" CssClass="TBLHR" Text="批　示:"></asp:Label><strong><span
                        style="font-size: 11pt"> </span></strong>
                    <asp:TextBox ID="txtSignComment1" runat="server" Width="328px"></asp:TextBox></td>
                <td align="right" style="font-weight: bold; font-size: 11pt; height: 33px">
                </td>
            </tr>
        </table>
    
    </div>
        <table style="font-weight: bold; font-size: 11pt" width="880">
            <tr>
                <td style="width: 869px">
                    <hr class="TBLHC" width="650" />
                </td>
            </tr>
        </table>
        <table style="font-weight: bold; font-size: 11pt" width="880">
            <tr>
                <td width="15%">
                    &nbsp;</td>
                <td>
                    <asp:Label ID="Label6" runat="server" CssClass="TBLHR" Text="表單編號:"></asp:Label></td>
                <td style="font-size: 11pt">
                    <asp:TextBox ID="txtDocNo" runat="server" BackColor="Info" BorderColor="White" BorderStyle="None"
                        ReadOnly="true" Width="100px"></asp:TextBox></td>
                <td style="font-size: 11pt">
                    <asp:Label ID="Label9" runat="server" CssClass="TBLHR" Text="版　　本:"></asp:Label></td>
                <td style="width: 164px">
                    <asp:TextBox ID="txtVer" runat="server" BackColor="Info" BorderStyle="None" ReadOnly="true"
                        Width="100px"></asp:TextBox></td>
                <td style="width: 166px">
                </td>
            </tr>
            <tr>
                <td style="height: 28px">
                </td>
                <td style="height: 28px">
                    <asp:Label ID="Label7" runat="server" CssClass="TBLHR" Text="分　　行:"></asp:Label></td>
                <td style="font-size: 11pt; height: 28px">
                    <asp:TextBox ID="txtBrName" runat="server" BackColor="Info" BorderStyle="None" ReadOnly="true"
                        Width="100px"></asp:TextBox></td>
                <td style="font-size: 11pt; height: 28px">
                    <asp:Label ID="Label10" runat="server" CssClass="TBLHR" Text="經 辦 人 :"></asp:Label></td>
                <td style="height: 28px">
                    <asp:TextBox ID="txtName1" runat="server" BackColor="Info" BorderStyle="None" ReadOnly="true"
                        Width="100px"></asp:TextBox></td>
                <td style="width: 166px; height: 28px">
                </td>
            </tr>
            <tr>
                <td style="height: 28px">
                </td>
                <td style="height: 28px">
                    <asp:Label ID="Label8" runat="server" CssClass="TBLHR" Text="所屬年月:"></asp:Label></td>
                <td style="height: 28px">
                    <asp:TextBox ID="txtYYMM" runat="server" BackColor="Info" BorderStyle="None" ReadOnly="true"
                        Width="100px"></asp:TextBox></td>
                <td style="height: 28px">
                    <asp:Label ID="Label11" runat="server" CssClass="TBLHR" Text="填 報 日 :"></asp:Label></td>
                <td style="font-size: 11pt; width: 164px; height: 28px">
                    <asp:TextBox ID="txtRecordDate" runat="server" BackColor="Info" BorderStyle="None"
                        ReadOnly="true" Width="100px"></asp:TextBox></td>
                <td style="font-size: 11pt; width: 166px; height: 28px">
                </td>
            </tr>
        </table>
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" CellPadding="4"
            Font-Size="Smaller" ForeColor="#333333" GridLines="None"
            Width="1200px" OnPreRender="OnPreRender">
            <HeaderStyle BackColor="#990000" CssClass="TBLHC" Font-Bold="True" ForeColor="White" />
            <RowStyle BackColor="#FFFBD6" ForeColor="#333333" />
            <AlternatingRowStyle BackColor="White" />
            <Columns>
                <asp:TemplateField HeaderText="客戶名稱">
                    <ItemTemplate>
                        <asp:Label ID="txtCmpName" runat="server" CssClass="TBLHL" Text='<%# Eval("CmpName") %>'
                            Width="140px"></asp:Label>
                    </ItemTemplate>
                    <ItemStyle HorizontalAlign="Center" Width="10%" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="客戶統編">
                    <ItemTemplate>
                        <asp:Label ID="txtCmpid" runat="server" CssClass="TBLHL" Text='<%# Eval("Cmpid") %>'
                            Width="90px"></asp:Label>
                    </ItemTemplate>
                    <ItemStyle HorizontalAlign="Center" Width="8%" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="AO">
                    <ItemTemplate>
                        <asp:Label ID="txtEmpid" runat="server" CssClass="TBLHL" Text='<%# Eval("Empid") %>'
                            Width="90px"></asp:Label>
                        <asp:Label ID="txtEmpName" runat="server" CssClass="TBLHL" Text='<%# Eval("EmpName") %>'
                            Width="90px"></asp:Label>
                        <asp:Label ID="lblChange" runat="server" CssClass="TBLHL" 
                            Width="90px"></asp:Label>
                        <asp:Label ID="txtEmpid2" runat="server" CssClass="TBLHL" 
                            Width="90px"></asp:Label>
                        <asp:Label ID="txtEmpName2" runat="server" CssClass="TBLHL" 
                            Width="90px"></asp:Label>
                    </ItemTemplate>
                    <ItemStyle HorizontalAlign="Center" Width="8%" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="97年6月平均動用率(%)">
                    <ItemTemplate>
                        <asp:Label ID="txtRate6" runat="server" CssClass="TBLHL" Width="140px"></asp:Label><%--Text='<%# Eval("Rate6") %>'--%>
                    </ItemTemplate>
                    <ItemStyle Width="2%" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="未動用原因">
                    <ItemTemplate>
                        <asp:CheckBoxList ID="chkA" runat="server" Font-Size="10pt" RepeatColumns="3" RepeatDirection="Horizontal"
                            RepeatLayout="Flow">
                            <%--<asp:ListItem Value="1">1-額度</asp:ListItem>
                            <asp:ListItem Value="2">2-利率</asp:ListItem>
                            <asp:ListItem Value="3">3-費率、手續費</asp:ListItem>
                            <asp:ListItem Value="4">4-匯率</asp:ListItem>
                            <asp:ListItem Value="5">5-鑑價</asp:ListItem>
                            <asp:ListItem Value="6">6-徵提擔保品內容</asp:ListItem>
                            <asp:ListItem Value="7">7-距離較遠</asp:ListItem>
                            <asp:ListItem Value="8">8-台新合併影響遭同業中傷<br/></asp:ListItem>
                            <asp:ListItem Value="9">9-其他商品無法滿足客戶需求</asp:ListItem>
                            <asp:ListItem Value="10">10-作業程序繁瑣</asp:ListItem>--%>
                        </asp:CheckBoxList>
                    </ItemTemplate>
                    <ItemStyle Width="20%" Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="平均動用率(月份/%)">
                    <ItemTemplate>
                        <asp:Label ID="lblMonth7" runat="server" Font-Size="Medium" Text="7" Width="20px"></asp:Label>
                        <asp:TextBox ID="txtRate7" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                        <asp:Label ID="lblMonth8" runat="server" Font-Size="Medium" Text="8" Width="20px"></asp:Label>
                        <asp:TextBox ID="txtRate8" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                        <asp:Label ID="lblMonth9" runat="server" Font-Size="Medium" Text="9" Width="20px"></asp:Label>
                        <asp:TextBox ID="txtRate9" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                        <asp:Label ID="lblMonth10" runat="server" Font-Size="Medium" Text="10" Width="20px"></asp:Label>
                        <asp:TextBox ID="txtRate10" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                        <asp:Label ID="lblMonth11" runat="server" Font-Size="Medium" Text="11" Width="20px"></asp:Label>
                        <asp:TextBox ID="txtRate11" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                        <asp:Label ID="lblMonth12" runat="server" Font-Size="Medium" Text="12" Width="20px"></asp:Label>
                        <asp:TextBox ID="txtRate12" runat="server" CssClass="TBLHL" Width="120px" ReadOnly="true"></asp:TextBox><br />
                    </ItemTemplate>
                    <ItemStyle Width="12%" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="處理情形及執行瓶頸">
                    <ItemTemplate>
                        <asp:TextBox ID="txtPro7" runat="server" CssClass="TBLHL" Width="140px" ReadOnly="true"></asp:TextBox><br />
                        <asp:TextBox ID="txtPro8" runat="server" CssClass="TBLHL" Width="140px" ReadOnly="true"></asp:TextBox><br />
                        <asp:TextBox ID="txtPro9" runat="server" CssClass="TBLHL" Width="140px" ReadOnly="true"></asp:TextBox><br />
                        <asp:TextBox ID="txtPro10" runat="server" CssClass="TBLHL" Width="140px" ReadOnly="true"></asp:TextBox><br />
                        <asp:TextBox ID="txtPro11" runat="server" CssClass="TBLHL" Width="140px" ReadOnly="true"></asp:TextBox><br />
                        <asp:TextBox ID="txtPro12" runat="server" CssClass="TBLHL" Width="140px" ReadOnly="true"></asp:TextBox><br />
                    </ItemTemplate>
                    <ItemStyle HorizontalAlign="Center" Width="10%" />
                </asp:TemplateField>
            </Columns>
            <PagerStyle Font-Size="Large" />
        </asp:GridView>
        <br />
        <asp:SqlDataSource ID="chb_eform" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>" SelectCommand="select   *  from tblLoanRate  where DocNo=@DocNo" UpdateCommand="Update tblLogDetail set Sign1=@Sign1,Action1=@ACTION1,SignDate1=@SignDate1&#13;&#10;,DecManager=@DecManager,DecDate=@DecDate,FlowStatus=@FlowStatus,SignComment1=@SignComment1 where DocNo=@DocNo">
            <SelectParameters>
                <asp:Parameter Name="DOCNO" />
            </SelectParameters>
            <UpdateParameters>
                <asp:Parameter Name="Sign1" />
                <asp:Parameter Name="ACTION1" />
                <asp:Parameter Name="SignDate1" />
                <asp:Parameter Name="DecManager" />
                <asp:Parameter Name="DecDate" />
                <asp:Parameter Name="FlowStatus" />
                <asp:Parameter Name="SignComment1" />
                <asp:Parameter Name="DocNo" />
            </UpdateParameters>
        </asp:SqlDataSource>
    </form>
</body>
</html>
