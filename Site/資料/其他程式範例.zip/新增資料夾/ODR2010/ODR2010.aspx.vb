﻿Imports System.IO.StringWriter
Imports System.Web.UI.HtmlTextWriter

Partial Class Program_ODR2010_ODR2010
    Inherits System.Web.UI.Page
    Const 格式轉換日 As String = "2012/1/31"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '===== 從前一個網頁得到的值 IntraWeb/OACHB/Program/ODR2010/ODR2010QForm.asp ==========
        Dim YYY As String = Request.QueryString("YYY") '年
        Dim MM As String = Request.QueryString("MM") '月
        Dim YYYMM As String = ""

        lblYYY.Text = YYY
        lblMM.Text = MM
        YYYMM = YYY & MM
        HiddenYYYMM.Value = YYYMM

        DS_tblMoneyInChina.SelectParameters("YYYMM").DefaultValue = YYYMM
        sdsMoneyInChinaNew.SelectParameters("YYYMM").DefaultValue = YYYMM

        '某一月的最後一天日期
        Dim YYYY As String = Integer.Parse(YYY) + 1911 '西元年
        lblDD.Text = DateTime.DaysInMonth(YYYY, MM)

        '每月申報上個月資料, 101年3月起申報適用新格式(新增分行別)
        Dim tempD As DateTime = New Date(CInt(YYYY), CInt(MM), 1)
        If tempD > CDate(格式轉換日) Then
            gvNew.Visible = True
        Else
            gvNew.Visible = False
        End If
        Me.gvOld.Visible = Not Me.gvNew.Visible

    End Sub

    '增加gvOld、gvNew表頭表尾欄位(記得Gridview的ShowFooter要設為True)
    Protected Sub gvOld_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvOld.RowCreated, gvNew.RowCreated

        '============增加表頭=======================================
        If (e.Row.RowType = DataControlRowType.Header) Then
            Dim Header As TableCellCollection = e.Row.Cells
            Header.Clear()   '清除原本的表頭
            Header.Add(New TableHeaderCell()) '新增表頭

            '2012/2/8 modify 新增分行別
            If sender.id = "gvNew" Then
                Header(0).Text = _
                 "</table> <table border=2 cellpadding=2 cellspacing=2 >" & _
                    "<tr align=center>" & _
                        "<td bgcolor=Tan colspan=1 rowspan=3>分行名稱</td>" & _
                        "<td bgcolor=Tan colspan=9>放款資金運用於中國大陸餘額</td>" & _
                        "<td bgcolor=Tan colspan=9>保證款項資金運用於中國大陸餘額</td>" & _
                        "<td bgcolor=Tan colspan=3>應收帳款收買業務資金運用於中國大陸餘額</td>" & _
                        "<td bgcolor=Tan colspan=12>資金運用於中國大陸帳列金額逾期三個月以上</td>" & _
                    "</tr>" & _
                    "<tr align=center style=color: #000000; font-family: Times New Roman>" & _
                        "<td bgcolor=Tan colspan=2 >行業別</td>" & _
                        "<td bgcolor=Tan colspan=3 >放款申貸用途</td>" & _
                        "<td bgcolor=Tan colspan=3 >分行別</td>" & _
                        "<td bgcolor=Tan rowspan=2 >放款合計</td>" & _
                        "<td bgcolor=Tan colspan=3 >商業本票保證</td>" & _
                        "<td bgcolor=Tan colspan=3 >發行公司債</td>" & _
                         "<td bgcolor=Tan colspan=3 >其他</td>" & _
                        "<td bgcolor=Tan colspan=3 >分行別</td>" & _
                        "<td bgcolor=Tan colspan=3 >放款(D)</td>" & _
                        "<td bgcolor=Tan colspan=3 >保證墊款(E)</td>" & _
                        "<td bgcolor=Tan colspan=3 >應收帳款收買(F)</td>" & _
                        "<td bgcolor=Tan colspan=3 >合計(D+E+F)</td>" & _
                    "</tr>" & _
                    "<tr align=center style=font-family: Times New Roman>" & _
                        "<td bgcolor=Tan >傳統業</td>" & _
                        "<td bgcolor=Tan >科技業</td>" & _
                        "<td bgcolor=Tan >企業投資</td>" & _
                        "<td bgcolor=Tan >週轉金</td>" & _
                        "<td bgcolor=Tan >其他</td>" & _
                        "<td bgcolor=Tan >DBU</td>" & _
                        "<td bgcolor=Tan >OBU</td>" & _
                        "<td bgcolor=Tan style=width: 34px >海外分行</td>" & _
                        "<td bgcolor=Tan >DBU</td>" & _
                        "<td bgcolor=Tan >OBU</td>" & _
                        "<td bgcolor=Tan style=width: 34px >海外分行</td>" & _
                        "<td bgcolor=Tan >DBU</td>" & _
                        "<td bgcolor=Tan >OBU</td>" & _
                        "<td bgcolor=Tan style=width: 34px >海外分行</td>" & _
                        "<td bgcolor=Tan >DBU</td>" & _
                        "<td bgcolor=Tan >OBU</td>" & _
                        "<td bgcolor=Tan style=width: 34px >海外分行</td>" & _
                        "<td bgcolor=Tan >DBU</td>" & _
                        "<td bgcolor=Tan >OBU</td>" & _
                        "<td bgcolor=Tan style=width: 34px >海外分行</td>" & _
                        "<td bgcolor=Tan >DBU</td>" & _
                        "<td bgcolor=Tan >OBU</td>" & _
                        "<td bgcolor=Tan style=width: 34px >海外分行</td>" & _
                        "<td bgcolor=Tan >DBU</td>" & _
                        "<td bgcolor=Tan >OBU</td>" & _
                        "<td bgcolor=Tan style=width: 34px >海外分行</td>" & _
                        "<td bgcolor=Tan >DBU</td>" & _
                        "<td bgcolor=Tan >OBU</td>" & _
                        "<td bgcolor=Tan style=width: 34px >海外分行</td>" & _
                        "<td bgcolor=Tan >DBU</td>" & _
                        "<td bgcolor=Tan >OBU</td>" & _
                        "<td bgcolor=Tan style=width: 34px >海外分行</td>" & _
                    "</tr>"
            Else
                Header(0).Text = "</table> <table border=2 cellpadding=2 cellspacing=2 ><tr align=center><td bgcolor=Tan  colspan=1 rowspan=3>分行名稱</td><td bgcolor=Tan  colspan=9>放款資金運用於中國大陸餘額</td><td bgcolor=Tan  colspan=3 rowspan=2>保證款項資金運用於中國大陸餘額</td><td bgcolor=Tan  colspan=1 rowspan=3>應收帳款收買業務資金運用於中國大陸餘額 </td><td bgcolor=Tan  colspan=3 rowspan=2>資金運用於中國大陸帳列金額逾期三個月以上</td></tr><tr align=center style=color: #000000; font-family: Times New Roman>  <td bgcolor=Tan  colspan=2 >行業別</td><td bgcolor=Tan colspan=3 >放款申貸用途</td><td bgcolor=Tan  colspan=3 >分行別</td><td bgcolor=Tan  rowspan=2>放款合計</td></tr><tr align=center style=font-family: Times New Roman><td bgcolor=Tan >傳統業</td><td bgcolor=Tan >科技業</td><td bgcolor=Tan>企業投資</td><td bgcolor=Tan>週轉金</td><td bgcolor=Tan>其他</td><td bgcolor=Tan >DBU</td><td bgcolor=Tan >OBU</td><td bgcolor=Tan style=width: 34px >海外分行</td><td bgcolor=Tan >商業本票保證</td><td bgcolor=Tan >發行公司債</td><td bgcolor=Tan >其他</td><td bgcolor=Tan >放款</td><td bgcolor=Tan >保證墊款</td><td bgcolor=Tan >應收帳款收買</td></tr>"
            End If

        ElseIf (e.Row.RowType = DataControlRowType.Footer) Then

            Dim footer As TableCellCollection = e.Row.Cells
            footer.Clear() '清除原本的表尾

            '2012/2/8 增加表尾(新舊表格各為34與17個欄位)
            Dim FCount As Integer '表尾數
            If sender.id = "gvNew" Then FCount = 34 Else FCount = 17
            For i As Integer = 1 To FCount '從1起算

                Dim tbCell As New TableCell()

                If i = 1 Then
                    tbCell.HorizontalAlign = HorizontalAlign.Right : tbCell.Text = "全行合計"
                Else
                    tbCell.HorizontalAlign = HorizontalAlign.Center : tbCell.Text = "NULL"
                End If
                footer.Add(tbCell)
            Next

        Else
            Exit Sub
        End If

    End Sub

    '2012/2/8 gvOld與gvNew表尾加總計算
    Protected Sub gvOld_DataBound(ByVal sender As Object, ByVal e As EventArgs) Handles gvOld.DataBound, gvNew.DataBound

        If sender.Rows.Count = 0 Then Exit Sub '無資料時不計算表尾合計數

        Dim cCount As Integer = sender.Rows(0).Cells.Count '欄位數(17 or 34)
        Dim c(33) As Decimal '0~33(新格式共34個欄位)

        For Each row As GridViewRow In sender.Rows

            sender.FooterRow.Cells(0).Text = "全行合計"
            For i As Integer = 1 To cCount - 1 '第0欄為文字(全行合計), 不需計算合計

                If row.Cells(i).Text <> "NULL" Then

                    c(i) += Decimal.Parse(row.Cells(i).Text.Replace("$", "").Replace(",", ""))
                    sender.FooterRow.Cells(i).Text = c(i).ToString("N0") '貨幣符號
                End If
            Next
        Next
    End Sub

    '===============將Gridview轉成excel檔===============================
    'aspx.vb檔前端須加Imports System.IO.StringWriter與Imports System.Web.UI.HtmlTextWriter
    Protected Sub btn_excel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_excel.Click
        '欄位為文字的 CSS設定
        Dim style As String = "<style> .text { mso-number-format:""\@""; } </style> "
        '以下為 GridView 轉 Excel 的程式
        Response.Clear()
        Response.AddHeader("content-disposition", "attachment;filename=MoneyInChina" & HiddenYYYMM.Value & ".xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excels"
        Response.Cache.SetCacheability(HttpCacheability.NoCache)

        Dim stringWrite As New System.IO.StringWriter()
        Dim htmlWrite As New HtmlTextWriter(stringWrite)

        If gvOld.Visible = True Then gvOld.RenderControl(htmlWrite) '顯示分行 
        If gvNew.Visible = True Then gvNew.RenderControl(htmlWrite) '顯示分行 

        Response.Write(style)
        Response.Write(stringWrite.ToString())
        Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>") '內容亂碼使用
        Response.End()
    End Sub

    '將Gridview轉成excel檔(加此 sub 就不會出現「run at server」錯誤)
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' 加此 sub 就不會出現「run at server」錯誤
    End Sub

    '將Gridview轉成excel檔(將每個欄位格式都設成「文字」)
    Protected Sub gvOld_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvOld.RowDataBound, gvNew.RowDataBound
        '將每個欄位格式都設成「文字」
        Dim i, j As Integer
        j = iif(sender.id = "gvOld", 16, 33)
        For i = 0 To j
            If e.Row.RowType = DataControlRowType.DataRow Then
                e.Row.Cells(i).Attributes.Add("class", "text")
            End If
        Next
    End Sub
    '===============將Gridview轉成excel檔===============================

End Class
