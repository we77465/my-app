﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODR2010.aspx.vb" Inherits="Program_ODR2010_ODR2010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
<center>
    <form id="form1" runat="server">
    <div>
        <asp:Label ID="Label1" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
            Text="本國銀行辦理授信及應收帳款收買業務資金運用於中國大陸彙總表"></asp:Label>
        <br />
        <asp:Label ID="Label2" runat="server" Font-Names="標楷體" Text="基準日"></asp:Label>
        <asp:Label ID="lblYYY" runat="server" Text="Label" ForeColor="Red"></asp:Label>
        <asp:Label ID="Label4" runat="server" Font-Names="標楷體" Text="年"></asp:Label>
        <asp:Label ID="lblMM" runat="server" Text="Label" ForeColor="Red"></asp:Label>
        <asp:Label ID="Label6" runat="server" Font-Names="標楷體" Text="月"></asp:Label>
        <asp:Label ID="lblDD" runat="server" Text="Label" ForeColor="Red"></asp:Label>
        <asp:Label ID="Label8" runat="server" Font-Names="標楷體" Text="日"></asp:Label>
        &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;
        <asp:Label ID="Label9" runat="server" Font-Names="標楷體" Text="單位:新台幣百萬元"></asp:Label>
        <asp:Button ID="btn_excel" runat="server" Height="25px" Text="匯出成EXCEL檔" Width="120px" /><br />
        <asp:GridView ID="gvOld" runat="server" AutoGenerateColumns="False" BackColor="LightGoldenrodYellow"
            BorderColor="Tan" BorderWidth="1px" CellPadding="2" DataKeyNames="DocNo"
            DataSourceID="DS_tblMoneyInChina" ForeColor="Black" GridLines="None" 
            ShowFooter="True" EmptyDataText="無相關資料可提供">
            <Columns>
                <asp:BoundField DataField="BRName" HeaderText="分行名稱" SortExpression="BRName" />
                <asp:BoundField DataField="A1" HeaderText="傳統業" SortExpression="A1" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="A2" HeaderText="科技業" SortExpression="A2" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="B1" HeaderText="企業投資" SortExpression="B1" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="B2" HeaderText="週轉金" SortExpression="B2" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="B3" HeaderText="其 他" SortExpression="B3" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="C1" HeaderText="DBU" SortExpression="C1" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="C2" HeaderText="OBU" SortExpression="C2" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="C3" HeaderText="海外分行" SortExpression="C3" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="D1" HeaderText="放款合計" SortExpression="D1" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="E1" HeaderText="商業本票保證" SortExpression="E1" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="E2" HeaderText="發行公司債" SortExpression="E2" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="E3" HeaderText="其他" SortExpression="E3" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="F1" HeaderText="應收帳款收買業務資金運用於中國大陸餘額" SortExpression="F1" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="G1" HeaderText="放款" SortExpression="G1" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="G2" HeaderText="保證墊款" SortExpression="G2" DataFormatString="{0:N0}" HtmlEncode="False" />
                <asp:BoundField DataField="G3" HeaderText="應收帳款收買" SortExpression="G3" DataFormatString="{0:N0}" HtmlEncode="False" />
            </Columns>
            <FooterStyle BackColor="Tan" />
            <PagerStyle BackColor="PaleGoldenrod" ForeColor="DarkSlateBlue" HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="DarkSlateBlue" ForeColor="GhostWhite" />
            <HeaderStyle BackColor="Tan" Font-Bold="True" />
            <AlternatingRowStyle BackColor="PaleGoldenrod" />
            <RowStyle HorizontalAlign="Right" />
        </asp:GridView>
        <asp:GridView ID="gvNew" runat="server" AutoGenerateColumns="False" 
            BackColor="LightGoldenrodYellow" BorderColor="Tan" BorderWidth="1px" 
            CellPadding="2" DataKeyNames="DocNo" DataSourceID="sdsMoneyInChinaNew" 
            EnableModelValidation="True" ForeColor="Black" GridLines="None" 
            ShowFooter="True" EmptyDataText="無相關資料可提供">
            <AlternatingRowStyle BackColor="PaleGoldenrod" />
            <Columns>
                <asp:BoundField DataField="BRName" HeaderText="分行名稱" SortExpression="BRName" />
                <asp:BoundField DataField="A1" DataFormatString="{0:N0}" HeaderText="傳統業" 
                    SortExpression="A1" />
                <asp:BoundField DataField="A2" DataFormatString="{0:N0}" HeaderText="科技業" 
                    SortExpression="A2" />
                <asp:BoundField DataField="B1" DataFormatString="{0:N0}" HeaderText="企業投資" 
                    SortExpression="B1" />
                <asp:BoundField DataField="B2" DataFormatString="{0:N0}" HeaderText="週轉金" 
                    SortExpression="B2" />
                <asp:BoundField DataField="B3" DataFormatString="{0:N0}" HeaderText="其他" 
                    SortExpression="B3" />
                <asp:BoundField DataField="C1" DataFormatString="{0:N0}" HeaderText="DBU" 
                    SortExpression="C1" />
                <asp:BoundField DataField="C2" DataFormatString="{0:N0}" HeaderText="OBU" 
                    SortExpression="C2" />
                <asp:BoundField DataField="C3" DataFormatString="{0:N0}" HeaderText="海外分行" 
                    SortExpression="C3" />
                <asp:BoundField DataField="D1" DataFormatString="{0:N0}" HeaderText="放款合計" 
                    SortExpression="D1" />
                <asp:BoundField DataField="E1_DBU" HeaderText="E1_DBU" 
                    SortExpression="E1_DBU" DataFormatString="{0:N0}" />
                <asp:BoundField DataField="E1_OBU" HeaderText="E1_OBU" 
                    SortExpression="E1_OBU" DataFormatString="{0:N0}" />
                <asp:BoundField DataField="E1_Over" HeaderText="E1_Over" 
                    SortExpression="E1_Over" DataFormatString="{0:N0}" />
                <asp:BoundField DataField="E2_DBU" HeaderText="E2_DBU" 
                    SortExpression="E2_DBU" DataFormatString="{0:N0}" />
                <asp:BoundField DataField="E2_OBU" HeaderText="E2_OBU" 
                    SortExpression="E2_OBU" DataFormatString="{0:N0}" />
                <asp:BoundField DataField="E2_Over" HeaderText="E2_Over" 
                    SortExpression="E2_Over" DataFormatString="{0:N0}" />
                <asp:BoundField DataField="E3_DBU" HeaderText="E3_DBU" 
                    SortExpression="E3_DBU" DataFormatString="{0:N0}" />
                <asp:BoundField DataField="E3_OBU" HeaderText="E3_OBU" 
                    SortExpression="E3_OBU" DataFormatString="{0:N0}" />
                <asp:BoundField DataField="E3_Over" HeaderText="E3_Over" 
                    SortExpression="E3_Over" DataFormatString="{0:N0}" />
                <asp:BoundField DataField="F_DBU" DataFormatString="{0:N0}" HeaderText="F_DBU" 
                    SortExpression="F_DBU" />
                <asp:BoundField DataField="F_OBU" DataFormatString="{0:N0}" HeaderText="F_OBU" 
                    SortExpression="F_OBU" />
                <asp:BoundField DataField="F_Over" DataFormatString="{0:N0}" 
                    HeaderText="F_Over" SortExpression="F_Over" />
                <asp:BoundField DataField="G1_DBU" DataFormatString="{0:N0}" 
                    HeaderText="G1_DBU" SortExpression="G1_DBU" />
                <asp:BoundField DataField="G1_OBU" DataFormatString="{0:N0}" 
                    HeaderText="G1_OBU" SortExpression="G1_OBU" />
                <asp:BoundField DataField="G1_Over" DataFormatString="{0:N0}" 
                    HeaderText="G1_Over" SortExpression="G1_Over" />
                <asp:BoundField DataField="G2_DBU" DataFormatString="{0:N0}" 
                    HeaderText="G2_DBU" SortExpression="G2_DBU" />
                <asp:BoundField DataField="G2_OBU" DataFormatString="{0:N0}" 
                    HeaderText="G2_OBU" SortExpression="G2_OBU" />
                <asp:BoundField DataField="G2_Over" DataFormatString="{0:N0}" 
                    HeaderText="G2_Over" SortExpression="G2_Over" />
                <asp:BoundField DataField="G3_DBU" DataFormatString="{0:N0}" 
                    HeaderText="G3_DBU" SortExpression="G3_DBU" />
                <asp:BoundField DataField="G3_OBU" DataFormatString="{0:N0}" 
                    HeaderText="G3_OBU" SortExpression="G3_OBU" />
                <asp:BoundField DataField="G3_Over" DataFormatString="{0:N0}" 
                    HeaderText="G3_Over" SortExpression="G3_Over" />
                <asp:BoundField DataField="GT_DBU" DataFormatString="{0:N0}" 
                    HeaderText="GT_DBU" SortExpression="GT_DBU" />
                <asp:BoundField DataField="GT_OBU" DataFormatString="{0:N0}" 
                    HeaderText="GT_OBU" SortExpression="GT_OBU" />
                <asp:BoundField DataField="GT_Over" DataFormatString="{0:N0}" 
                    HeaderText="GT_Over" SortExpression="GT_Over" />

            </Columns>
            <FooterStyle BackColor="Tan" />
            <HeaderStyle BackColor="Tan" Font-Bold="True" />
            <PagerStyle BackColor="PaleGoldenrod" ForeColor="DarkSlateBlue" 
                HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="DarkSlateBlue" ForeColor="GhostWhite" />
        </asp:GridView>
        <br />
        <table>
            <tr>
                <td style="width: 814px; height: 78px" align="left">
                    註：1.本表填報單位包括本國銀行之國內各營業單位、國際金融業務分行及海外分行。<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2.放款包括新台幣及外幣之短期貿易融資、貼現、擔保透支、短、中、長期擔保及無擔保放款及催收款項
                    (不包括保證、<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;承兌金額)； &nbsp;保證及應收帳款金額包括新台幣及外幣，外幣金額請按基準日中心匯率折算新台幣填報。<br />
                    &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;3.運用於大陸資金包括由經濟部投審會核准或報備之投資及未經核准但銀行依據與客戶往來研判可能用於大陸投資者。
                    <br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 4.「行業別」及「放款申貸用途」請填金額，「高科技產業」包括積體電路、通訊、精密機械、特用化學品與製藥、<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 資訊軟體、航太、生物科技等工業。
                    <br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5.國內總分支機構及國際金融業務分行依下列原則填報：
                    <br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (1)授信後資金匯至香港、澳門者全數填報，匯至其他地區者視情況填報；<br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;(2)授信戶會計師簽證報告或聯合徵信中心查詢有資金運用於大陸者，按銀行授信餘額占全體銀行授信總額之比例，
                    <br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 乘以授信戶投資大陸金額填報。惟若銀行確知客戶授信資金非用於大陸者，可免填報。<br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;(3)經實地查訪，授信客戶在台已無營運且已移往大陸投資者，全數填報。
                    <br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 海外分行請依上述（2）、（3）原則填報。
                    <br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 6.授信及應收帳款收買業務資金逾期三個月以上金額包括本金或利息延滯三個月以上<br />
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; （含列報逾期放款及尚未列報逾期放款）。<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7.行業別合計=放款申貸用途合計=分行別合計=放款合計&nbsp;<br />
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 8.本報表請於次月5日前報送財管處會計業務科。</td>
            </tr>
        </table>
        <br />
        <br />
        <br />
        <asp:HiddenField ID="HiddenYYYMM" runat="server" />
        <asp:SqlDataSource ID="DS_tblMoneyInChina" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="select * from tblMoneyInChina&#13;&#10;where YYYMM = @YYYMM and DocNo in (&#13;&#10;SELECT     DocNo&#13;&#10;FROM         tblLogDetail&#13;&#10;WHERE     (DocType = 'DR') AND (FlowStatus >= 3))">
            <SelectParameters>
                <asp:Parameter Name="YYYMM" />
            </SelectParameters>
        </asp:SqlDataSource>
    
        <asp:SqlDataSource ID="sdsMoneyInChinaNew" runat="server" 
            ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
            
            SelectCommand="SELECT DocNo, Brno, BRName, EmpID, EmpName, Ext, YYYMM, A1, A2, B1, B2, B3, C1, C2, C3, D1, E1, E2, E3, F1, G1, G2, G3, F_DBU, F_OBU, F_Over, G1_DBU, G1_OBU, G1_Over, G2_DBU, G2_OBU, G2_Over, G3_DBU, G3_OBU, G3_Over, ISNULL(G1_DBU, 0) + ISNULL(G2_DBU, 0) + ISNULL(G3_DBU, 0) AS GT_DBU, ISNULL(G1_OBU, 0) + ISNULL(G2_OBU, 0) + ISNULL(G3_OBU, 0) AS GT_OBU, ISNULL(G1_Over, 0) + ISNULL(G2_Over, 0) + ISNULL(G3_Over, 0) AS GT_Over, E1_DBU, E1_OBU, E1_Over, E2_DBU, E2_OBU, E2_Over, E3_DBU, E3_OBU, E3_Over FROM tblMoneyInChina WHERE (YYYMM = @YYYMM) AND (DocNo IN (SELECT DocNo FROM tblLogDetail WHERE (DocType = 'DR') AND (FlowStatus &gt;= 3)))">
            <SelectParameters>
                <asp:Parameter Name="YYYMM" />
            </SelectParameters>
        </asp:SqlDataSource>
    
    </div>
    </form>
    </center>
</body>
</html>
