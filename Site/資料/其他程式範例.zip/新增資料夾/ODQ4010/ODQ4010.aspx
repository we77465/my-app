﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODQ4010.aspx.vb" Inherits="Program_ODQ2010_ODQ2010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <center>
            
                <div>
                    <asp:Label ID="Label1" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
                        Text="台外幣放款餘額彙總表" Visible="False"></asp:Label>
                    <br />
                    <asp:Label ID="Label2" runat="server" Font-Names="標楷體" Text="查詢時間" Visible="False"></asp:Label>
                    <asp:Label ID="lblYYY" runat="server" ForeColor="Red" Text="Label" Visible="False"></asp:Label>
                    <asp:Label ID="Label4" runat="server" Font-Names="標楷體" Text="年" Visible="False"></asp:Label><strong>
                    </strong>
                    <asp:Label ID="lblMM" runat="server" ForeColor="Red" Text="Label" Visible="False"></asp:Label><strong>
                    </strong>
                    <asp:Label ID="Label6" runat="server" Font-Names="標楷體" Text="月" Visible="False"></asp:Label><strong>&nbsp;</strong><strong>
                    </strong>
                    <strong>
                        &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; </strong>
                    <asp:Label ID="Label9" runat="server" Font-Names="標楷體" Text="單位:新台幣千元" Visible="False"></asp:Label>
                    <asp:Button ID="btn_excel" runat="server" Height="25px" Text="匯出預估資料" Width="120px" Visible="False" />
                    <asp:Button ID="Button2" runat="server" Text="匯出實際資料" Visible="False" /><br />
                    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" BackColor="#DEBA84"
                        BorderColor="#DEBA84" BorderWidth="1px" CellPadding="3" DataSourceID="DS_tblMoneyInChina"
                        EmptyDataText="無相關資料可提供" ShowFooter="True" BorderStyle="None" CellSpacing="2" Visible="False"><RowStyle HorizontalAlign="Right" BackColor="#FFF7E7" ForeColor="#8C4510" />
                        <Columns>
                            <asp:BoundField DataField="LOANS_BRNO" HeaderText="分行代號" SortExpression="LOANS_BRNO" />
                            <asp:BoundField DataField="LOANS_BRNAME" HeaderText="分行名稱" SortExpression="LOANS_BRNAME" />
                            <asp:BoundField DataField="LOANS_TW_OVERAGE" HeaderText="預估台幣放款餘額" SortExpression="LOANS_TW_OVERAGE" DataFormatString="{0:N0}" HtmlEncode="False" />
                            <asp:BoundField DataField="LOANS_OUTLET_OVERAGE" HeaderText="預估外幣放款餘額【限外指單位填報】"
                                SortExpression="LOANS_OUTLET_OVERAGE" DataFormatString="{0:N0}" HtmlEncode="False" >
                                <HeaderStyle Width="150px" />
                            </asp:BoundField>
                        </Columns>
                        <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" />
                        <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" />
                        <SelectedRowStyle BackColor="#738A9C" ForeColor="White" Font-Bold="True" />
                        <HeaderStyle BackColor="#A55129" Font-Bold="True" ForeColor="White" />
                    </asp:GridView>
                    <br />
                    <asp:GridView ID="GridView2" runat="server" AutoGenerateColumns="False" BackColor="#DEBA84"
                        BorderColor="#DEBA84" BorderWidth="1px" CellPadding="3" DataSourceID="DS_tblMoneyInChina"
                        EmptyDataText="無相關資料可提供" ShowFooter="True" BorderStyle="None" CellSpacing="2" Visible="False">
                        <RowStyle HorizontalAlign="Right" BackColor="#FFF7E7" ForeColor="#8C4510" />
                        <Columns>
                            <asp:BoundField DataField="LOANS_BRNO" HeaderText="分行代號" SortExpression="LOANS_BRNO" />
                            <asp:BoundField DataField="LOANS_BRNAME" HeaderText="分行名稱" SortExpression="LOANS_BRNAME" />
                            <asp:BoundField DataField="LOANS_TW_OVERAGE_ACT" HeaderText="實際台幣放款餘額" SortExpression="LOANS_TW_OVERAGE_ACT" DataFormatString="{0:N0}" HtmlEncode="False" />
                            <asp:BoundField DataField="LOANS_OUTLET_OVERAGE_ACT" HeaderText="實際外幣放款餘額【限外指單位填報】"
                                SortExpression="LOANS_OUTLET_OVERAGE_ACT" DataFormatString="{0:N0}" HtmlEncode="False" >
                                <HeaderStyle Width="150px" />
                            </asp:BoundField>
                        </Columns>
                        <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" />
                        <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" />
                        <SelectedRowStyle BackColor="#738A9C" ForeColor="White" Font-Bold="True" />
                        <HeaderStyle BackColor="#A55129" Font-Bold="True" ForeColor="White" />
                    </asp:GridView>
                    &nbsp;
                    &nbsp;&nbsp;<br />
                    <asp:Label ID="Label3" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
                        Text="批次作業"></asp:Label>&nbsp;
                    <asp:Button ID="Button1" runat="server" Text="確定" /><br />
                    <asp:DropDownList ID="DropDownList1" runat="server" DataSourceID="DS_tblLoanMonthDetail"
                        DataTextField="LOANS_BRNO" DataValueField="LOANS_BRNO">
                    </asp:DropDownList>
                    &nbsp;<asp:Button ID="btn_Ok" runat="server" Text="選擇分行" Visible="False" />&nbsp;<asp:Button ID="btn_SelectAll"
                        runat="server" Text="選擇全部" Visible="False" />
                    <asp:Button ID="btn_Update" runat="server" Text="確定預估資料" Visible="False" />&nbsp;
                    <asp:Button ID="btn_Cancel" runat="server" Text="取消" Visible="False" /><br />
                    <br />
                    <asp:ListBox ID="ListBox1" runat="server" Visible="False"></asp:ListBox>&nbsp;<asp:ListBox ID="ListBox2"
                        runat="server" Visible="False"></asp:ListBox>
                    <asp:SqlDataSource ID="DS_LogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
                        SelectCommand="SELECT * FROM [tblLoanMonthDetail]" UpdateCommand="UPDATE tblLoanMonthDetail SET LOANS_IF_CAL = '否' WHERE (LOANS_DOCNO = @DocNo)">
                        <UpdateParameters>
                            <asp:Parameter Name="DocNo" />
                        </UpdateParameters>
                    </asp:SqlDataSource>
                    <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
                        DeleteCommand="DELETE FROM tblLogDetail WHERE (DocNo = @DocNo1) and (DocType = 'DR')"
                        InsertCommand="INSERT INTO [tblLogDetail] ([DocType], [DocNo], [BrNo], [EmpId], [RecordDate], [DataFlag], [FormType], [YYMM], [Sign1], [Action1], [SignDate1], [SignComment1], [Sign2], [Action2], [SignDate2], [SignComment2], [DecManager], [DecDate], [FlowStatus], [Ver]) VALUES (@DocType, @DocNo, @BrNo, @EmpId, @RecordDate, @DataFlag, @FormType, @YYMM, @Sign1, @Action1, @SignDate1, @SignComment1, @Sign2, @Action2, @SignDate2, @SignComment2, @DecManager, @DecDate, @FlowStatus, @Ver)"
                        SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
                        UpdateCommand="UPDATE [tblLogDetail] SET [FlowStatus] = @FlowStatus WHERE [DocNo] = @DocNo">
                        <InsertParameters>
                            <asp:Parameter DefaultValue="" Name="DocType" Type="String" />
                            <asp:Parameter DefaultValue="" Name="DocNo" Type="String" />
                            <asp:Parameter Name="BrNo" Type="String" />
                            <asp:Parameter Name="EmpId" Type="String" />
                            <asp:Parameter DefaultValue="" Name="RecordDate" Type="DateTime" />
                            <asp:Parameter DefaultValue="" Name="DataFlag" Type="String" />
                            <asp:Parameter Name="FormType" Type="String" />
                            <asp:Parameter Name="YYMM" Type="String" />
                            <asp:Parameter Name="Sign1" Type="String" />
                            <asp:Parameter Name="Action1" Type="String" />
                            <asp:Parameter Name="SignDate1" Type="DateTime" />
                            <asp:Parameter Name="SignComment1" Type="String" />
                            <asp:Parameter Name="Sign2" Type="String" />
                            <asp:Parameter Name="Action2" Type="String" />
                            <asp:Parameter Name="SignDate2" Type="DateTime" />
                            <asp:Parameter Name="SignComment2" Type="String" />
                            <asp:Parameter Name="DecManager" Type="String" />
                            <asp:Parameter Name="DecDate" Type="DateTime" />
                            <asp:Parameter Name="FlowStatus" Type="String" />
                            <asp:Parameter Name="Ver" Type="Int16" />
                        </InsertParameters>
                        <DeleteParameters>
                            <asp:Parameter Name="DocNo1" />
                        </DeleteParameters>
                        <SelectParameters>
                            <asp:Parameter Name="DocNo" />
                        </SelectParameters>
                        <UpdateParameters>
                            <asp:Parameter Name="FlowStatus" />
                            <asp:Parameter Name="DocNo" />
                        </UpdateParameters>
                    </asp:SqlDataSource>
                    <br />
                    <br />
                    <asp:SqlDataSource ID="DS_tblLoanMonthDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>" DeleteCommand="DELETE FROM [tblLoanMonthDetail] WHERE [LOANS_DOCNO] = @LOANS_DOCNO" InsertCommand="INSERT INTO [tblLoanMonthDetail] ([LOANS_DOCNO], [LOANS_BRNO], [LOANS_BRNAME], [LOANS_EMPID], [LOANS_EMPNAME], [LOANS_EXT], [LOANS_YEARLY], [LOANS_MONTHLY], [LOANS_TW_OVERAGE], [LOANS_OUTLET_OVERAGE]) VALUES (@LOANS_DOCNO, @LOANS_BRNO, @LOANS_BRNAME, @LOANS_EMPID, @LOANS_EMPNAME, @LOANS_EXT, @LOANS_YEARLY, @LOANS_MONTHLY, @LOANS_TW_OVERAGE, @LOANS_OUTLET_OVERAGE)" SelectCommand="SELECT LOANS_BRNO, LOANS_BRNAME, LOANS_TW_OVERAGE, LOANS_OUTLET_OVERAGE, LOANS_TW_OVERAGE_ACT, LOANS_OUTLET_OVERAGE_ACT FROM tblLoanMonthDetail WHERE (LOANS_BRNO = @LOANS_BRNO) AND (LOANS_YEARLY = @LOANS_YEARLY) AND (LOANS_MONTHLY = @LOANS_MONTHLY) AND (LOANS_DOCNO IN (SELECT DocNo FROM tblLogDetail WHERE (DocType = 'DQ') AND (FlowStatus >= 3)))" UpdateCommand="UPDATE [tblLoanMonthDetail] SET [LOANS_BRNO] = @LOANS_BRNO, [LOANS_BRNAME] = @LOANS_BRNAME, [LOANS_EMPID] = @LOANS_EMPID, [LOANS_EMPNAME] = @LOANS_EMPNAME, [LOANS_EXT] = @LOANS_EXT, [LOANS_YEARLY] = @LOANS_YEARLY, [LOANS_MONTHLY] = @LOANS_MONTHLY, [LOANS_TW_OVERAGE] = @LOANS_TW_OVERAGE, [LOANS_OUTLET_OVERAGE] = @LOANS_OUTLET_OVERAGE WHERE [LOANS_DOCNO] = @LOANS_DOCNO">
                        <SelectParameters>
                            <asp:Parameter Name="LOANS_BRNO" />
                            <asp:Parameter Name="LOANS_YEARLY" />
                            <asp:Parameter Name="LOANS_MONTHLY" />
                        </SelectParameters>
                        <DeleteParameters>
                            <asp:Parameter Name="LOANS_DOCNO" Type="String" />
                        </DeleteParameters>
                        <UpdateParameters>
                            <asp:Parameter Name="LOANS_BRNO" Type="String" />
                            <asp:Parameter Name="LOANS_BRNAME" Type="String" />
                            <asp:Parameter Name="LOANS_EMPID" Type="String" />
                            <asp:Parameter Name="LOANS_EMPNAME" Type="String" />
                            <asp:Parameter Name="LOANS_EXT" Type="String" />
                            <asp:Parameter Name="LOANS_YEARLY" Type="String" />
                            <asp:Parameter Name="LOANS_MONTHLY" Type="String" />
                            <asp:Parameter Name="LOANS_TW_OVERAGE" Type="Decimal" />
                            <asp:Parameter Name="LOANS_OUTLET_OVERAGE" Type="Decimal" />
                            <asp:Parameter Name="LOANS_DOCNO" Type="String" />
                        </UpdateParameters>
                        <InsertParameters>
                            <asp:Parameter Name="LOANS_DOCNO" Type="String" />
                            <asp:Parameter Name="LOANS_BRNO" Type="String" />
                            <asp:Parameter Name="LOANS_BRNAME" Type="String" />
                            <asp:Parameter Name="LOANS_EMPID" Type="String" />
                            <asp:Parameter Name="LOANS_EMPNAME" Type="String" />
                            <asp:Parameter Name="LOANS_EXT" Type="String" />
                            <asp:Parameter Name="LOANS_YEARLY" Type="String" />
                            <asp:Parameter Name="LOANS_MONTHLY" Type="String" />
                            <asp:Parameter Name="LOANS_TW_OVERAGE" Type="Decimal" />
                            <asp:Parameter Name="LOANS_OUTLET_OVERAGE" Type="Decimal" />
                        </InsertParameters>
                    </asp:SqlDataSource>
                    <br />
                    <asp:SqlDataSource ID="DS_tblMoneyInChina" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
                        SelectCommand="SELECT LOANS_BRNO, LOANS_BRNAME, LOANS_TW_OVERAGE, LOANS_OUTLET_OVERAGE, LOANS_TW_OVERAGE_ACT, LOANS_OUTLET_OVERAGE_ACT FROM tblLoanMonthDetail WHERE (LOANS_YEARLY = @LOANS_YEARLY) AND (LOANS_MONTHLY = @LOANS_MONTHLY) AND (LOANS_DOCNO IN (SELECT DocNo FROM tblLogDetail WHERE (DocType = 'DQ') AND (FlowStatus >= 3)))">
                        <SelectParameters>
                            <asp:Parameter Name="LOANS_YEARLY" />
                            <asp:Parameter Name="LOANS_MONTHLY" />
                        </SelectParameters>
                    </asp:SqlDataSource>
                    <asp:HiddenField ID="HiddenYYYMM" runat="server" />
                </div>
           
        </center>
    
    </div>
    </form>
</body>
</html>
