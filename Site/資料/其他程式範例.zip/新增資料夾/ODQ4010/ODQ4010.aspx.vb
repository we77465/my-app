﻿Imports System.IO.StringWriter
Imports System.Web.UI.HtmlTextWriter
Imports System.Collections.Generic
Imports System.Data.SqlClient
Partial Class Program_ODQ2010_ODQ2010
    Inherits System.Web.UI.Page

    
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '===== 從前一個網頁得到的值 IntraWeb/OACHB/Program/ODR2010/ODR2010QForm.asp ==========
        Dim YYY As String = Request.QueryString("YYY") '年        Dim docno As String = ""
        Dim MM As String = Request.QueryString("MM") '月        Dim RQBRNO As String = Request.QueryString("RQBRNO") '分行代碼
        Dim YYYMM As String = ""
        'Response.Write("strDate:" & YYY & "<br>")
        'Response.Write("strDate1:" & MM & "<br>")
        lblYYY.Text = YYY
        lblMM.Text = MM
        YYYMM = YYY & MM
        HiddenYYYMM.Value = YYYMM

        If (RQBRNO = "-1") Then
            GridView1.DataSourceID = "DS_tblMoneyInChina"
            GridView2.DataSourceID = "DS_tblMoneyInChina"
            DropDownList1.DataSourceID = "DS_tblMoneyInChina"
            DS_tblMoneyInChina.SelectParameters("LOANS_YEARLY").DefaultValue = YYY
            DS_tblMoneyInChina.SelectParameters("LOANS_MONTHLY").DefaultValue = MM
            DS_tblMoneyInChina.Select(DataSourceSelectArguments.Empty)

        Else
            GridView1.DataSourceID = "DS_tblLoanMonthDetail"
            GridView2.DataSourceID = "DS_tblLoanMonthDetail"
            DropDownList1.DataSourceID = "DS_tblLoanMonthDetail"
            DS_tblLoanMonthDetail.SelectParameters("LOANS_YEARLY").DefaultValue = YYY
            DS_tblLoanMonthDetail.SelectParameters("LOANS_MONTHLY").DefaultValue = MM
            DS_tblLoanMonthDetail.SelectParameters("LOANS_BRNO").DefaultValue = RQBRNO
            DS_tblLoanMonthDetail.Select(DataSourceSelectArguments.Empty)
        End If



        '某一月的最後一天日期
        Dim YYYY As String = Integer.Parse(YYY) + 1911 '西元年
        'Response.Write(YYYY)
        'Response.Write(DateTime.DaysInMonth(YYYY, MM))




    End Sub

    '增加Gridview1表頭表尾欄位(記得Gridview的ShowFooter要設為True)
    Protected Sub GridView1_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowCreated

        '============增加表頭=======================================
        '  If Not (e.Row.RowType = DataControlRowType.Header) Then
        'Exit Sub
        'End If

        'Dim Header As TableCellCollection = e.Row.Cells
        'Header.Clear()   '清除原本的表頭
        'Header.Add(New TableHeaderCell()) '新增表頭
        'Header(0).Text = "</table> <table border=2 cellpadding=2 cellspacing=2 ><tr align=center><td bgcolor=Tan  colspan=1 rowspan=3>分行名稱</td><td bgcolor=Tan  colspan=9>放款資金運用於中國大陸餘額</td><td bgcolor=Tan  colspan=3 rowspan=2>保證款項資金運用於中國大陸餘額</td><td bgcolor=Tan  colspan=1 rowspan=3>應收帳款收買業務資金運用於中國大陸餘額 </td><td bgcolor=Tan  colspan=3 rowspan=2>資金運用於中國大陸帳列金額逾期三個月以上</td></tr><tr align=center style=color: #000000; font-family: Times New Roman>  <td bgcolor=Tan  colspan=2 >行業別</td><td bgcolor=Tan colspan=3 >放款申貸用途</td><td bgcolor=Tan  colspan=3 >分行別</td><td bgcolor=Tan  rowspan=2>放款合計</td></tr><tr align=center style=font-family: Times New Roman><td bgcolor=Tan >傳統業</td><td bgcolor=Tan >科技業</td><td bgcolor=Tan>企業投資</td><td bgcolor=Tan>週轉金</td><td bgcolor=Tan>其他</td><td bgcolor=Tan >DBU</td><td bgcolor=Tan >OBU</td><td bgcolor=Tan style=width: 34px >海外分行</td><td bgcolor=Tan >商業本票保證</td><td bgcolor=Tan >發行公司債</td><td bgcolor=Tan >其他</td><td bgcolor=Tan >放款</td><td bgcolor=Tan >保證墊款</td><td bgcolor=Tan >應收帳款收買</td></tr>"

        '===========增加表尾=========================================
        If Not (e.Row.RowType = DataControlRowType.Footer) Then
            Exit Sub
        End If

        Dim footer As TableCellCollection = e.Row.Cells
        footer.Clear() '清除原本的表尾

        '增加表尾,共4個Cell
        Dim gv1 As New TableCell()
        gv1.HorizontalAlign = HorizontalAlign.Right
        gv1.Text = "全行合計"
        footer.Add(gv1)

        Dim gv2 As New TableCell()
        gv2.HorizontalAlign = HorizontalAlign.Center
        gv2.Text = "NULL"
        footer.Add(gv2)

        Dim gv3 As New TableCell()
        gv3.HorizontalAlign = HorizontalAlign.Right
        gv3.Text = "NULL"
        footer.Add(gv3)

        Dim gv4 As New TableCell()
        gv4.HorizontalAlign = HorizontalAlign.Right
        gv4.Text = "NULL"
        footer.Add(gv4)

    




    End Sub

    'Gridview1表尾加總計算
    Protected Sub GridView1_DataBound(ByVal sender As Object, ByVal e As EventArgs) Handles GridView1.DataBound

        If GridView1.Rows.Count = 0 Then
            Exit Sub
        End If

        Dim gv1, gv2, gv3, gv4 As Decimal
        '各欄位加總計算
        For Each row As GridViewRow In GridView1.Rows


            'Response.Write("1:" & row.Cells(1).Text & "<br>")
            'Response.Write("2:" & row.Cells(2).Text & "<br>")
            'Response.Write("3:" & row.Cells(3).Text & "<br>")
            'Response.Write("4:" & row.Cells(4).Text & "<br>")
            'Response.Write("5:" & row.Cells(5).Text & "<br>")
            'Response.Write("6:" & row.Cells(6).Text & "<br>")
            'Response.Write("7:" & row.Cells(7).Text & "<br>")
            'Response.Write("8:" & row.Cells(8).Text & "<br>")
            'Response.Write("9:" & row.Cells(9).Text & "<br>")
            'Response.Write("10:" & row.Cells(10).Text & "<br>")
            'Response.Write("11:" & row.Cells(11).Text & "<br>")
            'Response.Write("12:" & row.Cells(12).Text & "<br>")
            'Response.Write("13:" & row.Cells(13).Text & "<br>")
            'Response.Write("14:" & row.Cells(14).Text & "<br>")
            'Response.Write("15:" & row.Cells(15).Text & "<br>")
            'Response.Write("16:" & row.Cells(16).Text & "<br>")

            GridView1.FooterRow.Cells(0).Text = "全行合計"
            GridView1.FooterRow.Cells(1).Text = ""

            '            If (row.Cells(1).Text <> "NULL") Then
            'gv1 += Decimal.Parse(row.Cells(1).Text.Replace("$", "").Replace(",", ""))
            'GridView1.FooterRow.Cells(1).Text = gv1.ToString("N0") '貨幣符號
            'End If

            If (row.Cells(2).Text <> "NULL") Then
                gv2 += Decimal.Parse(row.Cells(2).Text.Replace("$", "").Replace(",", ""))
                GridView1.FooterRow.Cells(2).Text = gv2.ToString("N0") '貨幣符號
            End If

            If (row.Cells(3).Text <> "NULL") Then
                gv3 += Decimal.Parse(row.Cells(3).Text.Replace("$", "").Replace(",", ""))
                GridView1.FooterRow.Cells(3).Text = gv3.ToString("N0") '貨幣符號
            End If
        Next

    End Sub

    '===============將Gridview轉成excel檔===============================
    '記的aspx.vb檔前端要加Imports System.IO.StringWriter跟Imports System.Web.UI.HtmlTextWriter
    Protected Sub btn_excel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_excel.Click
        '欄位為文字的 CSS設定
        Dim style As String = "<style> .text { mso-number-format:""\@""; } </style> "
        '以下為 GridView 轉 Excel 的程式
        Response.Clear()
        Response.AddHeader("content-disposition", "attachment;filename=moneyCalucate.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excels"
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Dim stringWrite As New System.IO.StringWriter()
        Dim htmlWrite As New HtmlTextWriter(stringWrite)

        If GridView1.Visible = True Then
            GridView1.RenderControl(htmlWrite) '顯示分行 
        End If

        Response.Write(style)
        Response.Write(stringWrite.ToString())
        Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>") '內容亂碼使用
        Response.End()
    End Sub

    '將Gridview轉成excel檔(加此 sub 就不會出現「run at server」錯誤)
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' 加此 sub 就不會出現「run at server」錯誤
    End Sub

    '將Gridview轉成excel檔(將每個欄位格式都設成「文字」)
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        '將每個欄位格式都設成「文字」
        Dim i As Integer
        For i = 0 To 3
            If e.Row.RowType = DataControlRowType.DataRow Then
                e.Row.Cells(i).Attributes.Add("class", "text")
            End If
        Next
    End Sub
    '===============將Gridview轉成excel檔===============================
    Protected Sub DS_tblLoanMonthDetail_Selecting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceSelectingEventArgs) Handles DS_tblLoanMonthDetail.Selecting

    End Sub

    Protected Sub btn_Ok_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Ok.Click
        ListBox1.Items.Add(DropDownList1.SelectedValue.ToString())
    End Sub

    Protected Sub btn_Cancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Cancel.Click
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
    End Sub

    Protected Sub btn_SelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_SelectAll.Click
        Dim i As Integer
        For i = 0 To DropDownList1.Items.Count - 1
            ListBox1.Items.Add(DropDownList1.Items(i).ToString())
        Next
    End Sub

    Protected Sub btn_Update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Update.Click
        Dim temp As List(Of String)
        Dim DocNo As String = ""
        Dim i As Integer
        For i = 0 To ListBox1.Items.Count - 1
            DocNo = "DQ" & HiddenYYYMM.Value.ToString() & ListBox1.Items(i).ToString() & "0"
            ListBox2.Items.Add(DocNo.ToString())
        Next
        Dim j As Integer
        For j = 0 To ListBox2.Items.Count - 1
            Dim hDocNo As String = ListBox2.Items(j).ToString()
            DS_tblLogDetail.UpdateCommand = "Update tblLogDetail set FlowStatus='-1' , DecDate='" & Now() & "' where DocNo='" & hDocNo & "'"
            DS_tblLogDetail.Update()
        Next
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim i As Integer
        For i = 0 To DropDownList1.Items.Count - 1
            ListBox1.Items.Add(DropDownList1.Items(i).ToString())
        Next
        Dim temp As List(Of String)
        Dim DocNo As String = ""
        Dim k As Integer
        For k = 0 To ListBox1.Items.Count - 1
            DocNo = "DQ" & HiddenYYYMM.Value.ToString() & ListBox1.Items(k).ToString() & "0"
            ListBox2.Items.Add(DocNo.ToString())
        Next
        Dim j As Integer
        For j = 0 To ListBox2.Items.Count - 1
            Dim hDocNo As String = ListBox2.Items(j).ToString()
            DS_LogDetail.UpdateParameters("DocNo").DefaultValue = hDocNo.ToString()
            DS_tblLogDetail.UpdateCommand = "Update tblLogDetail set FlowStatus='-1', DecDate='" & Now() & "' where DocNo='" & hDocNo & "'"
            DS_tblLogDetail.Update()
            DS_LogDetail.Update()
        Next
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()

    End Sub

    Protected Sub GridView2_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView2.RowCreated

        '============增加表頭=======================================
        '  If Not (e.Row.RowType = DataControlRowType.Header) Then
        'Exit Sub
        'End If

        'Dim Header As TableCellCollection = e.Row.Cells
        'Header.Clear()   '清除原本的表頭
        'Header.Add(New TableHeaderCell()) '新增表頭
        'Header(0).Text = "</table> <table border=2 cellpadding=2 cellspacing=2 ><tr align=center><td bgcolor=Tan  colspan=1 rowspan=3>分行名稱</td><td bgcolor=Tan  colspan=9>放款資金運用於中國大陸餘額</td><td bgcolor=Tan  colspan=3 rowspan=2>保證款項資金運用於中國大陸餘額</td><td bgcolor=Tan  colspan=1 rowspan=3>應收帳款收買業務資金運用於中國大陸餘額 </td><td bgcolor=Tan  colspan=3 rowspan=2>資金運用於中國大陸帳列金額逾期三個月以上</td></tr><tr align=center style=color: #000000; font-family: Times New Roman>  <td bgcolor=Tan  colspan=2 >行業別</td><td bgcolor=Tan colspan=3 >放款申貸用途</td><td bgcolor=Tan  colspan=3 >分行別</td><td bgcolor=Tan  rowspan=2>放款合計</td></tr><tr align=center style=font-family: Times New Roman><td bgcolor=Tan >傳統業</td><td bgcolor=Tan >科技業</td><td bgcolor=Tan>企業投資</td><td bgcolor=Tan>週轉金</td><td bgcolor=Tan>其他</td><td bgcolor=Tan >DBU</td><td bgcolor=Tan >OBU</td><td bgcolor=Tan style=width: 34px >海外分行</td><td bgcolor=Tan >商業本票保證</td><td bgcolor=Tan >發行公司債</td><td bgcolor=Tan >其他</td><td bgcolor=Tan >放款</td><td bgcolor=Tan >保證墊款</td><td bgcolor=Tan >應收帳款收買</td></tr>"

        '===========增加表尾=========================================
        If Not (e.Row.RowType = DataControlRowType.Footer) Then
            Exit Sub
        End If

        Dim footer As TableCellCollection = e.Row.Cells
        footer.Clear() '清除原本的表尾

        '增加表尾,共4個Cell
        Dim gv1 As New TableCell()
        gv1.HorizontalAlign = HorizontalAlign.Right
        gv1.Text = "全行合計"
        footer.Add(gv1)

        Dim gv2 As New TableCell()
        gv2.HorizontalAlign = HorizontalAlign.Center
        gv2.Text = "NULL"
        footer.Add(gv2)

        Dim gv3 As New TableCell()
        gv3.HorizontalAlign = HorizontalAlign.Right
        gv3.Text = "NULL"
        footer.Add(gv3)

        Dim gv4 As New TableCell()
        gv4.HorizontalAlign = HorizontalAlign.Right
        gv4.Text = "NULL"
        footer.Add(gv4)
    End Sub

    Protected Sub GridView2_DataBinding(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView2.DataBinding

    End Sub

    Protected Sub GridView2_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView2.DataBound
        If GridView2.Rows.Count = 0 Then
            Exit Sub
        End If

        Dim gv1, gv2, gv3, gv4 As Decimal
        '各欄位加總計算
        For Each row As GridViewRow In GridView2.Rows


            'Response.Write("1:" & row.Cells(1).Text & "<br>")
            'Response.Write("2:" & row.Cells(2).Text & "<br>")
            'Response.Write("3:" & row.Cells(3).Text & "<br>")
            'Response.Write("4:" & row.Cells(4).Text & "<br>")
            'Response.Write("5:" & row.Cells(5).Text & "<br>")
            'Response.Write("6:" & row.Cells(6).Text & "<br>")
            'Response.Write("7:" & row.Cells(7).Text & "<br>")
            'Response.Write("8:" & row.Cells(8).Text & "<br>")
            'Response.Write("9:" & row.Cells(9).Text & "<br>")
            'Response.Write("10:" & row.Cells(10).Text & "<br>")
            'Response.Write("11:" & row.Cells(11).Text & "<br>")
            'Response.Write("12:" & row.Cells(12).Text & "<br>")
            'Response.Write("13:" & row.Cells(13).Text & "<br>")
            'Response.Write("14:" & row.Cells(14).Text & "<br>")
            'Response.Write("15:" & row.Cells(15).Text & "<br>")
            'Response.Write("16:" & row.Cells(16).Text & "<br>")

            GridView2.FooterRow.Cells(0).Text = "全行合計"
            GridView2.FooterRow.Cells(1).Text = ""

            '            If (row.Cells(1).Text <> "NULL") Then
            'gv1 += Decimal.Parse(row.Cells(1).Text.Replace("$", "").Replace(",", ""))
            'GridView1.FooterRow.Cells(1).Text = gv1.ToString("N0") '貨幣符號
            'End If

            If (row.Cells(2).Text <> "NULL") Then
                gv2 += Decimal.Parse(row.Cells(2).Text.Replace("$", "").Replace(",", ""))
                GridView2.FooterRow.Cells(2).Text = gv2.ToString("N0") '貨幣符號
            End If

            If (row.Cells(3).Text <> "NULL") Then
                gv3 += Decimal.Parse(row.Cells(3).Text.Replace("$", "").Replace(",", ""))
                GridView2.FooterRow.Cells(3).Text = gv3.ToString("N0") '貨幣符號
            End If
        Next
    End Sub

    Protected Sub GridView2_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView2.RowDataBound
        '將每個欄位格式都設成「文字」
        Dim i As Integer
        For i = 0 To 3
            If e.Row.RowType = DataControlRowType.DataRow Then
                e.Row.Cells(i).Attributes.Add("class", "text")
            End If
        Next
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        '欄位為文字的 CSS設定
        Dim style As String = "<style> .text { mso-number-format:""\@""; } </style> "
        '以下為 GridView 轉 Excel 的程式
        Response.Clear()
        Response.AddHeader("content-disposition", "attachment;filename=moneyActual.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excels"
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Dim stringWrite As New System.IO.StringWriter()
        Dim htmlWrite As New HtmlTextWriter(stringWrite)

        If GridView2.Visible = True Then
            GridView2.RenderControl(htmlWrite) '顯示分行 
        End If

        Response.Write(style)
        Response.Write(stringWrite.ToString())
        Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>") '內容亂碼使用
        Response.End()
    End Sub
End Class
