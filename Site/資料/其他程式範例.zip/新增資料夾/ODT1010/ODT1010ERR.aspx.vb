﻿
Partial Class Program_ODT1010_ODT1010ERR
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = Request.QueryString("Msg")
        'Response.Write(Request.QueryString("Msg"))
    End Sub
End Class
