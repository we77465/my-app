﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODT1010ERR.aspx.vb" Inherits="Program_ODT1010_ODT1010ERR" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
</head>
<body style="font-size: 20pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <asp:Label ID="Label1" runat="server" ForeColor="Red" Height="136px" Text="error!!"
            Width="680px"></asp:Label><br />
        &nbsp;</div>
    </form>
</body>
</html>
