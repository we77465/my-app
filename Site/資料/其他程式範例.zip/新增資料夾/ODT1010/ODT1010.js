﻿// JScript 檔

function ChkALL()
         { 
             var EXT = document.forms['form1'].txt_Ext.value;//分機
             var IntraMgrName1 = document.forms['form1'].txt_IntraMgrName1.value;//內部管理工作人員
             var JobName1 = document.forms['form1'].txt_JobName1.value;//職 稱:
             var Date1 = document.forms['form1'].txt_Date1.value;//擔任(卸任)日期
             
             
             
               //分機
            if (EXT=="")
            {
                alert("分機必填");
                document.getElementById("txt_Ext").focus();  
               return false;
            }
            
              //內部管理工作人員
             //if (IntraMgrName1=="")
            //{
              //  alert("請選擇 員編 後按 檢核 再按 新增");
               // document.getElementById("ddl__IntraMgrID1").focus(); 
               //return false;
            //}
            
            
             //擔任(卸任)日期
             if (Date1=="")
            {
                alert("擔任(卸任)日期必填");
                document.getElementById("txt_Date1").focus(); 
               return false;
            }
            
               //alert('新增成功') ;
               return true;
         
         }
         
         function ChkALL2()
         { 
         
             
             
             
             
             var EXT = document.forms['form1'].txt_Ext.value;//分機
             var IntraMgrName2 = document.forms['form1'].txt_IntraMgrName2.value;//內部管理工作人員
             var JobName2 = document.forms['form1'].txt_JobName2.value;//職 稱:
             var Date2 = document.forms['form1'].txt_Date2.value;//擔任(卸任)日期
             
             
             
               //分機
            if (EXT=="")
            {
                alert("分機必填");
                document.getElementById("txt_Ext").focus();  
               return false;
            }
            
              //內部管理工作人員
             //if (IntraMgrName2=="")
            //{
              //  alert("請選擇 員編 後按 檢核 再按 新增");
               // document.getElementById("ddl__IntraMgrID2").focus(); 
               //return false;
           // }
            
            
             //擔任(卸任)日期
             if (Date2=="")
            {
                alert("擔任(卸任)日期必填");
                document.getElementById("txt_Date2").focus(); 
               return false;
            }
            
               // alert('新增成功') ;
               return true;
         
         }
         
         
         
         function SaveCheck()
         {
         
                var EXT = document.forms['form1'].txt_Ext.value;//分機
                var savecheck = document.forms['form1'].hid_savecheck.value;//是否有資料
                
                //分機
                if (EXT=="")
                {
                    alert("分機必填");
                    document.getElementById("txt_Ext").focus();  
                    return false;
                }
            
            
                //是否有資料
                if (savecheck=="N")
                {
                    alert("尚未填報資料");
                    document.getElementById("ddl__IntraMgrID1").focus();
                    return false;
                }
            
               alert('儲存成功,請單位主管核可') ;
               return true;
         
         }
         
         
     
         
         