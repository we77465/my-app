﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODT2010.aspx.vb" Inherits="Program_ODC2010_IntraMgrQuery_IntraMgrQuery" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
     <script language="JavaScript">
        if (navigator.appName.indexOf('Internet Explorer') != -1)
        {
	        document.onmousedown = noSourceExplorer;
        }

            function noSourceExplorer()
            {
	            if (event.button == 2 | event.button == 3)
	            {
	                if (confirm('是否列印?')) 
	                {
	                    window.print();
                    }
	            }
            }
    </script>
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <asp:Label ID="Label2" runat="server" Font-Size="Medium" Text="ODT2010"></asp:Label>&nbsp;
        <asp:Label ID="Label1" runat="server" Font-Size="Medium" ForeColor="Red" Text="專責內部管理工作人員查詢"></asp:Label><br />
        <br />
        請選擇單位：<asp:DropDownList ID="DropDownList1" runat="server" AppendDataBoundItems="True"
            DataSourceID="DS_BRANCH" DataTextField="BRNAME" DataValueField="BRNO">
            <asp:ListItem>all</asp:ListItem>
        </asp:DropDownList><br />
        <br />
        現行名單查詢： &nbsp;<asp:Button ID="Button1" runat="server" Text="查 詢" />
        &nbsp; 歷任名單查詢：<asp:Button ID="Button2" runat="server" Text="查 詢" /><br />
        <hr />
        現行名單查詢：&nbsp;
        <asp:Button ID="btn_excel" runat="server" Height="25px" Text="匯出成EXCEL檔" Width="120px" />
        <asp:Button ID="Button4" runat="server" Text="開/關" /><br />
        <asp:GridView ID="GridView2" runat="server" AutoGenerateColumns="False" CellPadding="4"
            DataSourceID="DS_tblIntraMgrManAll" EmptyDataText="無相關資料" ForeColor="#333333"
            GridLines="None">
            <RowStyle BackColor="#EFF3FB" />
            <Columns>
                <asp:BoundField DataField="BRNO" HeaderText="單位代號" ReadOnly="True" SortExpression="BRNO" />
                <asp:BoundField DataField="BRNAME" HeaderText="單位名稱" ReadOnly="True" SortExpression="BRNAME" />
                <asp:BoundField DataField="STAFF" HeaderText="員工代號" ReadOnly="True" SortExpression="STAFF" />
                <asp:BoundField DataField="NAME" HeaderText="姓 名" ReadOnly="True" SortExpression="NAME" />
                <asp:BoundField DataField="JOBNAME" HeaderText="職 稱" ReadOnly="True" SortExpression="JOBNAME" />
                <asp:BoundField DataField="EnableDate" HeaderText="擔任日期" ReadOnly="True" SortExpression="EnableDate" />
            </Columns>
            <FooterStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <PagerStyle BackColor="#2461BF" ForeColor="White" HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="#D1DDF1" Font-Bold="True" ForeColor="#333333" />
            <HeaderStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <EditRowStyle BackColor="#2461BF" />
            <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        <br />
        &nbsp;<br />
        歷任名單查詢：<asp:Button ID="Button3" runat="server" Height="25px" Text="匯出成EXCEL檔" Width="120px" />&nbsp;<asp:Button
            ID="Button5" runat="server" Text="開/關" />
        <asp:GridView
            ID="GridView1" runat="server" AutoGenerateColumns="False" CellPadding="4" DataSourceID="DS_tblIntraMgrManLogAll"
            EmptyDataText="無相關資料" ForeColor="#333333" GridLines="None">
            <RowStyle BackColor="#FFE0C0" />
            <Columns>
                <asp:BoundField DataField="Brno" HeaderText="單位代號" SortExpression="Brno" />
                <asp:BoundField DataField="BrnoName" HeaderText="單位名稱" SortExpression="BrnoName" />
                <asp:BoundField DataField="IntraMgrID" HeaderText="員工代號" SortExpression="IntraMgrID" />
                <asp:BoundField DataField="IntraMgrName" HeaderText="姓 名" SortExpression="IntraMgrName" />
                <asp:BoundField DataField="JobName" HeaderText="職 稱" SortExpression="JobName" />
                <asp:BoundField DataField="EnableDate" HeaderText="擔任日期" SortExpression="EnableDate" />
                <asp:BoundField DataField="DisableDate" HeaderText="卸任日期" SortExpression="DisableDate" />
            </Columns>
            <FooterStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <PagerStyle BackColor="#2461BF" ForeColor="White" HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="#D1DDF1" Font-Bold="True" ForeColor="#333333" />
            <HeaderStyle BackColor="#C04000" Font-Bold="True" ForeColor="White" />
            <EditRowStyle BackColor="#2461BF" />
            <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        <br />
        <asp:SqlDataSource ID="DS_tblIntraMgrManAll" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
            SelectCommand="SELECT E.BRNO, B.BRNAME, E.STAFF, E.NAME, J.JOBNAME,EJ.JOB_DA as EnableDate &#13;&#10;FROM EMPLOYEE AS E &#13;&#10;INNER JOIN JOBCODE AS J ON E.JOBCODE = J.JOBCODE &#13;&#10;INNER JOIN BRANCH AS B ON E.BRNO = B.BRNO &#13;&#10;INNER JOIN EMPLOYEEJOB AS EJ ON E.STAFF = EJ.EMPLID AND E.JOBCODE = EJ.JOBCODE &#13;&#10;WHERE (E.STATUS = '1') &#13;&#10;AND (E.JOBCODE IN ('713000', '812000', '190410', '513000'))  &#13;&#10;UNION SELECT Brno AS BRNO, BrnoName AS BRNAME, IntraMgrID AS STAFF, IntraMgrName AS NAME, JobName AS JOBNAME,EnableDate FROM chb_eform.dbo.tblIntraMgrMan  WHERE  (Master = 'M') &#13;&#10;ORDER BY E.BRNO">
        </asp:SqlDataSource>
        <br />
        &nbsp;<asp:SqlDataSource ID="DS_tblIntraMgrManLogAll" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT Brno, BrnoName, IntraMgrID, IntraMgrName, JobName, EnableDate, DisableDate FROM tblIntraMgrManForm WHERE (DisableDate <> '') and (Master = 'M') AND (DocNo IN (SELECT DocNo FROM tblLogDetail WHERE (DocType = 'DT') AND (FlowStatus = '3')))">
        </asp:SqlDataSource>
        <br />
        &nbsp;&nbsp;<asp:SqlDataSource ID="DS_BRANCH" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
            SelectCommand="select BRNO,BRNO+'-'+BRNAME as BRNAME FROM BRANCH"></asp:SqlDataSource>
        <br />
        &nbsp;
    </div>
    </form>
</body>
</html>
