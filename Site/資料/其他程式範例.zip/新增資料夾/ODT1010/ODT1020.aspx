﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODT1020.aspx.vb" Inherits="Program_ODT1010_ODT1020" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
     <script language="JavaScript">
        if (navigator.appName.indexOf('Internet Explorer') != -1)
        {
	        document.onmousedown = noSourceExplorer;
        }

            function noSourceExplorer()
            {
	            if (event.button == 2 | event.button == 3)
	            {
	                if (confirm('是否列印?')) 
	                {
	                    window.print();
                    }
	            }
            }
    </script>
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <div>
            <asp:Label ID="Label18" runat="server" Font-Bold="True" Text="主 管 (負責人) 核 示"></asp:Label><table
                id="tbls" border="2" cellpadding="2" cellspacing="2" style="width: 726px">
                <tr>
                    <td bgcolor="khaki">
                        單位主管:</td>
                    <td align="center" colspan="2">
                        &nbsp;<asp:TextBox ID="txtSign1" runat="server" BackColor="White" Width="70px"></asp:TextBox>&nbsp;
                        &nbsp;<asp:TextBox ID="txtSign1Name" runat="server" BackColor="White" Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki">
                        簽 核 日:</td>
                    <td align="center">
                        &nbsp;<asp:TextBox ID="txtSignDate1" runat="server" BackColor="White" Width="100px"></asp:TextBox></td>
                    <td bgcolor="khaki">
                        簽 核:</td>
                    <td align="center">
                        &nbsp;<asp:Button ID="BtnSign1OK" runat="server" ForeColor="Red" Text="決 行" />&nbsp;
                        <asp:Button ID="BtnSign1Back" runat="server" ForeColor="Red" Text="退 回" />
                        <asp:Button ID="Button2" runat="server" Text="匯出列印" /></td>
                </tr>
                <tr>
                    <td bgcolor="khaki" style="height: 64px">
                        批 示:</td>
                    <td colspan="6" style="height: 64px">
                        &nbsp;<asp:TextBox ID="txtSignComment1" runat="server" BackColor="White" Height="50px"
                            Width="630px"></asp:TextBox></td>
                </tr>
            </table>
            <asp:Label ID="Label16" runat="server" Font-Bold="True" Text="表 單 內 容"></asp:Label><br />
            <table border="2" cellpadding="2" cellspacing="2" width="720">
                <tr>
                    <td bgcolor="khaki" style="width: 60px">
                        <asp:Label ID="Label10" runat="server" Font-Size="Small" ForeColor="Red" Text="ODT1020"></asp:Label></td>
                    <td style="font-size: 12pt; color: #000000">
                        &nbsp;<asp:Label ID="Label9" runat="server" Font-Names="標楷體" Font-Size="Medium" ForeColor="Red"
                            Text="專責內部管理工作人員指派表" Width="220px"></asp:Label></td>
                    <td bgcolor="khaki" >
                        表單號碼：</td>
                    <td >
                        &nbsp;
                        <asp:Label ID="lblDOCNO" runat="server" Font-Size="Medium" ForeColor="Red" Text="Label"></asp:Label></td>
                    <td bgcolor="khaki">
                        固有號碼:</td>
                    <td >
                        &nbsp; &nbsp;<asp:TextBox ID="txtGoouNum" runat="server" BackColor="#E0E0E0" Width="50px"></asp:TextBox></td>
                </tr>
                <tr >
                    <td bgcolor="khaki" style="width: 60px">
                        <span style="font-size: 9pt; font-family: 新細明體">單位</span>：</td>
                    <td>
                        &nbsp;<asp:TextBox ID="txt_Brno" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox>&nbsp;
                        <asp:TextBox ID="txt_Brno_Name" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki">
                        <span style="font-size: 10pt">填 報 人：</span></td>
                    <td style="font-size: 10pt; font-family: 標楷體">
                        &nbsp;<asp:TextBox ID="txt_EmpID" runat="server" BackColor="#E0E0E0" BorderColor="White"
                            ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                        <asp:TextBox ID="txt_EmpName" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki" style="font-size: 10pt">
                        分 機：</td>
                    <td style="font-size: 12pt; font-family: 標楷體">
                        &nbsp;<asp:TextBox ID="txt_Ext" runat="server" MaxLength="4" ValidationGroup="1"
                            Width="50px" BackColor="#E0E0E0" ReadOnly="True"></asp:TextBox></td>
                </tr>
                <tr >
                    <td bgcolor="khaki" style="width: 60px">
                        </td>
                    <td>
                        &nbsp;<asp:TextBox ID="txt_YYYMM" runat="server" BackColor="#E0E0E0" MaxLength="5"
                            ReadOnly="True" Width="70px" Visible="False"></asp:TextBox></td>
                    <td bgcolor="khaki">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;&nbsp;</td>
                    <td align="center" bgcolor="khaki">
                        <span style="font-size: 9pt; font-family: 新細明體">填報日期</span>:</td>
                    <td align="center">
                        <asp:TextBox ID="txt_RecordDate" runat="server" BackColor="#E0E0E0" MaxLength="5"
                            ReadOnly="True" Width="70px"></asp:TextBox></td>
                </tr>
                <tr style="font-size: 12pt; font-family: Times New Roman">
                    <td colspan="6">
                        <font size="2">人力資源處 台照：                            <br />
                            <br />
                            本單位專責內部管理工作人員，依「彰化銀行內部管理工作實施要點」指派下列人員擔任，報請備查<br />
                            目前本單位專責內部管理工作人員名單如下:&nbsp;<asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False"
                                BackColor="#DEBA84" BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px"
                                CellPadding="2" CellSpacing="1" DataSourceID="DS_tblIntraMgrMan" EmptyDataText="無相關資料">
                                <RowStyle BackColor="#FFF7E7" Font-Size="Medium" ForeColor="#8C4510" />
                                <Columns>
                                    <asp:BoundField DataField="BRNO" HeaderText="單位" SortExpression="BRNO" />
                                    <asp:BoundField DataField="BRNAME" HeaderText="單位名稱" SortExpression="BRNAME" />
                                    <asp:BoundField DataField="STAFF" HeaderText="員工代號" SortExpression="STAFF" />
                                    <asp:BoundField DataField="NAME" HeaderText="姓名" SortExpression="NAME" />
                                    <asp:BoundField DataField="JOBNAME" HeaderText="職 稱" SortExpression="JOBNAME" />
                                </Columns>
                                <FooterStyle BackColor="#F7DFB5" Font-Size="Medium" ForeColor="#8C4510" />
                                <PagerStyle Font-Size="Medium" ForeColor="#8C4510" HorizontalAlign="Center" />
                                <SelectedRowStyle BackColor="#738A9C" Font-Bold="True" Font-Size="Medium" ForeColor="White" />
                                <HeaderStyle BackColor="#A55129" Font-Bold="True" Font-Size="Medium" ForeColor="White" />
                                <EmptyDataRowStyle Font-Size="Medium" />
                            </asp:GridView>
                            <br />
                            異動表如下:<br />
                            <asp:GridView ID="GridView2" runat="server" AutoGenerateColumns="False" BackColor="#DEBA84"
                                BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px" CellPadding="2" CellSpacing="1"
                                DataKeyNames="DocNo,Brno,IntraMgrID,Master,status" DataSourceID="DS_tblIntraMgrManForm"
                                EmptyDataText="無相關填報資料">
                                <RowStyle BackColor="#FFF7E7" Font-Size="Medium" ForeColor="#8C4510" />
                                <EmptyDataRowStyle Font-Size="Medium" />
                                <Columns>
                                    <asp:BoundField DataField="DocNo" HeaderText="表單編號" ReadOnly="True" SortExpression="DocNo" >
                                        <HeaderStyle Font-Size="Smaller" />
                                        <ItemStyle Font-Size="XX-Small" />
                                    </asp:BoundField>
                                    <asp:BoundField DataField="Brno" HeaderText="單位" ReadOnly="True" SortExpression="Brno" >
                                        <HeaderStyle Font-Size="Smaller" />
                                        <ItemStyle Font-Size="XX-Small" />
                                    </asp:BoundField>
                                    <asp:BoundField DataField="BrnoName" HeaderText="單位名稱" SortExpression="BrnoName" >
                                        <HeaderStyle Font-Size="XX-Small" />
                                        <ItemStyle Font-Size="XX-Small" />
                                    </asp:BoundField>
                                    <asp:BoundField DataField="IntraMgrID" HeaderText="員工代號" ReadOnly="True" SortExpression="IntraMgrID" >
                                        <HeaderStyle Font-Size="XX-Small" />
                                        <ItemStyle Font-Size="XX-Small" />
                                    </asp:BoundField>
                                    <asp:BoundField DataField="IntraMgrName" HeaderText="姓名" SortExpression="IntraMgrName" >
                                        <HeaderStyle Font-Size="XX-Small" />
                                        <ItemStyle Font-Size="XX-Small" />
                                    </asp:BoundField>
                                    <asp:BoundField DataField="JobName" HeaderText="職 稱" SortExpression="JobName" >
                                        <HeaderStyle Font-Size="XX-Small" />
                                        <ItemStyle Font-Size="XX-Small" />
                                    </asp:BoundField>
                                    <asp:BoundField DataField="Master" HeaderText="主辦" ReadOnly="True" SortExpression="Master" >
                                        <FooterStyle Font-Size="XX-Small" />
                                        <ItemStyle Font-Size="XX-Small" />
                                    </asp:BoundField>
                                    <asp:BoundField DataField="EnableDate" HeaderText="擔任日期" SortExpression="EnableDate" >
                                        <HeaderStyle Font-Size="XX-Small" />
                                    </asp:BoundField>
                                    <asp:BoundField DataField="DisableDate" HeaderText="卸任日期" SortExpression="DisableDate" >
                                        <HeaderStyle Font-Size="XX-Small" />
                                        <ItemStyle Font-Size="XX-Small" />
                                    </asp:BoundField>
                                    <asp:BoundField DataField="status" HeaderText="狀態(Add:新增)(Del:刪除)" ReadOnly="True" SortExpression="status" >
                                        <HeaderStyle Font-Size="XX-Small" />
                                    </asp:BoundField>
                                </Columns>
                                <FooterStyle BackColor="#F7DFB5" Font-Size="Medium" ForeColor="#8C4510" />
                                <PagerStyle Font-Size="Medium" ForeColor="#8C4510" HorizontalAlign="Center" />
                                <SelectedRowStyle BackColor="#738A9C" Font-Bold="True" Font-Size="Medium" ForeColor="White" />
                                <HeaderStyle BackColor="#A55129" Font-Bold="True" Font-Size="Medium" ForeColor="White" />
                                <EditRowStyle Font-Size="Medium" />
                                <AlternatingRowStyle Font-Size="Medium" />
                            </asp:GridView>
                            <br />
                            <span style="font-size: 9pt; font-family: 新細明體">備註<span lang="EN-US">: </span>依據本行「內部管理工作實施要點」明定<font
                                color="red"><span style="color: red">「專責內部管理工作人員」</span></font>應由下列主管擔任之</span><span
                                    style="font-size: 9pt"><span style="font-family: 新細明體"><span lang="EN-US">:&nbsp;<br />
                                        &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span>國內衛星分行<span lang="EN-US">-- </span>
                                        作業主管</span></span><span lang="EN-US"><br />
                                            <span style="font-size: 9pt; font-family: 新細明體">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span>
                                        </span><span style="font-size: 9pt; font-family: 新細明體">證券經紀商<span lang="EN-US">--</span>交割主管</span><span
                                            lang="EN-US"><br />
                                            <span style="font-size: 9pt; font-family: 新細明體">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span>
                                        </span><span style="font-size: 9pt; font-family: 新細明體">國際金融業務分行<span lang="EN-US"> --
                                        </span>企金主管</span><span lang="EN-US"><br />
                                            <span style="font-size: 9pt; font-family: 新細明體">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span>
                                        </span><span style="font-size: 9pt; font-family: 新細明體">區營運處<span lang="EN-US"> -- </span>
                                            一般支援組組長</span><span lang="EN-US"><br />
                                                <asp:Label ID="Label7" runat="server" ForeColor="Red" Text="前開四種單位所定主管人員異動時，於填報「職務報告表」後無需再以本系統填報本表單報備。"></asp:Label><asp:Label
                                                    ID="Label8" runat="server" ForeColor="Red" Text="惟總行各處及國外分行均應由單位主管自行指派「專責內部管理工作人員」，並以本系統填報本表單傳送人力資源處備查。"></asp:Label></span></font></td>
                </tr>
               
              </table>
        </div>
        <br />
        單位主管： &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 填報人：&nbsp;<br />
        <br />
        &nbsp;&nbsp;<asp:SqlDataSource ID="DS_tblIntraMgrMan" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
            SelectCommand="SELECT E.BRNO, B.BRNAME, E.STAFF, E.NAME, J.JOBNAME FROM EMPLOYEE AS E INNER JOIN JOBCODE AS J ON E.JOBCODE = J.JOBCODE INNER JOIN BRANCH AS B ON E.BRNO = B.BRNO WHERE (E.STATUS = '1') AND (E.JOBCODE IN ('721600', '713000', '812000', '190410', '513000')) AND (E.BRNO = @BRNO1) and (@BRNO1 not in (select b1.BRNO from chb_pub.dbo.BRANCH as b1 left join (select BRNO from chb_pub.dbo.crc_rel_br) as b2 on b1.BRNO = b2.BRNO where b2.BRNO is null)) UNION SELECT Brno AS BRNO, BrnoName AS BRNAME, IntraMgrID AS STAFF, IntraMgrName AS NAME, JobName AS JOBNAME FROM chb_eform.dbo.tblIntraMgrMan WHERE (Brno = @BRNO2) and (Master = 'M')" DeleteCommand="delete FROM chb_eform..tblIntraMgrMan where (Master = 'M') and Brno+'-'+IntraMgrID in (SELECT Brno+'-'+IntraMgrID as tmp1 FROM chb_eform.dbo.tblIntraMgrManForm WHERE (DocNo = @DocNo) AND (status = 'Del'))" InsertCommand="INSERT INTO chb_eform.dbo.tblIntraMgrMan(Brno, BrnoName, IntraMgrID, IntraMgrName, JobName, Master,EnableDate) SELECT Brno, BrnoName, IntraMgrID, IntraMgrName, JobName, Master,EnableDate FROM chb_eform.dbo.tblIntraMgrManForm WHERE (DocNo = @DocNo) AND (status = 'Add')">
            <SelectParameters>
                <asp:Parameter Name="BRNO1" />
                <asp:Parameter Name="BRNO2" />
            </SelectParameters>
            <DeleteParameters>
                <asp:Parameter Name="DocNo" />
            </DeleteParameters>
            <InsertParameters>
                <asp:Parameter Name="DocNo" />
            </InsertParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblIntraMgrManForm" runat="server" ConflictDetection="CompareAllValues"
            ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            InsertCommand="INSERT INTO [tblIntraMgrManForm] ([DocNo], [Brno], [BrnoName], [YYYMM], [Keyin], [Ext], [GoouNum], [IntraMgrID], [IntraMgrName], [JobName], [Master], [EnableDate], [DisableDate], [status]) VALUES (@DocNo, @Brno, @BrnoName, @YYYMM, @Keyin, @Ext, @GoouNum, @IntraMgrID, @IntraMgrName, @JobName, @Master, @EnableDate, @DisableDate, @status)"
            OldValuesParameterFormatString="original_{0}" SelectCommand="SELECT * FROM [tblIntraMgrManForm] where DocNo = @DocNo">
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <InsertParameters>
                <asp:Parameter Name="DocNo" Type="String" />
                <asp:Parameter Name="Brno" Type="String" />
                <asp:Parameter Name="BrnoName" Type="String" />
                <asp:Parameter Name="YYYMM" Type="String" />
                <asp:Parameter Name="Keyin" Type="String" />
                <asp:Parameter Name="Ext" Type="String" />
                <asp:Parameter Name="GoouNum" Type="String" />
                <asp:Parameter Name="IntraMgrID" Type="String" />
                <asp:Parameter Name="IntraMgrName" Type="String" />
                <asp:Parameter Name="JobName" Type="String" />
                <asp:Parameter Name="Master" Type="String" />
                <asp:Parameter Name="EnableDate" Type="String" />
                <asp:Parameter Name="DisableDate" Type="String" />
                <asp:Parameter Name="status" Type="String" />
            </InsertParameters>
        </asp:SqlDataSource>
        &nbsp;&nbsp;&nbsp;<br />
        <br />
        &nbsp;<asp:SqlDataSource ID="DS_BRANCH" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT BRNO, BRNAME FROM chb_pub.dbo.BRANCH WHERE (BRNO = @gBrNo)" ProviderName="<%$ ConnectionStrings:chb_pub.ProviderName %>">
            <SelectParameters>
                <asp:FormParameter FormField="gBrNo" Name="gBrNo" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_EMPLOYEE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
            SelectCommand="SELECT [STAFF], [NAME], [BRNO], [JOBCODE], [STATUS] FROM [EMPLOYEE] WHERE (BRNO = @BRNO) AND (STATUS='1')">
            <SelectParameters>
                <asp:Parameter Name="BRNO" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_JOBCODE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
            SelectCommand="SELECT   E.STAFF, E.NAME, E.JOBCODE, J.JOBNAME  FROM  EMPLOYEE AS E INNER JOIN JOBCODE AS J ON E.JOBCODE = J.JOBCODE WHERE     E.STAFF =@STAFF ">
            <SelectParameters>
                <asp:Parameter Name="STAFF" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblGoouNum" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
            SelectCommand="SELECT * FROM [tblGoouNum]">
            <SelectParameters>
                <asp:Parameter Name="Brno" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblLogDetail WHERE (DocNo = @DocNo1) and (DocType = 'DS')"
            InsertCommand="INSERT INTO [tblLogDetail] ([DocType], [DocNo], [BrNo], [EmpId], [RecordDate], [DataFlag], [FormType], [YYMM], [Sign1], [Action1], [SignDate1], [SignComment1], [Sign2], [Action2], [SignDate2], [SignComment2], [DecManager], [DecDate], [FlowStatus], [Ver]) VALUES (@DocType, @DocNo, @BrNo, @EmpId, @RecordDate, @DataFlag, @FormType, @YYMM, @Sign1, @Action1, @SignDate1, @SignComment1, @Sign2, @Action2, @SignDate2, @SignComment2, @DecManager, @DecDate, @FlowStatus, @Ver)"
            SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
            UpdateCommand="UPDATE [tblLogDetail] SET  [Sign1] = @Sign1, [Action1] = @Action1, [SignDate1] = @SignDate1, [SignComment1] = @SignComment1,  [DecManager] = @DecManager, [DecDate] = @DecDate, [FlowStatus] = @FlowStatus  WHERE [DocNo] = @DocNo">
            <InsertParameters>
                <asp:Parameter DefaultValue="" Name="DocType" Type="String" />
                <asp:Parameter DefaultValue="" Name="DocNo" Type="String" />
                <asp:Parameter Name="BrNo" Type="String" />
                <asp:Parameter Name="EmpId" Type="String" />
                <asp:Parameter DefaultValue="" Name="RecordDate" Type="DateTime" />
                <asp:Parameter DefaultValue="" Name="DataFlag" Type="String" />
                <asp:Parameter Name="FormType" Type="String" />
                <asp:Parameter Name="YYMM" Type="String" />
                <asp:Parameter Name="Sign1" Type="String" />
                <asp:Parameter Name="Action1" Type="String" />
                <asp:Parameter Name="SignDate1" Type="DateTime" />
                <asp:Parameter Name="SignComment1" Type="String" />
                <asp:Parameter Name="Sign2" Type="String" />
                <asp:Parameter Name="Action2" Type="String" />
                <asp:Parameter Name="SignDate2" Type="DateTime" />
                <asp:Parameter Name="SignComment2" Type="String" />
                <asp:Parameter Name="DecManager" Type="String" />
                <asp:Parameter Name="DecDate" Type="DateTime" />
                <asp:Parameter Name="FlowStatus" Type="String" />
                <asp:Parameter Name="Ver" Type="Int16" />
            </InsertParameters>
            <DeleteParameters>
                <asp:Parameter Name="DocNo1" />
            </DeleteParameters>
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <UpdateParameters>
                <asp:Parameter Name="Sign1" />
                <asp:Parameter Name="Action1" />
                <asp:Parameter Name="SignDate1" />
                <asp:Parameter Name="SignComment1" />
                <asp:Parameter Name="DecManager" />
                <asp:Parameter Name="DecDate" />
                <asp:Parameter Name="FlowStatus" />
                <asp:Parameter Name="DocNo" />
            </UpdateParameters>
        </asp:SqlDataSource>
        &nbsp;<br />
        <asp:SqlDataSource ID="DS_ALL_EMP" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
            SelectCommand="SELECT B_1.CRCNO, E_1.BRNO, B_1.BRNAME, E_1.STATUS, E_1.STAFF, E_1.NAME, E_1.JOBCODE, E_1.JOBNAME FROM (SELECT E.BRNO, E.STATUS, E.STAFF, E.NAME, E.JOBCODE, J.JOBNAME FROM EMPLOYEE AS E LEFT OUTER JOIN JOBCODE AS J ON E.JOBCODE = J.JOBCODE) AS E_1 LEFT OUTER JOIN (SELECT B.BRNO, B.BRNAME, C.CRCNO FROM BRANCH AS B LEFT OUTER JOIN crc_rel_br AS C ON B.BRNO = C.BRNO) AS B_1 ON E_1.BRNO = B_1.BRNO ORDER BY B_1.CRCNO, E_1.BRNO, E_1.STAFF">
        </asp:SqlDataSource>
        <br />
        &nbsp;
        <br />
    
    </div>
    </form>
</body>
</html>
