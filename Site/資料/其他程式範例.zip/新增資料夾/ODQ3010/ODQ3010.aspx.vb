﻿Imports System.Data.SqlClient
Partial Class Program_ODQ3010_ODQ3010
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not IsPostBack) Then
            '==============================================================================================
            '前一頁傳來的值  \IntraWeb\OACHB\Program\ODK3010\ODK3010List.asp
            Dim hDocNo As String = Request.Form("hDocNo")
            hidn_hDocNo.Value = hDocNo
            'Response.Write("hDocNo:" & Request.Form("hDocNo") & "<br>")
            '==============================================================================================
            '表單表頭區塊
            GettblMoneyInChinaDB(hDocNo)   '從DS_tblSell_Report(DB)取值(資料內容)

            '==============================================================================================
            '負責人決行區塊
            GetDBLogDetail(hDocNo) '從DB(tblLogDetail)取值(負責人ID,簽核日,批示)

            Dim EmpId As Integer = Integer.Parse(txtSign1.Text.Trim()) '負責人ID
            'Response.Write("EmpId:" & EmpId & "<br>")
            txtSign1Name.Text = GetEmpID2Name(EmpId)  '利用員編找名字(負責人姓名)

            '==============================================================================================
            '資料區塊


        End If
    End Sub    '利用員編找名字
    Private Function GetEmpID2Name(ByVal EmpId)

        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select NAME from chb_pub..EMPLOYEE where STAFF ='" & EmpId & "'"
            'Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function

    '從DB(tblLogDetail)取值(負責人ID,簽核日,批示)
    Private Sub GetDBLogDetail(ByVal docno)
        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            Dim FlowStatus As String = ""
            tmpsql = "SELECT  Sign1,SignDate1,SignComment1,FlowStatus FROM tblLogDetail where DocNo = '" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read
                txtSign1.Text = reader(0).ToString() '負責人ID
                txtSignDate1.Text = Format(DateValue(reader(1).ToString()), "yyyy/MM/dd") '簽核日
                txtSignComment1.Text = reader(2).ToString() '批示
                FlowStatus = reader(3).ToString()
            End While
            txt_status.Text = FlowStatus & "-" & GetFlowStatus(FlowStatus)
            reader.Close()
            cmd.Dispose()
        End Using
    End Sub

    '從DS_tblLoanMonthDetail(DB)取值(資料內容)
    Private Sub GettblMoneyInChinaDB(ByVal docno)

        '=================資 料 庫 撈 資 料==================

        Using conn As New SqlConnection(DS_tblMoneyInChina.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  LOANS_DOCNO, LOANS_BRNO, LOANS_BRNAME, LOANS_EMPID, LOANS_EMPNAME, LOANS_EXT, LOANS_YEARLY, LOANS_MONTHLY, LOANS_TW_OVERAGE , LOANS_OUTLET_OVERAGE   FROM tblLoanMonthDetail where LOANS_DOCNO = '" & docno & "'"
            'Response.Write(tmpsql)
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read
                lblDOCNO.Text = reader(0).ToString() 'DocNo  
                txt_Brno.Text = reader(1).ToString()  'Brno   
                txt_Brno_Name.Text = reader(2).ToString()  'BRName 
                txt_EmpID.Text = reader(3).ToString()  'EmpID  
                txt_EmpName.Text = reader(4).ToString()  'EmpName
                txt_Ext.Text = reader(5).ToString()  'Ext    
                txt_YYYMM.Text = reader(6).ToString() & reader(7).ToString() 'YYYMM  
                txt_TWOVERAGE.Text = reader(8).ToString() '台幣
                txt_OUTLETOVERAGE.Text = reader(9).ToString() '外幣
            End While
            reader.Close()
            cmd.Dispose()
        End Using

    End Sub

    '確定 ,UPDATE 表單流程DB(tblLogDetail) 資料
    Protected Sub BtnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnOK.Click
        Dim hDocNo As String = hidn_hDocNo.Value '表單編號
        DS_tblLogDetail.UpdateCommand = "Update tblLogDetail Set FlowStatus=4 where DocNo='" + hDocNo + "'"
        DS_tblLogDetail.Update()

        Response.Write("<script language=javascript>alert('確定成功!')</script>")
        Response.Write("<script language=javascript>window.location.href='/oachb/program/ODQ3010/ODQ3010QForm.asp'</script>")

    End Sub

    '退回 ,UPDATE 表單流程DB(tblLogDetail) 資料 
    Protected Sub BtnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnBack.Click
        Dim hDocNo As String = hidn_hDocNo.Value '表單編號
        DS_tblLogDetail.UpdateCommand = "Update tblLogDetail set FlowStatus='-1' where DocNo='" + hDocNo + "'"
        DS_tblLogDetail.Update()

        Response.Write("<script language=javascript>alert('退回成功!')</script>")
        Response.Write("<script language=javascript>window.location.href='/oachb/program/ODQ3010/ODQ3010QForm.asp'</script>")

    End Sub

    '輸入流程狀態tmpFlowID代碼,回傳tmpFlowStatus中文('0退回;1待簽核;2待決行;3已決行;-1總行退件;4已確認;99已送至總行)
    Private Function GetFlowStatus(ByVal tmpFlowID)
        Dim tmpFlowStatus As String = ""
        Using conn As New SqlConnection(DS_tblSysCode.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  TblDesc FROM tblSysCode WHERE TblId = '11' AND TblCd =" & tmpFlowID
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                tmpFlowStatus = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using
        '0		退回
        '1		待簽核
        '2		待決行
        '3		已決行
        '-1		總行退件
        '4		已確認
        '99		已送至總行
        Return tmpFlowStatus
    End Function



End Class
