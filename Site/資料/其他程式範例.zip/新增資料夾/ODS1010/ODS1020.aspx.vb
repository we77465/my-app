﻿Imports System.Data.SqlClient
Partial Class Program_ODS1010_ODS1020
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Not IsPostBack) Then
            '前一頁傳來的值 IntraWeb\OACHB\Program\OAOvrd\OAOvrdList.asp
            Dim hOvrd As String = Request.Form("hOvrd") '?
            Dim hQFlowStatus As String = Request.Form("hQFlowStatus") '流程狀態
            Dim hDocNo As String = Request.Form("hDocNo")  '表單編號
            Dim hUsrId As String = Request.Form("hUsrId") '負責人ID
            hidn_hUsrId.Value = hUsrId '負責人ID
            Dim hUsrName As String = Request.Form("hUsrName") '負責人NAME

            'Response.Write("hOvrd:" & Request.Form("hOvrd") & "<br>")
            'Response.Write("hQFlowStatus:" & Request.Form("hQFlowStatus") & "<br>")
            'Response.Write("hDocNo:" & Request.Form("hDocNo") & "<br>")
            'Response.Write("hUsrId:" & Request.Form("hUsrId") & "<br>")
            'Response.Write("hUsrName:" & Request.Form("hUsrName") & "<br>")
            'Response.Write("BtnSign1OK:" & BtnSign1OK.Visible & "<br>")
            'Response.Write("BtnSign1Back:" & BtnSign1Back.Visible & "<br>")

            GetDBLogDetail(hDocNo) '從DB(tblLogDetail)取值
            GettblIntraMgrRptDB(hDocNo)  '從tblMoneyInChinaDB取值(資料內容)

            '==============================================================================================
            '流程區塊
            lblDOCNO.Text = hDocNo '表單編號
            txt_status.Text = HiddenFlowStatus.Value & "-" & GetFlowStatus(HiddenFlowStatus.Value) '狀 態
            '0:負責人退回  1:待簽核 2:待決行 3:已決行 -1:總行退件 4:已確認  99:已送至總行() 
            txtVer.Text = HiddenVer.Value  '版本
            txt_Brno.Text = HiddenBrno.Value  '分行
            txt_Brno_Name.Text = GetBrno2Name(HiddenBrno.Value) '分行名稱
            txt_EmpID.Text = HiddenEmpId.Value  '經辦
            txt_EmpName.Text = GetEmpID2Name(HiddenEmpId.Value) '經辦名稱
            txt_Ext.Text = HiddenExt.Value '分機
            txt_YYYMM.Text = HiddenYYMM.Value '所屬年月
            txt_RecordDate.Text = FormatDateTime(HiddenRecordDate.Value, DateFormat.ShortDate) '申報日期            
            '==============================================================================================
            '決行區塊
            '如果已簽核過就去撈db的來顯示
            txtSign1.Text = HiddenSign1.Value '負責人
            txtSign1Name.Text = GetEmpID2Name(HiddenSign1.Value) '負責人名稱
            txtSignDate1.Text = HiddenSignDate1.Value '簽核日
            txtSignComment1.Text = HiddenSignComment1.Value   '批示
            '如果db沒值就用此組
            txtSign1.Text = hUsrId '負責人ID
            txtSign1Name.Text = GetEmpID2Name(hUsrId) '負責人名稱
            txtSignDate1.Text = FormatDateTime(Now(), DateFormat.ShortDate) '簽核日
            'txtSignComment1.Text '批示
            '==============================================================================================
            '資料區塊
            '從DS_tblSell_Report(DB)取值(資料內容)

            '0:負責人退回  1:待簽核 2:待決行 3:已決行 -1:總行退件 4:已確認  99:已送至總行() 
            If (HiddenFlowStatus.Value = "4" Or HiddenFlowStatus.Value = "-1") Then '如果已送總行則不給按
                BtnSign1OK.Visible = False
                BtnSign1Back.Visible = False
            Else
                BtnSign1OK.Visible = True
                BtnSign1Back.Visible = True
            End If
            'Response.Write("Hidden_status:" & HiddenFlowStatus.Value & "<br>")

        End If

    End Sub

    '利用分行代號找出分行名稱
    Private Function GetBrno2Name(ByVal gBrNo)
        Dim BrnoName As String = ""
        Using conn As New SqlConnection(DS_BRANCH.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select BRNAME from chb_pub..BRANCH where BRNO ='" & gBrNo & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                BrnoName = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using

        Return BrnoName
    End Function

    '利用員編找名字
    Private Function GetEmpID2Name(ByVal EmpId)

        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select NAME from chb_pub..EMPLOYEE where STAFF ='" & EmpId & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function

    '輸入流程狀態tmpFlowID代碼,回傳tmpFlowStatus中文('0退回;1待簽核;2待決行;3已決行;-1總行退件;4已確認;99已送至總行)
    Private Function GetFlowStatus(ByVal tmpFlowID)
        Dim tmpFlowStatus As String = ""
        Using conn As New SqlConnection(DS_tblSysCode.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  TblDesc FROM tblSysCode WHERE TblId = '11' AND TblCd =" & tmpFlowID
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                tmpFlowStatus = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using
        '0		退回
        '1		待簽核
        '2		待決行
        '3		已決行
        '-1		總行退件
        '4		已確認
        '99		已送至總行
        Return tmpFlowStatus
    End Function

    '從表單流程DB(tblLogDetail)取值
    Private Sub GetDBLogDetail(ByVal docno)
        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  FlowStatus,Ver,BrNo,EmpId,YYMM,RecordDate,Sign1,SignDate1,SignComment1 FROM tblLogDetail where DocNo = '" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read

                HiddenFlowStatus.Value = reader(0).ToString() '狀態
                HiddenVer.Value = reader(1).ToString() '版本
                HiddenBrno.Value = reader(2).ToString() '分行
                HiddenEmpId.Value = reader(3).ToString() '經辦
                HiddenYYMM.Value = reader(4).ToString() '所屬年月
                HiddenRecordDate.Value = reader(5).ToString() '申報日期
                HiddenSign1.Value = reader(6).ToString() '負責人
                HiddenSignDate1.Value = reader(7).ToString() '簽核日
                HiddenSignComment1.Value = reader(8).ToString()   '批示

            End While
            reader.Close()
            cmd.Dispose()
        End Using
    End Sub


    '同意,決行成功 ,UPDATE 表單流程DB(tblLogDetail) 資料
    Protected Sub BtnSign1OK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSign1OK.Click

        DS_tblLogDetail.UpdateParameters("Sign1").DefaultValue = hidn_hUsrId.Value '負責人ID
        DS_tblLogDetail.UpdateParameters("ACTION1").DefaultValue = "D"
        DS_tblLogDetail.UpdateParameters("SignDate1").DefaultValue = Now() ' 日期時間
        DS_tblLogDetail.UpdateParameters("DecManager").DefaultValue = hidn_hUsrId.Value ' 負責人ID
        DS_tblLogDetail.UpdateParameters("DecDate").DefaultValue = Now() '日期時間
        DS_tblLogDetail.UpdateParameters("FlowStatus").DefaultValue = "3" '流程狀態
        DS_tblLogDetail.UpdateParameters("SignComment1").DefaultValue = txtSignComment1.Text '批示
        DS_tblLogDetail.UpdateParameters("DocNo").DefaultValue = lblDOCNO.Text '表單編號

        DS_tblLogDetail.Update()
        Response.Write("<script language=javascript>alert('決行成功!')</script>")
        Response.Write("<script language=javascript>window.location.href='/OACHB/Program/OAOvrd/OAOvrdQForm.asp?hOvrd=2'</script>")
    End Sub

    '退回 ,UPDATE 表單流程DB(tblLogDetail) 資料
    Protected Sub BtnSign1Back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSign1Back.Click

        DS_tblLogDetail.UpdateParameters("Sign1").DefaultValue = hidn_hUsrId.Value '負責人ID
        DS_tblLogDetail.UpdateParameters("ACTION1").DefaultValue = "B"
        DS_tblLogDetail.UpdateParameters("SignDate1").DefaultValue = Now() ' 日期時間
        DS_tblLogDetail.UpdateParameters("DecManager").DefaultValue = "" ' 負責人ID
        DS_tblLogDetail.UpdateParameters("DecDate").DefaultValue = "" '日期時間
        DS_tblLogDetail.UpdateParameters("FlowStatus").DefaultValue = "0" '流程狀態
        DS_tblLogDetail.UpdateParameters("SignComment1").DefaultValue = txtSignComment1.Text '批示
        DS_tblLogDetail.UpdateParameters("DocNo").DefaultValue = lblDOCNO.Text '表單編號

        DS_tblLogDetail.Update()
        Response.Write("<script language=javascript>alert('退回成功!')</script>")
        Response.Write("<script language=javascript>window.location.href='/OACHB/Program/OAOvrd/OAOvrdQForm.asp?hOvrd=2'</script>")
    End Sub

    '匯出列印
    Protected Sub BtnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnExport.Click
        '匯出成HTML檔
        Response.AddHeader("content-disposition", "attachment; filename=saveExcel.html")
        Response.Charset = "utf-8"
        Response.ContentType = "Content-Language;content=zh-tw"
        Response.ContentType = "application/vnd.ms-excel"
    End Sub

    '從DS_tblIntraMgrRpt(DB)取值(資料內容)
    Private Sub GettblIntraMgrRptDB(ByVal docno)

        '=================變 數 宣 告==================



        '=================資 料 庫 撈 資 料==================
        Try

            Using conn As New SqlConnection(DS_tblIntraMgrRpt.ConnectionString)
                conn.Open()
                Dim tmpsql As String
                tmpsql = "SELECT DocNo, Brno, BRName, EmpId, EmpName, Ext, YYYMM,SN,Brno_2,Brno_Name_2,Sign1Name_2,EmpName_2, Content1, Improve, Item  FROM   tblIntraMgrRpt where DocNo = '" & docno & "'"
                'Response.Write(tmpsql)
                Dim cmd As New SqlCommand(tmpsql, conn)
                Dim reader As SqlDataReader = cmd.ExecuteReader()
                While reader.Read

                    lblDOCNO.Text = reader(0).ToString() 'DocNo  
                    txt_Brno.Text = reader(1).ToString()  'Brno   
                    txt_Brno_Name.Text = reader(2).ToString()  'BRName 
                    txt_EmpID.Text = reader(3).ToString()  'EmpID  
                    txt_EmpName.Text = reader(4).ToString()  'EmpName
                    txt_Ext.Text = reader(5).ToString()  'Ext    
                    txt_YYYMM.Text = reader(6).ToString()  'YYYMM 

                    txt_GoouNum.Text = reader(7).ToString() '固有號碼:
                    txt_Brno_2.Text = reader(8).ToString() '單位:
                    txt_Brno_Name_2.Text = reader(9).ToString() '單位:
                    txtSign1Name_2.Text = reader(10).ToString() '主管:
                    txt_EmpName_2.Text = reader(11).ToString() '報告人:
                    txtContent1.Text = reader(12).ToString()  '該當人員及具體內容
                    txtImprove.Text = reader(13).ToString()  '建議或改進意見    

                    Dim i As Integer                                       '0981104
                    For i = 1 To (Len(reader(14).ToString())) Step 1
                        If Mid(reader(14).ToString(), i, 1) = "1" Then
                            CheckBoxList1.Items(i - 1).Selected = True
                        End If
                    Next                                                   '1104


                End While
                reader.Close()
                cmd.Dispose()
            End Using

        Catch ex As Exception

            Response.Write("<script language=javascript>alert('讀取資料庫失敗,原因:" & ex.Message & "')</script>")

        End Try

    End Sub
End Class
