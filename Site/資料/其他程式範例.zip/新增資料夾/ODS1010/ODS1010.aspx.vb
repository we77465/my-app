﻿Imports System.IO.StringWriter
Imports System.Web.UI.HtmlTextWriter
Imports System.Data.SqlClient

Partial Class Program_ODS1010_ODS1010
    Inherits System.Web.UI.Page
    '此表單需經 電子表單/管理人員名單維護/專責內部管理工作人員指派表 or 專責內部管理工作助理人員指派表 指派後才開放填報
    'or  
    '國內衛星分行--作業主管; 證券經紀商--交割主管; 國際金融業務分行--企金主管; 區營運處--一般支援組組長

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Not IsPostBack) Then
            '===========================================================================================
            '0. 前一個網頁(ODS1010QForm.asp)得到的值
            Dim docno As String = ""
            Dim hDocNo As String = ""
            Dim hYear As String = ""
            Dim hMonth As String = ""
            Dim gBrNo As String = ""
            Dim gEmpId As String = ""

            docno = Request.Form("hDocNo").Replace(",", "") '表單編號
            hDocNo = Request.Form("hDocNo").Replace(",", "") '表單編號
            hYear = Request.Form("hYear").Replace(",", "") '年度
            hMonth = Request.Form("hMonth").Replace(",", "") '月
            gBrNo = Request.Form("gBrNo") '分行代號
            gEmpId = Request.Form("gEmpId") '員編

            '//判斷是否為填報人員,若否不給填並導回上一頁
            Dim IntraMgrMan1 As String = GetIntraMgrMan1(gBrNo, gEmpId)
            Dim IntraMgrMan2 As String = GetIntraMgrMan2(gBrNo, gEmpId)

            If IntraMgrMan1 = "0" And IntraMgrMan2 = "0" Then
                Response.Write("<script language=javascript>alert('非填報人員,請向該單位專責內部管理人員申請')</script>")
                Response.Write("<script language=javascript>window.location.href='/oachb/program/ODS1010/ODS1010QForm.asp'</script>")
            End If

            'Response.Write("docno:" & docno & "<br>")
            'Response.Write("hDocNo:" & hDocNo & "<br>")
            'Response.Write("hMonth:" & hMonth & "<br>")
            'Response.Write("hYear:" & hYear & "<br>")
            'Response.Write("gBrNo:" & gBrNo & "<br>")
            'Response.Write("gEmpId:" & gEmpId & "<br>")
            'Response.Write("IntraMgrMan1(emp):" & IntraMgrMan1 & "<br>")
            'Response.Write("IntraMgrMan2:" & IntraMgrMan2 & "<br>")

            hidn_EMPID.Value = gEmpId

            txtSign1Name_2.Text = GetBossName(gBrNo) '主管

            '//組表單編號
            If (hDocNo <> "") Then
                docno = hDocNo '表單已存在
            Else
                '表單不存在,組表單編號
                docno = "DS" & hYear & hMonth & gBrNo
                docno = GetLastNum(docno)
                'Response.Write("docno:" & docno & "<br>")
            End If

            '//組上半部欄位
            lblDOCNO.Text = docno '表單編號
            txt_Brno.Text = gBrNo '分行代號
            txt_Brno_Name.Text = GetBrno2Name(gBrNo) '分行名稱
            txt_EmpID.Text = gEmpId '經辦員編
            txt_EmpName.Text = GetEmpID2Name(gEmpId) '經辦名稱
            txt_YYYMM.Text = hYear & hMonth '所屬年月
            txt_RecordDate.Text = Format(Now(), "MM/dd/yyyy") '申報日期

            ''===========================================================================================
            '1. 查DS_tblLogDetail(DB)看表單編號是否已存在,如果沒有則新增,如果有的話則導到更新的頁面
            Dim tmpDocnoStatus As Array = CheckDocnoInDB(docno) '輸入表單編號,回傳(0表單編號是否存在,1流程代號,2流程日期,3版本)
            Dim tmpdocno As String = tmpDocnoStatus(0)
            Dim tmpFlowID As String = tmpDocnoStatus(1)
            Dim tmpDate As String = tmpDocnoStatus(2)
            Dim tmpVer As String = tmpDocnoStatus(3)
            Dim tmpSign1 As String = tmpDocnoStatus(4)
            Dim tmpSignDate1 As String = tmpDocnoStatus(5)
            Dim tmpSignComment1 As String = tmpDocnoStatus(6)

            '===========================================================================================
            '2. 表單編號不存在,可新增
            If (tmpdocno = "") Then '表單不存在,可新增
                txt_status.Text = "分行新增中"
                '按鈕
                BtnAdd.Visible = True '新增按鈕顯示

                txt_Brno_2.Text = gBrNo '分行代號
                txt_Brno_Name_2.Text = GetBrno2Name(gBrNo) '分行名稱
                txt_EmpName_2.Text = GetEmpID2Name(gEmpId) '經辦名稱
                txt_GoouNum.Text = GetGoouNum(gBrNo)
            Else
                '===========================================================================================
                '3. 表單編號已存在,load DB

                '輸入流程狀態tmpFlowID代碼,回傳tmpFlowStatus中文
                txt_status.Text = GetFlowStatus(tmpFlowID)
                txtDate.Text = tmpDate '流程狀態2(日期)
                txtVer.Text = tmpVer
                txtSign1.Text = tmpSign1 '負責人ID
                'txtContent2.Text = tmpContent2 'XX

                If (tmpSign1 <> "") Then
                    txtSign1Name.Text = GetEmpID2Name(tmpSign1) '負責人name
                    'txtSign1Name_2.Text = GetEmpID2Name(tmpSign1) '負責人name
                End If
                txtSignDate1.Text = tmpSignDate1 '簽核日
                txtSignComment1.Text = tmpSignComment1 '批示

                '如果flowstatus是0,1,2,-1則經辦可修改
                If (tmpFlowID = "0" Or tmpFlowID = "1" Or tmpFlowID = "2" Or tmpFlowID = "-1") Then
                    BtnMod.Visible = True '修改按鈕顯示
                    BtnDel.Visible = True '刪除按鈕顯示

                Else '已決行及已放行不能改

                    txt_Ext.ReadOnly = True
                    txtSign1Name_2.ReadOnly = True
                    txtContent1.ReadOnly = True
                    txtImprove.ReadOnly = True

                End If

                '如果flowstatus是4
                'If (tmpFlowID = "4") Then
                'txtContent2.Text = GettmpContent2(tmpContent2) 'XX
                'End If

                '從tblIntraMgrRpt(DB)取值
                GettblIntraMgrRptDB()
            End If
                '===========================================================================================
                '檢查相關欄位是否有填值
                BtnAdd.Attributes.Add("onclick", "return ChkALL()") '新增               
                BtnMod.Attributes.Add("onclick", "return ChkALL()") '修改

        End If

    End Sub

    '匯出列印
    Protected Sub BtnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnExport.Click
        '匯出成HTML檔
        Response.AddHeader("content-disposition", "attachment; filename=saveExcel.htm")
        Response.Charset = "utf-8"
        Response.ContentType = "Content-Language;content=zh-tw"
        Response.ContentType = "application/vnd.ms-excel"

    End Sub

    '利用分行代號找出分行名稱
    Private Function GetBrno2Name(ByVal gBrNo)
        Dim BrnoName As String = ""
        Using conn As New SqlConnection(DS_BRANCH.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select BRNAME from chb_pub..BRANCH where BRNO ='" & gBrNo & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                BrnoName = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using

        Return BrnoName
    End Function

    '利用員編找名字
    Private Function GetEmpID2Name(ByVal gEmpId)
        ''Response.Write("gEmpId:" & gEmpId & "<br>")
        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select NAME from chb_pub..EMPLOYEE where STAFF ='" & gEmpId & "'"
            ''Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function

    '查主管名稱
    Private Function GetBossName(ByVal gBrno)
        ''Response.Write("gEmpId:" & gEmpId & "<br>")
        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            '派籌備分行經理人員,於赴任前暫先掛於國內營運處,致國內營運處於填報[內部管理綜合報告表]時,報表內[單位主管]欄位出現該經理姓名,非該單位處長姓名
            tmpsql = "SELECT  TOP (1) NAME  FROM chb_pub..EMPLOYEE  WHERE  (BRNO = '" & gBrno & "') AND (JOBCODE IN ('110000', '120000', '130000', '160000', '170000', '180000', '190000', '200000', '210000', '220000', '230000','240000', '250000', '260000', '270000', '280000', '510000', '710000', '720001', '190400', '810000')) and STATUS='1' ORDER BY JOBCODE"
            'Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
                'Response.Write("aaa:" & reader2(0).ToString() & "<br>")
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function

    '輸入流程狀態tmpFlowID代碼,回傳tmpFlowStatus中文('0退回;1待簽核;2待決行;3已決行;-1總行退件;4已確認;99已送至總行)
    Private Function GetFlowStatus(ByVal tmpFlowID)
        Dim tmpFlowStatus As String = ""
        Using conn As New SqlConnection(DS_tblSysCode.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  TblDesc FROM tblSysCode WHERE TblId = '11' AND TblCd =" & tmpFlowID
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                tmpFlowStatus = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using
        '0		退回
        '1		待簽核
        '2		待決行
        '3		已決行
        '-1		總行退件
        '4		已確認
        '99		已送至總行
        Return tmpFlowStatus
    End Function

    '輸入表單編號,回傳(0表單編號是否存在,1流程代號,2流程日期,3版本,4負責人id,5負責人審核日期,6負責人批示) db:tblLogDetail
    Private Function CheckDocnoInDB(ByVal docno) As Object
        Dim DocnoInDB(6)
        Dim tmpdocno As String = ""
        Dim tmpFlowStatus As String = ""
        Dim tmpRecordDate As String = ""
        Dim tmpSignDate1 As String = ""
        Dim tmpDecDate As String = ""
        Dim tmpDate As String = ""
        Dim tmpVer As String = ""
        Dim tmpSign1 As String = ""
        Dim tmpSignComment1 As String = ""

        '去DS_tblLogDetail(DB)查表單編號
        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select DocType,DocNo, BrNo,EmpId,RecordDate,DataFlag,FormType,YYMM,Sign1,Action1,SignDate1,SignComment1,Sign2,Action2,SignDate2,SignComment2,DecManager,DecDate,FlowStatus,Ver from tblLogDetail where DocNo ='" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read
                tmpdocno = reader(1).ToString() '表單編號
                tmpRecordDate = reader(4).ToString() '分行日期
                tmpSign1 = reader(8).ToString() '負責人id
                tmpSignDate1 = reader(10).ToString() '負責人審核日期
                tmpSignComment1 = reader(11).ToString() '負責人批示
                tmpDecDate = reader(17).ToString() '日期
                tmpFlowStatus = reader(18).ToString() '表單流程
                tmpVer = reader(19).ToString() '版本

            End While
            reader.Close()
            cmd.Dispose()
        End Using

        '利用流程代號決定回傳日期
        Select Case tmpFlowStatus
            Case -1 '總行退回 
                tmpDate = FormatDateTime(tmpDecDate, DateFormat.ShortDate)

            Case 0 '退回
                tmpDate = FormatDateTime(tmpSignDate1, DateFormat.ShortDate)
            Case 1 '待簽核
                tmpDate = FormatDateTime(tmpRecordDate, DateFormat.ShortDate)
            Case 3 '已決行
                tmpDate = FormatDateTime(tmpSignDate1, DateFormat.ShortDate)
            Case 4 '已確認
                tmpDate = FormatDateTime(tmpDecDate, DateFormat.ShortDate)
        End Select

        DocnoInDB(0) = tmpdocno '表單編號
        DocnoInDB(1) = tmpFlowStatus '流程狀態
        DocnoInDB(2) = tmpDate '流程狀態後面的日期
        DocnoInDB(3) = tmpVer '版本
        DocnoInDB(4) = tmpSign1 '負責人id
        DocnoInDB(5) = tmpSignDate1 '負責人審核日期
        DocnoInDB(6) = tmpSignComment1 '負責人批示

        Return DocnoInDB
    End Function

    '新增按鈕
    Protected Sub BtnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd.Click
        Dim cunt As Integer = CheckBoxList1.Items.Count '總數量
        Dim sele As String = "" '0981028
        Dim i As Integer
        For i = 0 To (cunt - 1) Step 1
            If CheckBoxList1.Items(i).Selected Then
                sele = sele & "1"
            Else
                sele = sele & "0"
            End If
        Next

        If txtContent1.Text.Trim().Length = 0 Then
            Response.Write("<script language=javascript>alert('請填寫該當人員及具體內容')</script>")
            Return
        End If
        If txtContent1.Text.Trim().Contains("無該當") = True Then
            Response.Write("<script language=javascript>alert('該當人員及具體內容不得為無該當')</script>")
            Return
        End If

        DS_tblIntraMgrRpt.InsertParameters("Item").DefaultValue = sele

        DS_tblIntraMgrRpt.InsertParameters("DocNo").DefaultValue = lblDOCNO.Text '表單編號
        DS_tblIntraMgrRpt.InsertParameters("Brno").DefaultValue = txt_Brno.Text '分行代碼
        DS_tblIntraMgrRpt.InsertParameters("BRName").DefaultValue = txt_Brno_Name.Text '分行名稱
        DS_tblIntraMgrRpt.InsertParameters("EmpID").DefaultValue = txt_EmpID.Text '經辦
        DS_tblIntraMgrRpt.InsertParameters("EmpName").DefaultValue = txt_EmpName.Text '經辦名稱
        DS_tblIntraMgrRpt.InsertParameters("Ext").DefaultValue = txt_Ext.Text '分行代號
        DS_tblIntraMgrRpt.InsertParameters("YYYMM").DefaultValue = txt_YYYMM.Text '所屬年月

        '資料內容
        DS_tblIntraMgrRpt.InsertParameters("SN").DefaultValue = txt_GoouNum.Text '固有號碼:
        DS_tblIntraMgrRpt.InsertParameters("Brno_2").DefaultValue = txt_Brno_2.Text '單位:
        DS_tblIntraMgrRpt.InsertParameters("Brno_Name_2").DefaultValue = txt_Brno_Name_2.Text '單位:
        DS_tblIntraMgrRpt.InsertParameters("Sign1Name_2").DefaultValue = txtSign1Name_2.Text '主管:
        DS_tblIntraMgrRpt.InsertParameters("EmpName_2").DefaultValue = txt_EmpName_2.Text '報告人: 
        DS_tblIntraMgrRpt.InsertParameters("Content1").DefaultValue = txtContent1.Text '該當人員及具體內容
        DS_tblIntraMgrRpt.InsertParameters("Improve").DefaultValue = txtImprove.Text '建議或改善意見

        '新增chb_eform 表單流程
        DS_tblLogDetail.InsertParameters("DocType").DefaultValue = "DS"
        DS_tblLogDetail.InsertParameters("DocNo").DefaultValue = lblDOCNO.Text.ToString.Trim() '表單編號
        DS_tblLogDetail.InsertParameters("BrNo").DefaultValue = txt_Brno.Text.ToString.Trim() '分行代碼
        DS_tblLogDetail.InsertParameters("EmpId").DefaultValue = txt_EmpID.Text.ToString.Trim() '經辦員編
        DS_tblLogDetail.InsertParameters("RecordDate").DefaultValue = Now()
        DS_tblLogDetail.InsertParameters("DataFlag").DefaultValue = "N"
        DS_tblLogDetail.InsertParameters("YYMM").DefaultValue = txt_YYYMM.Text.ToString.Trim() '年月
        DS_tblLogDetail.InsertParameters("FlowStatus").DefaultValue = "2"
        DS_tblLogDetail.InsertParameters("Ver").DefaultValue = "1"

        Try
            DS_tblIntraMgrRpt.Insert()
            DS_tblLogDetail.Insert()
            Response.Write("<script language=javascript>alert('新增完畢!')</script>")
            Response.Write("<script language=javascript>window.location.href='/oachb/program/ODS1010/ODS1010QForm.asp'</script>")
        Catch ex As Exception
            Response.Write("<script language=javascript>alert('新增失敗,原因:" & ex.Message & "')</script>")
        End Try



    End Sub


    '按下修改
    Protected Sub BtnMod_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnMod.Click
        Dim gEmpId As String = hidn_EMPID.Value
        txt_EmpID.Text = gEmpId '經辦員編
        txt_EmpName.Text = GetEmpID2Name(gEmpId) '找出經辦名稱

        Dim cunt As Integer = CheckBoxList1.Items.Count '總數量
        Dim sele As String = "" '0981028
        Dim i As Integer
        For i = 0 To (cunt - 1) Step 1
            If CheckBoxList1.Items(i).Selected Then
                sele = sele & "1"
            Else
                sele = sele & "0"
            End If
            'Dim cunt As Integer = CheckBoxList1.Items.Count '總數量
            'Dim sele As String = "," '0981028
            'Dim i As Integer
            'For i = 0 To (cunt - 1) Step 1
            '    If CheckBoxList1.Items(i).Selected Then
            '        sele = sele & " " & CheckBoxList1.Items(i).Value
            '    End If
        Next

        If txtContent1.Text.Trim().Length = 0 Then
            Response.Write("<script language=javascript>alert('請填寫該當人員及具體內容')</script>")
            Return
        End If
        If txtContent1.Text.Trim().Contains("無該當") = True Then
            Response.Write("<script language=javascript>alert('該當人員及具體內容不得為無該當')</script>")
            Return
        End If      

        DS_tblIntraMgrRpt.UpdateParameters("Item").DefaultValue = sele
        '修改表單內容 tblMoneyInChina
        DS_tblIntraMgrRpt.UpdateParameters("DocNo").DefaultValue = lblDOCNO.Text '表單編號
        DS_tblIntraMgrRpt.UpdateParameters("Brno").DefaultValue = txt_Brno.Text '分行代碼
        DS_tblIntraMgrRpt.UpdateParameters("BRName").DefaultValue = txt_Brno_Name.Text '分行名稱
        DS_tblIntraMgrRpt.UpdateParameters("EmpID").DefaultValue = txt_EmpID.Text '經辦
        DS_tblIntraMgrRpt.UpdateParameters("EmpName").DefaultValue = txt_EmpName.Text '經辦名稱
        DS_tblIntraMgrRpt.UpdateParameters("Ext").DefaultValue = txt_Ext.Text '分行代號
        DS_tblIntraMgrRpt.UpdateParameters("YYYMM").DefaultValue = txt_YYYMM.Text '所屬年月


        '資料內容
        DS_tblIntraMgrRpt.UpdateParameters("SN").DefaultValue = txt_GoouNum.Text '固有號碼:
        DS_tblIntraMgrRpt.UpdateParameters("Brno_2").DefaultValue = txt_Brno_2.Text '單位:
        DS_tblIntraMgrRpt.UpdateParameters("Brno_Name_2").DefaultValue = txt_Brno_Name_2.Text '單位:
        DS_tblIntraMgrRpt.UpdateParameters("Sign1Name_2").DefaultValue = txtSign1Name_2.Text '主管:
        DS_tblIntraMgrRpt.UpdateParameters("EmpName_2").DefaultValue = txt_EmpName_2.Text '報告人: 
        DS_tblIntraMgrRpt.UpdateParameters("Content1").DefaultValue = txtContent1.Text '該當人員及具體內容
        DS_tblIntraMgrRpt.UpdateParameters("Improve").DefaultValue = txtImprove.Text '建議或改善意見

        '修改chb_eform 表單流程 (UPDATE [tblLogDetail] SET [EmpId] = @EmpId, [RecordDate] = @RecordDate, [DataFlag] = @DataFlag, [Sign1] = @Sign1, [Action1] = @Action1, [SignDate1] = @SignDate1, [SignComment1] = @SignComment1,  [DecManager] = @DecManager, [DecDate] = @DecDate, [FlowStatus] = @FlowStatus, [Ver] = @Ver WHERE [DocNo] = @DocNo)
        Dim docno As String = lblDOCNO.Text
        Dim tmpDocnoStatus As Array
        tmpDocnoStatus = CheckDocnoInDB(docno)
        Dim NewVer As String = Decimal.Parse(tmpDocnoStatus(3).ToString.Trim()) + 1 '版本+1
        DS_tblLogDetail.UpdateParameters("DocNo").DefaultValue = docno
        DS_tblLogDetail.UpdateParameters("EmpId").DefaultValue = txt_EmpID.Text '經辦員編
        DS_tblLogDetail.UpdateParameters("RecordDate").DefaultValue = Now()
        DS_tblLogDetail.UpdateParameters("DataFlag").DefaultValue = "N"
        DS_tblLogDetail.UpdateParameters("FlowStatus").DefaultValue = "2"
        DS_tblLogDetail.UpdateParameters("Ver").DefaultValue = NewVer
        DS_tblLogDetail.UpdateParameters("Sign1").DefaultValue = ""
        DS_tblLogDetail.UpdateParameters("Action1").DefaultValue = ""
        DS_tblLogDetail.UpdateParameters("SignDate1").DefaultValue = "" ' 日期時間
        DS_tblLogDetail.UpdateParameters("DecManager").DefaultValue = "" ' 負責人ID
        DS_tblLogDetail.UpdateParameters("DecDate").DefaultValue = "" '日期時間
        DS_tblLogDetail.UpdateParameters("SignComment1").DefaultValue = "" '批示

        Try
            DS_tblIntraMgrRpt.Update()
            DS_tblLogDetail.Update()
            Response.Write("<script language=javascript>alert('修改完畢!')</script>")
            Response.Write("<script language=javascript>window.location.href='/oachb/program/ODS1010/ODS1010QForm.asp'</script>")

        Catch ex As Exception
            Response.Write("<script language=javascript>alert('修改失敗,原因:" & ex.Message & "')</script>")
        End Try

    End Sub

    '刪除按鈕
    Protected Sub BtnDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnDel.Click

        DS_tblLogDetail.DeleteParameters("DocNo1").DefaultValue = lblDOCNO.Text.Trim()
        DS_tblIntraMgrRpt.DeleteParameters("DocNo").DefaultValue = lblDOCNO.Text.Trim()

        DS_tblLogDetail.Delete() '刪除 chb_eform 表單流程
        DS_tblIntraMgrRpt.Delete() '刪除 DS_tblIntraMgrRpt 表單流程

        Response.Write("<script language=javascript>alert('刪除完畢!')</script>")
        Response.Write("<script language=javascript>window.location.href='/oachb/program/ODS1010/ODS1010QForm.asp'</script>")
    End Sub

    '從DS_tblIntraMgrRpt(DB)取值(資料內容)
    Private Sub GettblIntraMgrRptDB()

        '=================變 數 宣 告==================
        Dim docno As String
        docno = lblDOCNO.Text
        '=================資 料 庫 撈 資 料==================
        Try

            Using conn As New SqlConnection(DS_tblIntraMgrRpt.ConnectionString)
                conn.Open()
                Dim tmpsql As String
                tmpsql = "SELECT DocNo, Brno, BRName, EmpId, EmpName, Ext, YYYMM,SN,Brno_2,Brno_Name_2,Sign1Name_2,EmpName_2, Content1, Improve, Item  FROM   tblIntraMgrRpt where DocNo = '" & docno & "'"
                ''Response.Write(tmpsql)
                Dim cmd As New SqlCommand(tmpsql, conn)
                Dim reader As SqlDataReader = cmd.ExecuteReader()
                While reader.Read

                    lblDOCNO.Text = reader(0).ToString() 'DocNo  
                    txt_Brno.Text = reader(1).ToString()  'Brno   
                    txt_Brno_Name.Text = reader(2).ToString()  'BRName 
                    txt_EmpID.Text = reader(3).ToString()  'EmpID  
                    txt_EmpName.Text = reader(4).ToString()  'EmpName
                    txt_Ext.Text = reader(5).ToString()  'Ext    
                    txt_YYYMM.Text = reader(6).ToString()  'YYYMM 

                    txt_GoouNum.Text = reader(7).ToString() '固有號碼:
                    txt_Brno_2.Text = reader(8).ToString() '單位:
                    txt_Brno_Name_2.Text = reader(9).ToString() '單位:
                    txtSign1Name_2.Text = reader(10).ToString() '主管:
                    txt_EmpName_2.Text = reader(11).ToString() '報告人:
                    txtContent1.Text = reader(12).ToString()  '該當人員及具體內容
                    txtImprove.Text = reader(13).ToString()  '建議或改進意見    
                    'txtItem.Text = reader(14).ToString() '項目1028

                    Dim i As Integer                                       '0981103
                    For i = 1 To (Len(reader(14).ToString())) Step 1
                        If Mid(reader(14).ToString(), i, 1) = "1" Then
                            CheckBoxList1.Items(i - 1).Selected = True
                        End If
                    Next                                                   '1103

                End While
                reader.Close()
                cmd.Dispose()
            End Using

        Catch ex As Exception

            'Response.Write("<script language=javascript>alert('讀取資料庫失敗,原因:" & ex.Message & "')</script>")

        End Try

    End Sub

    '表單流水編號尾碼
    '查詢tblLogDetail  找出該分行該月份最後一筆表單編號最後一位流水號,用來當做下一筆表單編號的參考
    'EXP:DB內最後一筆是 DS0980605012  -->2,則下一筆則是 DS0980605013
    Function GetLastNum(ByVal tmpdocno)
        Dim LastNum As String = ""
        Dim DocNo As String = tmpdocno
        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select max(DocNo),substring(max(DocNo),12,12) from tblLogDetail where DocType = 'DS' and substring(DocNo,1,11) = '" & tmpdocno & "'"
            'Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()

            While reader.Read
                LastNum = reader(1).ToString()

                If LastNum = "" Then
                    LastNum = "0"
                    DocNo = DocNo & LastNum
                Else
                    LastNum = Integer.Parse(LastNum) + 1
                    DocNo = DocNo & LastNum
                End If

            End While
        End Using
        Return DocNo
        'Response.Write("LastNum:" & LastNum & "<br>")
    End Function

    '查固有號碼
    Function GetGoouNum(ByVal BrNo)
        Dim GoouNum As String = ""

        Using conn As New SqlConnection(DS_GoouNum.ConnectionString)

            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  GoouNum  FROM  tblGoouNum WHERE Brno ='" & BrNo & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()

            While reader.Read
                GoouNum = reader(0).ToString() '表單編號
            End While
            reader.Close()
            cmd.Dispose()
        End Using

        Return GoouNum

    End Function

    '是否為填報人員1(JOBCODE)
    '專責內部管理工作人員應由下列主管擔任之: 
    '國內衛星分行-- 作業主管 
    '證券經紀商--交割主管
    '國際金融業務分行 -- 企金主管
    '區營運處 -- 一般支援組組長
    '分行經理

    Function GetIntraMgrMan1(ByVal gBrNo, ByVal gEmpId)

        Dim IntraMgrMan1 As String = "0"

        Using conn As New SqlConnection(DS_EMPLOYEE2.ConnectionString)

            conn.Open()
            Dim tmpsql As String
            '20120808
            'tmpsql = "SELECT COUNT(*) AS count FROM EMPLOYEE WHERE (JOBCODE IN ('713000', '812000', '190410', '513000')) AND (BRNO = '" & gBrNo & "') AND (STAFF = '" & gEmpId & "')"
            '讓證券經紀商的 交割主管(812000)、受託買賣主管(811000) 可填報
            tmpsql = "SELECT COUNT(*) AS count FROM EMPLOYEE WHERE (JOBCODE IN ('713000', '812000', '811000','190410', '513000')) AND (BRNO = '" & gBrNo & "') AND (STAFF = '" & gEmpId & "')"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()

            While reader.Read
                IntraMgrMan1 = reader(0).ToString() '表單編號
            End While
            reader.Close()
            cmd.Dispose()
        End Using

        Return IntraMgrMan1

    End Function

    '是否為填報人員2
    '總行各處及國外分行均由單位主管自行指派並以本表單報人力資源處備查
    '新增人員會存放在tblIntraMgrMan
    Function GetIntraMgrMan2(ByVal gBrNo, ByVal gEmpId)

        Dim IntraMgrMan2 As String = "0"

        Using conn As New SqlConnection(DS_tblIntraMgrMan.ConnectionString)

            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT COUNT(*) AS count FROM tblIntraMgrMan WHERE (Brno = '" & gBrNo & "') AND (IntraMgrID = '" & gEmpId & "')"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()

            While reader.Read
                IntraMgrMan2 = reader(0).ToString() '表單編號
            End While
            reader.Close()
            cmd.Dispose()
        End Using

        Return IntraMgrMan2

    End Function
End Class

'Function setdisplay()

'    Dim chkflag As String = chkUserInDb(UID)
'    If chkflag = UID Then

'        Dim UsedTracTool() As String = DaInDb(3).Split(";"c)
'        Dim i As Integer
'        For i = 0 To chk_TraTool.Items.Count - 1 Step i + 1
'            chk_TraTool.Items(i).Selected = False


'            For m = 0 To TracTool.Length - 1 Step m + 1
'                If TracTool(m).ToString() = "1.對員工之領導及輔導 " Then
'                    CheckBoxList1.Items(0).Selected = True
'                End If
'                If TracTool(m).ToString() = "二" Then
'                    CheckBoXList1.Items(1).Selected = True
'                End If
'                If TracTool(m).ToString() = "三" Then
'                    CheckBoXList1.Items(2).Selected = True
'                End If
'                If TracTool(m).ToString() = "四" Then
'                    CheckBoXList1.Items(3).Selected = True
'                End If
'                If TracTool(m).ToString() = "五" Then
'                    CheckBoXList1.Items(4).Selected = True
'                End If


