﻿// JScript 檔
function ChkALL()
         { 
             var EXT=document.forms['form1'].txt_Ext.value;//分機
             var Sign1Name_2=document.forms['form1'].txtSign1Name_2.value;//主管名稱
             var Content1=document.forms['form1'].txtContent1.value;     //限字數  
              var Content1=document.forms['form1'].txtImprove.value;     //限字數 
              
            //分機
            if (EXT=="")
            {
                alert("分機必填");
                document.getElementById("txt_Ext").focus();  
               return false;
            }
            
                     
            //主管名稱    
            if (Sign1Name_2 == "")
            {
                alert("主管名稱必填");
                 document.getElementById("txtSign1Name_2").focus();                
                return false;            
            }
            
               
         
        
           //限字數    
           
                 
 
           if (document.getElementById('txtContent1').value.length > 370){
                
                    alert("該當人員及具體內容不可超過370個字!");
                    
                   return false; 
                           
         }
     
       
       
         if (document.getElementById('txtImprove').value.length > 370){
                
                    alert("建議或改進意見不可超過370個字!");
                    
                   return false; 
                           
         }
       return true;
               
         }