﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODS1010.aspx.vb" Inherits="Program_ODS1010_ODS1010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
     <script language="JavaScript">
        if (navigator.appName.indexOf('Internet Explorer') != -1)
        {
	        document.onmousedown = noSourceExplorer;
        }

            function noSourceExplorer()
            {
	            if (event.button == 2 | event.button == 3)
	            {
	                if (confirm('是否列印?')) 
	                {
	                    window.print();
                    }
	            }
            }
    </script>
   <script language="JavaScript" type="text/javascript" src="ODS1010.js"></script> 
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <script language=javascript>alert('若無填報資料請選擇無該當')</script>
    <form id="form1" runat="server">
        <div>
            &nbsp;<asp:Label ID="Label17" runat="server" Font-Bold="True" ForeColor="Black" Text="流 程 狀 態"></asp:Label>
            <hr />
            <table border="2" cellpadding="2" cellspacing="2" style="width: 726px" id="tblflow">
                <tr>
                    <td bgcolor="khaki">
                        <asp:Label ID="Label5" runat="server" Font-Size="Small" ForeColor="Red" Text="ODS1010"></asp:Label></td>
                    <td style="font-size: 12pt; color: #000000">
                        <asp:Label ID="Label4" runat="server" Font-Bold="True" Font-Names="標楷體" Font-Size="Medium"
                            ForeColor="Red" Text="內部管理綜合報告表" Width="164px"></asp:Label></td>
                    <td bgcolor="khaki" style="width: 62px">
                        功 能：</td>
                    <td align="center" colspan="3">
                        &nbsp;&nbsp;
                        <asp:Button ID="BtnAdd" runat="server" Text="新  增" ValidationGroup="1" Visible="False" />&nbsp; &nbsp;<asp:Button ID="BtnNoCheck" runat="server" ForeColor="Red" Text="無該當" Visible="False" />
                        &nbsp;&nbsp;
                        <asp:Button ID="BtnMod" runat="server" Text="修  改" ValidationGroup="1" Visible="False" />
                        &nbsp;&nbsp;
                        <asp:Button ID="BtnDel" runat="server" Text="刪  除" Visible="False" />
                        &nbsp;&nbsp;
                    <asp:Button ID="BtnExport" runat="server" Text="匯 出 列 印" /></td>
                </tr>
                <tr>
                    <td bgcolor="khaki">
                        表單號碼：</td>
                    <td>
                        <asp:Label ID="lblDOCNO" runat="server" Font-Size="Medium" ForeColor="Red" Text="Label"></asp:Label></td>
                    <td bgcolor="khaki" style="color: #000000; width: 62px;">
                        狀 態：</td>
                    <td align="center" style="height: 30px">
                        <asp:TextBox ID="txt_status" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                        &nbsp;<asp:TextBox ID="txtDate" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki">
                        &nbsp;版 本:<span id="Label11" class="TBLHR" style="font-size: 9pt"></span></td>
                    <td align="center" style="height: 30px">
                        <asp:TextBox ID="txtVer" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="50px"></asp:TextBox></td>
                </tr>
                <tr>
                    <td bgcolor="khaki">
                        <span style="font-size: 9pt; font-family: 新細明體">單位</span>：</td>
                    <td align="center">
                        &nbsp;
                        <asp:TextBox ID="txt_Brno" runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>
                        &nbsp;&nbsp;
                        <asp:TextBox ID="txt_Brno_Name" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                            Width="70px"></asp:TextBox></td>
                    <td bgcolor="khaki" style="width: 62px">
                        填 報 人：</td>
                    <td align="center">
                        &nbsp;<asp:TextBox ID="txt_EmpID" runat="server" BackColor="#E0E0E0" BorderColor="White"
                            ReadOnly="True" Width="70px"></asp:TextBox>&nbsp; &nbsp;<asp:TextBox ID="txt_EmpName"
                                runat="server" BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                    </td>
                    <td bgcolor="khaki">
                        分 機：</td>
                    <td align="center">
                        &nbsp;<asp:TextBox ID="txt_Ext" runat="server" MaxLength="4" ValidationGroup="1"
                            Width="50px"></asp:TextBox></td>
                </tr>
                <tr>
                    <td bgcolor="khaki">
                        所屬年月：</td>
                    <td align="center">
                        &nbsp;
                        <asp:TextBox ID="txt_YYYMM" runat="server" BackColor="#E0E0E0" MaxLength="5" ReadOnly="True"
                            Width="70px"></asp:TextBox>
                    </td>
                    <td bgcolor="khaki" style="width: 62px">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;<br />
                        </td>
                    <td bgcolor="khaki">
                        <span style="font-size: 9pt; font-family: 新細明體">填報日期</span>:</td>
                    <td>
                        &nbsp;<asp:TextBox ID="txt_RecordDate" runat="server" BackColor="#E0E0E0" MaxLength="5"
                            ReadOnly="True" Width="70px"></asp:TextBox></td>
                </tr>
            </table>
            <hr />
            <asp:Label ID="Label18" runat="server" Font-Bold="True" Text="主 管 (負責人) 核 示"></asp:Label></div>
        <table border="2" cellpadding="2" cellspacing="2" style="width: 726px" id="tbls">
            <tr>
                <td bgcolor="khaki" style="height: 30px">
                    單位主管:</td>
                <td align="center" colspan="2" style="height: 30px">
                    &nbsp;<asp:TextBox ID="txtSign1" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="70px"></asp:TextBox>&nbsp; &nbsp;<asp:TextBox ID="txtSign1Name" runat="server"
                            BackColor="#E0E0E0" ReadOnly="True" Width="70px"></asp:TextBox></td>
                <td bgcolor="khaki" style="height: 30px">
                    簽 核 日:</td>
                <td align="center" style="height: 30px">
                    &nbsp;<asp:TextBox ID="txtSignDate1" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                        Width="100px"></asp:TextBox></td>
                <td bgcolor="khaki" style="height: 30px">
                    簽 核:</td>
                <td align="center" style="height: 30px">
                    &nbsp;&nbsp;
                </td>
            </tr>
            <tr>
                <td bgcolor="khaki" style="height: 64px">
                    批 示:</td>
                <td colspan="6" style="height: 64px">
                    &nbsp;<asp:TextBox ID="txtSignComment1" runat="server" BackColor="#E0E0E0" Height="50px"
                        ReadOnly="True" Width="620px"></asp:TextBox></td>
            </tr>
        </table>
        <hr />
        <asp:Label ID="Label16" runat="server" Font-Bold="True" Text="表 單 內 容"></asp:Label><br />
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    <!---  here --->
        <table  border="2" cellpadding="2" cellspacing="2" style="width:725px" id = "ODS1010table">
        
        
         <tr>
                <td  colspan="3" align="center">
        <asp:Label ID="Label12" runat="server" BorderStyle="None" Font-Size="Large" Text="內部管理綜合報告表" Font-Bold="True"></asp:Label>
                    &nbsp;
                </td>
                
               
            </tr>
            <tr>
                <td style="width: 880px" >
                    &nbsp;<asp:Label ID="Label13" runat="server" Text="人力資源處   台照"></asp:Label></td>
                <td style="width: 148px" >
                    &nbsp;</td>
                <td >
                    <asp:Label ID="Label14" runat="server" Text="固有號碼:"></asp:Label>&nbsp;
                    <asp:TextBox ID="txt_GoouNum" runat="server" Width="90px" ReadOnly="True"></asp:TextBox></td>
            </tr>
            <tr>
                <td style="width: 880px" >
        <asp:Label ID="Label1" runat="server" Text="單位:"></asp:Label>&nbsp;
                    <asp:TextBox ID="txt_Brno_2" runat="server" BackColor="White" Width="40px" ReadOnly="True"></asp:TextBox>
                    <asp:TextBox ID="txt_Brno_Name_2" runat="server" BackColor="White"
                        Width="90px" ReadOnly="True"></asp:TextBox></td>
                <td style="width: 148px" >
        <asp:Label ID="Label3" runat="server" Text="主管:"></asp:Label>&nbsp;&nbsp;
                    <asp:TextBox ID="txtSign1Name_2" runat="server" BackColor="White"
                        Width="100px"></asp:TextBox></td>
                <td >
        <asp:Label ID="Label7" runat="server" Text="報告人:"></asp:Label>&nbsp;&nbsp;
                    <asp:TextBox ID="txt_EmpName_2" runat="server" BackColor="White"
                        Width="100px" ReadOnly="True"></asp:TextBox></td>
            </tr>
            <tr align="center">
                <td bgcolor="khaki" style="width: 880px; height: 2px" >
                    項&nbsp; 目</td>
                <td bgcolor="khaki" style="width: 148px; height: 2px">
                    &nbsp; &nbsp;
                    <asp:Label ID="Label2" runat="server" BorderStyle="None" Font-Bold="False" Font-Size="Small"
                        Text="該當人員及具體內容"></asp:Label></td>
                <td bgcolor="khaki" style="height: 2px" >
                    <asp:Label ID="Label6" runat="server" BorderStyle="None" Font-Bold="False" Font-Size="Small"
                        Text="建議或改進意見"></asp:Label></td>
            </tr>
            <tr>
                <td bgcolor="khaki" style="width: 880px; height: 241px" rowspan="17" >
                    &nbsp;請選取項目:<br />
                    <asp:CheckBoxList ID="CheckBoxList1" runat="server" Height="464px">
                        <asp:ListItem Value="1.對員工之領導及輔導 ">1.對員工之領導及輔導 </asp:ListItem>
                        <asp:ListItem Value="2.對本行各方面之反應意見 ">2.對本行各方面之反應意見 </asp:ListItem>
                        <asp:ListItem Value="3.對人事管理之意見 ">3.對人事管理之意見</asp:ListItem>
                        <asp:ListItem Value="4.日常工作協調及執行情形 ">4.日常工作協調及執行情形</asp:ListItem>
                        <asp:ListItem Value="5.員工在職訓練辦理情形 ">5.員工在職訓練辦理情形</asp:ListItem>
                        <asp:ListItem>6.職務指派之執行情形</asp:ListItem>
                        <asp:ListItem>7.平常考核辦理情形 </asp:ListItem>
                        <asp:ListItem>8.員工服務態度之輔導 </asp:ListItem>
                        <asp:ListItem>9.員工勤惰之管理 </asp:ListItem>
                        <asp:ListItem>10.單位紀律之維護 </asp:ListItem>
                        <asp:ListItem>11.員工品德操守生活之考核輔導 </asp:ListItem>
                        <asp:ListItem>12.與客戶、朋友之交往情形 </asp:ListItem>
                        <asp:ListItem>13.金錢往來情形 </asp:ListItem>
                        <asp:ListItem>14.員工士氣 </asp:ListItem>
                        <asp:ListItem>15.行內風氣 </asp:ListItem>
                        <asp:ListItem>16.行舍周圍及內部環境衛生安全防護 </asp:ListItem>
                        <asp:ListItem>17.其他內部管理綜合意見 </asp:ListItem>
                    </asp:CheckBoxList></td>
                <td rowspan="17" style="width: 148px; height: 241px">
                    <asp:TextBox ID="txtContent1" runat="server" Height="496px" TextMode="MultiLine"
                        Width="215px"></asp:TextBox>
                    &nbsp;&nbsp;</td>
                <td  rowspan="17" style="height: 241px">
                    <asp:TextBox ID="txtImprove" runat="server" Height="496px" TextMode="MultiLine" Width="215px"></asp:TextBox></td>
            </tr>
            <tr>
                
            </tr>
             <tr>
                
            </tr>
             <tr>
               
            </tr>
             <tr>
               
            </tr>
             <tr>
               
            </tr>
             <tr>
               
            </tr>
             <tr>
               
            </tr>
             <tr>
               
            </tr>
             <tr>
              
            </tr>
             <tr>
             
            </tr>
             <tr>
               
            </tr>
             <tr>
             
            </tr>
             <tr>
              
            </tr>
             <tr>
               
            </tr>
             <tr>
               
            </tr>
             <tr>
              
            </tr>
              <tr>
                <td style="width: 230px" colspan="3">
                    &nbsp;</td>
              
            </tr>
              <tr>
                <td style="width: 230px" colspan="3">
        </td>
             
            </tr>
        </table>
       
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <br />
        <asp:HiddenField ID="hidn_EMPID" runat="server" />
        <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM tblLogDetail WHERE (DocNo = @DocNo1) and (DocType = 'DS')"
            InsertCommand="INSERT INTO [tblLogDetail] ([DocType], [DocNo], [BrNo], [EmpId], [RecordDate], [DataFlag], [FormType], [YYMM], [Sign1], [Action1], [SignDate1], [SignComment1], [Sign2], [Action2], [SignDate2], [SignComment2], [DecManager], [DecDate], [FlowStatus], [Ver]) VALUES (@DocType, @DocNo, @BrNo, @EmpId, @RecordDate, @DataFlag, @FormType, @YYMM, @Sign1, @Action1, @SignDate1, @SignComment1, @Sign2, @Action2, @SignDate2, @SignComment2, @DecManager, @DecDate, @FlowStatus, @Ver)"
            SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
            UpdateCommand="UPDATE [tblLogDetail] SET [EmpId] = @EmpId, [RecordDate] = @RecordDate, [DataFlag] = @DataFlag, [Sign1] = @Sign1, [Action1] = @Action1, [SignDate1] = @SignDate1, [SignComment1] = @SignComment1,  [DecManager] = @DecManager, [DecDate] = @DecDate, [FlowStatus] = @FlowStatus, [Ver] = @Ver WHERE [DocNo] = @DocNo">
            <InsertParameters>
                <asp:Parameter DefaultValue="" Name="DocType" Type="String" />
                <asp:Parameter DefaultValue="" Name="DocNo" Type="String" />
                <asp:Parameter Name="BrNo" Type="String" />
                <asp:Parameter Name="EmpId" Type="String" />
                <asp:Parameter DefaultValue="" Name="RecordDate" Type="DateTime" />
                <asp:Parameter DefaultValue="" Name="DataFlag" Type="String" />
                <asp:Parameter Name="FormType" Type="String" />
                <asp:Parameter Name="YYMM" Type="String" />
                <asp:Parameter Name="Sign1" Type="String" />
                <asp:Parameter Name="Action1" Type="String" />
                <asp:Parameter Name="SignDate1" Type="DateTime" />
                <asp:Parameter Name="SignComment1" Type="String" />
                <asp:Parameter Name="Sign2" Type="String" />
                <asp:Parameter Name="Action2" Type="String" />
                <asp:Parameter Name="SignDate2" Type="DateTime" />
                <asp:Parameter Name="SignComment2" Type="String" />
                <asp:Parameter Name="DecManager" Type="String" />
                <asp:Parameter Name="DecDate" Type="DateTime" />
                <asp:Parameter Name="FlowStatus" Type="String" />
                <asp:Parameter Name="Ver" Type="Int16" />
            </InsertParameters>
            <DeleteParameters>
                <asp:Parameter Name="DocNo1" />
            </DeleteParameters>
            <SelectParameters>
                <asp:Parameter Name="DocNo" />
            </SelectParameters>
            <UpdateParameters>
                <asp:Parameter Name="EmpId" />
                <asp:Parameter Name="RecordDate" />
                <asp:Parameter Name="DataFlag" />
                <asp:Parameter Name="Sign1" />
                <asp:Parameter Name="Action1" />
                <asp:Parameter Name="SignDate1" />
                <asp:Parameter Name="SignComment1" />
                <asp:Parameter Name="DecManager" />
                <asp:Parameter Name="DecDate" />
                <asp:Parameter Name="FlowStatus" />
                <asp:Parameter Name="Ver" />
                <asp:Parameter Name="DocNo" />
            </UpdateParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblSysCode" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT TblId, TblCd, TblDesc, TblSeq FROM tblSysCode WHERE (TblId = '11') AND (TblCd =@TblCd  )">
            <SelectParameters>
                <asp:Parameter Name="TblCd" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_BRANCH" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT BRNO, BRNAME FROM chb_pub.dbo.BRANCH WHERE (BRNO = @gBrNo)">
            <SelectParameters>
                <asp:FormParameter FormField="gBrNo" Name="gBrNo" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_EMPLOYEE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
            SelectCommand="SELECT STAFF, NAME FROM chb_pub.dbo.EMPLOYEE WHERE (STAFF = @gEmpId)">
            <SelectParameters>
                <asp:FormParameter FormField="gEmpId" Name="gEmpId" />
            </SelectParameters>
        </asp:SqlDataSource>
        &nbsp;&nbsp;&nbsp;&nbsp;<br />
        <asp:SqlDataSource ID="DS_tblIntraMgrRpt" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            DeleteCommand="DELETE FROM [tblIntraMgrRpt] WHERE [DocNo] = @DocNo" InsertCommand="INSERT INTO [tblIntraMgrRpt] ([DocNo], [Brno], [BRName], [EmpId], [EmpName], [Ext], [YYYMM], [SN], [Brno_2], [Brno_Name_2], [Sign1Name_2], [EmpName_2], [Content1], [Improve],[Item]) VALUES (@DocNo, @Brno, @BRName, @EmpId, @EmpName, @Ext, @YYYMM, @SN, @Brno_2, @Brno_Name_2, @Sign1Name_2, @EmpName_2, @Content1, @Improve,@Item)"
            SelectCommand="SELECT * FROM [tblIntraMgrRpt]" UpdateCommand="UPDATE [tblIntraMgrRpt] SET [Brno] = @Brno, [BRName] = @BRName, [EmpId] = @EmpId, [EmpName] = @EmpName, [Ext] = @Ext, [YYYMM] = @YYYMM, [SN] = @SN, [Brno_2] = @Brno_2, [Brno_Name_2] = @Brno_Name_2, [Sign1Name_2] = @Sign1Name_2, [EmpName_2] = @EmpName_2, [Content1] = @Content1, [Improve] = @Improve, [Item] = @Item WHERE [DocNo] = @DocNo">
            <DeleteParameters>
                <asp:Parameter Name="DocNo" Type="String" />
            </DeleteParameters>
            <UpdateParameters>
                <asp:Parameter Name="Brno" Type="String" />
                <asp:Parameter Name="BRName" Type="String" />
                <asp:Parameter Name="EmpId" Type="String" />
                <asp:Parameter Name="EmpName" Type="String" />
                <asp:Parameter Name="Ext" Type="String" />
                <asp:Parameter Name="YYYMM" Type="String" />
                <asp:Parameter Name="SN" Type="String" />
                <asp:Parameter Name="Brno_2" Type="String" />
                <asp:Parameter Name="Brno_Name_2" Type="String" />
                <asp:Parameter Name="Sign1Name_2" Type="String" />
                <asp:Parameter Name="EmpName_2" Type="String" />
                <asp:Parameter Name="Content1" Type="String" />
                <asp:Parameter Name="Improve" Type="String" />
                <asp:Parameter Name="Item" />
                <asp:Parameter Name="DocNo" Type="String" />
            </UpdateParameters>
            <InsertParameters>
                <asp:Parameter Name="DocNo" Type="String" />
                <asp:Parameter Name="Brno" Type="String" />
                <asp:Parameter Name="BRName" Type="String" />
                <asp:Parameter Name="EmpId" Type="String" />
                <asp:Parameter Name="EmpName" Type="String" />
                <asp:Parameter Name="Ext" Type="String" />
                <asp:Parameter Name="YYYMM" Type="String" />
                <asp:Parameter Name="SN" Type="String" />
                <asp:Parameter Name="Brno_2" Type="String" />
                <asp:Parameter Name="Brno_Name_2" Type="String" />
                <asp:Parameter Name="Sign1Name_2" Type="String" />
                <asp:Parameter Name="EmpName_2" Type="String" />
                <asp:Parameter Name="Content1" Type="String" />
                <asp:Parameter Name="Improve" Type="String" />
                <asp:Parameter Name="Item" />
            </InsertParameters>
        </asp:SqlDataSource>
        <br />
        <asp:SqlDataSource ID="DS_GoouNum" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
            SelectCommand="SELECT [GoouNum] FROM [tblGoouNum] where Brno =@Brno&#13;&#10;">
            <SelectParameters>
                <asp:Parameter Name="Brno" />
            </SelectParameters>
        </asp:SqlDataSource>
        <br />
        <asp:SqlDataSource ID="DS_EMPLOYEE2" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
            SelectCommand="SELECT COUNT(*) AS count FROM EMPLOYEE WHERE (JOBCODE IN ('721600', '713000', '812000', '190410', '513000')) AND (BRNO = @BRNO) AND (STAFF = @STAFF)">
            <SelectParameters>
                <asp:Parameter Name="BRNO" />
                <asp:Parameter Name="STAFF" />
            </SelectParameters>
        </asp:SqlDataSource>
        <asp:SqlDataSource ID="DS_tblIntraMgrMan" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
            SelectCommand="SELECT COUNT(*) AS count FROM tblIntraMgrMan WHERE (Brno = @Brno) AND (IntraMgrID = @IntraMgrID)">
            <SelectParameters>
                <asp:Parameter Name="Brno" />
                <asp:Parameter Name="IntraMgrID" />
            </SelectParameters>
        </asp:SqlDataSource>
        <br />
        <asp:HiddenField ID="Hid_sele" runat="server" />
        <br />
    </form>
</body>
</html>



