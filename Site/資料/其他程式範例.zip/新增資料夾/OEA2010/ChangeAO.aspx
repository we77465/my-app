﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ChangeAO.aspx.cs" Inherits="Program_OEA2010_ChangeAO" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head id="Head1" runat="server">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="../Common/css/Common.css"  /> 
    <title>未命名頁面</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <br />
        &nbsp;&nbsp;<asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False"
            CellPadding="4" DataSourceID="ChangeAO" ForeColor="#333333" GridLines="None">
            <FooterStyle BackColor="#990000" Font-Bold="True" ForeColor="White" />
            <RowStyle BackColor="#FFFBD6" ForeColor="#333333" />
            <Columns>
                <asp:BoundField DataField="Cmpid" HeaderText="統一編號" SortExpression="Cmpid">
                    <HeaderStyle Wrap="False" />
                    <ItemStyle Wrap="False" />
                </asp:BoundField>
                <asp:BoundField DataField="AOName" HeaderText="AO" SortExpression="AOName">
                    <HeaderStyle Wrap="False" />
                    <ItemStyle Wrap="False" />
                </asp:BoundField>
                <asp:BoundField DataField="ChangeDate" HeaderText="修改日期" SortExpression="ChangeDate">
                    <HeaderStyle Wrap="False" />
                    <ItemStyle Wrap="False" />
                </asp:BoundField>
            </Columns>
            <PagerStyle BackColor="#FFCC66" ForeColor="#333333" HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="#FFCC66" Font-Bold="True" ForeColor="Navy" />
            <HeaderStyle BackColor="#990000" Font-Bold="True" ForeColor="White" />
            <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        <br />
        &nbsp;<asp:Button ID="btnSave" runat="server" Text="關閉視窗" Width="90px" OnClick="btnSave_Click" /></div>
        <asp:SqlDataSource ID="ChangeAO" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
        DeleteCommand="delete from tblLoanRateAO where  DOCNO=@DOCNO" 
        InsertCommand="insert into tblLoanRateAO (DOCNO,BRNO,Cmpid,ChangeDate,AO,AOName) values(@DOCNO,@BRNO,@Cmpid,@ChangeDate,@AO,@AOName)" 
        SelectCommand="select distinct * from tblLoanRateAO where Cmpid=@Cmpid">
            <SelectParameters>
                <asp:Parameter Name="Cmpid" />
            </SelectParameters>
            <DeleteParameters>
                <asp:Parameter Name="DOCNO" />
            </DeleteParameters>
            <InsertParameters>
                <asp:Parameter Name="DOCNO" />
                <asp:Parameter Name="BRNO" />
                <asp:Parameter Name="Cmpid" />
                <asp:Parameter Name="ChangeDate" />
                <asp:Parameter Name="AO" />
                <asp:Parameter Name="AOName" />
            </InsertParameters>
        </asp:SqlDataSource>
    </form>
</body>
</html>
