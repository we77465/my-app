﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.VisualBasic;
using System.IO;
using DataAccessLayer.DALC;

public partial class Program_OEA2010_ChangeAO : System.Web.UI.Page
{
    String strCmpid, strDOCNO;
    protected void Page_Load(object sender, EventArgs e)
    {
        strCmpid = Request.QueryString["Cmpid"].ToString();
        ChangeAO.SelectParameters["Cmpid"].DefaultValue = strCmpid.ToString();
        GridView1.DataBind();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.opener=null;window.close();</script>");
    }
}
