﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Collections.Specialized;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.VisualBasic;
using System.IO;
using DataAccessLayer.DALC;

public partial class Program_OEA2010_OEA2020 : System.Web.UI.Page
{
    DataSet ds = new DataSet();
    Int32 index = 0;
    String strBRNO = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        using (Bussiness buss = new Bussiness())
        {
            ds = buss.select("select a.BRNO,b.BRNAME,a.CmpName,a.Cmpid from tblLoanRate as a inner join"+
                " chb_pub..BRANCH as b on a.BRNO=b.BRNO where Chk='Y' ", chb_eform.ConnectionString);
        }
        if (ds.Tables[0].Rows.Count == 0)
            lblMsg.Text = "無資料";
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            SqlDataSource datasource = (SqlDataSource)e.Row.FindControl("Detail");
            datasource.SelectParameters["BRNO"].DefaultValue = e.Row.Cells[0].Text;
            datasource.SelectParameters["Cmpid"].DefaultValue = e.Row.Cells[3].Text;
            ViewState["BRNO"] = e.Row.Cells[0].Text;
            ViewState["Row"] = e.Row.RowIndex;
        }
    }
    protected void GridView2_Add(object sender, System.Web.UI.WebControls.CommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            String strCmpid = e.CommandArgument.ToString();
            ViewState["Cmpid"] = strCmpid.ToString();
            DataControlFieldCell controlParent = (DataControlFieldCell)((Button)sender).Parent;
            SqlDataSource datasource = (SqlDataSource)controlParent.FindControl("SqlDataSource1");
            
            datasource.InsertParameters["BRNO"].DefaultValue = ViewState["BRNO"].ToString();
            datasource.InsertParameters["Cmpid"].DefaultValue = strCmpid;
            datasource.Insert();
            
            GridView gridview = (GridView)controlParent.FindControl("GridView2");
            gridview.EditIndex = gridview.Rows.Count;
            gridview.DataBind();
        }
    }
    protected void GridView2_Save(object sender, System.Web.UI.WebControls.CommandEventArgs e)
    {
        if (e.CommandName == "Save")
        {
            DataControlFieldCell controlParent = (DataControlFieldCell)((Button)sender).Parent;
            SqlDataSource datasource = (SqlDataSource)controlParent.FindControl("Detail");
            
            GridView GVR = (GridView)controlParent.FindControl("GridView2");
            datasource.DeleteParameters["BRNO"].DefaultValue = ViewState["BRNO"].ToString();
            datasource.DeleteParameters["Cmpid"].DefaultValue = ViewState["Cmpid"].ToString();
            datasource.Delete();
            for (int i = 0; i < GVR.Rows.Count; i++)
            {
                TextBox Date = (TextBox)GVR.Rows[i].FindControl("txtDate");
                TextBox Process = (TextBox)GVR.Rows[i].FindControl("txtProcess");
               
                datasource.InsertParameters["BRNO"].DefaultValue = ViewState["BRNO"].ToString();
                datasource.InsertParameters["Cmpid"].DefaultValue = ViewState["Cmpid"].ToString();
                datasource.InsertParameters["Date"].DefaultValue = Date.Text.Trim();
                datasource.InsertParameters["Process"].DefaultValue = Process.Text.Trim();
                datasource.Insert();
                //Response.Write(Date.Text);
            }
        }
    }
}
