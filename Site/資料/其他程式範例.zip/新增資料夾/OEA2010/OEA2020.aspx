﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="OEA2020.aspx.cs" Inherits="Program_OEA2010_OEA2020" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head id="Head1" runat="server">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <script language="JavaScript" type="text/javascript" src="..\Common\js\Numeric.js"></script>
    <script language="JavaScript" type="text/javascript" src="..\Common\js\Other.js"></script>
    <link rel="stylesheet" type="text/css" href="../Common/css/Common.css"  /> 
    <title>未命名頁面</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <br />
        <asp:Label ID="lblMsg" runat="server" Text="" Width="320px" Font-Bold="true"></asp:Label><br />
        <asp:GridView ID="GridView1" runat="server" CellPadding="4" ForeColor="#333333" 
        GridLines="None" AutoGenerateColumns="False" DataSourceID="chb_eform" OnRowDataBound="GridView1_RowDataBound">
            <RowStyle BackColor="#FFFBD6" ForeColor="#333333" Font-Size="Small" />
            <Columns>
                <asp:BoundField DataField="BRNO" HeaderText="分行代號" SortExpression="BRNO" />
                <asp:BoundField DataField="BRNAME" HeaderText="分行名稱" SortExpression="BRNAME" />
                <asp:BoundField DataField="CmpName" HeaderText="客戶名稱" SortExpression="CmpName" />
                <asp:BoundField DataField="Cmpid" HeaderText="統一編號" SortExpression="Cmpid" />
                <asp:TemplateField HeaderText="處理進度">
                    <ItemTemplate>
                        <asp:GridView ID="GridView2" runat="server" CellPadding="4" ForeColor="Black" GridLines="Horizontal" AutoGenerateColumns="False" 
                             DataSourceID="Detail" BackColor="White" BorderColor="#CCCCCC" BorderStyle="None" BorderWidth="1px" >
                            <FooterStyle BackColor="#CCCC99" ForeColor="Black" />
                            <PagerStyle BackColor="White" ForeColor="Black" HorizontalAlign="Right" />
                            <SelectedRowStyle BackColor="#CC3333" Font-Bold="True" ForeColor="White" />
                            <HeaderStyle BackColor="#333333" Font-Bold="True" ForeColor="White" Font-Size="Small" />
                            <Columns>
                                <asp:TemplateField HeaderText="日期" SortExpression="Date">
                                    <ItemTemplate>
                                        <asp:TextBox ID="txtDate" runat="server" Text='<%# Bind("Date") %>' Width="80px"></asp:TextBox>
                                    </ItemTemplate>
                                    
                                </asp:TemplateField>
                                <asp:TemplateField HeaderText="處理進度" SortExpression="Process">
                                    <ItemTemplate>
                                        <asp:TextBox ID="txtProcess" runat="server" Text='<%# Bind("Process") %>' Width="245px"></asp:TextBox>
                                    </ItemTemplate>
                                </asp:TemplateField>
                                <asp:TemplateField HeaderText="經辦員">
                                    <HeaderStyle Wrap="False" />
                                    <ItemTemplate>
                                        <asp:TextBox ID="txtEmpName" runat="server" Text='<%# Bind("EmpName") %>' Width="100px"></asp:TextBox>
                                    </ItemTemplate>
                                </asp:TemplateField>
                            </Columns>
                            <RowStyle Font-Size="Small" />
                            <EditRowStyle Font-Size="Small" />
                            <EmptyDataRowStyle Font-Size="Small" />
                            <AlternatingRowStyle Font-Size="Small" />
                        </asp:GridView>
                        <asp:Button ID="btnAdd" runat="server" OnCommand="GridView2_Add" Text="新增" CommandName="Add" CommandArgument='<%#DataBinder.Eval(Container.DataItem,"Cmpid")%>'></asp:Button>
                        <asp:Button ID="btnSave" runat="server" OnCommand="GridView2_Save" Text="儲存" CommandName="Save" CommandArgument='<%#DataBinder.Eval(Container.DataItem,"Cmpid")%>'/>
                        <asp:SqlDataSource ID="Detail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
                            SelectCommand="select Date,Process,EmpName from tblLoanRateDetail where BRNO=@BRNO and Cmpid=@Cmpid" 
                            InsertCommand="insert into tblLoanRateDetail (BRNO,Cmpid,Date,Process) values (@BRNO,@Cmpid,@Date,@Process)" 
                            UpdateCommand="update tblLoanRateDetail set Date=@Date, Process=@Process where Cmpid=@Cmpid"
                            DeleteCommand="delete from tblLoanRateDetail where BRNO=@BRNO and Cmpid=@Cmpid" >
                            <SelectParameters>
                                <asp:Parameter Name="BRNO" />
                                <asp:Parameter Name="Cmpid" />
                            </SelectParameters>
                            <InsertParameters>
                                <asp:Parameter Name="BRNO" />
                                <asp:Parameter Name="Cmpid" />
                                <asp:Parameter Name="Date" />
                                <asp:Parameter Name="Process" />
                            </InsertParameters>
                            <UpdateParameters>
                                <asp:Parameter Name="Date" />
                                <asp:Parameter Name="Process" />
                                <asp:Parameter Name="Cmpid" />
                            </UpdateParameters>
                            <DeleteParameters>
                                <asp:Parameter Name="BRNO" />
                                <asp:Parameter Name="Cmpid" />
                            </DeleteParameters>
                        </asp:SqlDataSource><asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
                            SelectCommand="select Date,Process,EmpName from tblLoanRateDetail where BRNO=@BRNO and Cmpid=@Cmpid" 
                            InsertCommand="insert into tblLoanRateDetail (BRNO,Cmpid) values (@BRNO,@Cmpid)" 
                            UpdateCommand="update tblLoanRateDetail set Date=@Date, Process=@Process where Cmpid=@Cmpid"
                            DeleteCommand="delete from tblLoanRateDetail where BRNO=@BRNO and Cmpid=@Cmpid" >
                            <SelectParameters>
                                <asp:Parameter Name="BRNO" />
                                <asp:Parameter Name="Cmpid" />
                            </SelectParameters>
                            <InsertParameters>
                                <asp:Parameter Name="BRNO" />
                                <asp:Parameter Name="Cmpid" />
                            </InsertParameters>
                            <UpdateParameters>
                                <asp:Parameter Name="Date" />
                                <asp:Parameter Name="Process" />
                                <asp:Parameter Name="Cmpid" />
                            </UpdateParameters>
                            <DeleteParameters>
                                <asp:Parameter Name="BRNO" />
                                <asp:Parameter Name="Cmpid" />
                            </DeleteParameters>
                        </asp:SqlDataSource>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
            <PagerStyle BackColor="#FFCC66" ForeColor="#333333" HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="#FFCC66" Font-Bold="True" ForeColor="Navy" />
            <HeaderStyle BackColor="#990000" Font-Bold="True" ForeColor="White" Font-Size="Small" />
            <AlternatingRowStyle BackColor="White" Font-Size="Small" />
            <FooterStyle Font-Size="Small" />
            <EmptyDataRowStyle Font-Size="Small" />
            <EditRowStyle Font-Size="Small" />
        </asp:GridView>
        &nbsp;</div>
        <asp:SqlDataSource ID="chb_eform" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
        SelectCommand="select a.BRNO,b.BRNAME,a.CmpName,a.Cmpid  from  tblLoanRate as a  inner  join  chb_pub..BRANCH as b  on  a.BRNO=b.BRNO where  Chk='Y' "></asp:SqlDataSource>
    </form>
</body>
</html>
