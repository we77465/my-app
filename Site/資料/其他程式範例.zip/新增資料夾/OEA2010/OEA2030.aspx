﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="OEA2030.aspx.cs" Inherits="Program_OEA2010_OEA2030" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head id="Head1" runat="server">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="../Common/css/Common.css"  /> 
    <title>未命名頁面</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    <center>
        <asp:Label ID="txtMon1" runat="server" Width="90px" Text="09706"></asp:Label>~
        <asp:Label ID="txtMon2" runat="server" Width="90px" Text="09712"></asp:Label></center>
        <center>
        <%--<asp:Button ID="btnQuery" runat="server" Text="查  詢" OnClick="btnQuery_Click" /><br />--%>
        <br />
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" CellPadding="4" DataSourceID="chb_eform" ForeColor="#333333" GridLines="None">
            <FooterStyle BackColor="#990000" Font-Bold="True" ForeColor="White" />
            <RowStyle BackColor="#FFFBD6" ForeColor="#333333" />
            <Columns>
                <asp:BoundField DataField="BRNO" HeaderText="分行代號" SortExpression="BRNO" />
                <asp:BoundField DataField="BRNAME" HeaderText="分行名稱" SortExpression="BRNAME" />
                <asp:BoundField DataField="count" HeaderText="填報戶數" ReadOnly="True" SortExpression="count" />
            </Columns>
            <PagerStyle BackColor="#FFCC66" ForeColor="#333333" HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="#FFCC66" Font-Bold="True" ForeColor="Navy" />
            <HeaderStyle BackColor="#990000" Font-Bold="True" ForeColor="White" />
            <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        &nbsp;&nbsp;
        </center>
    </div>
        <asp:SqlDataSource ID="chb_eform" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
        SelectCommand="select x.BRNO , y.BRNAME, x.count from(SELECT  COUNT(*) AS count,BRNO FROM  tblLoanRate GROUP BY BRNO)as x inner join chb_pub..BRANCH as y on x.BRNO=y.BRNO order by x.BRNO"></asp:SqlDataSource>
    </form>
</body>
</html>
