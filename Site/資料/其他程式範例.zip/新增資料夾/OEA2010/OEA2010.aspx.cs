﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.VisualBasic;
using System.IO;
using DataAccessLayer.DALC;

public partial class Program_OEA2010_OEA2010Qform : System.Web.UI.Page
{
    DataSet ds = new DataSet();
    string strYYMMS, strYYMME, strSQL;
    protected void Page_Load(object sender, EventArgs e)
    {
        int intYYMM = int.Parse(txtYYMM2.Text.Trim().Substring(0, 3)) + 1911;
        strYYMMS = intYYMM.ToString() + txtYYMM1.Text.Trim().Substring(3, 2);
        strYYMME = intYYMM.ToString() + txtYYMM2.Text.Trim().Substring(3, 2);

        GridView1.Columns[7].HeaderText = "97年" + txtYYMM1.Text.Substring(3, 2).TrimStart('0') + "月平均動用率";
        GridView1.Columns[8].HeaderText = "97年" + txtYYMM2.Text.Substring(3, 2).TrimStart('0') + "月平均動用率";
        GridView1.Columns[9].HeaderText = "97年9月平均動用率";
        GridView1.Columns[10].HeaderText = "97年10月平均動用率";
        GridView1.Columns[11].HeaderText = "97年11月平均動用率";
        GridView1.Columns[12].HeaderText = "97年12月平均動用率";
        GridView1.Columns[13].HeaderText = txtYYMM1.Text.Substring(3, 2).TrimStart('0') + "月分行處理情形及執行瓶頸";
        GridView1.Columns[14].HeaderText = txtYYMM2.Text.Substring(3, 2).TrimStart('0') + "月分行處理情形及執行瓶頸"; ;
        GridView1.Columns[15].HeaderText = "9月分行處理情形及執行瓶頸";
        GridView1.Columns[16].HeaderText = "10月分行處理情形及執行瓶頸";
        GridView1.Columns[17].HeaderText = "11月分行處理情形及執行瓶頸";
        GridView1.Columns[18].HeaderText = "12月分行處理情形及執行瓶頸";
    }

    protected void btnNext_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < this.GridView1.Rows.Count; i++)
        {
            CheckBox Chk = this.GridView1.Rows[i].FindControl("Chk") as CheckBox;
            Label BRNO = this.GridView1.Rows[i].FindControl("txtBRNO") as Label;
            Label Cmpid = this.GridView1.Rows[i].FindControl("txtCmpid") as Label;
            if (Chk.Checked)
            {
                chb_eform.UpdateParameters["Chk"].DefaultValue = "Y";
                chb_eform.UpdateParameters["BRNO"].DefaultValue = BRNO.Text.Trim();
                chb_eform.UpdateParameters["Cmpid"].DefaultValue = Cmpid.Text.Trim();
                chb_eform.Update();
            }
            else
            {
                chb_eform.UpdateParameters["Chk"].DefaultValue = "";
                chb_eform.UpdateParameters["BRNO"].DefaultValue = BRNO.Text.Trim();
                chb_eform.UpdateParameters["Cmpid"].DefaultValue = Cmpid.Text.Trim();
                chb_eform.Update();
            }
        }
        Response.Redirect("OEA2020.aspx");
    }
    protected void btnExcel_Click(object sender, EventArgs e)
    {
        //Response.Write("a"); Response.End();
        for (int i = 0; i < this.GridView1.Rows.Count; i++)
        {
            CheckBox Chk = this.GridView1.Rows[i].FindControl("Chk") as CheckBox;
            Label BRNO = this.GridView1.Rows[i].FindControl("txtBRNO") as Label;
            Label Cmpid = this.GridView1.Rows[i].FindControl("txtCmpid") as Label;
            if (Chk.Checked)
            {
                chb_eform.UpdateParameters["Chk"].DefaultValue = "Y";
                chb_eform.UpdateParameters["BRNO"].DefaultValue = BRNO.Text.Trim();
                chb_eform.UpdateParameters["Cmpid"].DefaultValue = Cmpid.Text.Trim();
                chb_eform.Update();
            }
            else
            {
                chb_eform.UpdateParameters["Chk"].DefaultValue = "";
                chb_eform.UpdateParameters["BRNO"].DefaultValue = BRNO.Text.Trim();
                chb_eform.UpdateParameters["Cmpid"].DefaultValue = Cmpid.Text.Trim();
                chb_eform.Update();
            }
        }

        GridView gvExcel = new GridView();
        Response.Clear();
        Response.AddHeader("content-disposition", "attachment;filename=Excel.xls");
        Response.ContentType = "application/vnd.xls";
        System.IO.StringWriter sw = new System.IO.StringWriter();
        System.Web.UI.HtmlTextWriter htw = new HtmlTextWriter(sw);
        //解決亂碼問題
        Response.Write("<meta http-equiv='Content-Type'; content='text/html';charset='utf-8'>");
        gvExcel.AllowPaging = false;
        using (Bussiness buss = new Bussiness())
        {
            strSQL = "SELECT a.BRNO,b.BRNAME,a.CmpName,a.Cmpid,a.EmpName,b.Rate6*100 as Rate6,b.Rate7*100 as Rate7," +
                " b.Rate9*100 as Rate9,b.Rate10*100 as Rate10,b.Rate11*100 as Rate11,b.Rate12*100 as Rate12,a.P7,a.P8,a.P9,a.P10,a.P11,a.P12,(b.Rate7*100-b.Rate6*100) AS RateX," +
                " (b.LoanAmt7-b.LoanAmt6)as LoanAmt,a.C1, a.C2, a.C3,a.C4, a.C5, a.C6, a.C7, a.C8, a.C9, a.C10, a.C11,a.H1,a.H2" +
                " FROM tblLoanRate AS a INNER JOIN" +
                " (SELECT BRNO, BRNAME, Cmpid, " +
                " SUM(CASE YYMM WHEN '200807' THEN Rate6 ELSE 0 END) AS Rate6," +
                " SUM(CASE YYMM WHEN '200808' THEN Rate6 ELSE 0 END) AS Rate7," +
                " SUM(CASE YYMM WHEN '200809' THEN Rate6 ELSE 0 END) AS Rate9," +
                " SUM(CASE YYMM WHEN '200810' THEN Rate6 ELSE 0 END) AS Rate10," +
                " SUM(CASE YYMM WHEN '200811' THEN Rate6 ELSE 0 END) AS Rate11," +
                " SUM(CASE YYMM WHEN '200812' THEN Rate6 ELSE 0 END) AS Rate12," +
                " SUM(CASE YYMM WHEN '" + strYYMMS + "' THEN LoanAmt ELSE 0 END) AS LoanAmt6," +
                " SUM(CASE YYMM WHEN '" + strYYMME + "' THEN LoanAmt ELSE 0 END) AS LoanAmt7 " +
                " FROM tblLoanRate02 WHERE (YYMM<='200812' or YYMM>='200806')" +
                " GROUP BY BRNO, BRNAME, Cmpid) AS b " +
                " ON a.BRNO = b.BRNO AND a.Cmpid = b.Cmpid WHERE (a.Rate <= 50) AND a.Chk='Y'";
            ds = buss.select(strSQL, chb_eform.ConnectionString);
        }

        if (ds.Tables[0].Rows.Count > 0)
        {
            ds.Tables[0].Columns[0].ColumnName = "分行代號";
            ds.Tables[0].Columns[1].ColumnName = "分行名稱";
            ds.Tables[0].Columns[2].ColumnName = "客戶名稱";
            ds.Tables[0].Columns[3].ColumnName = "客戶統編";
            ds.Tables[0].Columns[4].ColumnName = "AO";
            ds.Tables[0].Columns[5].ColumnName = "97年" + txtYYMM1.Text.Substring(3, 2).TrimStart('0') + "月平均動用率";
            ds.Tables[0].Columns[6].ColumnName = "97年" + txtYYMM2.Text.Substring(3, 2).TrimStart('0') + "月平均動用率";
            ds.Tables[0].Columns[7].ColumnName = "97年9月平均動用率";
            ds.Tables[0].Columns[8].ColumnName = "97年10月平均動用率";
            ds.Tables[0].Columns[9].ColumnName = "97年11月平均動用率";
            ds.Tables[0].Columns[10].ColumnName = "97年12月平均動用率";
            ds.Tables[0].Columns[11].ColumnName = txtYYMM1.Text.Substring(3, 2).TrimStart('0') + "月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[12].ColumnName = txtYYMM2.Text.Substring(3, 2).TrimStart('0') + "月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[13].ColumnName = "97年9月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[14].ColumnName = "97年10月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[15].ColumnName = "97年11月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[16].ColumnName = "97年12月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[17].ColumnName = "成長or衰退";
            ds.Tables[0].Columns[18].ColumnName = "成長餘額";
            ds.Tables[0].Columns[30].ColumnName = "已結案";
            ds.Tables[0].Columns[31].ColumnName = "處理中";
            gvExcel.DataSource = ds;
            gvExcel.DataBind();
        }
        HtmlForm hf = new HtmlForm();
        Controls.Add(hf);
        hf.Controls.Add(gvExcel);
        hf.RenderControl(htw);
        Response.Write(sw.ToString());
        Response.End();
    }

    protected void btnAllExcel_Click(object sender, EventArgs e)
    {
        //Response.Clear();
        //Response.AddHeader("content-disposition", "attachment;filename=AllExcel.xls");
        //Response.ContentType = "application/vnd.xls";
        //System.IO.StringWriter sw = new System.IO.StringWriter();
        //System.Web.UI.HtmlTextWriter htw = new HtmlTextWriter(sw);
        //GridView1.Columns[0].Visible = GridView1.Columns[13].Visible = false;
        //HtmlForm hf = new HtmlForm();
        //Controls.Add(hf);
        //hf.Controls.Add(GridView1);
        //hf.RenderControl(htw);
        //Response.Write(sw.ToString());
        //Response.End();

        GridView gvExcel = new GridView();
        Response.Clear();
        Response.AddHeader("content-disposition", "attachment;filename=AllExcel.xls");
        Response.ContentType = "application/vnd.xls";
        System.IO.StringWriter sw = new System.IO.StringWriter();
        System.Web.UI.HtmlTextWriter htw = new HtmlTextWriter(sw);
        //解決亂碼問題
        Response.Write("<meta http-equiv='Content-Type'; content='text/html';charset='utf-8'>");
        gvExcel.AllowPaging = false;
        using (Bussiness buss = new Bussiness())
        {
            strSQL = "SELECT a.BRNO,b.BRNAME,a.CmpName,a.Cmpid,a.EmpName,b.Rate6*100 as Rate6,b.Rate7*100 as Rate7,"+
                    " b.Rate9*100 as Rate9,b.Rate10*100 as Rate10,b.Rate11*100 as Rate11,b.Rate12*100 as Rate12,a.P7,a.P8,a.P9,a.P10,a.P11,a.P12,(b.Rate7*100-b.Rate6*100) AS RateX," +
                    " (b.LoanAmt7-b.LoanAmt6)as LoanAmt,a.C1, a.C2, a.C3,a.C4, a.C5, a.C6, a.C7, a.C8, a.C9, a.C10, a.C11" +
                    " FROM tblLoanRate AS a inner JOIN" +
                    " (SELECT BRNO, BRNAME, Cmpid," +
                    " SUM(CASE YYMM WHEN '200807' THEN Rate6 ELSE 0 END) AS Rate6," +
                    " SUM(CASE YYMM WHEN '200808' THEN Rate6 ELSE 0 END) AS Rate7," +
                    " SUM(CASE YYMM WHEN '200809' THEN Rate6 ELSE 0 END) AS Rate9," +
                    " SUM(CASE YYMM WHEN '200810' THEN Rate6 ELSE 0 END) AS Rate10," +
                    " SUM(CASE YYMM WHEN '200811' THEN Rate6 ELSE 0 END) AS Rate11," +
                    " SUM(CASE YYMM WHEN '200812' THEN Rate6 ELSE 0 END) AS Rate12," +
                    " SUM(CASE YYMM WHEN '" + strYYMMS + "' THEN LoanAmt ELSE 0 END) AS LoanAmt6," +
                    " SUM(CASE YYMM WHEN '" + strYYMME + "' THEN LoanAmt ELSE 0 END) AS LoanAmt7 " +
                    " FROM tblLoanRate02 WHERE (YYMM<='200812' or YYMM>='200806')" +
                    " GROUP BY BRNO, BRNAME, Cmpid) AS b " +
                    " ON a.BRNO = b.BRNO AND a.Cmpid = b.Cmpid WHERE (a.Rate <= 50) order by a.BRNO";
            ds = buss.select(strSQL, chb_eform.ConnectionString);
        }
        if (ds.Tables[0].Rows.Count > 0)
        {
            ds.Tables[0].Columns[0].ColumnName = "分行代號";
            ds.Tables[0].Columns[1].ColumnName = "分行名稱";
            ds.Tables[0].Columns[2].ColumnName = "客戶名稱";
            ds.Tables[0].Columns[3].ColumnName = "客戶統編";
            ds.Tables[0].Columns[4].ColumnName = "AO";
            ds.Tables[0].Columns[5].ColumnName = "97年" + txtYYMM1.Text.Substring(3, 2).TrimStart('0') + "月平均動用率";
            ds.Tables[0].Columns[6].ColumnName = "97年" + txtYYMM2.Text.Substring(3, 2).TrimStart('0') + "月平均動用率";
            ds.Tables[0].Columns[7].ColumnName = "97年9月平均動用率";
            ds.Tables[0].Columns[8].ColumnName = "97年10月平均動用率";
            ds.Tables[0].Columns[9].ColumnName = "97年11月平均動用率";
            ds.Tables[0].Columns[10].ColumnName = "97年12月平均動用率";
            ds.Tables[0].Columns[11].ColumnName = txtYYMM1.Text.Substring(3, 2).TrimStart('0') + "月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[12].ColumnName = txtYYMM2.Text.Substring(3, 2).TrimStart('0') + "月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[13].ColumnName = "97年9月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[14].ColumnName = "97年10月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[15].ColumnName = "97年11月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[16].ColumnName = "97年12月分行處理情形及執行瓶頸";
            ds.Tables[0].Columns[17].ColumnName = "成長or衰退";
            ds.Tables[0].Columns[18].ColumnName = "成長餘額";
            gvExcel.DataSource = ds;
            gvExcel.DataBind();
        }
        HtmlForm hf = new HtmlForm();
        Controls.Add(hf);
        hf.Controls.Add(gvExcel);
        hf.RenderControl(htw);
        Response.Write(sw.ToString());
        Response.End();
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);
    }

    protected void OnPreRender(object sender, System.EventArgs e)
    {
        int i = 0;
        using (Bussiness buss = new Bussiness())
        {
            switch (DropDownList1.SelectedIndex)
            {
                case 1:
                    strSQL =
                    "SELECT a.DocNo,a.BRNO,b.BRNAME,a.CmpName,a.Cmpid,a.EmpName,b.Rate6*100 as Rate6,b.Rate7*100 as Rate7,"+
                    " b.Rate9*100 as Rate9,b.Rate10*100 as Rate10,b.Rate11*100 as Rate11,b.Rate12*100 as Rate12," +
                    " (b.Rate7*100-b.Rate6*100) AS RateX," +
                    " (b.LoanAmt7-b.LoanAmt6)as LoanAmt,a.C1, a.C2, a.C3,a.C4, a.C5, a.C6, a.C7, a.C8, a.C9, a.C10, a.C11,a.P7,a.P8,a.P9,a.P10,a.P11,a.P12,a.H1,a.H2" +
                    " FROM tblLoanRate AS a inner JOIN" +
                    " (SELECT BRNO, BRNAME, Cmpid," +
                    " SUM(CASE YYMM WHEN '200807' THEN Rate6 ELSE 0 END) AS Rate6," +
                    " SUM(CASE YYMM WHEN '200808' THEN Rate6 ELSE 0 END) AS Rate7," +
                    " SUM(CASE YYMM WHEN '200809' THEN Rate6 ELSE 0 END) AS Rate9," +
                    " SUM(CASE YYMM WHEN '200810' THEN Rate6 ELSE 0 END) AS Rate10," +
                    " SUM(CASE YYMM WHEN '200811' THEN Rate6 ELSE 0 END) AS Rate11," +
                    " SUM(CASE YYMM WHEN '200812' THEN Rate6 ELSE 0 END) AS Rate12," +
                    " SUM(CASE YYMM WHEN '" + strYYMMS + "' THEN LoanAmt ELSE 0 END) AS LoanAmt6," +
                    " SUM(CASE YYMM WHEN '" + strYYMME + "' THEN LoanAmt ELSE 0 END) AS LoanAmt7 " +
                    " FROM tblLoanRate02 WHERE (YYMM<='200812' and YYMM>='200806')" +
                    " GROUP BY BRNO, BRNAME, Cmpid) AS b " +
                    " ON a.BRNO = b.BRNO AND a.Cmpid = b.Cmpid WHERE (a.Rate <= 50) order by a.BRNO";
                    ds = buss.select(strSQL, chb_eform.ConnectionString);
                    break;

                case 2:
                    strSQL =
                    "SELECT a.DocNo,a.BRNO,b.BRNAME,a.CmpName,a.Cmpid,a.EmpName,b.Rate6*100 as Rate6,b.Rate7*100 as Rate7,"+
                    " b.Rate9*100 as Rate9,b.Rate10*100 as Rate10,b.Rate11*100 as Rate11,b.Rate12*100 as Rate12," +
                    " (b.Rate7*100-b.Rate6*100) AS RateX," +
                    " (b.LoanAmt7-b.LoanAmt6)as LoanAmt,a.C1, a.C2, a.C3,a.C4, a.C5, a.C6, a.C7, a.C8, a.C9, a.C10, a.C11,a.P7,a.P8,a.P9,a.P10,a.P11,a.P12,a.H1,a.H2" +
                    " FROM tblLoanRate AS a inner JOIN" +
                    " (SELECT BRNO, BRNAME, Cmpid," +
                    " SUM(CASE YYMM WHEN '200807' THEN Rate6 ELSE 0 END) AS Rate6," +
                    " SUM(CASE YYMM WHEN '200808' THEN Rate6 ELSE 0 END) AS Rate7," +
                    " SUM(CASE YYMM WHEN '200809' THEN Rate6 ELSE 0 END) AS Rate9," +
                    " SUM(CASE YYMM WHEN '200810' THEN Rate6 ELSE 0 END) AS Rate10," +
                    " SUM(CASE YYMM WHEN '200811' THEN Rate6 ELSE 0 END) AS Rate11," +
                    " SUM(CASE YYMM WHEN '200812' THEN Rate6 ELSE 0 END) AS Rate12," +
                    " SUM(CASE YYMM WHEN '" + strYYMMS + "' THEN LoanAmt ELSE 0 END) AS LoanAmt6," +
                    " SUM(CASE YYMM WHEN '" + strYYMME + "' THEN LoanAmt ELSE 0 END) AS LoanAmt7 " +
                    " FROM tblLoanRate02 WHERE (YYMM<='200812' and YYMM>='200806')" +
                    " GROUP BY BRNO, BRNAME, Cmpid) AS b ON a.BRNO = b.BRNO AND a.Cmpid = b.Cmpid WHERE (a.Rate <= 50) order by RateX desc";
                    ds = buss.select(strSQL, chb_eform.ConnectionString);
                    break;

                case 3:
                    strSQL =
                    "SELECT a.DocNo,a.BRNO,b.BRNAME,a.CmpName,a.Cmpid,a.EmpName,b.Rate6*100 as Rate6,b.Rate7*100 as Rate7,"+
                    " b.Rate9*100 as Rate9,b.Rate10*100 as Rate10,b.Rate11*100 as Rate11,b.Rate12*100 as Rate12," +
                    " (b.Rate7*100-b.Rate6*100) AS RateX," +
                    " (b.LoanAmt7-b.LoanAmt6)as LoanAmt,a.C1, a.C2, a.C3,a.C4, a.C5, a.C6, a.C7, a.C8, a.C9, a.C10, a.C11,a.P7,a.P8,a.P9,a.P10,a.P11,a.P12,a.H1,a.H2" +
                    " FROM tblLoanRate AS a inner JOIN" +
                    " (SELECT BRNO, BRNAME, Cmpid," +
                    " SUM(CASE YYMM WHEN '200807' THEN Rate6 ELSE 0 END) AS Rate6," +
                    " SUM(CASE YYMM WHEN '200808' THEN Rate6 ELSE 0 END) AS Rate7," +
                    " SUM(CASE YYMM WHEN '200809' THEN Rate6 ELSE 0 END) AS Rate9," +
                    " SUM(CASE YYMM WHEN '200810' THEN Rate6 ELSE 0 END) AS Rate10," +
                    " SUM(CASE YYMM WHEN '200811' THEN Rate6 ELSE 0 END) AS Rate11," +
                    " SUM(CASE YYMM WHEN '200812' THEN Rate6 ELSE 0 END) AS Rate12," +
                    " SUM(CASE YYMM WHEN '" + strYYMMS + "' THEN LoanAmt ELSE 0 END) AS LoanAmt6," +
                    " SUM(CASE YYMM WHEN '" + strYYMME + "' THEN LoanAmt ELSE 0 END) AS LoanAmt7 " +
                    " FROM tblLoanRate02 WHERE (YYMM<='200812' and YYMM>='200806')" +
                    " GROUP BY BRNO, BRNAME, Cmpid) AS b ON a.BRNO = b.BRNO AND a.Cmpid = b.Cmpid WHERE (a.Rate <= 50) order by RateX asc";
                    ds = buss.select(strSQL, chb_eform.ConnectionString);
                    break;
                case 4:
                    strSQL =
                    "SELECT a.DocNo,a.BRNO,b.BRNAME,a.CmpName,a.Cmpid,a.EmpName,b.Rate6*100 as Rate6,b.Rate7*100 as Rate7,"+
                    " b.Rate9*100 as Rate9,b.Rate10*100 as Rate10,b.Rate11*100 as Rate11,b.Rate12*100 as Rate12," +
                    " (b.Rate7*100-b.Rate6*100) AS RateX," +
                    " (b.LoanAmt7-b.LoanAmt6)as LoanAmt,a.C1, a.C2, a.C3,a.C4, a.C5, a.C6, a.C7, a.C8, a.C9, a.C10, a.C11,a.P7,a.P8,a.P9,a.P10,a.P11,a.P12,a.H1,a.H2" +
                    " FROM tblLoanRate AS a inner JOIN" +
                    " (SELECT BRNO, BRNAME, Cmpid," +
                    " SUM(CASE YYMM WHEN '200807' THEN Rate6 ELSE 0 END) AS Rate6," +
                    " SUM(CASE YYMM WHEN '200808' THEN Rate6 ELSE 0 END) AS Rate7," +
                    " SUM(CASE YYMM WHEN '200809' THEN Rate6 ELSE 0 END) AS Rate9," +
                    " SUM(CASE YYMM WHEN '200810' THEN Rate6 ELSE 0 END) AS Rate10," +
                    " SUM(CASE YYMM WHEN '200811' THEN Rate6 ELSE 0 END) AS Rate11," +
                    " SUM(CASE YYMM WHEN '200812' THEN Rate6 ELSE 0 END) AS Rate12," +
                    " SUM(CASE YYMM WHEN '" + strYYMMS + "' THEN LoanAmt ELSE 0 END) AS LoanAmt6," +
                    " SUM(CASE YYMM WHEN '" + strYYMME + "' THEN LoanAmt ELSE 0 END) AS LoanAmt7 " +
                    " FROM tblLoanRate02 WHERE (YYMM<='200812' and YYMM>='200806')" +
                    " GROUP BY BRNO, BRNAME, Cmpid) AS b ON a.BRNO = b.BRNO AND a.Cmpid = b.Cmpid WHERE (a.Rate <= 50) order by LoanAmt desc";
                    ds = buss.select(strSQL, chb_eform.ConnectionString);
                    break;

                default:
                    strSQL =
                    "SELECT a.DocNo,a.BRNO,b.BRNAME,a.CmpName,a.Cmpid,a.EmpName,b.Rate6*100 as Rate6,b.Rate7*100 as Rate7,"+
                    " b.Rate9*100 as Rate9,b.Rate10*100 as Rate10,b.Rate11*100 as Rate11,b.Rate12*100 as Rate12," +
                    " (b.Rate7*100-b.Rate6*100) AS RateX," +
                    " (b.LoanAmt7-b.LoanAmt6)as LoanAmt,a.C1, a.C2, a.C3,a.C4, a.C5, a.C6, a.C7, a.C8, a.C9, a.C10, a.C11,a.P7,a.P8,a.P9,a.P10,a.P11,a.P12,a.H1,a.H2" +
                    " FROM tblLoanRate AS a inner JOIN " +
                    " (SELECT BRNO, BRNAME, Cmpid," +
                    " SUM(CASE YYMM WHEN '200807' THEN Rate6 ELSE 0 END) AS Rate6," +
                    " SUM(CASE YYMM WHEN '200808' THEN Rate6 ELSE 0 END) AS Rate7," +
                    " SUM(CASE YYMM WHEN '200809' THEN Rate6 ELSE 0 END) AS Rate9," +
                    " SUM(CASE YYMM WHEN '200810' THEN Rate6 ELSE 0 END) AS Rate10," +
                    " SUM(CASE YYMM WHEN '200811' THEN Rate6 ELSE 0 END) AS Rate11," +
                    " SUM(CASE YYMM WHEN '200812' THEN Rate6 ELSE 0 END) AS Rate12," +
                    " SUM(CASE YYMM WHEN '" + strYYMMS + "' THEN LoanAmt ELSE 0 END) AS LoanAmt6," +
                    " SUM(CASE YYMM WHEN '" + strYYMME + "' THEN LoanAmt ELSE 0 END) AS LoanAmt7 " +
                    " FROM tblLoanRate02 WHERE (YYMM<='200812' and YYMM>='200806')" +
                    " GROUP BY BRNO, BRNAME, Cmpid) AS b " +
                    " ON a.BRNO = b.BRNO AND a.Cmpid = b.Cmpid WHERE (a.Rate <= 50) order by a.BRNO";
                    ds = buss.select(strSQL, chb_eform.ConnectionString);
                    break;
            }
        }
        GridView1.DataSource = ds;
        GridView1.DataBind();

        if (ds.Tables[0].Rows.Count > 0)
        {
            foreach (GridViewRow GVR in GridView1.Rows)
            {
                Label Lindex = (Label)GVR.FindControl("txtIndex");
                Label BRNO = (Label)GVR.FindControl("txtBRNO");
                Label BRNAME = (Label)GVR.FindControl("txtBRNAME");
                Label CmpName = (Label)GVR.FindControl("txtCmpName");
                Label Cmpid = (Label)GVR.FindControl("txtCmpid");
                Label EmpName = (Label)GVR.FindControl("txtEmpName");
                Label Rate6 = (Label)GVR.FindControl("txtRate6");
                Label Rate7 = (Label)GVR.FindControl("txtRate7");
                Label Rate9 = (Label)GVR.FindControl("txtRate9");
                Label Rate10 = (Label)GVR.FindControl("txtRate10");
                Label Rate11 = (Label)GVR.FindControl("txtRate11");
                Label Rate12 = (Label)GVR.FindControl("txtRate12");
                TextBox P6 = (TextBox)GVR.FindControl("txtP6");
                TextBox P7 = (TextBox)GVR.FindControl("txtP7");
                TextBox P8 = (TextBox)GVR.FindControl("txtP8");
                TextBox P9 = (TextBox)GVR.FindControl("txtP9");
                TextBox P10 = (TextBox)GVR.FindControl("txtP10");
                TextBox P11 = (TextBox)GVR.FindControl("txtP11");
                Label GL = (Label)GVR.FindControl("txtGL");
                Label Amt = (Label)GVR.FindControl("txtAmt");
                Label Reason = (Label)GVR.FindControl("txtReason");
                CheckBoxList chkA = (CheckBoxList)GVR.FindControl("chkA");
                chkA.Items.Clear();

                Reason.Text = "";
                int tmp_i = i + 1;
                Lindex.Text = tmp_i.ToString();
                BRNO.Text = ds.Tables[0].Rows[i]["BRNO"].ToString();
                BRNAME.Text = ds.Tables[0].Rows[i]["BRNAME"].ToString();
                CmpName.Text = ds.Tables[0].Rows[i]["CmpName"].ToString();
                Cmpid.Text = ds.Tables[0].Rows[i]["Cmpid"].ToString();
                EmpName.Text = ds.Tables[0].Rows[i]["EmpName"].ToString();
                Rate6.Text = ds.Tables[0].Rows[i]["Rate6"].ToString();
                Rate7.Text = ds.Tables[0].Rows[i]["Rate7"].ToString();
                Rate9.Text = ds.Tables[0].Rows[i]["Rate9"].ToString();
                Rate10.Text = ds.Tables[0].Rows[i]["Rate10"].ToString();
                Rate11.Text = ds.Tables[0].Rows[i]["Rate11"].ToString();
                Rate12.Text = ds.Tables[0].Rows[i]["Rate12"].ToString();
                P6.Text = ds.Tables[0].Rows[i]["P7"].ToString();
                P7.Text = ds.Tables[0].Rows[i]["P8"].ToString();
                P8.Text = ds.Tables[0].Rows[i]["P9"].ToString();
                P9.Text = ds.Tables[0].Rows[i]["P10"].ToString();
                P10.Text = ds.Tables[0].Rows[i]["P11"].ToString();
                P11.Text = ds.Tables[0].Rows[i]["P12"].ToString();
                GL.Text = ds.Tables[0].Rows[i]["RateX"].ToString();
                Amt.Text = ds.Tables[0].Rows[i]["LoanAmt"].ToString();
                if (ds.Tables[0].Rows[i]["C1"].ToString() == "Y")
                    Reason.Text = "1  ";
                if (ds.Tables[0].Rows[i]["C2"].ToString() == "Y")
                    Reason.Text = Reason.Text + "2  ";
                if (ds.Tables[0].Rows[i]["C3"].ToString() == "Y")
                    Reason.Text = Reason.Text + "3  ";
                if (ds.Tables[0].Rows[i]["C4"].ToString() == "Y")
                    Reason.Text = Reason.Text + "4  ";
                if (ds.Tables[0].Rows[i]["C5"].ToString() == "Y")
                    Reason.Text = Reason.Text + "5  ";
                if (ds.Tables[0].Rows[i]["C6"].ToString() == "Y")
                    Reason.Text = Reason.Text + "6  ";
                if (ds.Tables[0].Rows[i]["C7"].ToString() == "Y")
                    Reason.Text = Reason.Text + "7  ";
                if (ds.Tables[0].Rows[i]["C8"].ToString() == "Y")
                    Reason.Text = Reason.Text + "8  ";
                if (ds.Tables[0].Rows[i]["C9"].ToString() == "Y")
                    Reason.Text = Reason.Text + "9  ";
                if (ds.Tables[0].Rows[i]["C10"].ToString() == "Y")
                    Reason.Text = Reason.Text + "10  ";
                if (ds.Tables[0].Rows[i]["C11"].ToString() == "Y")
                    Reason.Text = Reason.Text + "11  ";

                for (int j = 1; j <= 2; j++)
                {
                    ListItem item = new ListItem();
                    if (j == 1)
                    {
                        item.Text = "已結案";
                        if (ds.Tables[0].Rows[i]["H1"].ToString() == "Y")
                            item.Selected = true;
                    }
                    else
                    {
                        item.Text = "處理中";
                        if (ds.Tables[0].Rows[i]["H2"].ToString() == "Y")
                            item.Selected = true;
                    }
                    chkA.Items.Add(item);
                }
                i++;
            }
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            Label BRNO = this.GridView1.Rows[i].FindControl("txtBRNO") as Label;
            Label Cmpid = this.GridView1.Rows[i].FindControl("txtCmpid") as Label;

            CheckBoxList chkA = this.GridView1.Rows[i].FindControl("chkA") as CheckBoxList;
            for (int j = 0; j < 2; j++)
            {
                //ListItem item = new ListItem();
                if (chkA.Items[0].Selected == true)
                {
                    using (Bussiness buss = new Bussiness())
                    {
                        buss.execute("update tblLoanRate set H1='Y' where BRNO='" + BRNO.Text + "' and Cmpid='" + Cmpid.Text + "'", chb_eform.ConnectionString);
                    }
                }
                else
                {
                    using (Bussiness buss = new Bussiness())
                    {
                        buss.execute("update tblLoanRate set H1='' where BRNO='" + BRNO.Text + "' and Cmpid='" + Cmpid.Text + "'", chb_eform.ConnectionString);
                    }
                }
                if (chkA.Items[1].Selected == true)
                {
                    using (Bussiness buss = new Bussiness())
                    {
                        buss.execute("update tblLoanRate set H2='Y' where BRNO='" + BRNO.Text + "' and Cmpid='" + Cmpid.Text + "'", chb_eform.ConnectionString);
                    }
                }
                else
                {
                    using (Bussiness buss = new Bussiness())
                    {
                        buss.execute("update tblLoanRate set H2='' where BRNO='" + BRNO.Text + "' and Cmpid='" + Cmpid.Text + "'", chb_eform.ConnectionString);
                    }
                }
            }
        }

    }

}
