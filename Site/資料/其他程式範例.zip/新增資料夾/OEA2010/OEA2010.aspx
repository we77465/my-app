﻿<%@ Page EnableEventValidation = "false"  Language="C#" AutoEventWireup="true" CodeFile="OEA2010.aspx.cs" Inherits="Program_OEA2010_OEA2010Qform" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head id="Head1" runat="server">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="../Common/css/Common.css"  /> 
    <title>未命名頁面</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:Label ID="Label1" runat="server" Text="查詢年月："></asp:Label>
        <asp:TextBox ID="txtYYMM1" runat="server" Text="09707" ReadOnly="true" Width="47px"></asp:TextBox>~
        <asp:TextBox ID="txtYYMM2" runat="server" Text="09708" Width="47px"></asp:TextBox>
        <asp:DropDownList ID="DropDownList1" runat="server" AutoPostBack="True" >
            <asp:ListItem>請選擇排序方式...</asp:ListItem>
            <asp:ListItem Value="1">分行代號</asp:ListItem>
            <asp:ListItem Value="2">成長</asp:ListItem>
            <asp:ListItem Value="3">衰退</asp:ListItem>
            <asp:ListItem Value="4">平均餘額</asp:ListItem>
        </asp:DropDownList>
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        <br />
        <br />
        <asp:Button ID="btnNext" runat="server" Text="編輯/查詢" Width="95px" OnClick="btnNext_Click" />&nbsp;
        <asp:Button ID="Button1" runat="server" Text="儲存" Width="80px" OnClick="btnSave_Click" />&nbsp;
        <asp:Button ID="btnExcel" runat="server" Text="匯出勾選欄位Excel" OnClick="btnExcel_Click" />
        <asp:Button ID="btnAllExcel" runat="server" Text="匯出全部欄位Excel" OnClick="btnAllExcel_Click" /><br />
        <br />
        <asp:GridView ID="GridView1"   runat="server" CellPadding="4" ForeColor="#333333"
             GridLines="None" AutoGenerateColumns="False" OnPreRender="OnPreRender" PageSize="20" >
            <FooterStyle BackColor="#990000" Font-Bold="True" ForeColor="White" />
            <RowStyle BackColor="#FFFBD6" ForeColor="#333333" Font-Size="Small"/>
            <Columns>
                <asp:TemplateField HeaderText="維護">
                   <ItemTemplate>
                       <asp:CheckBox ID="Chk" runat="server" />
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="排序">
                   <ItemTemplate>
                      <asp:Label ID="txtIndex" runat="server" CssClass="TBLHL" Width="35px" ></asp:Label>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="分行代號">
                   <ItemTemplate>
                      <asp:Label ID="txtBRNO" runat="server" CssClass="TBLHL" Width="40px" ></asp:Label>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="分行名稱">
                   <ItemTemplate>
                      <asp:Label ID="txtBRNAME" runat="server" CssClass="TBLHL" Width="100px" ></asp:Label>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="客戶名稱">
                   <ItemTemplate>
                      <asp:Label ID="txtCmpName" runat="server" CssClass="TBLHL" Width="180px" ></asp:Label>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="統一編號">
                   <ItemTemplate>
                      <asp:Label ID="txtCmpid" runat="server" CssClass="TBLHL" Width="90px" ></asp:Label>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="AO">
                   <ItemTemplate>
                      <asp:Label ID="txtEmpName" runat="server" CssClass="TBLHL" Width="80px" ></asp:Label>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:Label ID="txtRate6" CssClass="numericINPUT" runat="server" Width="80px" ></asp:Label>
                   </ItemTemplate>
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField >
                   <ItemTemplate>
                      <asp:Label ID="txtRate7" CssClass="numericINPUT" runat="server" Width="80px"></asp:Label>
                   </ItemTemplate>
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>                
                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:Label ID="txtRate9" CssClass="numericINPUT" runat="server" Width="80px" ></asp:Label>
                   </ItemTemplate>
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:Label ID="txtRate10" CssClass="numericINPUT" runat="server" Width="80px" ></asp:Label>
                   </ItemTemplate>
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:Label ID="txtRate11" CssClass="numericINPUT" runat="server" Width="80px" ></asp:Label>
                   </ItemTemplate>
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:Label ID="txtRate12" CssClass="numericINPUT" runat="server" Width="80px" ></asp:Label>
                   </ItemTemplate>
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>                
                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:TextBox ID="txtP6" runat="server" Width="130px" ReadOnly="true" TextMode="MultiLine"></asp:TextBox>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:TextBox ID="txtP7" runat="server" Width="130px" ReadOnly="true" TextMode="MultiLine"></asp:TextBox>
                   </ItemTemplate>
                </asp:TemplateField>

                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:TextBox ID="txtP8" runat="server" Width="130px" ReadOnly="true" TextMode="MultiLine"></asp:TextBox>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:TextBox ID="txtP9" runat="server" Width="130px" ReadOnly="true" TextMode="MultiLine"></asp:TextBox>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:TextBox ID="txtP10" runat="server" Width="130px" ReadOnly="true" TextMode="MultiLine"></asp:TextBox>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField>
                   <ItemTemplate>
                      <asp:TextBox ID="txtP11" runat="server" Width="130px" ReadOnly="true" TextMode="MultiLine"></asp:TextBox>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="成長or衰退">
                   <ItemTemplate>
                      <asp:Label ID="txtGL" runat="server" CssClass="numericINPUT" Width="60px" ></asp:Label>
                   </ItemTemplate>
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>
                <%--<asp:TemplateField >
                   <ItemTemplate>
                      <asp:Label ID="txtLoanAmt6" runat="server" CssClass="numericINPUT" Width="80px"></asp:Label>
                   </ItemTemplate>
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField >
                   <ItemTemplate>
                      <asp:Label ID="txtLoanAmt7" runat="server" CssClass="numericINPUT" Width="80px"></asp:Label>
                   </ItemTemplate>
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>--%>
                <asp:TemplateField HeaderText="成長餘額">
                   <ItemTemplate>
                      <asp:Label ID="txtAmt" runat="server" CssClass="numericINPUT" Width="70px" ></asp:Label>
                   </ItemTemplate>
                    <ItemStyle Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="未動用原因">
                   <ItemTemplate>
                      <asp:Label ID="txtReason" runat="server" CssClass="TBLHL" Width="70px" ></asp:Label>
                   </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="總行處理情形">
                   <ItemTemplate>
                      <asp:CheckBoxList ID="chkA" runat="server" Width="130px" RepeatDirection="Horizontal"></asp:CheckBoxList>
                   </ItemTemplate>
                    <HeaderStyle Wrap="False" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="歷任AO">
                   <ItemTemplate>
                      <asp:HyperLink ID="linkAO" runat="server" CssClass="TBLHL" Width="40px" NavigateUrl='<%#"/DotNet/Program/OEA2010/ChangeAO.aspx?CmpId="+DataBinder.Eval(Container.DataItem,"CmpId")%>' Target="_blank" Text="查詢"></asp:HyperLink><%--+"&DOCNO="+DataBinder.Eval(Container.DataItem,"DOCNO")--%>
                   </ItemTemplate>
                </asp:TemplateField>
            </Columns>
            <PagerStyle BackColor="#FFCC66" ForeColor="#333333" HorizontalAlign="Center" />
            <SelectedRowStyle BackColor="#FFCC66" Font-Bold="True" ForeColor="Navy" />
            <HeaderStyle BackColor="#990000" Font-Bold="True" ForeColor="White" Font-Size="Small" />
            <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        <br />
        <br />
        &nbsp;<asp:SqlDataSource ID="chb_eform" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
        SelectCommand="select * from tblLoanRate" 
        UpdateCommand="update tblLoanRate set Chk=@Chk where BRNO=@BRNO and Cmpid=@Cmpid">
            <UpdateParameters>
                <asp:Parameter Name="Chk" />
                <asp:Parameter Name="BRNO" />
                <asp:Parameter Name="Cmpid" />
            </UpdateParameters>
        </asp:SqlDataSource>
    </div>
    </form>
</body>
</html>
