﻿Imports System.Data.SqlClient
Partial Class Program_ODU1010_ODU1020
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Not IsPostBack) Then
            '前一頁傳來的值 IntraWeb\OACHB\Program\OAOvrd\OAOvrdList.asp
            Dim hOvrd As String = Request.Form("hOvrd") '主管2或是負責人
            Dim hQFlowStatus As String = Request.Form("hQFlowStatus") '流程狀態
            Dim hDocNo As String = Request.Form("hDocNo")  '表單編號
            Dim hUsrId As String = Request.Form("hUsrId") 'LoginID
            Dim hUsrName As String = Request.Form("hUsrName") '負責人NAME

            'Response.Write("hOvrd:" & Request.Form("hOvrd") & "<br>")
            'Response.Write("hQFlowStatus:" & Request.Form("hQFlowStatus") & "<br>")
            'Response.Write("hDocNo:" & Request.Form("hDocNo") & "<br>")
            'Response.Write("hUsrId:" & Request.Form("hUsrId") & "<br>")
            'Response.Write("hUsrName:" & Request.Form("hUsrName") & "<br>")
            'Response.Write("BtnSign1OK:" & BtnSign1OK.Visible & "<br>")
            'Response.Write("BtnSign1Back:" & BtnSign1Back.Visible & "<br>")

            txtSign1.Text = hUsrId '單位主管:
            txtSign1Name.Text = GetEmpID2Name(hUsrId) '單位主管:
            txtSignDate1.Text = FormatDateTime(Now(), DateFormat.ShortDate) '簽核日

            lblDOCNO.Text = hDocNo '表單編號
            '目前本單位專責內部管理工作人員名單如下,GridView1
            DS_tblIntraMgrMan.SelectParameters("BRNO2").DefaultValue = Mid(hDocNo, 6, 4)
            '異動表如下,GridView2
            DS_tblIntraMgrAssForm.SelectParameters("DocNo").DefaultValue = hDocNo
            GetDBLogDetail(hDocNo) '從DB(tblLogDetail)取值
            GetIntraMgrAssForm(hDocNo)  '從IntraMgrAssForm取值(資料內容)

        End If

    End Sub

    '決行
    Protected Sub BtnSign1OK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSign1OK.Click

        Dim docno As String = lblDOCNO.Text.Trim()
        'Response.Write(docno)

        DS_tblLogDetail.UpdateParameters("Sign1").DefaultValue = txtSign1.Text 'ID
        DS_tblLogDetail.UpdateParameters("ACTION1").DefaultValue = "D"
        DS_tblLogDetail.UpdateParameters("SignDate1").DefaultValue = Now() ' 日期時間
        DS_tblLogDetail.UpdateParameters("DecManager").DefaultValue = txtSign1.Text ' 負責人ID
        DS_tblLogDetail.UpdateParameters("DecDate").DefaultValue = Now() '日期時間
        DS_tblLogDetail.UpdateParameters("FlowStatus").DefaultValue = "3" '流程狀態
        DS_tblLogDetail.UpdateParameters("SignComment1").DefaultValue = txtSignComment1.Text '批示
        DS_tblLogDetail.UpdateParameters("DocNo").DefaultValue = lblDOCNO.Text '表單編號

        Try
            DS_tblIntraMgrMan.DeleteParameters("DocNo").DefaultValue = docno
            DS_tblIntraMgrMan.InsertParameters("DocNo").DefaultValue = docno
            DS_tblIntraMgrMan.Delete() '卸任
            DS_tblIntraMgrMan.Insert() '擔任
            DS_tblLogDetail.Update()
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try

        GridView1.DataBind()
        Response.Write("<script language=javascript>alert('決行成功!')</script>")
        Response.Write("<script language=javascript>window.location.href='/OACHB/Program/OAOvrd/OAOvrdQForm.asp?hOvrd=2'</script>")


    End Sub

    '退回
    Protected Sub BtnSign1Back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSign1Back.Click

        DS_tblLogDetail.UpdateParameters("Sign1").DefaultValue = txtSign1.Text '負責人ID
        DS_tblLogDetail.UpdateParameters("ACTION1").DefaultValue = "B"
        DS_tblLogDetail.UpdateParameters("SignDate1").DefaultValue = Now() ' 日期時間
        DS_tblLogDetail.UpdateParameters("DecManager").DefaultValue = "" ' 負責人ID
        DS_tblLogDetail.UpdateParameters("DecDate").DefaultValue = "" '日期時間
        DS_tblLogDetail.UpdateParameters("FlowStatus").DefaultValue = "0" '流程狀態
        DS_tblLogDetail.UpdateParameters("SignComment1").DefaultValue = txtSignComment1.Text '批示
        DS_tblLogDetail.UpdateParameters("DocNo").DefaultValue = lblDOCNO.Text '表單編號

        DS_tblLogDetail.Update()
        Response.Write("<script language=javascript>alert('退回成功!')</script>")
        Response.Write("<script language=javascript>window.location.href='/OACHB/Program/OAOvrd/OAOvrdQForm.asp?hOvrd=2'</script>")


    End Sub

    '匯出列印
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click

        '匯出成HTML檔
        Response.AddHeader("content-disposition", "attachment; filename=saveExcel.htm")
        Response.Charset = "utf-8"
        Response.ContentType = "Content-Language;content=zh-tw"
        Response.ContentType = "application/vnd.ms-excel"

    End Sub

    '從表單流程 DB(tblLogDetail)取值
    Private Sub GetDBLogDetail(ByVal docno)
        Using conn As New SqlConnection(DS_tblLogDetail.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  FlowStatus,Ver,BrNo,EmpId,YYMM,RecordDate,Sign1,SignDate1,SignComment1 FROM tblLogDetail where DocNo = '" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read

                txt_RecordDate.Text = reader(5).ToString() '申報日期

            End While
            reader.Close()
            cmd.Dispose()
        End Using
    End Sub

    '從表單內容 DB(IntraMgrAssForm)取值
    Private Sub GetIntraMgrAssForm(ByVal docno)
        Using conn As New SqlConnection(DS_tblIntraMgrAssForm.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT  GoouNum,Brno,BrnoName,Keyin,KeyinName,Ext,YYYMM FROM tblIntraMgrAssForm where DocNo = '" & docno & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            While reader.Read

                txtGoouNum.Text = reader(0).ToString() '固有號碼:
                txt_Brno.Text = reader(1).ToString() '分 行：
                txt_Brno_Name.Text = reader(2).ToString() '分 行：
                txt_EmpID.Text = reader(3).ToString() '填 報 人：
                txt_EmpName.Text = reader(4).ToString() '填 報 人：
                txt_Ext.Text = reader(5).ToString() '分 機：
                txt_YYYMM.Text = reader(6).ToString() '年 月:

            End While
            reader.Close()
            cmd.Dispose()
        End Using
    End Sub

    '利用員編找名字
    Private Function GetEmpID2Name(ByVal gEmpId)
        'Response.Write("gEmpId:" & gEmpId & "<br>")
        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select NAME from chb_pub..EMPLOYEE where STAFF ='" & gEmpId & "'"
            'Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function
End Class
