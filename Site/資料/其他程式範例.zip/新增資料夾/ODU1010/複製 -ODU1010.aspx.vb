﻿Imports System.Data.SqlClient
Partial Class Program_ODU1010_ODU1010
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Not IsPostBack) Then

            '此表單為"專責內部管理工作助理人員指派表",指派後經主管核可後方可填 電子表單/人資處/專責內部管理綜合報告表
            '另有"專責內部管理工作助理人員指派表",也是一樣

            '======================================= 相 關 參 數 設 定 =====================================
            Dim strLine(1) As String
            Dim EmpId As String = Request.Cookies("CHB_IW_")("User_ID").ToString() '員工編號,從Cookies來的

            '利用 getUserInfo 得到 分行id,員工姓名,分行名稱
            Dim drString As String = UserInfo.getUserInfo(EmpId)
            strLine = drString.Split(Char.Parse(","))
            Dim Brno As String = strLine(0).ToString() '分行
            Dim EmpName As String = strLine(1).ToString() '員工姓名
            Dim BrnoName As String = strLine(2).ToString() '分行名稱

            Dim yyy As String = Right(("000" & Integer.Parse(Format(Now(), "yyyy")) - 1911), 3) '西元年轉民國年
            Dim mm As String = Format(Now(), "MM") '月
            Dim dd As String = Format(Now(), "dd") '日

            '表單編號(查tblLogDetail去找最後一筆,再加1)
            Dim DocNo As String = "DU" & yyy & Brno & GetLastNum(Brno, yyy & mm) 'exp DU0980501001
            'Response.Write("DocNo:" & DocNo & "<br>")

            'Response.Write(yyy)
            'Response.Write("EmpId:" & EmpId & "<br>")
            'Response.Write("drString:" & drString & "<br>")
            'Response.Write("Brno:" & Brno & "<br>")
            'Response.Write("EmpName:" & EmpName & "<br>")
            'Response.Write("BrnoName:" & BrnoName & "<br>")
            hid_savecheck.Value = "N"
            '================================================== 表 單 內 容 區 塊 ==========================================
            lblDOCNO.Text = DocNo '表單編號
            txtGoouNum.Text = GetGoouNum(Brno) '固有號碼
            txt_Brno.Text = Brno '分行
            txt_Brno_Name.Text = BrnoName '分行名稱
            txt_EmpID.Text = EmpId '填 報 人
            txt_EmpName.Text = EmpName '填報人姓名
            txt_YYYMM.Text = yyy & mm '年月
            txt_RecordDate.Text = Format(Now(), "MM/dd/yyyy") '申報日期

            DS_tblIntraMgrMan.SelectParameters("BRNO2").DefaultValue = txt_Brno.Text

            '異動表如下 (GridView2)
            DS_tblIntraMgrAssForm.SelectParameters("DocNo").DefaultValue = lblDOCNO.Text


            DS_EMPLOYEE.SelectParameters("BRNO").DefaultValue = Brno '查該單位所有員工編號(ddl__IntraMgrID1)
            txt_Date1.Text = yyy & mm & dd '擔任日期 

            DS_tblIntraMgrMan2.SelectParameters("Brno").DefaultValue = Brno '查詢新增卸任人員(ddl__IntraMgrID2)
            txt_Date2.Text = yyy & mm & dd '卸任日期 

            btn_ADD.Attributes.Add("onclick", "return ChkALL()") '新增檢查 IntraMgr.js
            btn_DEL.Attributes.Add("onclick", "return ChkALL2()") '刪除檢查 IntraMgr.js
            btn_Save.Attributes.Add("onclick", "return SaveCheck()") '存檔檢查

        End If

    End Sub

    '新增擔任助理人員(檢 核)
    Protected Sub btn_Check1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Check1.Click

        txt_IntraMgrName1.Text = GetEmpID2Name(ddl__IntraMgrID1.Text) '利用員編找名字        txt_JobName1.Text = GetJobName(ddl__IntraMgrID1.Text) '利用員編找職務
        If txt_IntraMgrName1.Text = "" Or txt_JobName1.Text = "" Then
            Response.Write("<script language=javascript>alert('查無資料,請確定員編是否正確')</script>")
        End If


    End Sub

    '新增卸任助理人員(檢 核)
    Protected Sub btn_Check2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Check2.Click

        txt_IntraMgrName2.Text = GetEmpID2Name(ddl__IntraMgrID2.Text) '利用員編找名字        txt_JobName2.Text = GetJobName(ddl__IntraMgrID2.Text) '利用員編找職務
        If txt_IntraMgrName2.Text = "" Or txt_JobName2.Text = "" Then
            Response.Write("<script language=javascript>alert('查無資料,請確定員編是否正確')</script>")
        End If

    End Sub

    '新增擔任助理人員
    Protected Sub btn_ADD_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_ADD.Click

        '再檢核一次
        txt_IntraMgrName1.Text = GetEmpID2Name(ddl__IntraMgrID1.Text) '利用員編找名字        txt_JobName1.Text = GetJobName(ddl__IntraMgrID1.Text) '利用員編找職務

        '必填欄位過濾
        Dim Ext As String = txt_Ext.Text '分 機：
        Dim IntraMgrID As String = ddl__IntraMgrID1.Text '員工代號(專責內部管理工作助理人員)
        Dim IntraMgrName As String = txt_IntraMgrName1.Text '姓 名(專責內部管理工作助理人員)
        Dim JobName As String = txt_JobName1.Text '職 稱
        Dim Date1 As String = txt_Date1.Text '擔任(卸任)日期 

        'If Ext <> "" And IntraMgrID <> "" And IntraMgrName <> "" And JobName <> "" And Date1 <> "" Then

        DS_tblIntraMgrAssForm.InsertParameters("DocNo").DefaultValue = lblDOCNO.Text '表單號碼
        DS_tblIntraMgrAssForm.InsertParameters("Brno").DefaultValue = txt_Brno.Text '分行
        DS_tblIntraMgrAssForm.InsertParameters("BrnoName").DefaultValue = txt_Brno_Name.Text '分行
        DS_tblIntraMgrAssForm.InsertParameters("YYYMM").DefaultValue = txt_YYYMM.Text '所屬年月
        DS_tblIntraMgrAssForm.InsertParameters("Keyin").DefaultValue = txt_EmpID.Text '填 報 人
        DS_tblIntraMgrAssForm.InsertParameters("KeyinName").DefaultValue = txt_EmpName.Text '填 報 人
        DS_tblIntraMgrAssForm.InsertParameters("Ext").DefaultValue = txt_Ext.Text '分 機
        DS_tblIntraMgrAssForm.InsertParameters("GoouNum").DefaultValue = txtGoouNum.Text '固有號碼
        DS_tblIntraMgrAssForm.InsertParameters("IntraMgrID").DefaultValue = ddl__IntraMgrID1.Text '員工代號(專責內部管理工作助理人員)
        DS_tblIntraMgrAssForm.InsertParameters("IntraMgrName").DefaultValue = txt_IntraMgrName1.Text '姓 名(專責內部管理工作助理人員)
        DS_tblIntraMgrAssForm.InsertParameters("JobName").DefaultValue = txt_JobName1.Text '職 稱
        DS_tblIntraMgrAssForm.InsertParameters("Master").DefaultValue = "S" ' 助理工作人員 
        DS_tblIntraMgrAssForm.InsertParameters("EnableDate").DefaultValue = txt_Date1.Text '擔任日期
        DS_tblIntraMgrAssForm.InsertParameters("DisableDate").DefaultValue = "" '卸任日期
        DS_tblIntraMgrAssForm.InsertParameters("status").DefaultValue = "Add" '狀態(新增)

        'End If

        Try
            DS_tblIntraMgrAssForm.Insert()
            'Response.Write("<script language=javascript>window.location.href='/oachb/program/ODS1010/ODS1010QForm.asp'</script>")
        Catch ex As Exception
            Response.Write("<script language=javascript>alert('新增擔任失敗,原因:" & ex.Message & "')</script>")
        End Try

        GridView2.DataBind()
        hid_savecheck.Value = "Y"

    End Sub

    '新增卸任助理人員
    Protected Sub btn_DEL_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_DEL.Click

        '再檢核一次
        txt_IntraMgrName2.Text = GetEmpID2Name(ddl__IntraMgrID2.Text) '利用員編找名字        txt_JobName2.Text = GetJobName(ddl__IntraMgrID2.Text) '利用員編找職務

        Dim EnableDate As String = GettblIntraMgrManEnableDate(ddl__IntraMgrID2.Text) '擔任日期

        '必填欄位過濾
        Dim Ext As String = txt_Ext.Text '分 機：
        Dim IntraMgrID As String = ddl__IntraMgrID1.Text '員工代號(專責內部管理工作助理人員)
        Dim IntraMgrName As String = txt_IntraMgrName1.Text '姓 名(專責內部管理工作助理人員)
        Dim JobName As String = txt_JobName1.Text '職 稱
        Dim Date1 As String = txt_Date1.Text '擔任(卸任)日期 

        'If Ext <> "" And IntraMgrID <> "" And IntraMgrName <> "" And JobName <> "" And Date1 <> "" Then

        DS_tblIntraMgrAssForm.InsertParameters("DocNo").DefaultValue = lblDOCNO.Text '表單號碼
        DS_tblIntraMgrAssForm.InsertParameters("Brno").DefaultValue = txt_Brno.Text '分行
        DS_tblIntraMgrAssForm.InsertParameters("BrnoName").DefaultValue = txt_Brno_Name.Text '分行
        DS_tblIntraMgrAssForm.InsertParameters("YYYMM").DefaultValue = txt_YYYMM.Text '所屬年月
        DS_tblIntraMgrAssForm.InsertParameters("Keyin").DefaultValue = txt_EmpID.Text '填 報 人
        DS_tblIntraMgrAssForm.InsertParameters("KeyinName").DefaultValue = txt_EmpName.Text '填 報 人
        DS_tblIntraMgrAssForm.InsertParameters("Ext").DefaultValue = txt_Ext.Text '分 機
        DS_tblIntraMgrAssForm.InsertParameters("GoouNum").DefaultValue = txtGoouNum.Text '固有號碼
        DS_tblIntraMgrAssForm.InsertParameters("IntraMgrID").DefaultValue = ddl__IntraMgrID2.Text '員工代號(專責內部管理工作助理人員)
        DS_tblIntraMgrAssForm.InsertParameters("IntraMgrName").DefaultValue = txt_IntraMgrName2.Text '姓 名(專責內部管理工作助理人員)
        DS_tblIntraMgrAssForm.InsertParameters("JobName").DefaultValue = txt_JobName2.Text '職 稱
        DS_tblIntraMgrAssForm.InsertParameters("Master").DefaultValue = "S" '助理工作人員 
        DS_tblIntraMgrAssForm.InsertParameters("EnableDate").DefaultValue = EnableDate '擔任日期
        DS_tblIntraMgrAssForm.InsertParameters("DisableDate").DefaultValue = txt_Date2.Text '卸任日期
        DS_tblIntraMgrAssForm.InsertParameters("status").DefaultValue = "Del" '狀態(新增)

        'End If

        Try
            DS_tblIntraMgrAssForm.Insert()
        Catch ex As Exception
            Response.Write("<script language=javascript>alert('新增卸任失敗,原因:" & ex.Message & "')</script>")
        End Try

        GridView2.DataBind()
        hid_savecheck.Value = "Y"

    End Sub

    '儲存 
    Protected Sub btn_Save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Save.Click

        '檢查是否已填報資料,有填報才可儲存
        Dim count As String = GetDocnocount(lblDOCNO.Text)

        If count <> "0" Then '有填報資料

            '新增chb_eform 表單流程
            DS_tblLogDetail.InsertParameters("DocType").DefaultValue = "DU"
            DS_tblLogDetail.InsertParameters("DocNo").DefaultValue = lblDOCNO.Text.ToString.Trim() '表單編號
            DS_tblLogDetail.InsertParameters("BrNo").DefaultValue = txt_Brno.Text.ToString.Trim() '分行代碼
            DS_tblLogDetail.InsertParameters("EmpId").DefaultValue = txt_EmpID.Text.ToString.Trim() '經辦員編
            DS_tblLogDetail.InsertParameters("RecordDate").DefaultValue = Now()
            DS_tblLogDetail.InsertParameters("DataFlag").DefaultValue = "N"
            DS_tblLogDetail.InsertParameters("YYMM").DefaultValue = txt_YYYMM.Text.ToString.Trim() '年月
            DS_tblLogDetail.InsertParameters("FlowStatus").DefaultValue = "2" '送單位主管核可
            DS_tblLogDetail.InsertParameters("Ver").DefaultValue = "1"

            DS_tblLogDetail.Insert()

          

        Else '無填報資料
            'Response.Write("<script>alert('尚未填報資料') ;</script>")
        End If

    End Sub

    '查詢tblLogDetail  找出該分行該月份最後一筆表單編號最後一位流水號,用來當做下一筆表單編號的參考
    'EXP:DB內最後一筆是 DU0980501001 --> 001,則下一筆則是 DU0980501002
    Function GetLastNum(ByVal Brno, ByVal yyymm)

        Dim DocNo As String
        Dim num As String = ""


        Using conn As New SqlConnection(DS_tblIntraMgrAssForm.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "SELECT MAX(DocNo) AS DocNo, SUBSTRING(MAX(DocNo), 10, 12) AS NUM FROM tblIntraMgrAssForm WHERE  (Brno = '" & Brno & "') and (YYYMM = '" & yyymm & "')"
            'Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader As SqlDataReader = cmd.ExecuteReader()

            While reader.Read
                DocNo = reader(0).ToString()
                num = reader(1).ToString()
            End While
        End Using

        If num = "" Then
            num = "001"
        Else
            num = Right("000" & (Integer.Parse(num) + 1), 3) '補成3位數
        End If

        Return num
        'Response.Write("num:" & num & "<br>")
    End Function

    '利用員編找名字    Private Function GetEmpID2Name(ByVal gEmpId)
        ''Response.Write("gEmpId:" & gEmpId & "<br>")
        Dim EMPNAME As String = ""
        Using conn As New SqlConnection(DS_EMPLOYEE.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select NAME from chb_pub..EMPLOYEE where STAFF ='" & gEmpId & "'"
            ''Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader2 As SqlDataReader = cmd.ExecuteReader()
            While reader2.Read
                EMPNAME = reader2(0).ToString()
            End While
            reader2.Close()
            cmd.Dispose()
        End Using

        Return EMPNAME
    End Function

    '利用分行代號找出分行名稱
    Private Function GetBrno2Name(ByVal gBrNo)
        Dim BrnoName As String = ""
        Using conn As New SqlConnection(DS_BRANCH.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select BRNAME from chb_pub..BRANCH where BRNO ='" & gBrNo & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader1 As SqlDataReader = cmd.ExecuteReader()
            While reader1.Read
                BrnoName = reader1(0).ToString()
            End While
            reader1.Close()
            cmd.Dispose()
        End Using

        Return BrnoName
    End Function

    '利用員編找職務    Private Function GetJobName(ByVal gEmpId)
        ''Response.Write("gEmpId:" & gEmpId & "<br>")

        Dim STAFF As String = ""
        Dim NAME As String = ""
        Dim JOBCODE As String = ""
        Dim JOBNAME As String = ""

        Using conn As New SqlConnection(DS_JOBCODE.ConnectionString)
            conn.Open()
            Dim tmpsql As String

            'tmpsql = "SELECT  E.STAFF, E.NAME, E.BRNO,B.BRNAME, E.JOBCODE,J.JOBNAME FROM EMPLOYEE as E,BRANCH as B,JOBCODE as J WHERE (E.STATUS = '1') AND (E.BRNO = '" & Brno & "')AND (E.BRNO = B.BRNO)AND (E.JOBCODE = J.JOBCODE)"
            tmpsql = "SELECT   E.STAFF, E.NAME, E.JOBCODE, J.JOBNAME  FROM  EMPLOYEE AS E INNER JOIN JOBCODE AS J ON E.JOBCODE = J.JOBCODE WHERE     E.STAFF = '" & gEmpId & "'"
            'Response.Write("tmpsql:" & tmpsql & "<br>")
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader4 As SqlDataReader = cmd.ExecuteReader()
            While reader4.Read

                STAFF = reader4(0).ToString()
                NAME = reader4(1).ToString()
                JOBCODE = reader4(2).ToString()
                JOBNAME = reader4(3).ToString()

            End While
            reader4.Close()
            cmd.Dispose()
        End Using

        Return JOBNAME
    End Function

    '利用分行代號找出固有號碼
    Private Function GetGoouNum(ByVal gBrNo)
        Dim GoouNum As String = ""
        Using conn As New SqlConnection(DS_tblGoouNum.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select GoouNum from tblGoouNum where Brno ='" & gBrNo & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader5 As SqlDataReader = cmd.ExecuteReader()
            While reader5.Read
                GoouNum = reader5(0).ToString()
            End While
            reader5.Close()
            cmd.Dispose()
        End Using

        Return GoouNum
    End Function

    '查詢 EnableDate
    Private Function GettblIntraMgrManEnableDate(ByVal IntraMgrID)
        Dim EnableDate As String = ""
        Using conn As New SqlConnection(DS_tblIntraMgrMan2.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select Brno, BrnoName, IntraMgrID, IntraMgrName, JobName, Master, EnableDate from tblIntraMgrMan where IntraMgrID ='" & IntraMgrID & "' and Brno = '" & txt_Brno.Text & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader6 As SqlDataReader = cmd.ExecuteReader()
            While reader6.Read
                EnableDate = reader6(6).ToString()
            End While
            reader6.Close()
            cmd.Dispose()
        End Using

        Return EnableDate
    End Function

    '檢查是否已填報資料
    Private Function GetDocnocount(ByVal DocNo)
        Dim count As String = "0"
        Using conn As New SqlConnection(DS_tblIntraMgrAssForm.ConnectionString)
            conn.Open()
            Dim tmpsql As String
            tmpsql = "select count(*) from tblIntraMgrAssForm where DocNo ='" & DocNo & "'"
            Dim cmd As New SqlCommand(tmpsql, conn)
            Dim reader9 As SqlDataReader = cmd.ExecuteReader()
            While reader9.Read
                count = reader9(0).ToString()
            End While
            reader9.Close()
            cmd.Dispose()
        End Using

        Return count
    End Function

    '列印
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        '匯出成HTML檔
        Response.AddHeader("content-disposition", "attachment; filename=saveExcel.htm")
        Response.Charset = "utf-8"
        Response.ContentType = "Content-Language;content=zh-tw"
        Response.ContentType = "application/vnd.ms-excel"
    End Sub
End Class
