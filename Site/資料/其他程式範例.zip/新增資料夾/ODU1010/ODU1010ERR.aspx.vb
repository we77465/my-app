﻿
Partial Class Program_ODU1010_ODU1010ERR
    Inherits System.Web.UI.Page

End Class
