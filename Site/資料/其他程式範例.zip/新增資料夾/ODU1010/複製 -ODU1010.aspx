﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODU1010.aspx.vb" Inherits="Program_ODU1010_ODU1010" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>未命名頁面</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
     <script language="JavaScript">
        if (navigator.appName.indexOf('Internet Explorer') != -1)
        {
	        document.onmousedown = noSourceExplorer;
        }

            function noSourceExplorer()
            {
	            if (event.button == 2 | event.button == 3)
	            {
	                if (confirm('是否列印?')) 
	                {
	                    window.print();
                    }
	            }
            }
    </script>
    <script language="JavaScript" type="text/javascript" src="ODU1010.js"></script> 
</head>
<body style="font-size: 10pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <span style="font-family: Arial">
            <div>
                <table border="2" cellpadding="2" cellspacing="2" width="720">
                    <tr>
                        <td bgcolor="khaki" style="width: 60px">
                            <asp:Label ID="Label10" runat="server" Font-Size="Small" ForeColor="Red" Text="ODU1010"></asp:Label></td>
                        <td style="color: #000000">
                            &nbsp;<asp:Label ID="Label9" runat="server" Font-Names="標楷體" Font-Size="Medium" ForeColor="Red"
                                Text="專責內部管理工作助理人員指派表" Width="220px"></asp:Label></td>
                        <td bgcolor="khaki">
                            表單號碼：</td>
                        <td>
                            &nbsp;<asp:Label ID="lblDOCNO" runat="server" Font-Size="Medium" ForeColor="Red"
                                Text="Label"></asp:Label></td>
                        <td bgcolor="khaki" style="color: #000000">
                            固有號碼:</td>
                        <td>
                            &nbsp;<asp:TextBox ID="txtGoouNum" runat="server" BackColor="#E0E0E0" Width="50px"></asp:TextBox></td>
                    </tr>
                    <tr>
                        <td bgcolor="khaki" style="width: 60px">
                            <span style="font-size: 9pt; font-family: 新細明體">單位</span>：</td>
                        <td>
                            &nbsp;<asp:TextBox ID="txt_Brno" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                                Width="70px"></asp:TextBox>&nbsp;
                            <asp:TextBox ID="txt_Brno_Name" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                                Width="70px"></asp:TextBox></td>
                        <td bgcolor="khaki">
                            填 報 人：</td>
                        <td style="font-family: 標楷體">
                            &nbsp;<asp:TextBox ID="txt_EmpID" runat="server" BackColor="#E0E0E0" BorderColor="White"
                                ReadOnly="True" Width="70px"></asp:TextBox>&nbsp;
                            <asp:TextBox ID="txt_EmpName" runat="server" BackColor="#E0E0E0" ReadOnly="True"
                                Width="70px"></asp:TextBox></td>
                        <td bgcolor="khaki">
                            分 機：</td>
                        <td style="font-family: 標楷體">
                            &nbsp;<asp:TextBox ID="txt_Ext" runat="server" MaxLength="4" ValidationGroup="1"
                                Width="50px"></asp:TextBox></td>
                    </tr>
                    <tr style="font-family: Times New Roman">
                        <td bgcolor="khaki" style="width: 60px">
                            &nbsp;</td>
                        <td>
                            &nbsp;<asp:TextBox ID="txt_YYYMM" runat="server" BackColor="#E0E0E0" MaxLength="5"
                                ReadOnly="True" Width="70px" Visible="False"></asp:TextBox></td>
                        <td bgcolor="khaki">
                            &nbsp;</td>
                        <td align="center">
                            </td>
                        <td align="center" bgcolor="khaki">
                            <span style="font-size: 9pt; font-family: 新細明體">填報日期</span>:</td>
                        <td align="center">
                            <asp:TextBox ID="txt_RecordDate" runat="server" BackColor="#E0E0E0" MaxLength="5"
                                ReadOnly="True" Width="70px"></asp:TextBox></td>
                    </tr>
                </table>
                <table border="2" cellpadding="2" cellspacing="2" width="720">
                    <tr>
                        <td align="center" bgcolor="khaki" colspan="4">
                            <asp:Label ID="Label1" runat="server" Font-Bold="False" Font-Names="新細明體" Font-Size="Small"
                                ForeColor="Black" Text="專責內部管理工作助理人員異動"></asp:Label>&nbsp; &nbsp;&nbsp; &nbsp;
                            &nbsp;
                        </td>
                    </tr>
                    <tr style="font-family: Times New Roman">
                        <td colspan="4">
                            &nbsp;說明: 本表請於指派或更換助理人員時報備人力資源處。<br />
                        </td>
                    </tr>
                    <tr style="font-family: Times New Roman">
                        <td align="center" bgcolor="khaki" colspan="2">
                            新<span style="font-family: 新細明體">任專責內部管理工作助理人員</span></td>
                        <td align="center" bgcolor="khaki" colspan="2">
                            原<span style="font-family: 新細明體">任專責內部管理工作助理人員</span></td>
                    </tr>
                    <tr style="font-family: Times New Roman">
                        <td bgcolor="khaki" style="width: 65px">
                            <span style="font-size: 9pt; font-family: 新細明體">員工代號</span>:</td>
                        <td>
                            <asp:Label ID="Label2" runat="server" ForeColor="Black" Text="請以下面按鍵拉出單位人員，點選指派人員按下 [檢核] 後，系統會自動產生該員姓名與職稱"></asp:Label>
                            <br />
                            <br />
                            &nbsp;<asp:DropDownList ID="ddl__IntraMgrID1" runat="server" DataSourceID="DS_EMPLOYEE"
                                DataTextField="NAME" DataValueField="STAFF">
                            </asp:DropDownList>
                            &nbsp;<asp:Button ID="btn_Check1" runat="server" Text="檢 核" />
                            &nbsp; &nbsp;
                        </td>
                        <td bgcolor="khaki" style="width: 64px">
                            <span style="font-size: 9pt; font-family: 新細明體">員工代號</span>:</td>
                        <td>
                            <asp:Label ID="Label3" runat="server" ForeColor="Black" Text="請以下面按鍵拉出單位人員，點選指派人員按下 [檢核] 後，系統會自動產生該員姓名與職稱"></asp:Label>
                            <br />
                            <br />
                            &nbsp;<asp:DropDownList ID="ddl__IntraMgrID2" runat="server" DataSourceID="DS_tblIntraMgrMan2"
                                DataTextField="IntraMgrName" DataValueField="IntraMgrID">
                            </asp:DropDownList>
                            &nbsp;<asp:Button ID="btn_Check2" runat="server" Text="檢 核" />
                            &nbsp; &nbsp;
                        </td>
                    </tr>
                    <tr style="font-family: Times New Roman">
                        <td bgcolor="khaki" style="width: 65px">
                            姓 &nbsp;&nbsp; 名:</td>
                        <td>
                            &nbsp;<asp:TextBox ID="txt_IntraMgrName1" runat="server" ReadOnly="True"></asp:TextBox>
                        </td>
                        <td bgcolor="khaki" style="width: 64px">
                            姓 &nbsp;&nbsp; 名:</td>
                        <td>
                            &nbsp;<asp:TextBox ID="txt_IntraMgrName2" runat="server" ReadOnly="True"></asp:TextBox>
                        </td>
                    </tr>
                    <tr style="font-family: Times New Roman">
                        <td bgcolor="khaki" style="width: 65px">
                            職 &nbsp;&nbsp; 稱:</td>
                        <td>
                            &nbsp;<asp:TextBox ID="txt_JobName1" runat="server" ReadOnly="True"></asp:TextBox>
                        </td>
                        <td bgcolor="khaki" style="width: 64px">
                            職 &nbsp;&nbsp; 稱:</td>
                        <td>
                            &nbsp;<asp:TextBox ID="txt_JobName2" runat="server" ReadOnly="True"></asp:TextBox>
                        </td>
                    </tr>
                    <tr style="font-family: Times New Roman">
                        <td bgcolor="khaki" style="width: 65px">
                            擔任日期 :</td>
                        <td>
                            &nbsp;<asp:Label ID="Label4" runat="server" ForeColor="Red" Text="請輸入民國年,  例如:0980601"></asp:Label>
                            <asp:TextBox ID="txt_Date1" runat="server"></asp:TextBox>&nbsp;
                        </td>
                        <td bgcolor="khaki" style="width: 64px">
                            卸任日期 :</td>
                        <td>
                            &nbsp;<asp:Label ID="Label5" runat="server" ForeColor="Red" Text="請輸入民國年,  例如:0980601"></asp:Label>
                            <asp:TextBox ID="txt_Date2" runat="server"></asp:TextBox>&nbsp;
                        </td>
                    </tr>
                    <tr style="font-family: Times New Roman">
                        <td bgcolor="khaki" style="width: 65px">
                            擔任助理人員
                        </td>
                        <td>
                            &nbsp;<asp:Button ID="btn_ADD" runat="server" Text="新增擔任助理人員" />
                        </td>
                        <td bgcolor="khaki" style="width: 64px">
                            卸任助理人員:</td>
                        <td>
                            &nbsp;<asp:Button ID="btn_DEL" runat="server" Text="新增卸任助理人員" />
                        </td>
                    </tr>
                    <tr style="font-family: Times New Roman">
                        <td bgcolor="khaki" style="width: 65px">
                            功 能:</td>
                        <td colspan="3">
                            &nbsp;<asp:Button ID="btn_Save" runat="server" Text="儲 存" />&nbsp;
                            <asp:Button ID="Button1" runat="server" Text="匯出列印" />
                            <asp:Label ID="Label6" runat="server" ForeColor="Red" Text="滑鼠右鍵可直接列印"></asp:Label></td>
                    </tr>
                </table>
                <table border="2" cellpadding="2" cellspacing="2" style="font-family: Times New Roman"
                    width="720">
                    <tr style="font-family: Times New Roman">
                        <td colspan="6">
                            <font size="2">人力資源處 台照：
                                <br />
                                <br />
                                本單位專責內部管理工作助理人員擬指派下列人員擔任，報請備查<span style="color: #000080">。</span><br />
                                目前本單位專責內部管理工作助理人員名單如下:&nbsp;<asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False"
                                    BackColor="#DEBA84" BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px"
                                    CellPadding="2" CellSpacing="1" DataSourceID="DS_tblIntraMgrMan" EmptyDataText="無相關資料">
                                    <RowStyle BackColor="#FFF7E7" Font-Size="Medium" ForeColor="#8C4510" />
                                    <Columns>
                                        <asp:BoundField DataField="BRNO" HeaderText="單位" SortExpression="BRNO" />
                                        <asp:BoundField DataField="BRNAME" HeaderText="單位名稱" SortExpression="BRNAME" />
                                        <asp:BoundField DataField="STAFF" HeaderText="員工代號" SortExpression="STAFF" />
                                        <asp:BoundField DataField="NAME" HeaderText="姓名" SortExpression="NAME" />
                                        <asp:BoundField DataField="JOBNAME" HeaderText="職 稱" SortExpression="JOBNAME" />
                                        <asp:BoundField DataField="EnableDate" HeaderText="擔任日期" SortExpression="EnableDate" />
                                    </Columns>
                                    <FooterStyle BackColor="#F7DFB5" Font-Size="Medium" ForeColor="#8C4510" />
                                    <PagerStyle Font-Size="Medium" ForeColor="#8C4510" HorizontalAlign="Center" />
                                    <SelectedRowStyle BackColor="#738A9C" Font-Bold="True" Font-Size="Medium" ForeColor="White" />
                                    <HeaderStyle BackColor="#A55129" Font-Bold="True" Font-Size="Medium" ForeColor="White" />
                                    <EmptyDataRowStyle Font-Size="Medium" />
                                    <AlternatingRowStyle Font-Size="Medium" />
                                </asp:GridView>
                                &nbsp;
                                <br />
                                異動表如下:<br />
                                <asp:GridView ID="GridView2" runat="server" AutoGenerateColumns="False" BackColor="#DEBA84"
                                    BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px" CellPadding="1" CellSpacing="1"
                                    DataKeyNames="DocNo,Brno,IntraMgrID,Master,status" DataSourceID="DS_tblIntraMgrAssForm"
                                    EmptyDataText="無相關填報資料" Height="152px" Width="704px" Font-Size="XX-Small" HorizontalAlign="Center">
                                    <RowStyle BackColor="#FFF7E7" Font-Size="Medium" ForeColor="#8C4510" />
                                    <EmptyDataRowStyle Font-Size="Medium" />
                                    <Columns>
                                        <asp:BoundField DataField="DocNo" HeaderText="表單編號" ReadOnly="True" SortExpression="DocNo" >
                                            <ControlStyle Font-Size="XX-Small" />
                                            <FooterStyle Font-Size="XX-Small" />
                                            <HeaderStyle Font-Size="Smaller" />
                                            <ItemStyle Font-Size="XX-Small" />
                                        </asp:BoundField>
                                        <asp:BoundField DataField="Brno" HeaderText="單位" ReadOnly="True" SortExpression="Brno" >
                                            <ItemStyle Font-Size="Smaller" />
                                        </asp:BoundField>
                                        <asp:BoundField DataField="BrnoName" HeaderText="單位名稱" SortExpression="BrnoName" >
                                            <ItemStyle Font-Size="XX-Small" />
                                        </asp:BoundField>
                                        <asp:BoundField DataField="IntraMgrID" HeaderText="員工代號" ReadOnly="True" SortExpression="IntraMgrID" >
                                            <ItemStyle Font-Size="Medium" />
                                        </asp:BoundField>
                                        <asp:BoundField DataField="IntraMgrName" HeaderText="姓名" SortExpression="IntraMgrName" >
                                            <ItemStyle Font-Size="Smaller" />
                                        </asp:BoundField>
                                        <asp:BoundField DataField="JobName" HeaderText="職 稱" SortExpression="JobName" >
                                            <ItemStyle Font-Size="Smaller" />
                                        </asp:BoundField>
                                        <asp:BoundField DataField="Master" HeaderText="主辦" ReadOnly="True" SortExpression="Master" >
                                            <ItemStyle Font-Size="Small" />
                                        </asp:BoundField>
                                        <asp:BoundField DataField="EnableDate" HeaderText="擔任日期" SortExpression="EnableDate" >
                                            <ItemStyle Font-Size="Small" />
                                        </asp:BoundField>
                                        <asp:BoundField DataField="DisableDate" HeaderText="卸任日期" SortExpression="DisableDate" >
                                            <ItemStyle Font-Size="Small" />
                                        </asp:BoundField>
                                        <asp:BoundField DataField="status" HeaderText="狀態" ReadOnly="True"
                                            SortExpression="status" >
                                            <ItemStyle Font-Size="Smaller" />
                                        </asp:BoundField>
                                        <asp:CommandField ButtonType="Button" ShowDeleteButton="True" />
                                    </Columns>
                                    <FooterStyle BackColor="#F7DFB5" Font-Size="Medium" ForeColor="#8C4510" />
                                    <PagerStyle Font-Size="Medium" ForeColor="#8C4510" HorizontalAlign="Center" />
                                    <SelectedRowStyle BackColor="#738A9C" Font-Bold="True" Font-Size="Medium" ForeColor="White" />
                                    <HeaderStyle BackColor="#A55129" Font-Bold="True" Font-Size="Medium" ForeColor="White" />
                                    <EditRowStyle Font-Size="Medium" />
                                    <AlternatingRowStyle Font-Size="Medium" />
                                </asp:GridView>
                            </font>
                        </td>
                    </tr>
                </table>
            </div>
            <br />
            單位主管： &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 填報人：&nbsp;<br />
            <br />
            &nbsp;&nbsp;<asp:SqlDataSource ID="DS_tblIntraMgrMan" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
                SelectCommand="SELECT Brno AS BRNO, BrnoName AS BRNAME, IntraMgrID AS STAFF, IntraMgrName AS NAME, JobName AS JOBNAME, EnableDate FROM chb_eform.dbo.tblIntraMgrMan WHERE (Brno = @BRNO2) and (Master = 'S')">
                <SelectParameters>
                    <asp:Parameter Name="BRNO2" />
                </SelectParameters>
            </asp:SqlDataSource>
            <br />
            <asp:SqlDataSource ID="DS_tblIntraMgrMan2" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
                SelectCommand="select IntraMgrID,IntraMgrID+'-'+IntraMgrName as IntraMgrName ,EnableDate from tblIntraMgrMan where Brno = @Brno and Master = 'S'">
                <SelectParameters>
                    <asp:Parameter Name="Brno" />
                </SelectParameters>
            </asp:SqlDataSource>
            <br />
            <asp:SqlDataSource ID="DS_tblIntraMgrAssForm" runat="server" ConflictDetection="CompareAllValues"
                ConnectionString="<%$ ConnectionStrings:chb_eform %>" DeleteCommand="DELETE FROM [tblIntraMgrAssForm] WHERE [DocNo] = @original_DocNo AND [Brno] = @original_Brno AND [IntraMgrID] = @original_IntraMgrID AND [Master] = @original_Master AND [status] = @original_status "
                InsertCommand="INSERT INTO tblIntraMgrAssForm(DocNo, Brno, BrnoName, YYYMM, Keyin, KeyinName, Ext, GoouNum, IntraMgrID, IntraMgrName, JobName, Master, EnableDate, DisableDate, status) VALUES (@DocNo, @Brno, @BrnoName, @YYYMM, @Keyin, @KeyinName, @Ext, @GoouNum, @IntraMgrID, @IntraMgrName, @JobName, @Master, @EnableDate, @DisableDate, @status)"
                OldValuesParameterFormatString="original_{0}" SelectCommand="SELECT * FROM tblIntraMgrAssForm where DocNo = @DocNo"
                UpdateCommand="UPDATE [tblIntraMgrAssForm] SET [BrnoName] = @BrnoName, [YYYMM] = @YYYMM, [Keyin] = @Keyin, [Ext] = @Ext, [GoouNum] = @GoouNum, [IntraMgrName] = @IntraMgrName, [JobName] = @JobName, [EnableDate] = @EnableDate, [DisableDate] = @DisableDate WHERE [DocNo] = @original_DocNo AND [Brno] = @original_Brno AND [IntraMgrID] = @original_IntraMgrID AND [Master] = @original_Master AND [status] = @original_status AND (([BrnoName] = @original_BrnoName) OR ([BrnoName] IS NULL AND @original_BrnoName IS NULL)) AND (([YYYMM] = @original_YYYMM) OR ([YYYMM] IS NULL AND @original_YYYMM IS NULL)) AND (([Keyin] = @original_Keyin) OR ([Keyin] IS NULL AND @original_Keyin IS NULL)) AND (([Ext] = @original_Ext) OR ([Ext] IS NULL AND @original_Ext IS NULL)) AND (([GoouNum] = @original_GoouNum) OR ([GoouNum] IS NULL AND @original_GoouNum IS NULL)) AND (([IntraMgrName] = @original_IntraMgrName) OR ([IntraMgrName] IS NULL AND @original_IntraMgrName IS NULL)) AND (([JobName] = @original_JobName) OR ([JobName] IS NULL AND @original_JobName IS NULL)) AND (([EnableDate] = @original_EnableDate) OR ([EnableDate] IS NULL AND @original_EnableDate IS NULL)) AND (([DisableDate] = @original_DisableDate) OR ([DisableDate] IS NULL AND @original_DisableDate IS NULL))">
                <SelectParameters>
                    <asp:Parameter Name="DocNo" />
                </SelectParameters>
                <DeleteParameters>
                    <asp:Parameter Name="original_DocNo" />
                    <asp:Parameter Name="original_Brno" />
                    <asp:Parameter Name="original_IntraMgrID" />
                    <asp:Parameter Name="original_Master" />
                    <asp:Parameter Name="original_status" />
                </DeleteParameters>
                <UpdateParameters>
                    <asp:Parameter Name="BrnoName" Type="String" />
                    <asp:Parameter Name="YYYMM" Type="String" />
                    <asp:Parameter Name="Keyin" Type="String" />
                    <asp:Parameter Name="Ext" Type="String" />
                    <asp:Parameter Name="GoouNum" Type="String" />
                    <asp:Parameter Name="IntraMgrName" Type="String" />
                    <asp:Parameter Name="JobName" Type="String" />
                    <asp:Parameter Name="EnableDate" Type="String" />
                    <asp:Parameter Name="DisableDate" Type="String" />
                    <asp:Parameter Name="original_DocNo" Type="String" />
                    <asp:Parameter Name="original_Brno" Type="String" />
                    <asp:Parameter Name="original_IntraMgrID" Type="String" />
                    <asp:Parameter Name="original_Master" Type="String" />
                    <asp:Parameter Name="original_status" Type="String" />
                    <asp:Parameter Name="original_BrnoName" Type="String" />
                    <asp:Parameter Name="original_YYYMM" Type="String" />
                    <asp:Parameter Name="original_Keyin" Type="String" />
                    <asp:Parameter Name="original_Ext" Type="String" />
                    <asp:Parameter Name="original_GoouNum" Type="String" />
                    <asp:Parameter Name="original_IntraMgrName" Type="String" />
                    <asp:Parameter Name="original_JobName" Type="String" />
                    <asp:Parameter Name="original_EnableDate" Type="String" />
                    <asp:Parameter Name="original_DisableDate" Type="String" />
                </UpdateParameters>
                <InsertParameters>
                    <asp:Parameter Name="DocNo" Type="String" />
                    <asp:Parameter Name="Brno" Type="String" />
                    <asp:Parameter Name="BrnoName" Type="String" />
                    <asp:Parameter Name="YYYMM" Type="String" />
                    <asp:Parameter Name="Keyin" Type="String" />
                    <asp:Parameter Name="KeyinName" />
                    <asp:Parameter Name="Ext" Type="String" />
                    <asp:Parameter Name="GoouNum" Type="String" />
                    <asp:Parameter Name="IntraMgrID" Type="String" />
                    <asp:Parameter Name="IntraMgrName" Type="String" />
                    <asp:Parameter Name="JobName" Type="String" />
                    <asp:Parameter Name="Master" Type="String" />
                    <asp:Parameter Name="EnableDate" Type="String" />
                    <asp:Parameter Name="DisableDate" Type="String" />
                    <asp:Parameter Name="status" Type="String" />
                </InsertParameters>
            </asp:SqlDataSource>
            <br />
            <br />
            <br />
            &nbsp; &nbsp;<br />
            <asp:SqlDataSource ID="DS_EMPLOYEE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
                SelectCommand="select STAFF,STAFF+'-'+NAME as NAME from EMPLOYEE where STATUS = '1' and BRNO = @BRNO">
                <SelectParameters>
                    <asp:Parameter Name="BRNO" />
                </SelectParameters>
            </asp:SqlDataSource>
            <asp:SqlDataSource ID="DS_BRANCH" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub %>"
                SelectCommand="SELECT BRNO, BRNAME FROM chb_pub.dbo.BRANCH WHERE (BRNO = @gBrNo)">
                <SelectParameters>
                    <asp:FormParameter FormField="gBrNo" Name="gBrNo" />
                </SelectParameters>
            </asp:SqlDataSource>
            <asp:SqlDataSource ID="DS_EMPLOYEE1" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
                SelectCommand="SELECT [STAFF], [NAME], [BRNO], [JOBCODE], [STATUS] FROM [EMPLOYEE] WHERE (BRNO = @BRNO) AND (STATUS='1')">
                <SelectParameters>
                    <asp:Parameter Name="BRNO" />
                </SelectParameters>
            </asp:SqlDataSource>
            <asp:SqlDataSource ID="DS_JOBCODE" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
                SelectCommand="SELECT   E.STAFF, E.NAME, E.JOBCODE, J.JOBNAME  FROM  EMPLOYEE AS E INNER JOIN JOBCODE AS J ON E.JOBCODE = J.JOBCODE WHERE     E.STAFF =@STAFF ">
                <SelectParameters>
                    <asp:Parameter Name="STAFF" />
                </SelectParameters>
            </asp:SqlDataSource>
            <asp:SqlDataSource ID="DS_tblGoouNum" runat="server" ConnectionString="<%$ ConnectionStrings:chb_pub1 %>"
                SelectCommand="SELECT * FROM [tblGoouNum]">
                <SelectParameters>
                    <asp:Parameter Name="Brno" />
                </SelectParameters>
            </asp:SqlDataSource>
            <asp:SqlDataSource ID="DS_tblLogDetail" runat="server" ConnectionString="<%$ ConnectionStrings:chb_eform %>"
                DeleteCommand="DELETE FROM tblLogDetail WHERE (DocNo = @DocNo1) and (DocType = 'DS')"
                InsertCommand="INSERT INTO [tblLogDetail] ([DocType], [DocNo], [BrNo], [EmpId], [RecordDate], [DataFlag], [FormType], [YYMM], [Sign1], [Action1], [SignDate1], [SignComment1], [Sign2], [Action2], [SignDate2], [SignComment2], [DecManager], [DecDate], [FlowStatus], [Ver]) VALUES (@DocType, @DocNo, @BrNo, @EmpId, @RecordDate, @DataFlag, @FormType, @YYMM, @Sign1, @Action1, @SignDate1, @SignComment1, @Sign2, @Action2, @SignDate2, @SignComment2, @DecManager, @DecDate, @FlowStatus, @Ver)"
                SelectCommand="SELECT DocType, DocNo, BrNo, EmpId, RecordDate, DataFlag, FormType, YYMM, Sign1, Action1, SignDate1, SignComment1, Sign2, Action2, SignDate2, SignComment2, DecManager, DecDate, FlowStatus, Ver FROM tblLogDetail WHERE DocNo = @DocNo "
                UpdateCommand="UPDATE [tblLogDetail] SET [EmpId] = @EmpId, [RecordDate] = @RecordDate, [DataFlag] = @DataFlag, [Sign1] = @Sign1, [Action1] = @Action1, [SignDate1] = @SignDate1, [SignComment1] = @SignComment1,  [DecManager] = @DecManager, [DecDate] = @DecDate, [FlowStatus] = @FlowStatus, [Ver] = @Ver WHERE [DocNo] = @DocNo">
                <InsertParameters>
                    <asp:Parameter DefaultValue="" Name="DocType" Type="String" />
                    <asp:Parameter DefaultValue="" Name="DocNo" Type="String" />
                    <asp:Parameter Name="BrNo" Type="String" />
                    <asp:Parameter Name="EmpId" Type="String" />
                    <asp:Parameter DefaultValue="" Name="RecordDate" Type="DateTime" />
                    <asp:Parameter DefaultValue="" Name="DataFlag" Type="String" />
                    <asp:Parameter Name="FormType" Type="String" />
                    <asp:Parameter Name="YYMM" Type="String" />
                    <asp:Parameter Name="Sign1" Type="String" />
                    <asp:Parameter Name="Action1" Type="String" />
                    <asp:Parameter Name="SignDate1" Type="DateTime" />
                    <asp:Parameter Name="SignComment1" Type="String" />
                    <asp:Parameter Name="Sign2" Type="String" />
                    <asp:Parameter Name="Action2" Type="String" />
                    <asp:Parameter Name="SignDate2" Type="DateTime" />
                    <asp:Parameter Name="SignComment2" Type="String" />
                    <asp:Parameter Name="DecManager" Type="String" />
                    <asp:Parameter Name="DecDate" Type="DateTime" />
                    <asp:Parameter Name="FlowStatus" Type="String" />
                    <asp:Parameter Name="Ver" Type="Int16" />
                </InsertParameters>
                <DeleteParameters>
                    <asp:Parameter Name="DocNo1" />
                </DeleteParameters>
                <SelectParameters>
                    <asp:Parameter Name="DocNo" />
                </SelectParameters>
                <UpdateParameters>
                    <asp:Parameter Name="EmpId" />
                    <asp:Parameter Name="RecordDate" />
                    <asp:Parameter Name="DataFlag" />
                    <asp:Parameter Name="Sign1" />
                    <asp:Parameter Name="Action1" />
                    <asp:Parameter Name="SignDate1" />
                    <asp:Parameter Name="SignComment1" />
                    <asp:Parameter Name="DecManager" />
                    <asp:Parameter Name="DecDate" />
                    <asp:Parameter Name="FlowStatus" />
                    <asp:Parameter Name="Ver" />
                    <asp:Parameter Name="DocNo" />
                </UpdateParameters>
            </asp:SqlDataSource>
            <br />
            <br />
            <asp:HiddenField ID="hid_savecheck" runat="server" />
            &nbsp;<br />
        </span><br />
    
    </div>
    </form>
</body>
</html>
