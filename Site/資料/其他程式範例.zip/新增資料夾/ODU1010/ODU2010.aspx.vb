﻿
Partial Class Program_ODU1010_ODU2010
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    '現行名單查詢：GridView2
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        If DropDownList1.SelectedValue = "all" Then
            DS_tblIntraMgrManAll.SelectCommand = "SELECT Brno AS BRNO, BrnoName AS BRNAME, IntraMgrID AS STAFF, IntraMgrName AS NAME, JobName AS JOBNAME,EnableDate FROM chb_eform.dbo.tblIntraMgrMan  WHERE  (Master = 'S') "
        Else
            DS_tblIntraMgrManAll.SelectCommand = "SELECT Brno AS BRNO, BrnoName AS BRNAME, IntraMgrID AS STAFF, IntraMgrName AS NAME, JobName AS JOBNAME,EnableDate  FROM chb_eform.dbo.tblIntraMgrMan WHERE (Brno = '" & DropDownList1.SelectedValue & "') AND (Master = 'S')"
        End If
        GridView2.DataBind()
        GridView2.Visible = True

    End Sub

    '歷任名單查詢：GridView1
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click

        If DropDownList1.SelectedValue = "all" Then
            DS_tblIntraMgrManLogAll.SelectCommand = "SELECT Brno, BrnoName, IntraMgrID, IntraMgrName, JobName, EnableDate, DisableDate FROM tblIntraMgrAssForm WHERE (DisableDate <> '') and (Master = 'S') AND (DocNo IN (SELECT DocNo FROM tblLogDetail WHERE (DocType = 'DU') AND (FlowStatus = '3')))"
        Else
            DS_tblIntraMgrManLogAll.SelectCommand = "select Brno,BrnoName,IntraMgrID,IntraMgrName,JobName,EnableDate,DisableDate from tblIntraMgrAssForm where (Brno = '" & DropDownList1.SelectedValue & "') and (DisableDate <> '') and (Master = 'S')and DocNo in (select DocNo from tblLogDetail where (DocType = 'DU') and (FlowStatus = '3'))"
        End If
        GridView1.DataBind()
        GridView1.Visible = True

    End Sub

    '開/關 GridView2
    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click

        If GridView2.Visible = True Then
            GridView2.Visible = False
        Else
            GridView2.Visible = True
        End If

    End Sub

    '開/關 GridView1
    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button5.Click

        If GridView1.Visible = True Then
            GridView1.Visible = False
        Else
            GridView1.Visible = True
        End If

    End Sub

    '===============將Gridview轉成excel檔===============================
    '記的aspx.vb檔前端要加Imports System.IO.StringWriter跟Imports System.Web.UI.HtmlTextWriter
    Protected Sub btn_excel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_excel.Click
        GridView2.Visible = True
        '欄位為文字的 CSS設定
        Dim style As String = "<style> .text { mso-number-format:""\@""; } </style> "
        '以下為 GridView 轉 Excel 的程式
        Response.Clear()
        Response.AddHeader("content-disposition", "attachment;filename=IntraMgrManAss.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excels"
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Dim stringWrite As New System.IO.StringWriter()
        Dim htmlWrite As New HtmlTextWriter(stringWrite)

        If GridView2.Visible = True Then
            GridView2.RenderControl(htmlWrite) '顯示分行 
        End If

        Response.Write(style)
        Response.Write(stringWrite.ToString())
        Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>") '內容亂碼使用
        Response.End()
    End Sub

    '===============將Gridview轉成excel檔===============================
    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        GridView1.Visible = True
        '欄位為文字的 CSS設定
        Dim style As String = "<style> .text { mso-number-format:""\@""; } </style> "
        '以下為 GridView 轉 Excel 的程式
        Response.Clear()
        Response.AddHeader("content-disposition", "attachment;filename=IntraMgrManAssLog.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excels"
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Dim stringWrite As New System.IO.StringWriter()
        Dim htmlWrite As New HtmlTextWriter(stringWrite)

        If GridView1.Visible = True Then
            GridView1.RenderControl(htmlWrite) '顯示分行 
        End If

        Response.Write(style)
        Response.Write(stringWrite.ToString())
        Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>") '內容亂碼使用
        Response.End()
    End Sub


    '將Gridview轉成excel檔(加此 sub 就不會出現「run at server」錯誤)
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        ' 加此 sub 就不會出現「run at server」錯誤
    End Sub

    ''將Gridview轉成excel檔(將每個欄位格式都設成「文字」)
    'Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
    '    '將每個欄位格式都設成「文字」
    '    Dim i As Integer
    '    For i = 0 To 16
    '        If e.Row.RowType = DataControlRowType.DataRow Then
    '            e.Row.Cells(i).Attributes.Add("class", "text")
    '        End If
    '    Next
    'End Sub
End Class
