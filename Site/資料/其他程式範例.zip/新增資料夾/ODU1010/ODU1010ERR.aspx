﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODU1010ERR.aspx.vb" Inherits="Program_ODU1010_ODU1010ERR" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>專責內部管理工作助理人員指派表</title>
</head>
<body style="font-size: 20pt" bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div>
        <asp:Label ID="Label1" runat="server" ForeColor="Red" Height="136px" Text="非內部管理工作人員或單位主管(分行經理,區營運處處長,總行處長)不得填寫專責內部管理工作助理人員指派表"
            Width="680px"></asp:Label></div>
    </form>
</body>
</html>
