﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ODR3020.aspx.vb" Inherits="DotNet_Program_ODR3020_ODR3020" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <style type="text/css">

.t5
{
    COLOR: #ff0000;
    FONT-FAMILY: 新細明體;
    FONT-SIZE: 12px
}
        .style1
        {
            font-family: 標楷體;
        }
        .style2
        {
            text-align: center;
        }
        .style3
        {
            font-size: large;
        }
        .style4
        {
            color: #0000FF;
        }
        .style5
        {
            width: 100%;
        }
        .style6
        {
            font-size: x-small;
        }
    </style>
</head>
<body bgcolor="#ffffcc">
    <form id="form1" runat="server">
    <div class="style2">
    
        <div class="style2">
            <br />
            <span class="style1"><strong><span class="style3">本國銀行資金運用於大陸彙總表-稽催表列印</span><br />
            <br style="font-size: x-small" />
            </strong>
            <asp:Label ID="lbl年月" runat="server" style="color: #0000FF"></asp:Label>
            <span class="style4">未填報之分行<br />
            <span class="style6">&nbsp;</span></span><table class="style5">
                <tr>
                    <td align="center">
                        <asp:GridView ID="gvData" runat="server" AutoGenerateColumns="False" 
                            BackColor="White" BorderColor="#CC9966" BorderStyle="None" BorderWidth="1px" 
                            CellPadding="4" DataKeyNames="BRNO" DataSourceID="sds未填報" 
                            EnableModelValidation="True" Width="40%" AllowSorting="True">
                            <Columns>
                                <asp:BoundField DataField="BRNO" HeaderText="單位代號" ReadOnly="True" 
                                    SortExpression="BRNO" />
                                <asp:BoundField DataField="BRNAME" HeaderText="單位名稱" SortExpression="BRNAME" />
                            </Columns>
                            <FooterStyle BackColor="#FFFFCC" ForeColor="#330099" />
                            <HeaderStyle BackColor="#990000" Font-Bold="True" ForeColor="#FFFFCC" />
                            <PagerStyle BackColor="#FFFFCC" ForeColor="#330099" HorizontalAlign="Center" />
                            <RowStyle BackColor="White" ForeColor="#330099" />
                            <SelectedRowStyle BackColor="#FFCC66" Font-Bold="True" ForeColor="#663399" />
                        </asp:GridView>
                        <br />
                        <asp:Label ID="lblCount" runat="server" style="color: #FF0000"></asp:Label>
                    </td>
                </tr>
            </table>
            </span>
        </div>
        <asp:SqlDataSource ID="sds未填報" runat="server" 
            ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
            SelectCommand="SELECT BRNO, BRNAME FROM chb_pub.dbo.BRANCH WHERE (BRNO NOT IN (SELECT BrNo FROM tblLogDetail WHERE (DocType = 'DR') AND (YYMM = REPLACE(@YYMM, '/', '')) AND (FlowStatus &gt;= 3))) AND (BRNO &lt;&gt; '0000') ORDER BY BRNO">
            <SelectParameters>
                <asp:ControlParameter ControlID="lbl年月" Name="YYMM" PropertyName="Text" />
            </SelectParameters>
        </asp:SqlDataSource>
    
        <asp:SqlDataSource ID="sds已填報筆數" runat="server" 
            ConnectionString="<%$ ConnectionStrings:chb_eform %>" 
            SelectCommand="SELECT COUNT(*) AS 筆數 FROM tblLogDetail WHERE (DocType = 'DR') AND (YYMM = REPLACE(@YYMM, '/', '')) AND (FlowStatus &gt;= 3)">
            <SelectParameters>
                <asp:ControlParameter ControlID="lbl年月" Name="YYMM" PropertyName="Text" />
            </SelectParameters>
        </asp:SqlDataSource>
    
    </div>
    </form>
</body>
</html>
