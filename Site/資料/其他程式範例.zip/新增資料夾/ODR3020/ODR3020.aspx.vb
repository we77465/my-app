﻿
Partial Class DotNet_Program_ODR3020_ODR3020
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        Dim YYY As String = Request("txtYYMMS")        Me.lbl年月.Text = YYY

        Dim dv As Data.DataView = Me.sds已填報筆數.Select(New DataSourceSelectArguments)

        If dv.Count > 0 Then
            Me.lblCount.Text = "共有 " & dv(0)(0).ToString & " 家分行已填報完畢"
        End If

        dv.Dispose()
    End Sub

End Class
