﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// 新臺幣定期存款專案利率申請 - 新增/編輯申請單。
/// 僅「經辦」或「襄理」可進入（§2 權限設定：填報角色 = 經辦 + 襄理）；
/// 申請單在 Status = 0 (草稿/退回) 時才可修改。
/// </summary>
public partial class NtdEdit : Page
{
    protected NtdCurrentUser Me { get { return NtdCurrentUser.Current; } }

    /// <summary>URL 上的申請單號 (?no=)，空字串代表新增。</summary>
    private string ApplyNo { get { return (Request.QueryString["no"] ?? "").Trim(); } }

    protected void Page_Load(object sender, EventArgs e)
    {
        LblUser.Text = string.Format("{0} {1} ({2} {3}) [職等 {4}]",
            Me.EmpID, Me.EmpName, Me.BranchCode, Me.BranchName, Me.TitleLevel);

        // 每次都設定控制項文字，避免 ASPX 中文屬性值的編碼問題
        InitButtons();

        // §2 權限設定：填報角色 = 經辦 (TitleLevel=1) + 襄理 (TitleLevel=2)
        if (!Me.CanCreateApply)
        {
            ShowMessage("您的職位無法新增/編輯申請，僅經辦或襄理可操作。", "err");
            DisableForm();
            return;
        }

        if (IsPostBack) return;

        TxtApplyDate.Text = DateTime.Today.ToString("yyyy-MM-dd");
        LblBranch.Text = Me.BranchCode + " " + Me.BranchName;
        LblStatus.Text = StatusName(0);

        if (string.IsNullOrEmpty(ApplyNo))
        {
            // 新增：預設帶一筆空白明細
            BindDetailRows(new List<DetailRow> { new DetailRow { PeriodMonth = 12 } });
        }
        else
        {
            LoadExistingApply(ApplyNo);
            // 儲存草稿成功後重導回此頁時，顯示綠色提示
            if (Request.QueryString["saved"] == "1")
                ShowMessage("\u8349\u7a3f\u5132\u5b58\u6210\u529f\u3002\u53ef\u7e7c\u7e8c\u7de8\u8f2f\u6216\u9ede\u300c\u9001\u51fa\u7533\u8acb\u300d\u9032\u5165\u7c3d\u6838\u3002", "ok");  // 草稿儲存成功。可繼續編輯或點「送出申請」進入簽核。
        }
    }

    /// <summary>每次 Load 都重設按鈕/選項文字，確保不受 ASPX 編碼影響。</summary>
    private void InitButtons()
    {
        BtnSaveDraft.Text = "\u5132\u5b58\u8349\u7a3f";   // 儲存草稿
        BtnSubmit.Text = "\u9001\u51fa\u7533\u8acb";   // 送出申請
        BtnBack.Text = "\u8fd4\u56de\u5217\u8868";   // 返回列表
        BtnQueryCustomer.Text = "\u67e5\u8a62\u5ba2\u6236";   // 查詢客戶

        // 利害關係人選項（每次 Load 補齊，PostBack 時 ViewState 會保留選取值）
        if (RblIsRelated.Items.Count == 0)
        {
            RblIsRelated.Items.Add(new ListItem("\u662f", "Y"));  // 是
            RblIsRelated.Items.Add(new ListItem("\u5426", "N"));  // 否
        }
    }

    protected string NavUrl(string relativeUrl) { return Me.AppendSid(relativeUrl); }

    // ===== Repeater helper（供 ASPX DataBind 運算式呼叫）=====

    /// <summary>日期值→yyyy-MM-dd 字串；null/DBNull 回傳空字串。</summary>
    protected static string GetDateValue(object val)
    {
        if (val == null || val == DBNull.Value) return "";
        try { return Convert.ToDateTime(val).ToString("yyyy-MM-dd"); }
        catch { return ""; }
    }

    /// <summary>可空 decimal 值→字串；null/DBNull 回傳空字串。</summary>
    protected static string GetDecimalValue(object val)
    {
        if (val == null || val == DBNull.Value) return "";
        try { return Convert.ToDecimal(val).ToString("0.####"); }
        catch { return ""; }
    }

    // ===== 統編查詢客戶名稱 (UpdatePanel 局部更新) =====

    protected void BtnQueryCustomer_Click(object sender, EventArgs e)
    {
        LblQueryMsg.Text = "";
        string customerID = TxtCustomerID.Text.Trim();

        if (string.IsNullOrEmpty(customerID))
        { LblQueryMsg.Text = "\u8acb\u5148\u8f38\u5165\u7d71\u4e00\u7de8\u865f"; return; }  // 請先輸入統一編號

        if (customerID.Length < 8 || customerID.Length > 11)
        { LblQueryMsg.Text = "\u7d71\u4e00\u7de8\u865f\u683c\u5f0f\u932f\u8aa4\uff088-11\u78bc\uff09"; return; }  // 統一編號格式錯誤（8-11碼）

        try
        {
            F0101 result = RiskUtils.GetF0101Rs("System", customerID, "NTD",
                Me.BranchCode.Length >= 4 ? Me.BranchCode.Substring(0, 4) : Me.BranchCode);

            if (result.isSuccess && !string.IsNullOrEmpty(result.CNAME))
                TxtCustomerName.Text = result.CNAME;
            else
            {
                TxtCustomerName.Text = "";
                LblQueryMsg.Text = "\u67e5\u7121\u6b64\u7d71\u4e00\u7de8\u865f\u5c0d\u61c9\u7684\u5ba2\u6236\u8cc7\u6599";  // 查無此統一編號對應的客戶資料
            }
        }
        catch (Exception ex)
        {
            LblQueryMsg.Text = "\u67e5\u8a62\u5931\u6557\uff1a" + ex.Message;  // 查詢失敗：
        }
    }

    // ===== 載入既有申請單 =====

    private void LoadExistingApply(string applyNo)
    {
        var mainTable = Query(@"
            SELECT  ntd.*, ISNULL(branch.BRNAME, '') AS BranchName
            FROM    dbo.NTD_Main    ntd
            LEFT JOIN chb_pub.dbo.BRANCH branch ON branch.BRNO = ntd.BranchCode
            WHERE   ntd.ApplyNo = @ApplyNo",
            P("@ApplyNo", applyNo));

        if (mainTable.Rows.Count == 0)
        {
            ShowMessage("\u627e\u4e0d\u5230\u7533\u8acb\u55ae\uff1a" + applyNo, "err");  // 找不到申請單：
            DisableForm();
            return;
        }

        var row = mainTable.Rows[0];
        int currentStatus = Convert.ToInt32(row["Status"]);

        LitTitle.Text = "\u7de8\u8f2f\u7533\u8acb";  // 編輯申請
        LblApplyNo.Text = applyNo;
        LblBranch.Text = row["BranchCode"] + " " + row["BranchName"];
        TxtApplyDate.Text = Convert.ToDateTime(row["ApplyDate"]).ToString("yyyy-MM-dd");
        TxtGroupName.Text = Convert.ToString(row["GroupName"]);
        TxtCustomerID.Text = Convert.ToString(row["CustomerID"]);
        TxtCustomerName.Text = Convert.ToString(row["CustomerName"]);
        TxtBranchNote.Text = Convert.ToString(row["BranchNote"]);
        LblStatus.Text = StatusName(currentStatus);

        if (row["IsRelated"] != DBNull.Value)
        {
            string isRelated = Convert.ToString(row["IsRelated"]);
            var item = RblIsRelated.Items.FindByValue(isRelated);
            if (item != null) item.Selected = true;
        }

        if (row["Contrib3M"] != DBNull.Value) TxtContrib3M.Text = Convert.ToDecimal(row["Contrib3M"]).ToString("0.##");
        if (row["Contrib6M"] != DBNull.Value) TxtContrib6M.Text = Convert.ToDecimal(row["Contrib6M"]).ToString("0.##");
        if (row["Contrib1Y"] != DBNull.Value) TxtContrib1Y.Text = Convert.ToDecimal(row["Contrib1Y"]).ToString("0.##");
        if (row["RelatedAmt"] != DBNull.Value) TxtRelatedAmt.Text = Convert.ToDecimal(row["RelatedAmt"]).ToString("0.##");

        // 只有自己建的、Status=0 的單才可編輯
        bool isEditableNow = currentStatus == 0
            && string.Equals(Convert.ToString(row["CreateUser"]), Me.EmpID,
                             StringComparison.OrdinalIgnoreCase);

        if (!isEditableNow)
        {
            ShowMessage("\u6b64\u7533\u8acb\u55ae\u76ee\u524d\u72c0\u614b\u7121\u6cd5\u7de8\u8f2f\u3002", "warn");  // 此申請單目前狀態無法編輯。
            DisableForm();
        }

        // 載入明細
        var detailTable = Query(
            "SELECT * FROM dbo.NTD_Detail WHERE ApplyNo = @ApplyNo ORDER BY SeqNo",
            P("@ApplyNo", applyNo));
        RptDetail.DataSource = detailTable;
        RptDetail.DataBind();

        // 載入簽核紀錄
        LoadLog(applyNo);
    }

    /// <summary>鎖定所有輸入欄位，隱藏操作按鈕（唯讀模式）。</summary>
    private void DisableForm()
    {
        TxtGroupName.Enabled = false;
        TxtCustomerID.Enabled = false;
        TxtCustomerName.Enabled = false;
        BtnQueryCustomer.Enabled = false;
        TxtBranchNote.Enabled = false;
        TxtApplyDate.Enabled = false;
        TxtContrib3M.Enabled = false;
        TxtContrib6M.Enabled = false;
        TxtContrib1Y.Enabled = false;
        TxtRelatedAmt.Enabled = false;
        RblIsRelated.Enabled = false;
        BtnSaveDraft.Visible = false;
        BtnSubmit.Visible = false;
    }

    private void LoadLog(string applyNo)
    {
        var logTable = Query(
            "SELECT * FROM dbo.NTD_Log WHERE ApplyNo = @ApplyNo ORDER BY LogID DESC",
            P("@ApplyNo", applyNo));
        GvLog.DataSource = logTable;
        GvLog.DataBind();
        PnlLog.Visible = logTable.Rows.Count > 0;
    }

    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect(Me.AppendSid("Main.aspx"), true);
    }

    protected void BtnSaveDraft_Click(object sender, EventArgs e) { SaveApply(false); }
    protected void BtnSubmit_Click(object sender, EventArgs e) { SaveApply(true); }

    // ===== 儲存 / 送出申請 =====

    private void SaveApply(bool submitToWorkflow)
    {
        // --- 必填驗證（驗證失敗→顯示錯誤並重繪明細，不清空表單）---
        if (string.IsNullOrWhiteSpace(TxtCustomerID.Text))
        { ShowErrorAndRebind("\u8acb\u586b\u5beb\u5ba2\u6236\u7d71\u7de8/\u8eab\u5206\u8b49\u3002"); return; }  // 請填寫客戶統編/身分證。

        if (string.IsNullOrWhiteSpace(TxtCustomerName.Text))
        { ShowErrorAndRebind("\u8acb\u5148\u9ede\u300c\u67e5\u8a62\u5ba2\u6236\u300d\u5e36\u5165\u5ba2\u6236\u540d\u7a31\u3002"); return; }  // 請先點「查詢客戶」帶入客戶名稱。

        if (string.IsNullOrEmpty(RblIsRelated.SelectedValue))
        { ShowErrorAndRebind("\u8acb\u9078\u64c7\u662f\u5426\u5c6c\u5229\u5bb3\u95dc\u4fc2\u4eba\u3002"); return; }  // 請選擇是否屬利害關係人。

        if ((TxtBranchNote.Text ?? "").Length > 3000)
        { ShowErrorAndRebind("\u7533\u8acb\u55ae\u4f4d\u8aaa\u660e\u8d85\u904e 3,000 \u5b57\u3002"); return; }  // 申請單位說明超過 3,000 字。

        var detailRows = ReadDetailFromForm();
        if (detailRows.Count == 0)
        { ShowErrorAndRebind("\u81f3\u5c11\u8981\u6709\u4e00\u7b46\u660e\u7d30\u3002"); return; }  // 至少要有一筆明細。

        foreach (var detail in detailRows)
        {
            if (string.IsNullOrEmpty(detail.DepositType))
            { ShowErrorAndRebind("\u660e\u7d30\u5217\u7684\u5b58\u6b3e\u7a2e\u985e\u70ba\u5fc5\u586b\u9805\u76ee\u3002"); return; }  // 明細列的存款種類為必填項目。
        }

        DateTime applyDate;
        if (!DateTime.TryParse(TxtApplyDate.Text, out applyDate)) applyDate = DateTime.Today;

        // 申請總金額由明細列自動加總，不再由獨立欄位手動輸入
        decimal totalAmount = 0m;
        foreach (var d in detailRows)
            if (d.Amount.HasValue) totalAmount += d.Amount.Value;

        decimal? contrib3M = ParseNullableDecimal(TxtContrib3M.Text);
        decimal? contrib6M = ParseNullableDecimal(TxtContrib6M.Text);
        decimal? contrib1Y = ParseNullableDecimal(TxtContrib1Y.Text);
        decimal? relatedAmt = ParseNullableDecimal(TxtRelatedAmt.Text);

        string savedApplyNo = ApplyNo;

        try
        {
            using (var conn = new SqlConnection(ConnStr))
            {
                conn.Open();
                using (var transaction = conn.BeginTransaction())
                {
                    bool isNew = string.IsNullOrEmpty(savedApplyNo);
                    int fromStatus = 0;
                    int toStatus = submitToWorkflow ? 1 : 0;

                    if (isNew)
                    {
                        savedApplyNo = GenerateApplyNo(conn, transaction);
                        InsertMain(conn, transaction, savedApplyNo, applyDate, totalAmount, toStatus,
                                   contrib3M, contrib6M, contrib1Y, relatedAmt);
                    }
                    else
                    {
                        fromStatus = ReadStatusForEdit(conn, transaction, savedApplyNo);
                        UpdateMain(conn, transaction, savedApplyNo, applyDate, totalAmount, toStatus,
                                   contrib3M, contrib6M, contrib1Y, relatedAmt);
                        DeleteDetailsForRewrite(conn, transaction, savedApplyNo);
                    }

                    InsertDetailRows(conn, transaction, savedApplyNo, detailRows);
                    InsertLog(conn, transaction, savedApplyNo,
                              isNew ? "CREATE" : (submitToWorkflow ? "SUBMIT" : "EDIT"),
                              fromStatus, toStatus,
                              submitToWorkflow ? "\u9001\u51fa\u7533\u8acb" : "\u5b58\u8349\u7a3f");  // 送出申請 / 存草稿
                    transaction.Commit();
                }
            }
        }
        catch (InvalidOperationException ex)
        {
            ShowErrorAndRebind(ex.Message);
            return;
        }

        if (submitToWorkflow)
        {
            // 送出後跳到唯讀檢視頁
            Response.Redirect(Me.AppendSid("View.aspx?no=" + savedApplyNo), true);
        }
        else
        {
            // 儲存草稿：留在 Edit 頁，顯示成功提示，讓使用者可繼續編輯或送出
            Response.Redirect(Me.AppendSid("Edit.aspx?no=" + savedApplyNo + "&saved=1"), true);
        }
    }

    // ===== 產生申請單號 =====

    private static string GenerateApplyNo(SqlConnection conn, SqlTransaction transaction)
    {
        string prefix = "NTD" + DateTime.Now.ToString("yyyyMMdd");
        using (var cmd = new SqlCommand(@"
            SELECT ISNULL(MAX(CAST(RIGHT(ApplyNo, 4) AS INT)), 0) + 1
            FROM   dbo.NTD_Main
            WHERE  ApplyNo LIKE @Prefix + '%'", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@Prefix", prefix);
            int nextSeq = Convert.ToInt32(cmd.ExecuteScalar());
            return prefix + nextSeq.ToString("D4");
        }
    }

    // ===== 主檔 INSERT / UPDATE =====

    private void InsertMain(SqlConnection conn, SqlTransaction transaction,
                            string applyNo, DateTime applyDate, decimal totalAmount, int initialStatus,
                            decimal? contrib3M, decimal? contrib6M, decimal? contrib1Y, decimal? relatedAmt)
    {
        using (var cmd = new SqlCommand(@"
            INSERT INTO dbo.NTD_Main
                (ApplyNo, BranchCode, ApplyDate, CustomerName, CustomerID, GroupName,
                 TotalAmount, IsRelated,
                 Contrib3M, Contrib6M, Contrib1Y, RelatedAmt, BranchNote,
                 Status, CreateUser, CreateTime)
            VALUES
                (@ApplyNo, @BranchCode, @ApplyDate, @CustomerName, @CustomerID, @GroupName,
                 @TotalAmount, @IsRelated,
                 @Contrib3M, @Contrib6M, @Contrib1Y, @RelatedAmt, @BranchNote,
                 @Status, @CreateUser, GETDATE())", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@ApplyNo", applyNo);
            cmd.Parameters.AddWithValue("@BranchCode", Me.BranchCode);
            cmd.Parameters.AddWithValue("@ApplyDate", applyDate);
            cmd.Parameters.AddWithValue("@CustomerName", TxtCustomerName.Text.Trim());
            cmd.Parameters.AddWithValue("@CustomerID", (object)TxtCustomerID.Text.Trim() ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@GroupName", (object)TxtGroupName.Text.Trim() ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
            cmd.Parameters.AddWithValue("@IsRelated", RblIsRelated.SelectedValue);
            cmd.Parameters.AddWithValue("@Contrib3M", (object)contrib3M ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib6M", (object)contrib6M ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib1Y", (object)contrib1Y ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@RelatedAmt", (object)relatedAmt ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@BranchNote", TxtBranchNote.Text ?? "");
            cmd.Parameters.AddWithValue("@Status", initialStatus);
            cmd.Parameters.AddWithValue("@CreateUser", Me.EmpID);
            cmd.ExecuteNonQuery();
        }
    }

    private int ReadStatusForEdit(SqlConnection conn, SqlTransaction transaction, string applyNo)
    {
        using (var cmd = new SqlCommand(
            "SELECT Status, CreateUser FROM dbo.NTD_Main WHERE ApplyNo = @ApplyNo", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@ApplyNo", applyNo);
            using (var reader = cmd.ExecuteReader())
            {
                if (!reader.Read())
                    throw new InvalidOperationException("\u7533\u8acb\u55ae\u4e0d\u5b58\u5728\uff1a" + applyNo);  // 申請單不存在：

                int currentStatus = Convert.ToInt32(reader["Status"]);
                string createUser = Convert.ToString(reader["CreateUser"]);
                bool isMine = string.Equals(createUser, Me.EmpID, StringComparison.OrdinalIgnoreCase);
                if (currentStatus != 0 || !isMine)
                    throw new InvalidOperationException("\u6b64\u55ae\u76ee\u524d\u72c0\u614b\u7121\u6cd5\u7de8\u8f2f\u3002");  // 此單目前狀態無法編輯。

                return currentStatus;
            }
        }
    }

    private void UpdateMain(SqlConnection conn, SqlTransaction transaction,
                            string applyNo, DateTime applyDate, decimal totalAmount, int newStatus,
                            decimal? contrib3M, decimal? contrib6M, decimal? contrib1Y, decimal? relatedAmt)
    {
        using (var cmd = new SqlCommand(@"
            UPDATE dbo.NTD_Main
            SET    ApplyDate    = @ApplyDate,
                   CustomerName = @CustomerName,
                   CustomerID   = @CustomerID,
                   GroupName    = @GroupName,
                   TotalAmount  = @TotalAmount,
                   IsRelated    = @IsRelated,
                   Contrib3M    = @Contrib3M,
                   Contrib6M    = @Contrib6M,
                   Contrib1Y    = @Contrib1Y,
                   RelatedAmt   = @RelatedAmt,
                   BranchNote   = @BranchNote,
                   Status       = @Status,
                   UpdateUser   = @UpdateUser,
                   UpdateTime   = GETDATE()
            WHERE  ApplyNo      = @ApplyNo", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@ApplyNo", applyNo);
            cmd.Parameters.AddWithValue("@ApplyDate", applyDate);
            cmd.Parameters.AddWithValue("@CustomerName", TxtCustomerName.Text.Trim());
            cmd.Parameters.AddWithValue("@CustomerID", (object)TxtCustomerID.Text.Trim() ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@GroupName", (object)TxtGroupName.Text.Trim() ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
            cmd.Parameters.AddWithValue("@IsRelated", RblIsRelated.SelectedValue);
            cmd.Parameters.AddWithValue("@Contrib3M", (object)contrib3M ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib6M", (object)contrib6M ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib1Y", (object)contrib1Y ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@RelatedAmt", (object)relatedAmt ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@BranchNote", TxtBranchNote.Text ?? "");
            cmd.Parameters.AddWithValue("@Status", newStatus);
            cmd.Parameters.AddWithValue("@UpdateUser", Me.EmpID);
            cmd.ExecuteNonQuery();
        }
    }

    // ===== 明細 =====

    private void DeleteDetailsForRewrite(SqlConnection conn, SqlTransaction transaction, string applyNo)
    {
        using (var cmd = new SqlCommand(
            "DELETE FROM dbo.NTD_Detail WHERE ApplyNo = @ApplyNo", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@ApplyNo", applyNo);
            cmd.ExecuteNonQuery();
        }
    }

    private void InsertDetailRows(SqlConnection conn, SqlTransaction transaction,
                                  string applyNo, List<DetailRow> rows)
    {
        int seqNo = 1;
        foreach (var detail in rows)
        {
            using (var cmd = new SqlCommand(@"
                INSERT INTO dbo.NTD_Detail
                    (ApplyNo, SeqNo, DepositType, PeriodMonth, Amount, ProposedRate,
                     StartDate, EndDate, NewAmount, RenewAmount, Memo)
                VALUES
                    (@ApplyNo, @SeqNo, @DepositType, @PeriodMonth, @Amount, @ProposedRate,
                     @StartDate, @EndDate, @NewAmount, @RenewAmount, @Memo)", conn, transaction))
            {
                cmd.Parameters.AddWithValue("@ApplyNo", applyNo);
                cmd.Parameters.AddWithValue("@SeqNo", seqNo++);
                cmd.Parameters.AddWithValue("@DepositType", (object)detail.DepositType ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@PeriodMonth", detail.PeriodMonth);
                cmd.Parameters.AddWithValue("@Amount", detail.Amount);
                cmd.Parameters.AddWithValue("@ProposedRate", detail.ProposedRate);
                cmd.Parameters.AddWithValue("@StartDate", (object)detail.StartDate ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@EndDate", (object)detail.EndDate ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@NewAmount", (object)detail.NewAmount ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@RenewAmount", (object)detail.RenewAmount ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@Memo", (object)detail.Memo ?? DBNull.Value);
                cmd.ExecuteNonQuery();
            }
        }
    }

    // ===== 從前端表單讀取明細列 =====

    private List<DetailRow> ReadDetailFromForm()
    {
        var rows = new List<DetailRow>();
        for (int i = 0; i < 100; i++)
        {
            string depositType = Request.Form["DepositType_" + i];
            if (depositType == null) break;

            rows.Add(new DetailRow
            {
                DepositType = depositType.Trim(),
                Amount = ParseDecimal(Request.Form["Amount_" + i]),
                ProposedRate = ParseDecimal(Request.Form["Rate_" + i]),
                PeriodMonth = ParseInt(Request.Form["Period_" + i]),
                NewAmount = ParseNullableDecimal(Request.Form["NewAmount_" + i]),
                RenewAmount = ParseNullableDecimal(Request.Form["RenewAmount_" + i]),
                StartDate = ParseNullableDate(Request.Form["StartDate_" + i]),
                EndDate = ParseNullableDate(Request.Form["EndDate_" + i]),
                Memo = (Request.Form["Memo_" + i] ?? "").Trim()
            });
        }
        return rows;
    }

    /// <summary>
    /// 驗證失敗時：顯示錯誤訊息並把表單明細從 POST 資料重繪（不讓使用者看到空白明細）。
    /// </summary>
    private void ShowErrorAndRebind(string message)
    {
        ShowMessage(message, "err");
        BindDetailRows(ReadDetailFromForm());
        // 若有申請單號也重載簽核紀錄
        if (!string.IsNullOrEmpty(ApplyNo)) LoadLog(ApplyNo);
    }

    /// <summary>將 DetailRow 清單轉成 DataTable 後繫結到 Repeater，確保重繪正確。</summary>
    private void BindDetailRows(List<DetailRow> rows)
    {
        var dt = new DataTable();
        dt.Columns.Add("DepositType", typeof(string));
        dt.Columns.Add("Amount", typeof(decimal));
        dt.Columns.Add("ProposedRate", typeof(decimal));
        dt.Columns.Add("PeriodMonth", typeof(int));
        dt.Columns.Add("StartDate", typeof(DateTime));
        dt.Columns.Add("EndDate", typeof(DateTime));
        dt.Columns.Add("NewAmount", typeof(decimal));
        dt.Columns.Add("RenewAmount", typeof(decimal));
        dt.Columns.Add("Memo", typeof(string));

        foreach (var r in rows)
        {
            var dr = dt.NewRow();
            dr["DepositType"] = (object)r.DepositType ?? DBNull.Value;
            dr["Amount"] = r.Amount;
            dr["ProposedRate"] = r.ProposedRate;
            dr["PeriodMonth"] = r.PeriodMonth;
            dr["StartDate"] = (object)r.StartDate ?? DBNull.Value;
            dr["EndDate"] = (object)r.EndDate ?? DBNull.Value;
            dr["NewAmount"] = (object)r.NewAmount ?? DBNull.Value;
            dr["RenewAmount"] = (object)r.RenewAmount ?? DBNull.Value;
            dr["Memo"] = (object)r.Memo ?? DBNull.Value;
            dt.Rows.Add(dr);
        }
        RptDetail.DataSource = dt;
        RptDetail.DataBind();
    }

    // ===== 寫入簽核紀錄 =====

    private void InsertLog(SqlConnection conn, SqlTransaction transaction,
                           string applyNo, string actionType,
                           int fromStatus, int toStatus, string comment)
    {
        using (var cmd = new SqlCommand(@"
            INSERT INTO dbo.NTD_Log
                (ApplyNo, ActionType, FromStatus, ToStatus,
                 ActionUser, ActionUserName, Comment)
            VALUES
                (@ApplyNo, @ActionType, @FromStatus, @ToStatus,
                 @ActionUser, @ActionUserName, @Comment)", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@ApplyNo", applyNo);
            cmd.Parameters.AddWithValue("@ActionType", actionType);
            cmd.Parameters.AddWithValue("@FromStatus", fromStatus);
            cmd.Parameters.AddWithValue("@ToStatus", toStatus);
            cmd.Parameters.AddWithValue("@ActionUser", Me.EmpID);
            cmd.Parameters.AddWithValue("@ActionUserName", Me.EmpName);
            cmd.Parameters.AddWithValue("@Comment", comment ?? "");
            cmd.ExecuteNonQuery();
        }
    }

    // ===== UI 訊息 =====

    private void ShowMessage(string text, string level)
    {
        LblMessage.Visible = true;
        LblMessage.CssClass = "alert alert-" + level;
        LblMessage.Text = Server.HtmlEncode(text);
    }

    // ===== 資料存取 helper =====

    private static string ConnStr
    {
        get { return ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString; }
    }

    private static DataTable Query(string sql, params SqlParameter[] parameters)
    {
        using (var conn = new SqlConnection(ConnStr))
        using (var cmd = new SqlCommand(sql, conn))
        {
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            using (var adapter = new SqlDataAdapter(cmd))
            {
                var table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }
    }

    private static SqlParameter P(string name, object value)
    {
        return new SqlParameter(name, value ?? DBNull.Value);
    }

    // ===== 流程狀態 / 動作類型 顯示（供 GridView TemplateField 呼叫）=====

    /// <summary>簽核流程狀態代碼 → 中文名稱（對應需求確認書 §1 簽核流程）。</summary>
    protected static string StatusName(int status)
    {
        switch (status)
        {
            case 0: return "\u8349\u7a3f/\u9000\u56de";          // 草稿/退回
            case 1: return "\u5f85\u8956\u7406\u653e\u884c";     // 待襄理放行
            case 2: return "\u5f85\u7d93\u7406\u653e\u884c";     // 待經理放行
            case 4: return "\u5f85\u7e3d\u884c\u7d93\u8fa6\u5be9\u6838";  // 待總行經辦審核
            case 6: return "\u5f85\u7e3d\u884c\u79d1\u9577\u6c7a\u884c";  // 待總行科長決行
            case 9: return "\u7d50\u6848";                        // 結案
            default: return "\u672a\u77e5\u72c0\u614b";           // 未知狀態
        }
    }

    /// <summary>操作動作代碼（英文） → 中文顯示名稱。</summary>
    protected static string ActionTypeName(string actionType)
    {
        switch ((actionType ?? "").ToUpper())
        {
            case "CREATE": return "\u5efa\u7acb";   // 建立
            case "EDIT": return "\u4fee\u6539";   // 修改
            case "SUBMIT": return "\u9001\u51fa";   // 送出
            case "APPROVE": return "\u653e\u884c";   // 放行
            case "DECIDE": return "\u6c7a\u884c";   // 決行
            case "REJECT": return "\u9000\u56de";   // 退回
            default: return actionType ?? "";
        }
    }

    // ===== 型別轉換 helper =====

    private static decimal ParseDecimal(string s)
    {
        decimal v;
        return decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out v) ? v : 0m;
    }

    private static int ParseInt(string s)
    {
        int v;
        return int.TryParse(s, out v) ? v : 0;
    }

    private static decimal? ParseNullableDecimal(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        decimal v;
        return decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out v)
            ? (decimal?)v : null;
    }

    private static DateTime? ParseNullableDate(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        DateTime v;
        return DateTime.TryParse(s, out v) ? (DateTime?)v : null;
    }
}

// ===== 明細列資料物件 =====

/// <summary>Edit 頁前端明細列的資料承載物件，對應 dbo.NTD_Detail 各欄位。</summary>
public class DetailRow
{
    public string DepositType { get; set; }
    public decimal Amount { get; set; }
    public decimal ProposedRate { get; set; }
    public int PeriodMonth { get; set; }
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public decimal? NewAmount { get; set; }
    public decimal? RenewAmount { get; set; }
    public string Memo { get; set; }
}
