﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

/// <summary>
/// 新臺幣定期存款專案利率申請 - 唯讀檢視頁。
/// 不再使用 Detail.ascx，改直接在本頁載入並顯示申請主檔、明細與簽核紀錄。
/// </summary>
public partial class NtdView : Page
{
    protected NtdCurrentUser Me { get { return NtdCurrentUser.Current; } }

    protected void Page_Load(object sender, EventArgs e)
    {
        LblUser.Text = string.Format("{0} {1} ({2} {3}) [職等 {4}]",
            Me.EmpID, Me.EmpName, Me.BranchCode, Me.BranchName, Me.TitleLevel);

        string applyNo = Request.QueryString["no"];
        if (string.IsNullOrEmpty(applyNo))
        {
            ShowMessage("缺少申請單號。", "err");
            return;
        }

        if (!IsPostBack) LoadApply(applyNo);
    }

    protected string NavUrl(string relativeUrl) { return Me.AppendSid(relativeUrl); }

    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect(Me.AppendSid("Main.aspx"), true);
    }

    // ===== 載入申請單（主檔 + 明細 + 簽核紀錄）=====

    /// <summary>
    /// 載入並顯示指定申請單。
    /// 同時撈分行名稱（chb_pub.dbo.BRANCH）及利率別代號名稱（dbo.NTD_RateType）。
    /// CreateUser / UpdateUser 透過 NtdCurrentUser.FillEmpNames 轉為姓名。
    /// </summary>
    private void LoadApply(string applyNo)
    {
        // 主檔（含分行名稱與利率別名稱）
        var mainTable = Query(@"
            SELECT  ntd.*,
                    ISNULL(branch.BRNAME, '') AS BranchName,
                    ntd.CreateUser            AS CreateName,
                    ntd.UpdateUser            AS UpdateName,
                    rt.RateName
            FROM    dbo.NTD_Main    ntd
            LEFT JOIN chb_pub.dbo.BRANCH   branch ON branch.BRNO = ntd.BranchCode
            LEFT JOIN dbo.NTD_RateType     rt     ON rt.RateCode = ntd.RateTypeCode
            WHERE   ntd.ApplyNo = @ApplyNo",
            P("@ApplyNo", applyNo));

        // 將 CreateName / UpdateName 欄的員編替換為姓名
        NtdCurrentUser.FillEmpNames(mainTable, "CreateName", "UpdateName");

        if (mainTable.Rows.Count == 0)
        {
            ShowMessage("查無此申請單：" + applyNo, "err");
            return;
        }

        var row           = mainTable.Rows[0];
        int currentStatus = Convert.ToInt32(row["Status"]);

        LblApplyNo.Text      = Convert.ToString(row["ApplyNo"]);
        LblBranch.Text       = row["BranchCode"] + " " + row["BranchName"];
        LblApplyDate.Text    = Convert.ToDateTime(row["ApplyDate"]).ToString("yyyy-MM-dd");
        LblGroupName.Text    = Server.HtmlEncode(Convert.ToString(row["GroupName"]));
        LblCustomerID.Text   = Server.HtmlEncode(Convert.ToString(row["CustomerID"]));
        LblCustomerName.Text = Server.HtmlEncode(Convert.ToString(row["CustomerName"]));
        LblIsRelated.Text    = Convert.ToString(row["IsRelated"]) == "Y" ? "\u662f"
                             : Convert.ToString(row["IsRelated"]) == "N" ? "\u5426" : "";

        // 狀態徽章（CSS 對應 status-N）
        LblStatus.Text = string.Format("<span class='status status-{0}'>{1}</span>",
            currentStatus, StatusName(currentStatus));

        // 利率別代號（總行科長決行後才會有值）
        string rateCode  = Convert.ToString(row["RateTypeCode"]);
        LblRateType.Text = string.IsNullOrEmpty(rateCode)
            ? "(未填)"
            : rateCode + " " + Convert.ToString(row["RateName"]);

        // 建單/異動資訊
        LblCreate.Text = row["CreateUser"] + " " + Convert.ToString(row["CreateName"])
            + " @ " + Convert.ToDateTime(row["CreateTime"]).ToString("yyyy-MM-dd HH:mm");
        LblUpdate.Text = (row["UpdateTime"] == DBNull.Value)
            ? "(未異動)"
            : row["UpdateUser"] + " " + Convert.ToString(row["UpdateName"])
              + " @ " + Convert.ToDateTime(row["UpdateTime"]).ToString("yyyy-MM-dd HH:mm");

        // 貢獻度
        // 貢獻度四欄位單位均為仟元，依規格顯示千分位數字
        LblContrib3M.Text  = row["Contrib3M"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Contrib3M"]).ToString("N2");
        LblContrib6M.Text  = row["Contrib6M"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Contrib6M"]).ToString("N2");
        LblContrib1Y.Text  = row["Contrib1Y"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Contrib1Y"]).ToString("N2");
        LblRelatedAmt.Text = row["RelatedAmt"] == DBNull.Value ? "" : Convert.ToDecimal(row["RelatedAmt"]).ToString("N2");

        // 申請單位說明（空白時隱藏該區塊）
        LblBranchNote.Text        = Server.HtmlEncode(Convert.ToString(row["BranchNote"])).Replace("\n", "<br/>");
        PnlBranchNote.Visible     = !string.IsNullOrWhiteSpace(Convert.ToString(row["BranchNote"]));

        // 申請明細
        var detailTable = Query(
            "SELECT * FROM dbo.NTD_Detail WHERE ApplyNo = @ApplyNo ORDER BY SeqNo",
            P("@ApplyNo", applyNo));
        GvDetail.DataSource = detailTable;
        GvDetail.DataBind();

        // 合計列（由明細加總）
        decimal sumAmt = 0, sumNew = 0, sumRenew = 0;
        foreach (DataRow dr in detailTable.Rows)
        {
            if (dr["Amount"]       != DBNull.Value) sumAmt   += Convert.ToDecimal(dr["Amount"]);
            if (dr["NewAmount"]    != DBNull.Value) sumNew   += Convert.ToDecimal(dr["NewAmount"]);
            if (dr["RenewAmount"]  != DBNull.Value) sumRenew += Convert.ToDecimal(dr["RenewAmount"]);
        }
        LblSumAmount.Text   = sumAmt   != 0 ? sumAmt.ToString("0.####")   : "\u2014";
        LblSumNewAmt.Text   = sumNew   != 0 ? sumNew.ToString("0.####")   : "";
        LblSumRenewAmt.Text = sumRenew != 0 ? sumRenew.ToString("0.####") : "";

        // 簽核紀錄（有資料才顯示）
        var logTable = Query(
            "SELECT * FROM dbo.NTD_Log WHERE ApplyNo = @ApplyNo ORDER BY LogID DESC",
            P("@ApplyNo", applyNo));
        GvLog.DataSource = logTable;
        GvLog.DataBind();
        PnlLog.Visible = logTable.Rows.Count > 0;
    }

    private void ShowMessage(string text, string level)
    {
        LblMessage.Visible  = true;
        LblMessage.CssClass = "alert alert-" + level;
        LblMessage.Text     = Server.HtmlEncode(text);
    }

    // ===== 資料存取 / 流程狀態 helper =====

    /// <summary>chb_iom 連線字串（Web.config）。</summary>
    private static string ConnStr
    {
        get { return ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString; }
    }

    /// <summary>執行 SELECT，回傳 DataTable。</summary>
    private static DataTable Query(string sql, params SqlParameter[] parameters)
    {
        using (var conn = new SqlConnection(ConnStr))
        using (var cmd  = new SqlCommand(sql, conn))
        {
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            using (var adapter = new SqlDataAdapter(cmd))
            {
                var table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }
    }

    /// <summary>建立 SqlParameter；null 自動轉 DBNull。</summary>
    private static SqlParameter P(string name, object value)
    {
        return new SqlParameter(name, value ?? DBNull.Value);
    }

    /// <summary>簽核流程狀態代碼 → 中文名稱（對應需求確認書 §1 簽核流程）。</summary>
    protected static string StatusName(int status)
    {
        switch (status)
        {
            case 0: return "草稿/退回";
            case 1: return "待襄理放行";
            case 2: return "待經理放行";
            case 4: return "待總行經辦審核";
            case 6: return "待總行科長決行";
            case 9: return "結案";
            default: return "未知狀態";
        }
    }
}
