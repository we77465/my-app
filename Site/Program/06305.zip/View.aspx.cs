﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

/// <summary>
/// 新臺幣定期存款專案利率申請 - 唯讀檢視頁。
/// 客戶統編/名稱已移至 NTD_Detail，由 GvDetail 每列顯示。
/// 貢獻度新增 Related3M / Related6M，採 rowspan 版型。
/// </summary>
public partial class NtdView : Page
{
    protected NtdCurrentUser Me { get { return NtdCurrentUser.Current; } }

    protected void Page_Load(object sender, EventArgs e)
    {
        LblUser.Text = string.Format("{0} {1} ({2} {3}) [\u8077\u7b49 {4}]",
            Me.EmpID, Me.EmpName, Me.BranchCode, Me.BranchName, Me.TitleLevel);

        string applyNo = Request.QueryString["no"];
        if (string.IsNullOrEmpty(applyNo))
        {
            ShowMessage("\u7f3a\u5c11\u7533\u8acb\u55ae\u865f\u3002", "err");
            return;
        }

        if (!IsPostBack) LoadApply(applyNo);
    }

    protected string NavUrl(string relativeUrl) { return Me.AppendSid(relativeUrl); }

    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect(Me.AppendSid("Main.aspx"), true);
    }

    private void LoadApply(string applyNo)
    {
        var mainTable = Query(@"
            SELECT  ntd.*,
                    ISNULL(branch.BRNAME, '') AS BranchName,
                    ntd.CreateUser            AS CreateName,
                    ntd.UpdateUser            AS UpdateName
            FROM    dbo.NTD_Main    ntd
            LEFT JOIN chb_pub.dbo.BRANCH branch ON branch.BRNO = ntd.BranchCode
            WHERE   ntd.DocNo = @DocNo",
            P("@DocNo", applyNo));

        NtdCurrentUser.FillEmpNames(mainTable, "CreateName", "UpdateName");

        if (mainTable.Rows.Count == 0)
        {
            ShowMessage("\u67e5\u7121\u6b64\u7533\u8acb\u55ae\uff1a" + applyNo, "err");
            return;
        }

        var row           = mainTable.Rows[0];
        int currentStatus = Convert.ToInt32(row["Status"]);

        LblDocNo.Text   = Convert.ToString(row["DocNo"]);
        LblBranch.Text    = row["BranchCode"] + " " + row["BranchName"];
        LblApplyDate.Text = Convert.ToDateTime(row["ApplyDate"]).ToString("yyyy-MM-dd");
        LblGroupName.Text = Server.HtmlEncode(Convert.ToString(row["GroupName"]));
        LblIsRelated.Text = Convert.ToString(row["IsRelated"]) == "Y" ? "\u662f"
                          : Convert.ToString(row["IsRelated"]) == "N" ? "\u5426" : "";

        LblStatus.Text = string.Format("<span class='status status-{0}'>{1}</span>",
            currentStatus, StatusName(currentStatus));

        LblCreate.Text = row["CreateUser"] + " " + Convert.ToString(row["CreateName"])
            + " @ " + Convert.ToDateTime(row["CreateTime"]).ToString("yyyy-MM-dd HH:mm");
        LblUpdate.Text = (row["UpdateTime"] == DBNull.Value)
            ? "(\u672a\u7570\u52d5)"
            : row["UpdateUser"] + " " + Convert.ToString(row["UpdateName"])
              + " @ " + Convert.ToDateTime(row["UpdateTime"]).ToString("yyyy-MM-dd HH:mm");

        // 貢獻度 6 欄：客戶 3M/6M/1Y，關係戶 3M/6M/1Y
        LblContrib3M.Text  = row["Contrib3M"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Contrib3M"]).ToString("N2");
        LblContrib6M.Text  = row["Contrib6M"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Contrib6M"]).ToString("N2");
        LblContrib1Y.Text  = row["Contrib1Y"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Contrib1Y"]).ToString("N2");
        LblRelated3M.Text  = row["Related3M"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Related3M"]).ToString("N2");
        LblRelated6M.Text  = row["Related6M"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Related6M"]).ToString("N2");
        LblRelatedAmt.Text = row["RelatedAmt"] == DBNull.Value ? "" : Convert.ToDecimal(row["RelatedAmt"]).ToString("N2");

        LblBranchNote.Text    = Server.HtmlEncode(Convert.ToString(row["BranchNote"])).Replace("\n", "<br/>");
        PnlBranchNote.Visible = !string.IsNullOrWhiteSpace(Convert.ToString(row["BranchNote"]));

        // 申請明細（客戶欄已在 NTD_Detail 中）
        var detailTable = Query(
            "SELECT * FROM dbo.NTD_Detail WHERE DocNo = @DocNo ORDER BY SeqNo",
            P("@DocNo", applyNo));
        GvDetail.DataSource = detailTable;
        GvDetail.DataBind();

        // 合計列（由明細加總）
        decimal sumAmt = 0, sumNew = 0, sumRenew = 0;
        foreach (DataRow dr in detailTable.Rows)
        {
            if (dr["Amount"]      != DBNull.Value) sumAmt   += Convert.ToDecimal(dr["Amount"]);
            if (dr["NewAmount"]   != DBNull.Value) sumNew   += Convert.ToDecimal(dr["NewAmount"]);
            if (dr["RenewAmount"] != DBNull.Value) sumRenew += Convert.ToDecimal(dr["RenewAmount"]);
        }
        LblSumAmount.Text   = sumAmt   != 0 ? sumAmt.ToString("0.####")   : "\u2014";
        LblSumNewAmt.Text   = sumNew   != 0 ? sumNew.ToString("0.####")   : "";
        LblSumRenewAmt.Text = sumRenew != 0 ? sumRenew.ToString("0.####") : "";

        var logTable = Query(
            "SELECT * FROM dbo.NTD_Log WHERE DocNo = @DocNo ORDER BY LogID DESC",
            P("@DocNo", applyNo));
        GvLog.DataSource = logTable;
        GvLog.DataBind();
        PnlLog.Visible = logTable.Rows.Count > 0;
    }

    private void ShowMessage(string text, string level)
    {
        LblMessage.Visible  = true;
        LblMessage.CssClass = "alert alert-" + level;
        LblMessage.Text     = Server.HtmlEncode(text);
    }

    private static string ConnStr
    {
        get { return ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString; }
    }

    private static DataTable Query(string sql, params SqlParameter[] parameters)
    {
        using (var conn = new SqlConnection(ConnStr))
        using (var cmd  = new SqlCommand(sql, conn))
        {
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            using (var adapter = new SqlDataAdapter(cmd))
            {
                var table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }
    }

    private static SqlParameter P(string name, object value)
    {
        return new SqlParameter(name, value ?? DBNull.Value);
    }

    protected static string StatusName(int status)
    {
        switch (status)
        {
            case 0: return "\u8349\u7a3f/\u9000\u56de";
            case 1: return "\u5f85\u8956\u7406\u653e\u884c";
            case 2: return "\u5f85\u7d93\u7406\u653e\u884c";
            case 4: return "\u5f85\u7e3d\u884c\u7d93\u8fa6\u5be9\u6838";
            case 6: return "\u5f85\u7e3d\u884c\u79d1\u9577\u6c7a\u884c";
            case 9: return "\u7d50\u6848";
            default: return "\u672a\u77e5\u72c0\u614b";
        }
    }
}
