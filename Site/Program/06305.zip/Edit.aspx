﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Edit.aspx.cs" Inherits="NtdEdit" ValidateRequest="false"
    ResponseEncoding="UTF-8" ContentType="text/html; charset=utf-8" %>
<!DOCTYPE html>
<html>
<head runat="server">
    <meta charset="utf-8" />
    <title>新臺幣定期存款專案利率申請 - 申請單</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: "Microsoft JhengHei", "微軟正黑體", Arial, sans-serif; font-size: 14px; color: #222; background: #f4f6f9; margin: 0; }
        a { color: #1565c0; text-decoration: none; }
        a:hover { text-decoration: underline; }
        .topbar { background: #1565c0; color: #fff; padding: 10px 18px; display: flex; align-items: center; justify-content: space-between; }
        .topbar h1 { margin: 0; font-size: 18px; font-weight: 600; }
        .topbar .user { font-size: 13px; }
        .nav { background: #fff; padding: 0 18px; border-bottom: 1px solid #e0e0e0; }
        .nav a { padding: 12px 20px; color: #555; display: inline-block; border-bottom: 3px solid transparent; }
        .nav a.active { color: #1565c0; border-bottom-color: #1565c0; font-weight: bold; }
        .nav a:hover { background: #f0f4ff; }
        .container { padding: 18px; }
        .card { background: #fff; border: 1px solid #e0e0e0; padding: 18px; margin-bottom: 16px; }
        .card-title { font-size: 16px; font-weight: bold; margin: 0 0 12px; padding-bottom: 8px; border-bottom: 2px solid #1565c0; color: #1565c0; }
        .footer { text-align: center; color: #888; font-size: 12px; padding: 16px; }

        .form { width: 100%; border-collapse: collapse; }
        .form th { width: 160px; background: #e3f2fd; color: #1565c0; text-align: right; padding: 6px 10px; border: 1px solid #d0d0d0; }
        .form td { padding: 6px 10px; border: 1px solid #d0d0d0; }
        .form input[type=text], .form input[type=number], .form input[type=date], .form textarea, .form select {
            border: 1px solid #bdbdbd; border-radius: 3px; padding: 4px 6px; font-size: 13px; font-family: inherit;
        }
        .form textarea { width: 96%; }
        .form .req { color: #d32f2f; }

        .tbl { width: 100%; border-collapse: collapse; }
        .tbl th, .tbl td { border: 1px solid #d0d0d0; padding: 5px 6px; font-size: 12px; }
        .tbl th { background: #e3f2fd; font-weight: bold; color: #1565c0; text-align: center; }
        .tbl .num { text-align: right; }
        .tbl .ctr { text-align: center; }
        .tbl input[type=text], .tbl input[type=number], .tbl input[type=date], .tbl select {
            border: 1px solid #bdbdbd; border-radius: 3px; padding: 2px 4px; font-size: 12px; font-family: inherit;
        }

        /* 客戶欄（統一編號查詢）*/
        .cust-cell { min-width: 190px; }
        .cust-id-row { display: flex; align-items: center; gap: 4px; margin-bottom: 3px; }
        .btn-lookup { background: #0277bd; color: #fff; border: none; border-radius: 3px; padding: 2px 8px; cursor: pointer; font-size: 11px; font-family: inherit; white-space: nowrap; }
        .btn-lookup:hover { background: #01579b; }
        .cust-name-input { width: 100%; font-size: 12px; background: #f5f5f5; }

        .toolbar { padding: 8px 0; display: flex; gap: 6px; align-items: center; }
        .btn { display: inline-block; padding: 6px 16px; border: 1px solid #1565c0; background: #1565c0; color: #fff; border-radius: 3px; cursor: pointer; font-size: 13px; font-family: inherit; }
        .btn:hover { background: #0d47a1; }
        .btn-sub  { background: #757575; border-color: #757575; }
        .btn-sub:hover  { background: #424242; }
        .btn-ok   { background: #388e3c; border-color: #388e3c; }
        .btn-ok:hover   { background: #1b5e20; }

        .alert { padding: 10px 12px; margin-bottom: 12px; border-radius: 4px; }
        .alert-err  { background: #ffebee; color: #b71c1c; border: 1px solid #ef9a9a; }
        .alert-warn { background: #fff3e0; color: #e65100; border: 1px solid #ffcc80; }
        .alert-ok   { background: #e8f5e9; color: #1b5e20; border: 1px solid #a5d6a7; }

        .contrib-tbl { border-collapse: collapse; width: 100%; }
        .contrib-tbl th, .contrib-tbl td { border: 1px solid #d0d0d0; padding: 6px 8px; font-size: 13px; }
        .contrib-tbl th { background: #e3f2fd; font-weight: bold; color: #1565c0; text-align: center; }
        .contrib-tbl td { text-align: center; }
        .contrib-tbl td:first-child { background: #e3f2fd; color: #1565c0; font-weight: bold; text-align: right; white-space: nowrap; }
        .contrib-tbl input { width: 140px; }

        .note-txt { margin: 10px 0; font-size: 13px; color: #444; }
    </style>
    <script>
        function todayStr() {
            var d = new Date();
            return d.getFullYear() + '-' + ('0'+(d.getMonth()+1)).slice(-2) + '-' + ('0'+d.getDate()).slice(-2);
        }

        // 重新計算合計列（Amount / 新作 / 續作）
        function recalcTotal() {
            var i = 0, sumAmt = 0, sumNew = 0, sumRenew = 0;
            while (document.querySelector('[name="Amount_' + i + '"]')) {
                sumAmt   += parseFloat(document.querySelector('[name="Amount_'      + i + '"]').value) || 0;
                var ni    = document.querySelector('[name="NewAmount_'   + i + '"]');
                var ri    = document.querySelector('[name="RenewAmount_' + i + '"]');
                if (ni) sumNew   += parseFloat(ni.value) || 0;
                if (ri) sumRenew += parseFloat(ri.value) || 0;
                i++;
            }
            document.getElementById('SumAmount').textContent   = sumAmt   ? sumAmt.toFixed(4)   : '\u2014';
            document.getElementById('SumNewAmt').textContent   = sumNew   ? sumNew.toFixed(4)   : '';
            document.getElementById('SumRenewAmt').textContent = sumRenew ? sumRenew.toFixed(4) : '';
        }
        document.addEventListener('DOMContentLoaded', recalcTotal);

        // 透過 CustomerLookup.ashx（EAI F0101）依統一編號查詢客戶名稱
        function lookupCustomer(index) {
            var idInput   = document.querySelector('[name="CustomerID_'   + index + '"]');
            var nameInput = document.querySelector('[name="CustomerName_' + index + '"]');
            if (!idInput || !nameInput) return;
            var customerId = idInput.value.trim();
            if (!customerId) { alert('\u8acb\u5148\u8f38\u5165\u7d71\u4e00\u7de8\u865f'); return; }
            nameInput.value = '\u67e5\u8a62\u4e2d\u2026';
            fetch('CustomerLookup.ashx?id=' + encodeURIComponent(customerId))
                .then(function(r) { return r.json(); })
                .then(function(d) {
                    if (d.name) {
                        nameInput.value = d.name;
                    } else {
                        nameInput.value = '';
                        alert(d.error || '\u67e5\u8a62\u5931\u6557');
                    }
                })
                .catch(function() {
                    nameInput.value = '';
                    alert('\u67e5\u8a62\u767c\u751f\u932f\u8aa4\uff0c\u8acb\u7a0d\u5f8c\u518d\u8a66');
                });
        }

        function AddDetailRow() {
            var tbody = document.getElementById('DetailTable').tBodies[0];
            var index = tbody.rows.length;
            var today = todayStr();
            var minDate = '2000-01-01';
            var row = tbody.insertRow();
            row.innerHTML =
                '<td class="cust-cell">' +
                    '<div class="cust-id-row">' +
                        '\u7d71\u4e00\u7de8\u865f\uff1a<input type="text" name="CustomerID_'   + index + '" maxlength="11" style="width:105px" />' +
                        '<button type="button" class="btn-lookup" onclick="lookupCustomer(' + index + ')">\u67e5\u8a62</button>' +
                    '</div>' +
                    '\u5ba2\u6236\u540d\u7a31\uff1a<input type="text" name="CustomerName_' + index + '" class="cust-name-input" maxlength="200" readonly />' +
                '</td>' +
                '<td><select name="DepositType_' + index + '" style="width:115px">' +
                    '<option value="">--\u9078\u64c7--</option>' +
                    '<option value="\u5b9a\u671f\u5b58\u6b3e">\u5b9a\u671f\u5b58\u6b3e</option>' +
                    '<option value="\u5b9a\u671f\u5132\u84c4\u5b58\u6b3e">\u5b9a\u671f\u5132\u84c4\u5b58\u6b3e</option>' +
                '</select></td>' +
                '<td><input type="number" name="Amount_'      + index + '" min="0" step="0.0001" oninput="recalcTotal()" style="width:88px" /></td>' +
                '<td><input type="number" name="Rate_'        + index + '" min="0" step="0.0001" style="width:73px" /></td>' +
                '<td><input type="number" name="Period_'      + index + '" min="1" max="360" value="12" style="width:53px" /></td>' +
                '<td><input type="date"   name="StartDate_'   + index + '" value="' + today + '" min="' + minDate + '" onchange="checkBusinessDay(this)" style="width:118px" /></td>' +
                '<td><input type="date"   name="EndDate_'     + index + '" value="" min="' + minDate + '" onchange="checkBusinessDay(this)" style="width:118px" /></td>' +
                '<td><input type="number" name="NewAmount_'   + index + '" min="0" step="0.0001" oninput="recalcTotal()" style="width:83px" /></td>' +
                '<td><input type="number" name="RenewAmount_' + index + '" min="0" step="0.0001" oninput="recalcTotal()" style="width:83px" /></td>' +
                '<td><input type="text"   name="Memo_'        + index + '" maxlength="500" style="width:100%;min-width:80px" /></td>' +
                '<td class="ctr"><a href="javascript:void(0)" onclick="DeleteDetailRow(this)">\u522a\u9664</a></td>';
            recalcTotal();
        }

        function DeleteDetailRow(anchor) {
            var row = anchor.parentNode.parentNode;
            if (row.parentNode.rows.length <= 1) {
                alert('\u81f3\u5c11\u9700\u4fdd\u7559\u4e00\u7b46\u660e\u7d30\u3002');
                return;
            }
            row.parentNode.removeChild(row);
            recalcTotal();
        }

        function checkBusinessDay(input) {
            if (!input.value) return;
            var d = new Date(input.value);
            var day = d.getUTCDay();
            if (day === 0 || day === 6)
                alert('\u3010\u6ce8\u610f\u3011' + input.value + ' \u70ba\u9031\u672b\uff0c\u8d77\u5b58\u65e5/\u5230\u671f\u65e5\u9700\u70ba\u71df\u696d\u65e5\uff0c\u8acb\u78ba\u8a8d\u3002');
        }

        function CountBranchNoteChars(textarea) {
            var max = 3000;
            if (textarea.value.length > max) textarea.value = textarea.value.substring(0, max);
            document.getElementById('BranchNoteCharCount').innerText = textarea.value.length;
        }
    </script>
</head>
<body>
<form id="Form1" runat="server">
    <asp:ScriptManager ID="ScriptManager1" runat="server" />

    <div class="topbar">
        <h1>新臺幣定期存款專案利率申請</h1>
        <div class="user"><asp:Label ID="LblUser" runat="server" /></div>
    </div>
    <div class="nav">
        <a href="<%= NavUrl("Main.aspx") %>" class="active">待處理</a>
        <a href="<%= NavUrl("Query.aspx") %>">查詢</a>
        <a href="<%= NavUrl("Approve.aspx") %>">簽核/決行</a>
        <a href="<%= NavUrl("Report.aspx") %>">報表</a>
    </div>

    <div class="container">
        <asp:Label ID="LblMessage" runat="server" Visible="false" />

        <div class="card">
            <h2 class="card-title">
                <asp:Literal ID="LitTitle" runat="server" Text="新增申請" />
                <span style="float:right; font-weight:normal; font-size:13px; color:#666">
                    申請單號：<asp:Label ID="LblDocNo" runat="server" Text="(系統產生)" />
                    &nbsp;|&nbsp;
                    狀態：<asp:Label ID="LblStatus" runat="server" />
                </span>
            </h2>

            <%-- 基本資訊：申請日期 → 申請單位；所屬集團 --%>
            <table class="form">
                <tr>
                    <th>申請日期</th>
                    <td><asp:TextBox ID="TxtApplyDate" runat="server" TextMode="Date" /></td>
                    <th>申請單位</th>
                    <td><asp:Label ID="LblBranch" runat="server" /></td>
                </tr>
                <tr>
                    <th>所屬集團</th>
                    <td colspan="3"><asp:TextBox ID="TxtGroupName" runat="server" Width="300" MaxLength="100" /></td>
                </tr>
            </table>

            <%-- 申請內容：2 層表頭，客戶欄位入 table，每列含 EAI 查詢 --%>
            <h3 style="margin-top:18px;color:#1565c0">申請內容</h3>
            <table id="DetailTable" class="tbl">
                <thead>
                    <tr>
                        <th rowspan="2" class="cust-cell">客戶</th>
                        <th colspan="8">本次申請</th>
                        <th rowspan="2">備注</th>
                        <th rowspan="2" style="width:42px">動作</th>
                    </tr>
                    <tr>
                        <th style="width:120px">存款種類 <span class="req">*</span></th>
                        <th style="width:95px">總金額(億元)</th>
                        <th style="width:80px">利率(%)</th>
                        <th style="width:60px">期間(月)</th>
                        <th style="width:125px">起存日</th>
                        <th style="width:125px">到期日</th>
                        <th style="width:90px">新作(億元)</th>
                        <th style="width:90px">續作(億元)</th>
                    </tr>
                </thead>
                <tbody>
                    <asp:Repeater ID="RptDetail" runat="server">
                        <ItemTemplate>
                            <tr>
                                <td class="cust-cell">
                                    <div class="cust-id-row">
                                        統一編號：<input type="text" name='CustomerID_<%# Container.ItemIndex %>'
                                            value='<%# Server.HtmlEncode(Convert.ToString(Eval("CustomerID"))) %>'
                                            maxlength="11" style="width:105px" />
                                        <button type="button" class="btn-lookup"
                                            onclick="lookupCustomer(<%# Container.ItemIndex %>)">查詢</button>
                                    </div>
                                    客戶名稱：<input type="text" name='CustomerName_<%# Container.ItemIndex %>'
                                        value='<%# Server.HtmlEncode(Convert.ToString(Eval("CustomerName"))) %>'
                                        class="cust-name-input" maxlength="200" readonly />
                                </td>
                                <td>
                                    <select name='DepositType_<%# Container.ItemIndex %>' style="width:115px">
                                        <option value="">--選擇--</option>
                                        <option value="定期存款"     <%# Convert.ToString(Eval("DepositType")) == "定期存款"     ? "selected" : "" %>>定期存款</option>
                                        <option value="定期儲蓄存款" <%# Convert.ToString(Eval("DepositType")) == "定期儲蓄存款" ? "selected" : "" %>>定期儲蓄存款</option>
                                    </select>
                                </td>
                                <td><input type="number" name='Amount_<%# Container.ItemIndex %>'
                                    value='<%# Eval("Amount") %>' min="0" step="0.0001" oninput="recalcTotal()" style="width:88px" /></td>
                                <td><input type="number" name='Rate_<%# Container.ItemIndex %>'
                                    value='<%# Eval("ProposedRate") %>' min="0" step="0.0001" style="width:73px" /></td>
                                <td><input type="number" name='Period_<%# Container.ItemIndex %>'
                                    value='<%# Eval("PeriodMonth") %>' min="1" max="360" style="width:53px" /></td>
                                <td><input type="date" name='StartDate_<%# Container.ItemIndex %>'
                                    value='<%# GetDateValue(Eval("StartDate")) %>'
                                    min="2000-01-01" onchange="checkBusinessDay(this)" style="width:118px" /></td>
                                <td><input type="date" name='EndDate_<%# Container.ItemIndex %>'
                                    value='<%# GetDateValue(Eval("EndDate")) %>'
                                    min="2000-01-01" onchange="checkBusinessDay(this)" style="width:118px" /></td>
                                <td><input type="number" name='NewAmount_<%# Container.ItemIndex %>'
                                    value='<%# GetDecimalValue(Eval("NewAmount")) %>'
                                    min="0" step="0.0001" oninput="recalcTotal()" style="width:83px" /></td>
                                <td><input type="number" name='RenewAmount_<%# Container.ItemIndex %>'
                                    value='<%# GetDecimalValue(Eval("RenewAmount")) %>'
                                    min="0" step="0.0001" oninput="recalcTotal()" style="width:83px" /></td>
                                <td><input type="text" name='Memo_<%# Container.ItemIndex %>'
                                    value='<%# Server.HtmlEncode(Convert.ToString(Eval("Memo"))) %>'
                                    maxlength="500" style="width:100%;min-width:80px" /></td>
                                <td class="ctr"><a href="javascript:void(0)" onclick="DeleteDetailRow(this)">刪除</a></td>
                            </tr>
                        </ItemTemplate>
                    </asp:Repeater>
                </tbody>
                <tfoot>
                    <tr style="background:#e8f5e9; font-weight:bold;">
                        <td colspan="2" class="ctr">合計</td>
                        <td class="num" id="SumAmount" style="color:#1565c0"></td>
                        <td></td><td></td><td></td><td></td>
                        <td class="num" id="SumNewAmt"   style="color:#1565c0"></td>
                        <td class="num" id="SumRenewAmt" style="color:#1565c0"></td>
                        <td></td><td></td>
                    </tr>
                </tfoot>
            </table>
            <div class="toolbar">
                <a href="javascript:void(0)" onclick="AddDetailRow()" class="btn btn-sub">＋ 新增一筆明細</a>
            </div>

            <%-- 是否屬利害關係人（依規格置於申請內容下方） --%>
            <table class="form" style="margin-top:10px;">
                <tr>
                    <th>是否屬利害關係人 <span class="req">*</span></th>
                    <td colspan="3">
                        <%-- 選項由 code-behind InitButtons() 設定，避免 .aspx 中文屬性值的編碼問題 --%>
                        <asp:RadioButtonList ID="RblIsRelated" runat="server"
                            RepeatDirection="Horizontal" RepeatLayout="Flow" />
                    </td>
                </tr>
            </table>

            <%-- 靜態提示（依規格） --%>
            <p class="note-txt">※請於承作日期前三個營業日申請，並以電話聯繫本處以確認知悉。</p>

            <%-- 貢獻度：依規格 rowspan 版型 --%>
            <h3 style="margin-top:14px;color:#1565c0">貢獻度</h3>
            <table class="contrib-tbl">
                <tbody>
                    <tr>
                        <td>客戶存款實績(仟元)</td>
                        <th rowspan="2">最近三個月</th>
                        <td><asp:TextBox ID="TxtContrib3M" runat="server" TextMode="Number" /></td>
                        <th rowspan="2">最近六個月</th>
                        <td><asp:TextBox ID="TxtContrib6M" runat="server" TextMode="Number" /></td>
                        <th rowspan="2">最近一年貢獻度(仟元)</th>
                        <td><asp:TextBox ID="TxtContrib1Y" runat="server" TextMode="Number" /></td>
                    </tr>
                    <tr>
                        <td>關係戶存款實績(仟元)</td>
                        <td><asp:TextBox ID="TxtRelated3M" runat="server" TextMode="Number" /></td>
                        <td><asp:TextBox ID="TxtRelated6M" runat="server" TextMode="Number" /></td>
                        <td><asp:TextBox ID="TxtRelatedAmt" runat="server" TextMode="Number" /></td>
                    </tr>
                </tbody>
            </table>

            <%-- 申請單位說明 --%>
            <table class="form" style="margin-top:14px;">
                <tr>
                    <th>申請單位說明<br /><span style="font-size:11px;color:#888">(限 3,000 字)</span></th>
                    <td colspan="3">
                        <asp:TextBox ID="TxtBranchNote" runat="server" TextMode="MultiLine" Width="96%" Height="100"
                            MaxLength="3000" onkeyup="CountBranchNoteChars(this)" onchange="CountBranchNoteChars(this)" />
                        <div style="font-size:11px;color:#888">已輸入字數：<span id="BranchNoteCharCount">0</span> / 3000</div>
                    </td>
                </tr>
            </table>

            <%-- 按鈕 Text 由 code-behind InitButtons() 設定 --%>
            <div class="toolbar" style="margin-top:18px; border-top:1px solid #e0e0e0; padding-top:14px">
                <asp:Button ID="BtnSaveDraft" runat="server"
                    CssClass="btn btn-sub" OnClick="BtnSaveDraft_Click" />
                <asp:Button ID="BtnSubmit" runat="server"
                    CssClass="btn btn-ok"  OnClick="BtnSubmit_Click"
                    OnClientClick="return confirm('\u9001\u51fa\u5f8c\u5c07\u9032\u5165\u7c3d\u6838\u6d41\u7a0b\uff0c\u78ba\u5b9a\u9001\u51fa\uff1f');" />
                <asp:Button ID="BtnBack" runat="server"
                    CssClass="btn btn-sub" OnClick="BtnBack_Click" CausesValidation="false" />
            </div>
        </div>

        <%-- 簽核紀錄（有退回紀錄時才顯示） --%>
        <asp:Panel ID="PnlLog" runat="server" CssClass="card" Visible="false">
            <h2 class="card-title">簽核紀錄</h2>
            <asp:GridView ID="GvLog" runat="server" AutoGenerateColumns="false"
                CssClass="tbl" GridLines="None" EmptyDataText="無紀錄">
                <Columns>
                    <asp:BoundField DataField="ActionTime"     HeaderText="時間"  DataFormatString="{0:yyyy-MM-dd HH:mm}" ItemStyle-CssClass="ctr" />
                    <asp:BoundField DataField="ActionUser"     HeaderText="員編"  ItemStyle-CssClass="ctr" />
                    <asp:BoundField DataField="ActionUserName" HeaderText="姓名"  ItemStyle-CssClass="ctr" />
                    <asp:TemplateField HeaderText="動作" ItemStyle-CssClass="ctr">
                        <ItemTemplate><%# ActionTypeName(Convert.ToString(Eval("ActionType"))) %></ItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="狀態變化" ItemStyle-CssClass="ctr">
                        <ItemTemplate>
                            <%# StatusName(Convert.ToInt32(Eval("FromStatus"))) %>
                            &nbsp;&rarr;&nbsp;
                            <%# StatusName(Convert.ToInt32(Eval("ToStatus"))) %>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="Comment" HeaderText="簽核意見" />
                </Columns>
            </asp:GridView>
        </asp:Panel>
    </div>
    <div class="footer">© 經營管理處 - 新臺幣定期存款專案利率申請</div>
</form>
</body>
</html>
