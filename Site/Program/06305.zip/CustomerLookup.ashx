<%@ WebHandler Language="C#" Class="CustomerLookup" %>

using System;
using System.Web;

/// <summary>
/// 單筆客戶統編查詢 HTTP Handler。
/// JS fetch() 呼叫此端點，傳入 ?id=統一編號，回傳 JSON { "name":"..." } 或 { "error":"..." }。
/// 內部使用公司 EAI（RiskUtils.GetF0101Rs）查詢客戶名稱，與 Edit.aspx 原查詢邏輯相同。
/// </summary>
public class CustomerLookup : IHttpHandler
{
    public void ProcessRequest(HttpContext context)
    {
        context.Response.ContentType    = "application/json";
        context.Response.Charset        = "utf-8";
        context.Response.Cache.SetNoStore();

        string customerId = (context.Request.QueryString["id"] ?? "").Trim();

        // 基本格式驗證（統一編號 / 身分證：8–11 碼）
        if (string.IsNullOrEmpty(customerId) || customerId.Length < 8 || customerId.Length > 11)
        {
            Write(context, "error", "\u7d71\u4e00\u7de8\u865f\u683c\u5f0f\u932f\u8aa4\uff088\u201311\u78bc\uff09");
            return;
        }

        try
        {
            var user = NtdCurrentUser.Current;
            // EAI F0101 需要 4 碼分行代號；超過 4 碼時取前 4 碼
            string branchPrefix = user.BranchCode.Length >= 4
                ? user.BranchCode.Substring(0, 4)
                : user.BranchCode;

            F0101 result = RiskUtils.GetF0101Rs("System", customerId, "NTD", branchPrefix);

            if (result.isSuccess && !string.IsNullOrEmpty(result.CNAME))
            {
                Write(context, "name", EscapeJson(result.CNAME));
            }
            else
            {
                Write(context, "error", "\u67e5\u7121\u6b64\u7d71\u4e00\u7de8\u865f\u5c0d\u61c9\u7684\u5ba2\u6236\u8cc7\u6599");
            }
        }
        catch (Exception ex)
        {
            Write(context, "error", "\u67e5\u8a62\u5931\u6557\uff1a" + EscapeJson(ex.Message));
        }
    }

    private static void Write(HttpContext context, string key, string value)
    {
        context.Response.Write("{\"" + key + "\":\"" + value + "\"}");
    }

    private static string EscapeJson(string s)
    {
        if (s == null) return "";
        return s.Replace("\\", "\\\\").Replace("\"", "\\\"")
                .Replace("\r", "").Replace("\n", "");
    }

    public bool IsReusable { get { return false; } }
}
