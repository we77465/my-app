﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// 新臺幣定期存款專案利率申請 - 新增/編輯申請單。
/// 僅「經辦」或「襄理」可進入（§2 權限設定：填報角色 = 經辦 + 襄理）；
/// 申請單在 Status = 0（草稿/退回）時才可修改。
/// 客戶統編/名稱已移至每筆明細（NTD_Detail），支援同申請多客戶。
/// </summary>
public partial class NtdEdit : Page
{
    protected NtdCurrentUser Me { get { return NtdCurrentUser.Current; } }

    /// <summary>URL 上的申請單號 (?no=)，空字串代表新增。</summary>
    private string DocNo { get { return (Request.QueryString["no"] ?? "").Trim(); } }

    protected void Page_Load(object sender, EventArgs e)
    {
        LblUser.Text = string.Format("{0} {1} ({2} {3}) [\u8077\u7b49 {4}]",
            Me.EmpID, Me.EmpName, Me.BranchCode, Me.BranchName, Me.TitleLevel);

        InitButtons();

        if (!Me.CanCreateApply)
        {
            ShowMessage("\u60a8\u7684\u8077\u4f4d\u7121\u6cd5\u65b0\u589e/\u7de8\u8f2f\u7533\u8acb\uff0c\u50c5\u7d93\u8fa6\u6216\u8956\u7406\u53ef\u64cd\u4f5c\u3002", "err");
            DisableForm();
            return;
        }

        if (IsPostBack) return;

        TxtApplyDate.Text = DateTime.Today.ToString("yyyy-MM-dd");
        LblBranch.Text = Me.BranchCode + " " + Me.BranchName;
        LblStatus.Text = StatusName(0);

        if (string.IsNullOrEmpty(DocNo))
        {
            BindDetailRows(new List<DetailRow> { new DetailRow { PeriodMonth = 12 } });
        }
        else
        {
            LoadExistingApply(DocNo);
            if (Request.QueryString["saved"] == "1")
                ShowMessage("\u8349\u7a3f\u5132\u5b58\u6210\u529f\u3002\u53ef\u7e7c\u7e8c\u7de8\u8f2f\u6216\u9ede\u300c\u9001\u51fa\u7533\u8acb\u300d\u9032\u5165\u7c3d\u6838\u3002", "ok");
        }
    }

    /// <summary>每次 Load 都重設按鈕/選項文字，確保不受 ASPX 編碼影響。</summary>
    private void InitButtons()
    {
        BtnSaveDraft.Text = "\u5132\u5b58\u8349\u7a3f";   // 儲存草稿
        BtnSubmit.Text    = "\u9001\u51fa\u7533\u8acb";   // 送出申請
        BtnBack.Text      = "\u8fd4\u56de\u5217\u8868";   // 返回列表

        if (RblIsRelated.Items.Count == 0)
        {
            RblIsRelated.Items.Add(new ListItem("\u662f", "Y"));  // 是
            RblIsRelated.Items.Add(new ListItem("\u5426", "N"));  // 否
        }
    }

    protected string NavUrl(string relativeUrl) { return Me.AppendSid(relativeUrl); }

    // ===== Repeater helper（供 ASPX DataBind 運算式呼叫）=====

    /// <summary>日期值→yyyy-MM-dd 字串；null/DBNull 回傳空字串。</summary>
    protected static string GetDateValue(object val)
    {
        if (val == null || val == DBNull.Value) return "";
        try { return Convert.ToDateTime(val).ToString("yyyy-MM-dd"); }
        catch { return ""; }
    }

    /// <summary>可空 decimal 值→字串；null/DBNull 回傳空字串。</summary>
    protected static string GetDecimalValue(object val)
    {
        if (val == null || val == DBNull.Value) return "";
        try { return Convert.ToDecimal(val).ToString("0.####"); }
        catch { return ""; }
    }

    // ===== 載入既有申請單 =====

    private void LoadExistingApply(string applyNo)
    {
        var mainTable = Query(@"
            SELECT  ntd.*, ISNULL(branch.BRNAME, '') AS BranchName
            FROM    dbo.NTD_Main    ntd
            LEFT JOIN chb_pub.dbo.BRANCH branch ON branch.BRNO = ntd.BranchCode
            WHERE   ntd.DocNo = @DocNo",
            P("@DocNo", applyNo));

        if (mainTable.Rows.Count == 0)
        {
            ShowMessage("\u627e\u4e0d\u5230\u7533\u8acb\u55ae\uff1a" + applyNo, "err");
            DisableForm();
            return;
        }

        var row = mainTable.Rows[0];
        int currentStatus = Convert.ToInt32(row["Status"]);

        LitTitle.Text   = "\u7de8\u8f2f\u7533\u8acb";  // 編輯申請
        LblDocNo.Text = applyNo;
        LblBranch.Text  = row["BranchCode"] + " " + row["BranchName"];
        TxtApplyDate.Text  = Convert.ToDateTime(row["ApplyDate"]).ToString("yyyy-MM-dd");
        TxtGroupName.Text  = Convert.ToString(row["GroupName"]);
        TxtBranchNote.Text = Convert.ToString(row["BranchNote"]);
        LblStatus.Text     = StatusName(currentStatus);

        if (row["IsRelated"] != DBNull.Value)
        {
            var item = RblIsRelated.Items.FindByValue(Convert.ToString(row["IsRelated"]));
            if (item != null) item.Selected = true;
        }

        // 貢獻度（6 個欄位：客戶 3M/6M/1Y，關係戶 3M/6M/1Y）
        TxtContrib3M.Text  = row["Contrib3M"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Contrib3M"]).ToString("0.####");
        TxtContrib6M.Text  = row["Contrib6M"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Contrib6M"]).ToString("0.####");
        TxtContrib1Y.Text  = row["Contrib1Y"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Contrib1Y"]).ToString("0.####");
        TxtRelated3M.Text  = row["Related3M"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Related3M"]).ToString("0.####");
        TxtRelated6M.Text  = row["Related6M"]  == DBNull.Value ? "" : Convert.ToDecimal(row["Related6M"]).ToString("0.####");
        TxtRelatedAmt.Text = row["RelatedAmt"] == DBNull.Value ? "" : Convert.ToDecimal(row["RelatedAmt"]).ToString("0.####");

        bool isEditableNow = currentStatus == 0
            && string.Equals(Convert.ToString(row["CreateUser"]), Me.EmpID,
                             StringComparison.OrdinalIgnoreCase);

        if (!isEditableNow)
        {
            ShowMessage("\u6b64\u7533\u8acb\u55ae\u76ee\u524d\u72c0\u614b\u7121\u6cd5\u7de8\u8f2f\u3002", "warn");
            DisableForm();
        }

        var detailTable = Query(
            "SELECT * FROM dbo.NTD_Detail WHERE DocNo = @DocNo ORDER BY SeqNo",
            P("@DocNo", applyNo));
        RptDetail.DataSource = detailTable;
        RptDetail.DataBind();

        LoadLog(applyNo);
    }

    /// <summary>鎖定所有輸入欄位，隱藏操作按鈕（唯讀模式）。</summary>
    private void DisableForm()
    {
        TxtGroupName.Enabled   = false;
        TxtBranchNote.Enabled  = false;
        TxtApplyDate.Enabled   = false;
        TxtContrib3M.Enabled   = false;
        TxtContrib6M.Enabled   = false;
        TxtContrib1Y.Enabled   = false;
        TxtRelated3M.Enabled   = false;
        TxtRelated6M.Enabled   = false;
        TxtRelatedAmt.Enabled  = false;
        RblIsRelated.Enabled   = false;
        BtnSaveDraft.Visible   = false;
        BtnSubmit.Visible      = false;
    }

    private void LoadLog(string applyNo)
    {
        var logTable = Query(
            "SELECT * FROM dbo.NTD_Log WHERE DocNo = @DocNo ORDER BY LogID DESC",
            P("@DocNo", applyNo));
        GvLog.DataSource = logTable;
        GvLog.DataBind();
        PnlLog.Visible = logTable.Rows.Count > 0;
    }

    // ===== 按鈕事件 =====

    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect(Me.AppendSid("Main.aspx"), true);
    }

    protected void BtnSaveDraft_Click(object sender, EventArgs e) { SaveApply(false); }
    protected void BtnSubmit_Click(object sender, EventArgs e)    { SaveApply(true);  }

    // ===== 儲存 / 送出申請 =====

    private void SaveApply(bool submitToWorkflow)
    {
        if (string.IsNullOrEmpty(RblIsRelated.SelectedValue))
        { ShowErrorAndRebind("\u8acb\u9078\u64c7\u662f\u5426\u5c6c\u5229\u5bb3\u95dc\u4fc2\u4eba\u3002"); return; }

        if ((TxtBranchNote.Text ?? "").Length > 3000)
        { ShowErrorAndRebind("\u7533\u8acb\u55ae\u4f4d\u8aaa\u660e\u8d85\u904e 3,000 \u5b57\u3002"); return; }

        var detailRows = ReadDetailFromForm();
        if (detailRows.Count == 0)
        { ShowErrorAndRebind("\u81f3\u5c11\u8981\u6709\u4e00\u7b46\u660e\u7d30\u3002"); return; }

        foreach (var detail in detailRows)
        {
            if (string.IsNullOrEmpty(detail.CustomerID))
            { ShowErrorAndRebind("\u6bcf\u7b46\u660e\u7d30\u7684\u7d71\u4e00\u7de8\u865f\u70ba\u5fc5\u586b\u9805\u76ee\u3002"); return; }

            if (string.IsNullOrEmpty(detail.DepositType))
            { ShowErrorAndRebind("\u660e\u7d30\u5217\u7684\u5b58\u6b3e\u7a2e\u985e\u70ba\u5fc5\u586b\u9805\u76ee\u3002"); return; }
        }

        DateTime applyDate;
        if (!DateTime.TryParse(TxtApplyDate.Text, out applyDate)) applyDate = DateTime.Today;

        // 申請總金額由明細列 Amount 加總，系統自動計算
        decimal totalAmount = 0m;
        foreach (var d in detailRows) totalAmount += d.Amount;

        decimal? contrib3M  = ParseNullableDecimal(TxtContrib3M.Text);
        decimal? contrib6M  = ParseNullableDecimal(TxtContrib6M.Text);
        decimal? contrib1Y  = ParseNullableDecimal(TxtContrib1Y.Text);
        decimal? related3M  = ParseNullableDecimal(TxtRelated3M.Text);
        decimal? related6M  = ParseNullableDecimal(TxtRelated6M.Text);
        decimal? relatedAmt = ParseNullableDecimal(TxtRelatedAmt.Text);

        string savedDocNo = DocNo;

        try
        {
            using (var conn = new SqlConnection(ConnStr))
            {
                conn.Open();
                using (var transaction = conn.BeginTransaction())
                {
                    bool isNew     = string.IsNullOrEmpty(savedDocNo);
                    int fromStatus = 0;
                    int toStatus   = submitToWorkflow ? 1 : 0;

                    if (isNew)
                    {
                        savedDocNo = GenerateDocNo(conn, transaction);
                        InsertMain(conn, transaction, savedDocNo, applyDate, totalAmount, toStatus,
                                   contrib3M, contrib6M, contrib1Y, related3M, related6M, relatedAmt);
                    }
                    else
                    {
                        fromStatus = ReadStatusForEdit(conn, transaction, savedDocNo);
                        UpdateMain(conn, transaction, savedDocNo, applyDate, totalAmount, toStatus,
                                   contrib3M, contrib6M, contrib1Y, related3M, related6M, relatedAmt);
                        DeleteDetailsForRewrite(conn, transaction, savedDocNo);
                    }

                    InsertDetailRows(conn, transaction, savedDocNo, detailRows);
                    InsertLog(conn, transaction, savedDocNo,
                              isNew ? "CREATE" : (submitToWorkflow ? "SUBMIT" : "EDIT"),
                              fromStatus, toStatus,
                              submitToWorkflow ? "\u9001\u51fa\u7533\u8acb" : "\u5b58\u8349\u7a3f");
                    transaction.Commit();
                }
            }
        }
        catch (InvalidOperationException ex)
        {
            ShowErrorAndRebind(ex.Message);
            return;
        }

        if (submitToWorkflow)
            Response.Redirect(Me.AppendSid("View.aspx?no=" + savedDocNo), true);
        else
            Response.Redirect(Me.AppendSid("Edit.aspx?no=" + savedDocNo + "&saved=1"), true);
    }

    // ===== 申請單號產生 =====

    private string GenerateDocNo(SqlConnection conn, SqlTransaction transaction)
    {
        string prefix = "NTD" + DateTime.Today.ToString("yyyyMMdd");
        using (var cmd = new SqlCommand(
            "SELECT ISNULL(MAX(CAST(SUBSTRING(DocNo, LEN(@Prefix)+1, 4) AS INT)), 0) " +
            "FROM dbo.NTD_Main WHERE DocNo LIKE @Prefix + '%'", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@Prefix", prefix);
            int nextSeq = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
            return prefix + nextSeq.ToString("D4");
        }
    }

    // ===== 主檔 INSERT / UPDATE =====

    private void InsertMain(SqlConnection conn, SqlTransaction transaction,
                            string applyNo, DateTime applyDate, decimal totalAmount, int initialStatus,
                            decimal? contrib3M, decimal? contrib6M, decimal? contrib1Y,
                            decimal? related3M, decimal? related6M, decimal? relatedAmt)
    {
        using (var cmd = new SqlCommand(@"
            INSERT INTO dbo.NTD_Main
                (DocNo, BranchCode, ApplyDate, GroupName,
                 TotalAmount, IsRelated,
                 Contrib3M, Contrib6M, Contrib1Y,
                 Related3M, Related6M, RelatedAmt,
                 BranchNote, Status, CreateUser, CreateTime)
            VALUES
                (@DocNo, @BranchCode, @ApplyDate, @GroupName,
                 @TotalAmount, @IsRelated,
                 @Contrib3M, @Contrib6M, @Contrib1Y,
                 @Related3M, @Related6M, @RelatedAmt,
                 @BranchNote, @Status, @CreateUser, GETDATE())", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@DocNo",     applyNo);
            cmd.Parameters.AddWithValue("@BranchCode",  Me.BranchCode);
            cmd.Parameters.AddWithValue("@ApplyDate",   applyDate);
            cmd.Parameters.AddWithValue("@GroupName",   (object)TxtGroupName.Text.Trim()   ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
            cmd.Parameters.AddWithValue("@IsRelated",   RblIsRelated.SelectedValue);
            cmd.Parameters.AddWithValue("@Contrib3M",   (object)contrib3M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib6M",   (object)contrib6M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib1Y",   (object)contrib1Y  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Related3M",   (object)related3M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Related6M",   (object)related6M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@RelatedAmt",  (object)relatedAmt ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@BranchNote",  TxtBranchNote.Text ?? "");
            cmd.Parameters.AddWithValue("@Status",      initialStatus);
            cmd.Parameters.AddWithValue("@CreateUser",  Me.EmpID);
            cmd.ExecuteNonQuery();
        }
    }

    private int ReadStatusForEdit(SqlConnection conn, SqlTransaction transaction, string applyNo)
    {
        using (var cmd = new SqlCommand(
            "SELECT Status, CreateUser FROM dbo.NTD_Main WHERE DocNo = @DocNo", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@DocNo", applyNo);
            using (var reader = cmd.ExecuteReader())
            {
                if (!reader.Read())
                    throw new InvalidOperationException("\u7533\u8acb\u55ae\u4e0d\u5b58\u5728\uff1a" + applyNo);

                int currentStatus = Convert.ToInt32(reader["Status"]);
                string createUser = Convert.ToString(reader["CreateUser"]);
                bool isMine = string.Equals(createUser, Me.EmpID, StringComparison.OrdinalIgnoreCase);
                if (currentStatus != 0 || !isMine)
                    throw new InvalidOperationException("\u6b64\u55ae\u76ee\u524d\u72c0\u614b\u7121\u6cd5\u7de8\u8f2f\u3002");

                return currentStatus;
            }
        }
    }

    private void UpdateMain(SqlConnection conn, SqlTransaction transaction,
                            string applyNo, DateTime applyDate, decimal totalAmount, int newStatus,
                            decimal? contrib3M, decimal? contrib6M, decimal? contrib1Y,
                            decimal? related3M, decimal? related6M, decimal? relatedAmt)
    {
        using (var cmd = new SqlCommand(@"
            UPDATE dbo.NTD_Main
            SET    ApplyDate   = @ApplyDate,
                   GroupName   = @GroupName,
                   TotalAmount = @TotalAmount,
                   IsRelated   = @IsRelated,
                   Contrib3M   = @Contrib3M,
                   Contrib6M   = @Contrib6M,
                   Contrib1Y   = @Contrib1Y,
                   Related3M   = @Related3M,
                   Related6M   = @Related6M,
                   RelatedAmt  = @RelatedAmt,
                   BranchNote  = @BranchNote,
                   Status      = @Status,
                   UpdateUser  = @UpdateUser,
                   UpdateTime  = GETDATE()
            WHERE  DocNo     = @DocNo", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@DocNo",     applyNo);
            cmd.Parameters.AddWithValue("@ApplyDate",   applyDate);
            cmd.Parameters.AddWithValue("@GroupName",   (object)TxtGroupName.Text.Trim()   ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
            cmd.Parameters.AddWithValue("@IsRelated",   RblIsRelated.SelectedValue);
            cmd.Parameters.AddWithValue("@Contrib3M",   (object)contrib3M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib6M",   (object)contrib6M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib1Y",   (object)contrib1Y  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Related3M",   (object)related3M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Related6M",   (object)related6M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@RelatedAmt",  (object)relatedAmt ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@BranchNote",  TxtBranchNote.Text ?? "");
            cmd.Parameters.AddWithValue("@Status",      newStatus);
            cmd.Parameters.AddWithValue("@UpdateUser",  Me.EmpID);
            cmd.ExecuteNonQuery();
        }
    }

    // ===== 明細 =====

    private void DeleteDetailsForRewrite(SqlConnection conn, SqlTransaction transaction, string applyNo)
    {
        using (var cmd = new SqlCommand(
            "DELETE FROM dbo.NTD_Detail WHERE DocNo = @DocNo", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@DocNo", applyNo);
            cmd.ExecuteNonQuery();
        }
    }

    private void InsertDetailRows(SqlConnection conn, SqlTransaction transaction,
                                  string applyNo, List<DetailRow> rows)
    {
        int seqNo = 1;
        foreach (var detail in rows)
        {
            using (var cmd = new SqlCommand(@"
                INSERT INTO dbo.NTD_Detail
                    (DocNo, SeqNo, CustomerID, CustomerName,
                     DepositType, PeriodMonth, Amount, ProposedRate,
                     StartDate, EndDate, NewAmount, RenewAmount, Memo)
                VALUES
                    (@DocNo, @SeqNo, @CustomerID, @CustomerName,
                     @DepositType, @PeriodMonth, @Amount, @ProposedRate,
                     @StartDate, @EndDate, @NewAmount, @RenewAmount, @Memo)", conn, transaction))
            {
                cmd.Parameters.AddWithValue("@DocNo",      applyNo);
                cmd.Parameters.AddWithValue("@SeqNo",        seqNo++);
                cmd.Parameters.AddWithValue("@CustomerID",   (object)detail.CustomerID   ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@CustomerName", (object)detail.CustomerName ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@DepositType",  (object)detail.DepositType  ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@PeriodMonth",  detail.PeriodMonth);
                cmd.Parameters.AddWithValue("@Amount",       detail.Amount);
                cmd.Parameters.AddWithValue("@ProposedRate", detail.ProposedRate);
                cmd.Parameters.AddWithValue("@StartDate",    (object)detail.StartDate    ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@EndDate",      (object)detail.EndDate      ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@NewAmount",    (object)detail.NewAmount    ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@RenewAmount",  (object)detail.RenewAmount  ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@Memo",         (object)detail.Memo         ?? DBNull.Value);
                cmd.ExecuteNonQuery();
            }
        }
    }

    // ===== 從前端表單讀取明細列 =====

    private List<DetailRow> ReadDetailFromForm()
    {
        var rows = new List<DetailRow>();
        for (int i = 0; i < 200; i++)
        {
            // 以 DepositType_N 的存在與否判斷是否有第 N 列
            string depositType = Request.Form["DepositType_" + i];
            if (depositType == null) break;

            rows.Add(new DetailRow
            {
                CustomerID   = (Request.Form["CustomerID_"   + i] ?? "").Trim(),
                CustomerName = (Request.Form["CustomerName_" + i] ?? "").Trim(),
                DepositType  = depositType.Trim(),
                Amount       = ParseDecimal(Request.Form["Amount_"      + i]),
                ProposedRate = ParseDecimal(Request.Form["Rate_"        + i]),
                PeriodMonth  = ParseInt(Request.Form["Period_"     + i]),
                NewAmount    = ParseNullableDecimal(Request.Form["NewAmount_"    + i]),
                RenewAmount  = ParseNullableDecimal(Request.Form["RenewAmount_" + i]),
                StartDate    = ParseNullableDate(Request.Form["StartDate_" + i]),
                EndDate      = ParseNullableDate(Request.Form["EndDate_"   + i]),
                Memo         = (Request.Form["Memo_" + i] ?? "").Trim()
            });
        }
        return rows;
    }

    /// <summary>驗證失敗時：顯示錯誤訊息並把表單明細從 POST 資料重繪。</summary>
    private void ShowErrorAndRebind(string message)
    {
        ShowMessage(message, "err");
        BindDetailRows(ReadDetailFromForm());
        if (!string.IsNullOrEmpty(DocNo)) LoadLog(DocNo);
    }

    /// <summary>將 DetailRow 清單轉成 DataTable 後繫結到 Repeater。</summary>
    private void BindDetailRows(List<DetailRow> rows)
    {
        var dt = new DataTable();
        dt.Columns.Add("CustomerID",   typeof(string));
        dt.Columns.Add("CustomerName", typeof(string));
        dt.Columns.Add("DepositType",  typeof(string));
        dt.Columns.Add("Amount",       typeof(decimal));
        dt.Columns.Add("ProposedRate", typeof(decimal));
        dt.Columns.Add("PeriodMonth",  typeof(int));
        dt.Columns.Add("StartDate",    typeof(DateTime));
        dt.Columns.Add("EndDate",      typeof(DateTime));
        dt.Columns.Add("NewAmount",    typeof(decimal));
        dt.Columns.Add("RenewAmount",  typeof(decimal));
        dt.Columns.Add("Memo",         typeof(string));

        foreach (var r in rows)
        {
            var dr = dt.NewRow();
            dr["CustomerID"]   = (object)r.CustomerID   ?? DBNull.Value;
            dr["CustomerName"] = (object)r.CustomerName ?? DBNull.Value;
            dr["DepositType"]  = (object)r.DepositType  ?? DBNull.Value;
            dr["Amount"]       = r.Amount;
            dr["ProposedRate"] = r.ProposedRate;
            dr["PeriodMonth"]  = r.PeriodMonth;
            dr["StartDate"]    = (object)r.StartDate    ?? DBNull.Value;
            dr["EndDate"]      = (object)r.EndDate      ?? DBNull.Value;
            dr["NewAmount"]    = (object)r.NewAmount    ?? DBNull.Value;
            dr["RenewAmount"]  = (object)r.RenewAmount  ?? DBNull.Value;
            dr["Memo"]         = (object)r.Memo         ?? DBNull.Value;
            dt.Rows.Add(dr);
        }
        RptDetail.DataSource = dt;
        RptDetail.DataBind();
    }

    // ===== 簽核紀錄 =====

    private void InsertLog(SqlConnection conn, SqlTransaction transaction,
                           string applyNo, string actionType,
                           int fromStatus, int toStatus, string comment)
    {
        using (var cmd = new SqlCommand(@"
            INSERT INTO dbo.NTD_Log
                (DocNo, ActionType, FromStatus, ToStatus,
                 ActionUser, ActionUserName, Comment)
            VALUES
                (@DocNo, @ActionType, @FromStatus, @ToStatus,
                 @ActionUser, @ActionUserName, @Comment)", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@DocNo",        applyNo);
            cmd.Parameters.AddWithValue("@ActionType",     actionType);
            cmd.Parameters.AddWithValue("@FromStatus",     fromStatus);
            cmd.Parameters.AddWithValue("@ToStatus",       toStatus);
            cmd.Parameters.AddWithValue("@ActionUser",     Me.EmpID);
            cmd.Parameters.AddWithValue("@ActionUserName", Me.EmpName);
            cmd.Parameters.AddWithValue("@Comment",        comment ?? "");
            cmd.ExecuteNonQuery();
        }
    }

    // ===== UI 訊息 =====

    private void ShowMessage(string text, string level)
    {
        LblMessage.Visible  = true;
        LblMessage.CssClass = "alert alert-" + level;
        LblMessage.Text     = Server.HtmlEncode(text);
    }

    // ===== 資料存取 helper =====

    private static string ConnStr
    {
        get { return ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString; }
    }

    private static DataTable Query(string sql, params SqlParameter[] parameters)
    {
        using (var conn = new SqlConnection(ConnStr))
        using (var cmd  = new SqlCommand(sql, conn))
        {
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            using (var adapter = new SqlDataAdapter(cmd))
            {
                var table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }
    }

    private static SqlParameter P(string name, object value)
    {
        return new SqlParameter(name, value ?? DBNull.Value);
    }

    // ===== 流程狀態 / 動作類型 顯示 =====

    protected static string StatusName(int status)
    {
        switch (status)
        {
            case 0: return "\u8349\u7a3f/\u9000\u56de";
            case 1: return "\u5f85\u8956\u7406\u653e\u884c";
            case 2: return "\u5f85\u7d93\u7406\u653e\u884c";
            case 4: return "\u5f85\u7e3d\u884c\u7d93\u8fa6\u5be9\u6838";
            case 6: return "\u5f85\u7e3d\u884c\u79d1\u9577\u6c7a\u884c";
            case 9: return "\u7d50\u6848";
            default: return "\u672a\u77e5\u72c0\u614b";
        }
    }

    protected static string ActionTypeName(string actionType)
    {
        switch ((actionType ?? "").ToUpper())
        {
            case "CREATE":  return "\u5efa\u7acb";
            case "EDIT":    return "\u4fee\u6539";
            case "SUBMIT":  return "\u9001\u51fa";
            case "APPROVE": return "\u653e\u884c";
            case "DECIDE":  return "\u6c7a\u884c";
            case "REJECT":  return "\u9000\u56de";
            default: return actionType ?? "";
        }
    }

    // ===== 型別轉換 helper =====

    private static decimal ParseDecimal(string s)
    {
        decimal v;
        return decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out v) ? v : 0m;
    }

    private static int ParseInt(string s)
    {
        int v;
        return int.TryParse(s, out v) ? v : 0;
    }

    private static decimal? ParseNullableDecimal(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        decimal v;
        return decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out v)
            ? (decimal?)v : null;
    }

    private static DateTime? ParseNullableDate(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        DateTime v;
        return DateTime.TryParse(s, out v) ? (DateTime?)v : null;
    }
}

// ===== 明細列資料物件 =====

/// <summary>Edit 頁前端明細列的資料承載物件，對應 dbo.NTD_Detail 各欄位。</summary>
public class DetailRow
{
    public string    CustomerID   { get; set; }
    public string    CustomerName { get; set; }
    public string    DepositType  { get; set; }
    public decimal   Amount       { get; set; }
    public decimal   ProposedRate { get; set; }
    public int       PeriodMonth  { get; set; }
    public DateTime? StartDate    { get; set; }
    public DateTime? EndDate      { get; set; }
    public decimal?  NewAmount    { get; set; }
    public decimal?  RenewAmount  { get; set; }
    public string    Memo         { get; set; }
}
