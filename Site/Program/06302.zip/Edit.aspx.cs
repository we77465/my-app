﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Web.UI;

/// <summary>
/// 新臺幣定期存款專案利率申請 - 新增/編輯申請單。
/// 僅「經辦」或「襄理」可進入（§2 權限設定：填報角色 = 經辦 + 襄理）；
/// 申請單在 Status = 0 (草稿/退回) 時才可修改。
/// </summary>
public partial class NtdEdit : Page
{
    protected NtdCurrentUser Me { get { return NtdCurrentUser.Current; } }

    /// <summary>URL 上的申請單號 (?no=)，空字串代表新增。</summary>
    private string ApplyNo { get { return Request.QueryString["no"]; } }

    protected void Page_Load(object sender, EventArgs e)
    {
        LblUser.Text = string.Format("{0} {1} ({2} {3}) [職等 {4}]",
            Me.EmpID, Me.EmpName, Me.BranchCode, Me.BranchName, Me.TitleLevel);

        // 在 code-behind 設定 RadioButtonList 選項，避免 .aspx 中文屬性值的編碼問題
        if (!IsPostBack)
        {
            RblIsRelated.Items.Clear();
            RblIsRelated.Items.Add(new System.Web.UI.WebControls.ListItem("\u662f", "Y"));  // 是
            RblIsRelated.Items.Add(new System.Web.UI.WebControls.ListItem("\u5426", "N"));  // 否
        }

        // §2 權限設定：填報角色 = 經辦 (TitleLevel=1) + 襄理 (TitleLevel=2)
        if (!Me.CanCreateApply)
        {
            ShowMessage("您的職位無法新增/編輯申請，僅經辦或襄理可操作。", "err");
            DisableForm();
            return;
        }

        if (IsPostBack) return;

        TxtApplyDate.Text = DateTime.Today.ToString("yyyy-MM-dd");
        LblBranch.Text    = Me.BranchCode + " " + Me.BranchName;
        LblStatus.Text    = StatusName(0);

        if (string.IsNullOrEmpty(ApplyNo))
        {
            // 新增：預設帶一筆空白明細，期間預設 12 個月
            RptDetail.DataSource = new List<DetailRow>
            {
                new DetailRow { PeriodMonth = 12 }
            };
            RptDetail.DataBind();
        }
        else
        {
            LoadExistingApply(ApplyNo);
        }
    }

    protected string NavUrl(string relativeUrl) { return Me.AppendSid(relativeUrl); }

    // ===== 統編查詢客戶名稱 (UpdatePanel 局部更新) =====

    protected void BtnQueryCustomer_Click(object sender, EventArgs e)
    {
        LblQueryMsg.Text = "";
        string customerID = TxtCustomerID.Text.Trim();

        if (string.IsNullOrEmpty(customerID))
        {
            LblQueryMsg.Text = "請先輸入統一編號";
            return;
        }
        if (customerID.Length < 8 || customerID.Length > 11)
        {
            LblQueryMsg.Text = "統一編號格式錯誤（8-11碼）";
            return;
        }

        try
        {
            // 透過公司 EAI F0101 電文查詢客戶名稱（RiskUtils.GetF0101Rs 位於 App_Code/RiskUpdateWise.cs）
            F0101 result = RiskUtils.GetF0101Rs("System", customerID, "NTD",
                Me.BranchCode.Length >= 4 ? Me.BranchCode.Substring(0, 4) : Me.BranchCode);

            if (result.isSuccess && !string.IsNullOrEmpty(result.CNAME))
            {
                TxtCustomerName.Text = result.CNAME;
            }
            else
            {
                TxtCustomerName.Text = "";
                LblQueryMsg.Text = "查無此統一編號對應的客戶資料";
            }
        }
        catch (Exception ex)
        {
            LblQueryMsg.Text = "查詢失敗：" + ex.Message;
        }
    }

    // ===== 載入既有申請單 =====

    private void LoadExistingApply(string applyNo)
    {
        // 同時撈分行名稱（對應 chb_pub.dbo.BRANCH.BRNO = NTD_Main.BranchCode）
        var mainTable = Query(@"
            SELECT  ntd.*, ISNULL(branch.BRNAME, '') AS BranchName
            FROM    dbo.NTD_Main    ntd
            LEFT JOIN chb_pub.dbo.BRANCH branch ON branch.BRNO = ntd.BranchCode
            WHERE   ntd.ApplyNo = @ApplyNo",
            P("@ApplyNo", applyNo));

        if (mainTable.Rows.Count == 0)
        {
            ShowMessage("找不到申請單：" + applyNo, "err");
            DisableForm();
            return;
        }

        var row           = mainTable.Rows[0];
        int currentStatus = Convert.ToInt32(row["Status"]);

        LitTitle.Text         = "編輯申請";
        LblApplyNo.Text       = applyNo;
        LblBranch.Text        = row["BranchCode"] + " " + row["BranchName"];
        TxtApplyDate.Text     = Convert.ToDateTime(row["ApplyDate"]).ToString("yyyy-MM-dd");
        TxtGroupName.Text     = Convert.ToString(row["GroupName"]);
        TxtCustomerID.Text    = Convert.ToString(row["CustomerID"]);
        TxtCustomerName.Text  = Convert.ToString(row["CustomerName"]);
        TxtTotalAmount.Text   = (row["TotalAmount"] == DBNull.Value)
            ? "" : Convert.ToDecimal(row["TotalAmount"]).ToString("0.##");
        TxtReason.Text        = Convert.ToString(row["Reason"]);
        TxtBranchNote.Text    = Convert.ToString(row["BranchNote"]);
        LblStatus.Text        = StatusName(currentStatus);

        if (row["IsRelated"] != DBNull.Value)
            RblIsRelated.SelectedValue = Convert.ToString(row["IsRelated"]);

        if (row["Contrib3M"]  != DBNull.Value) TxtContrib3M.Text  = Convert.ToDecimal(row["Contrib3M"]).ToString("0.##");
        if (row["Contrib6M"]  != DBNull.Value) TxtContrib6M.Text  = Convert.ToDecimal(row["Contrib6M"]).ToString("0.##");
        if (row["Contrib1Y"]  != DBNull.Value) TxtContrib1Y.Text  = Convert.ToDecimal(row["Contrib1Y"]).ToString("0.##");
        if (row["RelatedAmt"] != DBNull.Value) TxtRelatedAmt.Text = Convert.ToDecimal(row["RelatedAmt"]).ToString("0.##");

        // 只有自己建的、Status=0 的單才可編輯
        bool isEditableNow = currentStatus == 0
            && string.Equals(Convert.ToString(row["CreateUser"]), Me.EmpID,
                             StringComparison.OrdinalIgnoreCase);

        if (!isEditableNow)
        {
            ShowMessage("此申請單目前狀態無法編輯。", "warn");
            DisableForm();
        }

        // 載入明細
        var detailTable = Query(
            "SELECT * FROM dbo.NTD_Detail WHERE ApplyNo = @ApplyNo ORDER BY SeqNo",
            P("@ApplyNo", applyNo));
        RptDetail.DataSource = detailTable;
        RptDetail.DataBind();

        // 載入簽核紀錄
        var logTable = Query(
            "SELECT * FROM dbo.NTD_Log WHERE ApplyNo = @ApplyNo ORDER BY LogID DESC",
            P("@ApplyNo", applyNo));
        GvLog.DataSource = logTable;
        GvLog.DataBind();
        PnlLog.Visible = logTable.Rows.Count > 0;
    }

    /// <summary>鎖定所有輸入欄位，隱藏操作按鈕（唯讀模式）。</summary>
    private void DisableForm()
    {
        TxtGroupName.Enabled    = false;
        TxtCustomerID.Enabled   = false;
        TxtCustomerName.Enabled = false;
        BtnQueryCustomer.Enabled= false;
        TxtTotalAmount.Enabled  = false;
        TxtReason.Enabled       = false;
        TxtBranchNote.Enabled   = false;
        TxtApplyDate.Enabled    = false;
        TxtContrib3M.Enabled    = false;
        TxtContrib6M.Enabled    = false;
        TxtContrib1Y.Enabled    = false;
        TxtRelatedAmt.Enabled   = false;
        RblIsRelated.Enabled    = false;
        BtnSaveDraft.Visible    = false;
        BtnSubmit.Visible       = false;
    }

    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect(Me.AppendSid("Main.aspx"), true);
    }

    protected void BtnSaveDraft_Click(object sender, EventArgs e) { SaveApply(false); }
    protected void BtnSubmit_Click(object sender, EventArgs e)    { SaveApply(true);  }

    // ===== 儲存 / 送出申請 =====

    private void SaveApply(bool submitToWorkflow)
    {
        // --- 必填驗證 ---
        if (string.IsNullOrWhiteSpace(TxtCustomerID.Text))
        { ShowMessage("請填寫客戶統編/身分證。", "err"); return; }

        if (string.IsNullOrWhiteSpace(TxtCustomerName.Text))
        { ShowMessage("請先點「查詢客戶」帶入客戶名稱。", "err"); return; }

        if (string.IsNullOrEmpty(RblIsRelated.SelectedValue))
        { ShowMessage("請選擇是否屬利害關係人。", "err"); return; }

        decimal totalAmount;
        if (!decimal.TryParse(TxtTotalAmount.Text, out totalAmount) || totalAmount < 0)
        { ShowMessage("申請總金額格式錯誤。", "err"); return; }

        // 申請理由與申請單位說明各限 3,000 字（含標點符號，對應規格 §3）
        if ((TxtReason.Text ?? "").Length > 3000)
        { ShowMessage("申請理由超過 3,000 字。", "err"); return; }

        if ((TxtBranchNote.Text ?? "").Length > 3000)
        { ShowMessage("申請單位說明超過 3,000 字。", "err"); return; }

        var detailRows = ReadDetailFromForm();
        if (detailRows.Count == 0)
        { ShowMessage("至少要有一筆明細。", "err"); return; }

        foreach (var detail in detailRows)
        {
            if (string.IsNullOrEmpty(detail.DepositType))
            { ShowMessage("明細列的存款種類為必填項目。", "err"); return; }
        }

        DateTime applyDate;
        if (!DateTime.TryParse(TxtApplyDate.Text, out applyDate)) applyDate = DateTime.Today;

        decimal? contrib3M  = ParseNullableDecimal(TxtContrib3M.Text);
        decimal? contrib6M  = ParseNullableDecimal(TxtContrib6M.Text);
        decimal? contrib1Y  = ParseNullableDecimal(TxtContrib1Y.Text);
        decimal? relatedAmt = ParseNullableDecimal(TxtRelatedAmt.Text);

        string savedApplyNo = ApplyNo;
        using (var conn = new SqlConnection(ConnStr))
        {
            conn.Open();
            using (var transaction = conn.BeginTransaction())
            {
                bool isNew      = string.IsNullOrEmpty(savedApplyNo);
                int  fromStatus = 0;
                int  toStatus   = submitToWorkflow ? 1 : 0;  // 送出 → status=1（待襄理放行）

                if (isNew)
                {
                    savedApplyNo = GenerateApplyNo(conn, transaction);
                    InsertMain(conn, transaction, savedApplyNo, applyDate, totalAmount, toStatus,
                               contrib3M, contrib6M, contrib1Y, relatedAmt);
                }
                else
                {
                    fromStatus = ReadStatusForEdit(conn, transaction, savedApplyNo);
                    UpdateMain(conn, transaction, savedApplyNo, applyDate, totalAmount, toStatus,
                               contrib3M, contrib6M, contrib1Y, relatedAmt);
                    // 全刪再重插，確保明細順序與數量正確
                    DeleteDetailsForRewrite(conn, transaction, savedApplyNo);
                }

                InsertDetailRows(conn, transaction, savedApplyNo, detailRows);
                InsertLog(conn, transaction, savedApplyNo,
                          isNew ? "CREATE" : (submitToWorkflow ? "SUBMIT" : "EDIT"),
                          fromStatus, toStatus,
                          submitToWorkflow ? "送出申請" : "存草稿");

                transaction.Commit();
            }
        }
        // 儲存後跳回唯讀檢視頁
        Response.Redirect(Me.AppendSid("View.aspx?no=" + savedApplyNo), true);
    }

    // ===== 產生申請單號 =====

    /// <summary>
    /// 依日期產生流水號：NTDyyyyMMdd + 4位序號（同日最大值+1）。
    /// 例：NTD202506300001。
    /// </summary>
    private static string GenerateApplyNo(SqlConnection conn, SqlTransaction transaction)
    {
        string prefix = "NTD" + DateTime.Now.ToString("yyyyMMdd");
        using (var cmd = new SqlCommand(@"
            SELECT ISNULL(MAX(CAST(RIGHT(ApplyNo, 4) AS INT)), 0) + 1
            FROM   dbo.NTD_Main
            WHERE  ApplyNo LIKE @Prefix + '%'", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@Prefix", prefix);
            int nextSeq = Convert.ToInt32(cmd.ExecuteScalar());
            return prefix + nextSeq.ToString("D4");
        }
    }

    // ===== 主檔 INSERT / UPDATE =====

    private void InsertMain(SqlConnection conn, SqlTransaction transaction,
                            string applyNo, DateTime applyDate, decimal totalAmount, int initialStatus,
                            decimal? contrib3M, decimal? contrib6M, decimal? contrib1Y, decimal? relatedAmt)
    {
        using (var cmd = new SqlCommand(@"
            INSERT INTO dbo.NTD_Main
                (ApplyNo, BranchCode, ApplyDate, CustomerName, CustomerID, GroupName,
                 TotalAmount, Reason, IsRelated,
                 Contrib3M, Contrib6M, Contrib1Y, RelatedAmt, BranchNote,
                 Status, CreateUser, CreateTime)
            VALUES
                (@ApplyNo, @BranchCode, @ApplyDate, @CustomerName, @CustomerID, @GroupName,
                 @TotalAmount, @Reason, @IsRelated,
                 @Contrib3M, @Contrib6M, @Contrib1Y, @RelatedAmt, @BranchNote,
                 @Status, @CreateUser, GETDATE())", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@ApplyNo",      applyNo);
            cmd.Parameters.AddWithValue("@BranchCode",   Me.BranchCode);
            cmd.Parameters.AddWithValue("@ApplyDate",    applyDate);
            cmd.Parameters.AddWithValue("@CustomerName", TxtCustomerName.Text.Trim());
            cmd.Parameters.AddWithValue("@CustomerID",   (object)TxtCustomerID.Text.Trim()  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@GroupName",    (object)TxtGroupName.Text.Trim()   ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@TotalAmount",  totalAmount);
            cmd.Parameters.AddWithValue("@Reason",       TxtReason.Text ?? "");
            cmd.Parameters.AddWithValue("@IsRelated",    RblIsRelated.SelectedValue);
            cmd.Parameters.AddWithValue("@Contrib3M",    (object)contrib3M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib6M",    (object)contrib6M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib1Y",    (object)contrib1Y  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@RelatedAmt",   (object)relatedAmt ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@BranchNote",   TxtBranchNote.Text ?? "");
            cmd.Parameters.AddWithValue("@Status",       initialStatus);
            cmd.Parameters.AddWithValue("@CreateUser",   Me.EmpID);
            cmd.ExecuteNonQuery();
        }
    }

    /// <summary>
    /// 讀取既有申請單的 Status，同時驗證「是否可編輯」（必須是自己建的且 Status=0）。
    /// </summary>
    private int ReadStatusForEdit(SqlConnection conn, SqlTransaction transaction, string applyNo)
    {
        using (var cmd = new SqlCommand(
            "SELECT Status, CreateUser FROM dbo.NTD_Main WHERE ApplyNo = @ApplyNo", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@ApplyNo", applyNo);
            using (var reader = cmd.ExecuteReader())
            {
                if (!reader.Read())
                    throw new InvalidOperationException("申請單不存在：" + applyNo);

                int    currentStatus = Convert.ToInt32(reader["Status"]);
                string createUser    = Convert.ToString(reader["CreateUser"]);
                bool   isMine        = string.Equals(createUser, Me.EmpID, StringComparison.OrdinalIgnoreCase);
                if (currentStatus != 0 || !isMine)
                    throw new InvalidOperationException("此單目前狀態無法編輯。");

                return currentStatus;
            }
        }
    }

    private void UpdateMain(SqlConnection conn, SqlTransaction transaction,
                            string applyNo, DateTime applyDate, decimal totalAmount, int newStatus,
                            decimal? contrib3M, decimal? contrib6M, decimal? contrib1Y, decimal? relatedAmt)
    {
        using (var cmd = new SqlCommand(@"
            UPDATE dbo.NTD_Main
            SET    ApplyDate    = @ApplyDate,
                   CustomerName = @CustomerName,
                   CustomerID   = @CustomerID,
                   GroupName    = @GroupName,
                   TotalAmount  = @TotalAmount,
                   Reason       = @Reason,
                   IsRelated    = @IsRelated,
                   Contrib3M    = @Contrib3M,
                   Contrib6M    = @Contrib6M,
                   Contrib1Y    = @Contrib1Y,
                   RelatedAmt   = @RelatedAmt,
                   BranchNote   = @BranchNote,
                   Status       = @Status,
                   UpdateUser   = @UpdateUser,
                   UpdateTime   = GETDATE()
            WHERE  ApplyNo      = @ApplyNo", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@ApplyNo",      applyNo);
            cmd.Parameters.AddWithValue("@ApplyDate",    applyDate);
            cmd.Parameters.AddWithValue("@CustomerName", TxtCustomerName.Text.Trim());
            cmd.Parameters.AddWithValue("@CustomerID",   (object)TxtCustomerID.Text.Trim()  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@GroupName",    (object)TxtGroupName.Text.Trim()   ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@TotalAmount",  totalAmount);
            cmd.Parameters.AddWithValue("@Reason",       TxtReason.Text ?? "");
            cmd.Parameters.AddWithValue("@IsRelated",    RblIsRelated.SelectedValue);
            cmd.Parameters.AddWithValue("@Contrib3M",    (object)contrib3M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib6M",    (object)contrib6M  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Contrib1Y",    (object)contrib1Y  ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@RelatedAmt",   (object)relatedAmt ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@BranchNote",   TxtBranchNote.Text ?? "");
            cmd.Parameters.AddWithValue("@Status",       newStatus);
            cmd.Parameters.AddWithValue("@UpdateUser",   Me.EmpID);
            cmd.ExecuteNonQuery();
        }
    }

    // ===== 明細 =====

    private void DeleteDetailsForRewrite(SqlConnection conn, SqlTransaction transaction, string applyNo)
    {
        using (var cmd = new SqlCommand(
            "DELETE FROM dbo.NTD_Detail WHERE ApplyNo = @ApplyNo", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@ApplyNo", applyNo);
            cmd.ExecuteNonQuery();
        }
    }

    private void InsertDetailRows(SqlConnection conn, SqlTransaction transaction,
                                  string applyNo, List<DetailRow> rows)
    {
        int seqNo = 1;
        foreach (var detail in rows)
        {
            using (var cmd = new SqlCommand(@"
                INSERT INTO dbo.NTD_Detail
                    (ApplyNo, SeqNo, DepositType, PeriodMonth, Amount, ProposedRate,
                     StartDate, EndDate, NewAmount, RenewAmount, Memo)
                VALUES
                    (@ApplyNo, @SeqNo, @DepositType, @PeriodMonth, @Amount, @ProposedRate,
                     @StartDate, @EndDate, @NewAmount, @RenewAmount, @Memo)", conn, transaction))
            {
                cmd.Parameters.AddWithValue("@ApplyNo",      applyNo);
                cmd.Parameters.AddWithValue("@SeqNo",        seqNo++);
                cmd.Parameters.AddWithValue("@DepositType",  (object)detail.DepositType  ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@PeriodMonth",  detail.PeriodMonth);
                cmd.Parameters.AddWithValue("@Amount",       detail.Amount);
                cmd.Parameters.AddWithValue("@ProposedRate", detail.ProposedRate);
                cmd.Parameters.AddWithValue("@StartDate",    (object)detail.StartDate    ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@EndDate",      (object)detail.EndDate      ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@NewAmount",    (object)detail.NewAmount    ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@RenewAmount",  (object)detail.RenewAmount  ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@Memo",         (object)detail.Memo         ?? DBNull.Value);
                cmd.ExecuteNonQuery();
            }
        }
    }

    // ===== 從前端表單讀取明細列 =====

    /// <summary>
    /// 從 Request.Form 讀取前端 JS 動態產生的明細列。
    /// 欄位命名規則：{FieldName}_{index}（index 從 0 開始）。
    /// 例：DepositType_0、Amount_0、Rate_0……
    /// 連續找不到 DepositType_{index} 時即停止。
    /// </summary>
    private List<DetailRow> ReadDetailFromForm()
    {
        var rows = new List<DetailRow>();
        for (int i = 0; i < 100; i++)   // 最多 100 筆，防止惡意輸入
        {
            string depositType = Request.Form["DepositType_" + i];
            if (depositType == null) break;  // 找不到此 index → 沒有更多列

            // Amount / Rate / Period 允許空白（儲存為 0）
            decimal amount      = ParseDecimal(Request.Form["Amount_"      + i]);
            decimal rate        = ParseDecimal(Request.Form["Rate_"        + i]);
            int     period      = ParseInt    (Request.Form["Period_"      + i]);
            decimal? newAmount  = ParseNullableDecimal(Request.Form["NewAmount_"   + i]);
            decimal? renewAmt   = ParseNullableDecimal(Request.Form["RenewAmount_" + i]);
            DateTime? startDate = ParseNullableDate(Request.Form["StartDate_"  + i]);
            DateTime? endDate   = ParseNullableDate(Request.Form["EndDate_"    + i]);
            string   memo       = (Request.Form["Memo_" + i] ?? "").Trim();

            rows.Add(new DetailRow
            {
                DepositType  = depositType.Trim(),
                Amount       = amount,
                ProposedRate = rate,
                PeriodMonth  = period,
                StartDate    = startDate,
                EndDate      = endDate,
                NewAmount    = newAmount,
                RenewAmount  = renewAmt,
                Memo         = memo
            });
        }
        return rows;
    }

    // ===== 寫入簽核紀錄 =====

    /// <summary>
    /// 寫入一筆簽核/操作紀錄到 dbo.NTD_Log。
    /// actionType 慣例：CREATE / EDIT / SUBMIT / APPROVE / DECIDE / REJECT。
    /// </summary>
    private void InsertLog(SqlConnection conn, SqlTransaction transaction,
                           string applyNo, string actionType,
                           int fromStatus, int toStatus, string comment)
    {
        using (var cmd = new SqlCommand(@"
            INSERT INTO dbo.NTD_Log
                (ApplyNo, ActionType, FromStatus, ToStatus,
                 ActionUser, ActionUserName, Comment)
            VALUES
                (@ApplyNo, @ActionType, @FromStatus, @ToStatus,
                 @ActionUser, @ActionUserName, @Comment)", conn, transaction))
        {
            cmd.Parameters.AddWithValue("@ApplyNo",        applyNo);
            cmd.Parameters.AddWithValue("@ActionType",     actionType);
            cmd.Parameters.AddWithValue("@FromStatus",     fromStatus);
            cmd.Parameters.AddWithValue("@ToStatus",       toStatus);
            cmd.Parameters.AddWithValue("@ActionUser",     Me.EmpID);
            cmd.Parameters.AddWithValue("@ActionUserName", Me.EmpName);
            cmd.Parameters.AddWithValue("@Comment",        comment ?? "");
            cmd.ExecuteNonQuery();
        }
    }

    // ===== UI 訊息 =====

    private void ShowMessage(string text, string level)
    {
        LblMessage.Visible  = true;
        LblMessage.CssClass = "alert alert-" + level;
        LblMessage.Text     = Server.HtmlEncode(text);
    }

    // ===== 資料存取 helper =====

    /// <summary>chb_iom 連線字串（Web.config connectionStrings["chb_iom"]）。</summary>
    private static string ConnStr
    {
        get { return ConfigurationManager.ConnectionStrings["chb_iom"].ConnectionString; }
    }

    /// <summary>執行 SELECT，回傳 DataTable。</summary>
    private static DataTable Query(string sql, params SqlParameter[] parameters)
    {
        using (var conn = new SqlConnection(ConnStr))
        using (var cmd  = new SqlCommand(sql, conn))
        {
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            using (var adapter = new SqlDataAdapter(cmd))
            {
                var table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }
    }

    /// <summary>建立 SqlParameter；null 自動轉 DBNull。</summary>
    private static SqlParameter P(string name, object value)
    {
        return new SqlParameter(name, value ?? DBNull.Value);
    }

    /// <summary>簽核流程狀態代碼 → 中文名稱（對應需求確認書 §1 簽核流程）。</summary>
    protected static string StatusName(int status)
    {
        switch (status)
        {
            case 0: return "草稿/退回";
            case 1: return "待襄理放行";
            case 2: return "待經理放行";
            case 4: return "待總行經辦審核";
            case 6: return "待總行科長決行";
            case 9: return "結案";
            default: return "未知狀態";
        }
    }

    // ===== 型別轉換 helper =====

    /// <summary>字串轉 decimal，失敗回傳 0。</summary>
    private static decimal ParseDecimal(string s)
    {
        decimal v;
        return decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out v) ? v : 0m;
    }

    /// <summary>字串轉 int，失敗回傳 0。</summary>
    private static int ParseInt(string s)
    {
        int v;
        return int.TryParse(s, out v) ? v : 0;
    }

    /// <summary>字串轉可空 decimal；空白或格式錯誤回傳 null。</summary>
    private static decimal? ParseNullableDecimal(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        decimal v;
        return decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out v)
            ? (decimal?)v : null;
    }

    /// <summary>字串轉可空 DateTime；空白或格式錯誤回傳 null。</summary>
    private static DateTime? ParseNullableDate(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        DateTime v;
        return DateTime.TryParse(s, out v) ? (DateTime?)v : null;
    }
}

// ===== 明細列資料物件 =====

/// <summary>
/// Edit 頁前端明細列的資料承載物件。
/// 對應 dbo.NTD_Detail 的各欄位。
/// </summary>
public class DetailRow
{
    public string    DepositType  { get; set; }   // 存款種類（定期存款 / 定期儲蓄存款）
    public decimal   Amount       { get; set; }   // 金額（億元）
    public decimal   ProposedRate { get; set; }   // 利率（%）
    public int       PeriodMonth  { get; set; }   // 期間（月）
    public DateTime? StartDate    { get; set; }   // 起存日
    public DateTime? EndDate      { get; set; }   // 到期日
    public decimal?  NewAmount    { get; set; }   // 新作（億元）
    public decimal?  RenewAmount  { get; set; }   // 續作（億元）
    public string    Memo         { get; set; }   // 備注
}
